<?php
/**
 * ILoveYouBD Professional AI Publishing System - Phase 2 Core Engine
 * Fully modular implementation for high-quality semantic SEO automation, Advanced Schema,
 * EEAT Layer, Quality Scoring, Similarity, Content Refresh, and Engagement Blocks.
 *
 * @package ILYBD_Neon
 * @version 2.0.0
 */

if (!defined('ABSPATH')) exit;

class ILYBD_AI_Publishing_Engine_V2 {

    /**
     * Singleton instance
     */
    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // Initialize hooks or configurations if needed
    }

    /**
     * MODULE 1: AI Content Quality Scoring Engine
     * Calculates a complete score based on SEO and user value rules.
     */
    public function calculate_quality_score($title, $content, $tags = [], $category_id = 0) {
        $factors = [];
        $total_score = 0;

        // Fix undefined mb_str_word_count using preg_split
        $clean_content = wp_strip_all_tags($content);
        $words = preg_split('~[^\p{L}\p{N}\']+~u', $clean_content, -1, PREG_SPLIT_NO_EMPTY);
        $word_count = is_array($words) ? count($words) : (mb_strlen($clean_content) / 5);
        if ($word_count >= 1500) {
            $factors['word_count'] = 20; // Maximum score for top depth
        } elseif ($word_count >= 1000) {
            $factors['word_count'] = 15;
        } elseif ($word_count >= 500) {
            $factors['word_count'] = 10;
        } else {
            $factors['word_count'] = 3; // Demote short content
        }

        // Readability / Subheading Structure
        $h2_count = substr_count(strtolower($content), '<h2>') + substr_count(strtolower($content), '<h2 ');
        $h3_count = substr_count(strtolower($content), '<h3>') + substr_count(strtolower($content), '<h3 ');
        if ($h2_count >= 3 && $h3_count >= 2) {
            $factors['headings'] = 15;
        } elseif ($h2_count >= 1) {
            $factors['headings'] = 10;
        } else {
            $factors['headings'] = 2; // Demote plain stream of text
        }

        // Internal Links (using standard links format)
        $link_count = substr_count(strtolower($content), '<a ') + substr_count(strtolower($content), 'ilybd-inline-recommendation');
        if ($link_count >= 3) {
            $factors['internal_links'] = 10;
        } elseif ($link_count >= 1) {
            $factors['internal_links'] = 6;
        } else {
            $factors['internal_links'] = 0;
        }

        // External Authority Links
        $authority_domains = ['wikipedia.org', 'google.com', 'w3.org', 'wordpress.org', 'github.com', 'microsoft.com', 'php.net', 'stackoverflow.com', 'techcrunch.com'];
        $has_authority = 0;
        foreach ($authority_domains as $dom) {
            if (strpos($content, $dom) !== false) {
                $has_authority = 10;
                break;
            }
        }
        $factors['authority_links'] = $has_authority;

        // FAQ Presence
        $has_faq = (strpos($content, 'faq') !== false || strpos($content, 'frequently asked') !== false || strpos($content, 'প্রশ্নোত্তর') !== false || strpos($content, 'প্রশ্নাবলী') !== false) ? 10 : 0;
        $factors['faq_count'] = $has_faq;

        // Images Count
        $placeholder_imgs = substr_count($content, '[INLINE_IMAGE') + substr_count($content, 'ily-inline-image') + substr_count($content, '<img ');
        if ($placeholder_imgs >= 3) {
            $factors['image_count'] = 10;
        } elseif ($placeholder_imgs >= 1) {
            $factors['image_count'] = 6;
        } else {
            $factors['image_count'] = 0;
        }

        // Tables Presence (engagement helper)
        $has_tables = (strpos($content, '<table') !== false) ? 10 : 0;
        $factors['tables'] = $has_tables;

        // Uniqueness & Keyword coverage check
        $has_keywords = 0;
        if (!empty($tags)) {
            foreach ($tags as $tag) {
                if (mb_strpos(mb_strtolower($content), mb_strtolower($tag)) !== false) {
                    $has_keywords += 3;
                }
            }
        }
        $factors['keyword_coverage'] = min(10, $has_keywords ? $has_keywords : 5);

        // Spam Detection / AI Slop Demotions (e.g. "In summary", "Crucial", "Essentially", "Additionally")
        $ai_markers = ['in conclusion', 'it is important to note', 'firstly', 'secondly', 'furthermore', 'moreover', 'tapestry of', 'not only', 'as mentioned earlier'];
        $spam_penalty = 0;
        foreach ($ai_markers as $marker) {
            if (strpos(strtolower($content), $marker) !== false) {
                $spam_penalty += 3;
            }
        }
        $factors['spam_detection'] = max(0, 15 - $spam_penalty);

        // Sum overall score
        foreach ($factors as $pts) {
            $total_score += $pts;
        }

        // Limit range strictly
        $total_score = min(100, max(0, $total_score));

        // Scoring Resolution Rule:
        // 90-100 = Auto Publish
        // 80-89 = Review Queue
        // Below 80 = Reject / Draft
        $decision = 'publish';
        if ($total_score >= 90) {
            $decision = 'publish';
        } elseif ($total_score >= 80) {
            $decision = 'review_queue';
        } else {
            $decision = 'draft'; // reject auto-publish, regenerate or hold
        }

        return [
            'score' => $total_score,
            'breakdown' => $factors,
            'decision' => $decision,
            'word_count' => $word_count
        ];
    }

    /**
     * MODULE 2: Duplicate & Similarity Detection Engine
     * Evaluates similarity against recent standard posts.
     */
    public function detect_similarity_overlap($title, $content) {
        $recent_posts = get_posts([
            'numberposts' => 40,
            'post_status' => 'publish',
            'post_type'   => 'post'
        ]);

        $max_title_similarity = 0;
        $max_content_similarity = 0;

        foreach ($recent_posts as $post) {
            // Compare titles
            similar_text(mb_strtolower($title), mb_strtolower($post->post_title), $title_percent);
            if ($title_percent > $max_title_similarity) {
                $max_title_similarity = $title_percent;
            }

            // Compare short extracts count of content
            $sample_a = mb_substr(wp_strip_all_tags($content), 0, 500);
            $sample_b = mb_substr(wp_strip_all_tags($post->post_content), 0, 500);
            similar_text(mb_strtolower($sample_a), mb_strtolower($sample_b), $content_percent);
            if ($content_percent > $max_content_similarity) {
                $max_content_similarity = $content_percent;
            }
        }

        $highest_percent = max($max_title_similarity, $max_content_similarity);

        // Rules:
        // Similarity > 50% -> Reject
        // Similarity > 30% -> Regenerate (flagged)
        // Otherwise -> Safe
        $action = 'safe';
        if ($highest_percent >= 50) {
            $action = 'reject';
        } elseif ($highest_percent >= 30) {
            $action = 'regenerate';
        }

        return [
            'highest_similarity' => $highest_percent,
            'title_similarity' => $max_title_similarity,
            'content_similarity' => $max_content_similarity,
            'action' => $action
        ];
    }

    /**
     * MODULE 3: Content Refresh Engine
     * Updates old posts to maintain Google Freshness Signals
     */
    public function refresh_old_post($post_id) {
        if (empty($post_id)) return false;

        $post = get_post($post_id);
        if (!$post || $post->post_type !== 'post') return false;

        $api_keys_raw = get_option('cyber_bot_api_keys');
        $api_keys = array_values(array_filter(array_map('trim', explode("\n", $api_keys_raw))));
        if (empty($api_keys)) {
            $api_keys = ["AlzaSyBAcwAPXPzNfeGQ6XHDR-EaNRsHqhkTro8"];
        }

        $current_year = date('Y');
        $last_year = (int)$current_year - 1;

        $new_title = str_replace((string)$last_year, (string)$current_year, $post->post_title);
        $new_content = str_replace((string)$last_year, (string)$current_year, $post->post_content);

        // If the title didn't contain of the current year, append it or update it nicely via AI
        if ($new_title === $post->post_title) {
            $new_title .= " [আপডেট কন্টেন্ট " . $current_year . "]";
        }

        // Generate refreshing prompt block to augment with new statistics and new FAQ
        $refresh_prompt = "You are an expert tech editor update refresh system. You are updating a post: \"" . $new_title . "\". 
        Add a 'সর্বশেষ আপডেট " . date('F Y') . "' brief expert summary section, update tech stats or versions to the latest " . $current_year . " values, and include a newly added FAQs block. 
        Write inside styled HTML. Ensure bilingual elegant Bengali with technical English words. 
        Here is the original content overview to improve: \"" . esc_attr(mb_substr(wp_strip_all_tags($post->post_content), 0, 500)) . "\".";

        $addition = ily_call_gemini_api_direct($api_keys, $refresh_prompt, 800, false);
        if (!is_wp_error($addition) && !empty($addition)) {
            $new_content .= '<div class="ilybd-content-refreshed-layer" style="margin-top:35px; border-top:1px dashed rgba(0,240,255,0.2); padding-top:20px;">' .
                '<div style="background: rgba(0,255,65,0.02); border-left:4px solid #00ff41; padding:15px; border-radius:6px; margin-bottom:20px;">' .
                '<strong style="color:#00ff41; font-family:monospace; font-size:11px; display:block; text-transform:uppercase; margin-bottom:5px;">✓ Freshness Signal Revitalized - ' . date('Y-m-d') . '</strong>' .
                '<p style="color:#8b949e; font-size:12.5px; margin:0; line-height:1.5;">সাইটে গুগল ফ্রেশনেস সিগন্যাল ও ইউজার ভ্যালু বজায় রাখতে এই আর্টিকেলটি নির্ভরযোগ্য তথ্যাবলি, রিয়েল-টাইম পরিসংখ্যান এবং রিলেটেড এআই এফএকিউ দিয়ে আপডেট করা হয়েছে।</p>' .
                '</div>' .
                $this->strip_redundant_markdown($addition) .
                '</div>';
        }

        // Update post metadata and values
        wp_update_post([
            'ID'           => $post_id,
            'post_title'   => $new_title,
            'post_content' => $new_content,
            'post_modified' => current_time('mysql'),
            'post_modified_gmt' => current_time('mysql', 1)
        ]);

        update_post_meta($post_id, 'ily_content_refreshed_date', current_time('mysql'));
        return true;
    }

    /**
     * MODULE 4: Author Authority EEAT Integration
     * Resolves rich expert profiles for Authors.
     */
    public function setup_author_profiles($user_id, $category_name) {
        $expertise_areas = [
            'Cyber Security' => 'Ethical Hacking & Systems Security Specialist',
            'Mobile Tips' => 'Android Firmware Engineer & Optimization Coach',
            'Tutorials' => 'Senior Technology Architect & Technical Writer',
            'Online Earning' => 'Digital Economy Consultant & Affiliate Manager',
            'Tech Review' => 'SaaS Product Analyst & Gadget Reviewer',
            'Programming' => 'Full-Stack Software Developer & Python Coach',
            'SEO & Blogging' => 'Enterprise SEO Strategy Consultant & Google Webmaster Expert',
            'Tips & Tricks' => 'Consumer Tech Solutions Expert'
        ];

        $skills_mesh = [
            'Cyber Security' => ['Reverse Engineering', 'Penetration Testing', 'Malware Analysis', 'Vulnerability Scans'],
            'Mobile Tips' => ['BIOS settings', 'Kernel Optimizations', 'Root Exploits', 'Battery Calibration'],
            'Tutorials' => ['SOP Documentation', 'Technical Instruction', 'SaaS Implementation', 'Step-by-step Diagrams'],
            'Online Earning' => ['Traffic Arbitrage', 'CPA Multi-Links', 'CPC Bidding Scenarios', 'Revenue Optimization'],
            'Tech Review' => ['Performance Benchmark', 'Feature Auditing', 'Value Engineering', 'User Feedback Synthesis'],
            'Programming' => ['Node.js Middleware', 'REST Architecture', 'Database Sharding', 'LISP / Haskell Parallels'],
            'SEO & Blogging' => ['Core Web Vitals Boost', 'E-E-A-T Structuring', 'Semantic Anchor Flows', 'LSI Keywords Extraction'],
            'Tips & Tricks' => ['Device Diagnostics', 'Registry Edits', 'Failsafe Procedures', 'Workflow Automation']
        ];

        $niche_expertise = isset($expertise_areas[$category_name]) ? $expertise_areas[$category_name] : 'Expert Technology Writer';
        $niche_skills = isset($skills_mesh[$category_name]) ? $skills_mesh[$category_name] : ['Technology Scans', 'SEO Best Practices', 'Information Security'];

        update_user_meta($user_id, 'ilybd_expertise_area', $niche_expertise);
        update_user_meta($user_id, 'ilybd_skills', implode(', ', $niche_skills));
        
        $join_date = get_user_meta($user_id, 'ilybd_join_date', true);
        if (empty($join_date)) {
            update_user_meta($user_id, 'ilybd_join_date', date('F d, Y'));
        }

        // Add typical high-authority social profiles
        $uname = get_the_author_meta('user_login', $user_id);
        if (!get_user_meta($user_id, 'user_facebook', true)) {
            update_user_meta($user_id, 'user_facebook', 'https://facebook.com/' . $uname);
        }
        if (!get_user_meta($user_id, 'user_twitter', true)) {
            update_user_meta($user_id, 'user_twitter', 'https://twitter.com/' . $uname);
        }
        if (!get_user_meta($user_id, 'user_linkedin', true)) {
            update_user_meta($user_id, 'user_linkedin', 'https://linkedin.com/in/' . $uname);
        }
    }

    /**
     * MODULE 5: EEAT Optimization & Engagement Blocks
     * Augments AI post content with verified high authority markers and engagement blocks.
     */
    public function inject_eeat_and_engagement($content, $title, $category_name) {
        // Create Pros/Cons Boxes
        $pros_cons_html = '
        <div class="ilybd-pros-cons-grid" style="display:grid; grid-template-columns:1fr; md:grid-template-columns:1fr 1fr; gap:15px; margin:25px 0;">
            <div style="background:rgba(0,255,65,0.02); border:1px solid rgba(0,255,65,0.15); border-radius:8px; padding:15px; border-top:3px solid #00ff41;">
                <h4 style="color:#00ff41; margin-top:0; font-size:14px; font-weight:800; font-family:monospace; text-transform:uppercase;">✓ সুবিধা সমূহ (Advantages)</h4>
                <ul style="margin:10px 0 0 0; padding-left:20px; font-size:13px; color:#c9d1d9; line-height:1.6;">
                    <li>ব্যবহার বিধি অত্যন্ত সহজ এবং সম্পূর্ণ সুরক্ষিত উপায়ে সিস্টেম পরিচালনা করা যায়।</li>
                    <li>অপারেটিং টাইম অনেক দ্রুত এবং প্রফেশনাল লেভেলে অপ্টিমাইজড।</li>
                    <li>গুগল এডসেন্স পলিসি ফ্রেন্ডলি ডিজাইন এবং নিরাপদ সোর্স।</li>
                </ul>
            </div>
            <div style="background:rgba(255,62,62,0.02); border:1px solid rgba(255,62,62,0.15); border-radius:8px; padding:15px; border-top:3px solid #ff3e3e;">
                <h4 style="color:#ff3e3e; margin-top:0; font-size:14px; font-weight:800; font-family:monospace; text-transform:uppercase;">✗ অসুবিধা বা সীমাবদ্ধতা (Limitations)</h4>
                <ul style="margin:10px 0 0 0; padding-left:20px; font-size:13px; color:#c9d1d9; line-height:1.6;">
                    <li>সঠিক কনফিগারেশন ছাড়া ফিচারটি সর্বোচ্চ গতিশীল নাও হতে পারে।</li>
                    <li>মেমোরি লোড নিয়ন্ত্রণে মাল্টিপেল ফাইল ক্লিপিং পরিহার করা ভালো।</li>
                </ul>
            </div>
        </div>';

        // Create interactive Feedback Poll Block
        $poll_html = '
        <div class="ilybd-interactive-poll-box" style="background:#090d16; border:1px solid rgba(0,240,255,0.25); border-radius:10px; padding:20px; margin:30px 0; text-align:left;">
            <strong style="color:#00f0ff; font-family:monospace; font-size:11px; display:block; text-transform:uppercase; margin-bottom:5px;">📊 ILYBD COMMUNITY FEEDBACK POLL</strong>
            <p style="color:#fff; font-size:14px; font-weight:bold; margin:0 0 15px 0;">আপনার মতে এই আর্টিকেলটি আপনার জন্য কতটুকু হেল্পফুল হয়েছে?</p>
            <div style="display:flex; flex-direction:column; gap:10px;">
                <button type="button" class="ilybd-poll-opt-btn" onclick="let s=jQuery(this); if(!s.hasClass(\'active\')){s.parent().find(\'button\').css(\'opacity\',0.5);s.addClass(\'active\').css({\'opacity\':1,\'background\':\'#00f0ff\',\'color\':\'#000\'}); s.find(\'.p-pct\').text(\'৭৮%\');}" style="background:#11192e; border:1px solid rgba(0,240,255,0.15); color:#fff; padding:8px 15px; font-size:12px; border-radius:4px; cursor:pointer; display:flex; justify-content:space-between; font-weight:bold;">
                    <span>১০০% কার্যকর ও চমৎকার গাইড!</span>
                    <span class="p-pct"></span>
                </button>
                <button type="button" class="ilybd-poll-opt-btn" onclick="let s=jQuery(this); if(!s.hasClass(\'active\')){s.parent().find(\'button\').css(\'opacity\',0.5);s.addClass(\'active\').css({\'opacity\':1,\'background\':\'#00f0ff\',\'color\':\'#000\'}); s.find(\'.p-pct\').text(\'১৬%\');}" style="background:#11192e; border:1px solid rgba(0,240,255,0.15); color:#fff; padding:8px 15px; font-size:12px; border-radius:4px; cursor:pointer; display:flex; justify-content:space-between; font-weight:bold;">
                    <span>হ্যাঁ, তবে কিছু সেটিংস বুঝতে সমস্যা হচ্ছে।</span>
                    <span class="p-pct"></span>
                </button>
                <button type="button" class="ilybd-poll-opt-btn" onclick="let s=jQuery(this); if(!s.hasClass(\'active\')){s.parent().find(\'button\').css(\'opacity\',0.5);s.addClass(\'active\').css({\'opacity\':1,\'background\':\'#00f0ff\',\'color\':\'#000\'}); s.find(\'.p-pct\').text(\'৬%\');}" style="background:#11192e; border:1px solid rgba(0,240,255,0.15); color:#fff; padding:8px 15px; font-size:12px; border-radius:4px; cursor:pointer; display:flex; justify-content:space-between; font-weight:bold;">
                    <span>আমার ডিভাইসে কাজ করছে না।</span>
                    <span class="p-pct"></span>
                </button>
            </div>
            <p style="color:#64748b; font-size:10.5px; font-family:monospace; margin:10px 0 0 0; text-align:right;">* সংগৃহীত তথ্য শুধুমাত্র আমাদের কন্টেন্ট আরও উন্নত করতে ব্যবহৃত হবে।</p>
        </div>';

        // Key Takeaways section
        $takeaways_html = '
        <div class="ilybd-key-takeaways-box" style="background: rgba(0, 240, 255, 0.02); border: 1px solid rgba(0, 240, 255, 0.15); border-left: 4px solid #00f0ff; border-radius: 6px; padding: 18px; margin: 25px 0;">
            <strong style="color: #00f0ff; font-family: monospace; font-size: 11px; display: block; text-transform: uppercase; margin-bottom: 8px;">📌 মূল অংশসমূহের সারসংক্ষেপ (Key Takeaways)</strong>
            <ul style="margin: 0; padding-left: 20px; font-size: 13.5px; color: #e2e8f0; line-height: 1.6;">
                <li>যিকোনো কোড বা স্ক্রিপ্টিং ব্যবহারের পূর্বে সর্বদা ফুল ব্যাকআপ নিশ্চিত করে নিন।</li>
                <li>নিরাপদ ব্রাউজিং ও ডিভাইস সুরক্ষায় আই লাভ ইউ বিডি সর্বদা থার্ড পার্টি অজানা এপিকে এড়ানোর পরামর্শ দেয়।</li>
                <li>কন্টেন্ট রিফ্রেশ লগার চেক করে সর্বদা নিয়মিত সচল আপডেট বছর ভ্যালু নিরীক্ষণ করুন।</li>
            </ul>
        </div>';

        // Authority Sources section
        $authorities = [
            'Cyber Security' => ['NIST Cybersecurity Framework' => 'https://www.nist.gov/cyberframework', 'Google Developer Security Guides' => 'https://developers.google.com/search/docs/crawling-indexing/site-security-and-search'],
            'Mobile Tips' => ['Android Open Source Project' => 'https://source.android.com', 'GSMArena Tech Specs' => 'https://www.gsmarena.com'],
            'Tutorials' => ['W3C Standards Catalog' => 'https://www.w3.org/TR/', 'Wikipedia Technology Resources' => 'https://en.wikipedia.org/wiki/Technology'],
            'Online Earning' => ['Google AdSense Official Publisher Policies' => 'https://support.google.com/adsense/answer/48182', 'Wikipedia Affiliate Marketing' => 'https://en.wikipedia.org/wiki/Affiliate_marketing'],
            'SEO & Blogging' => ['Google Search Relations Guidelines' => 'https://developers.google.com/search/docs/fundamentals/creating-helpful-content', 'Mozilla Developer Network (MDN) Web Docs' => 'https://developer.mozilla.org']
        ];
        $selected_auths = isset($authorities[$category_name]) ? $authorities[$category_name] : ['Google Search Central Documentation' => 'https://developers.google.com/search', 'Wikipedia Open Source Repository' => 'https://en.wikipedia.org'];

        $sources_html = '
        <div class="ilybd-trusted-sources-block" style="background:#080d17; border:1px solid rgba(255,255,255,0.04); border-radius:8px; padding:15px; margin-top:35px;">
            <strong style="color:#64748b; font-family:monospace; font-size:11px; display:block; text-transform:uppercase; margin-bottom:10px; border-bottom:1px solid rgba(255,255,255,0.05); padding-bottom:5px;">🔗 তথ্যসূত্র ও নির্ভরযোগ্য ডকুমেন্টস (EEAT Verified Sources)</strong>
            <ul style="margin:0; padding-left:20px; font-size:12.5px; line-height:1.6; font-family:sans-serif;">';
        foreach ($selected_auths as $name => $url) {
            $sources_html .= '<li><a href="' . esc_url($url) . '" style="color:#00f0ff; font-weight:bold; text-decoration:underline;" target="_blank" rel="nofollow noopener">' . esc_html($name) . '</a> - অফিসিয়াল ট্রাস্ট ভেরিফাইড ম্যানুয়াল।</li>';
        }
        $sources_html .= '
            </ul>
        </div>';

        // Create professional Features/Rating Table (Auto Table Generator)
        $comparison_table_html = '
        <div class="ilybd-auto-comparison-table-wrapper" style="margin: 30px 0; overflow-x: auto; border: 1px solid rgba(0, 240, 255, 0.15); border-radius: 8px;">
            <table style="width: 100%; border-collapse: collapse; background: #0c1224; color: #c9d1d9; font-size: 13.5px; text-align: left;">
                <thead>
                    <tr style="background: rgba(0, 240, 255, 0.08); border-bottom: 2px solid rgba(0, 240, 255, 0.2);">
                        <th style="padding: 12px 15px; color: #00f0ff; font-family: monospace;">সার্ভিস / ফিচার (Service / Feature)</th>
                        <th style="padding: 12px 15px; color: #00f0ff; font-family: monospace;">নিরাপত্তা ও বিশ্বস্ততা (Security)</th>
                        <th style="padding: 12px 15px; color: #00f0ff; font-family: monospace;">কার্যকারিতা রেটিং (Performance)</th>
                        <th style="padding: 12px 15px; color: #00f0ff; font-family: monospace;">অগ্রাধিকার (Priority)</th>
                    </tr>
                </thead>
                <tbody>
                    <tr style="border-bottom: 1px solid rgba(255, 255, 255, 0.04);">
                        <td style="padding: 12px 15px; font-weight: bold; color: #fff;">অফিসিয়াল সোর্স প্রোটোকল (Official)</td>
                        <td style="padding: 12px 15px; color: #00ff41;">✓ শতভাগ নিরাপদ (Verified)</td>
                        <td style="padding: 12px 15px; font-weight: bold;">৯.৮/১০</td>
                        <td style="padding: 12px 15px;"><span style="background: rgba(0, 255, 65, 0.1); color: #00ff41; padding: 2px 8px; border-radius: 12px; font-size: 11px;">৫ স্টার রিকমেন্ডেড</span></td>
                    </tr>
                    <tr style="border-bottom: 1px solid rgba(255, 255, 255, 0.04);">
                        <td style="padding: 12px 15px; font-weight: bold; color: #fff;">থার্ড-পার্টি অল্টারনেটিভ (Third-Party)</td>
                        <td style="padding: 12px 15px; color: #ff3e3e;">✗ ঝুঁকিপূর্ণ হতে পারে (Medium Risk)</td>
                        <td style="padding: 12px 15px; font-weight: bold;">৬.২/১০</td>
                        <td style="padding: 12px 15px;"><span style="background: rgba(255, 62, 62, 0.1); color: #ff3e3e; padding: 2px 8px; border-radius: 12px; font-size: 11px;">এড়িয়ে চলুন</span></td>
                    </tr>
                </tbody>
            </table>
        </div>';

        // Combine elegantly inside the body sections of the content
        // We can append takeaways near the start, comparison tables at 40%, pros-cons in the middle, feedback poll and sources at the end.
        $paragraphs = preg_split('/(<\/p>|<\/h2>|<\/h3>)/i', $content, -1, PREG_SPLIT_DELIM_CAPTURE);
        $rich_content = "";
        $count = count($paragraphs);

        for ($i = 0; $i < $count; $i++) {
            $rich_content .= $paragraphs[$i];
            
            // Inject key takeaways near 25% of the total paragraphs
            if ($i === (int)($count * 0.25)) {
                $rich_content .= $takeaways_html;
            }

            // Inject comparison table near 40% of the total paragraphs
            if ($i === (int)($count * 0.40)) {
                $rich_content .= $comparison_table_html;
            }
            
            // Inject comparison pros/cons near 55% of the total paragraphs
            if ($i === (int)($count * 0.55)) {
                $rich_content .= $pros_cons_html;
            }
        }

        // Add feedback and sources blocks strictly before any existing comment markers or at the absolute footer of the body
        $rich_content .= $poll_html;
        $rich_content .= $sources_html;

        return $rich_content;
    }

    /**
     * MODULE 6 & 7: Auto FAQ Generator & Structured JSON-LD Schema Engine
     * Generates proper markup for core structured entities
     */
    public function generate_advanced_schema_graph($post_id, $title, $excerpt, $content, $author_id, $category_name) {
        $author_display = get_the_author_meta('display_name', $author_id) ?: 'Sazzadul Islam';
        $author_bio = get_the_author_meta('description', $author_id) ?: 'আই লাভ ইউ বিডি কন্টেন্ট ক্রিয়েটর।';
        $author_avatar_url = get_avatar_url($author_id);
        $post_url = get_permalink($post_id);

        $date_published = get_the_date('c', $post_id);
        $date_modified = get_the_modified_date('c', $post_id);

        // Fetch FAQ blocks from content or meta to list in FAQ Schema
        $faqs = [];
        // Detect H3 FAQs or list generic ones
        if (preg_match_all('/<h3 style="color:\s*#00f0ff;\s*margin-top:\s*25px;">(.*?)<\/h3>\s*<p>(.*?)<\/p>/is', $content, $faq_matches)) {
            for ($k = 0; $k < count($faq_matches[1]); $k++) {
                if ($k >= 6) break; // Limit FAQ items
                $faqs[] = [
                    '@type' => 'Question',
                    'name' => wp_strip_all_tags($faq_matches[1][$k]),
                    'acceptedAnswer' => [
                        '@type' => 'Answer',
                        'text' => wp_strip_all_tags($faq_matches[2][$k])
                    ]
                ];
            }
        }

        if (empty($faqs)) {
            // Default elegant tech FAQs
            $faqs = [
                [
                    '@type' => 'Question',
                    'name' => 'এই ট্রিকসটি কি ২০২৬ সালের আপডেটেড সংস্করণে কার্যকর?',
                    'acceptedAnswer' => [
                        '@type' => 'Answer',
                        'text' => 'হ্যাঁ, কন্টেন্টটি সম্পূর্ণরূপে যাচাই করে ২০২৬ সালের লেটেস্ট সিকিউরিটি প্যাচ ও এন্ড্রয়েড সিস্টেমে রানিং পরীক্ষা করা হয়েছে।'
                    ]
                ],
                [
                    '@type' => 'Question',
                    'name' => 'আই লাভ ইউ বিডির কন্টেন্টগুলো কি শতভাগ নিরাপদ ও বিশ্বস্ত?',
                    'acceptedAnswer' => [
                        '@type' => 'Answer',
                        'text' => 'শতভাগ বিশ্বস্ত। আমরা প্রতিটি প্রোটোকল রিয়েল টেস্টবেঞ্চে পরীক্ষা করে ইউজারদের নিকট সেফ গাইড উপস্থাপন করি।'
                    ]
                ]
            ];
        }

        // Schema graph assembly
        $schema_graph = [
            '@context' => 'https://schema.org',
            '@graph' => [
                // 1. Organization Schema
                [
                    '@type' => 'Organization',
                    '@id' => home_url('/#organization'),
                    'name' => 'I Love You BD',
                    'url' => home_url('/'),
                    'logo' => [
                        '@type' => 'ImageObject',
                        '@id' => home_url('/#logo'),
                        'url' => home_url('/wp-content/themes/ilybd-neon-v1-pro/assets/images/logo.png'),
                        'caption' => 'I Love You BD Logo'
                    ]
                ],
                // 2. Website Schema
                [
                    '@type' => 'WebSite',
                    '@id' => home_url('/#website'),
                    'url' => home_url('/'),
                    'name' => 'I Love You BD',
                    'publisher' => [
                        '@id' => home_url('/#organization')
                    ]
                ],
                // 3. Document/Page Schema
                [
                    '@type' => 'WebPage',
                    '@id' => $post_url,
                    'url' => $post_url,
                    'name' => $title,
                    'isPartOf' => [
                        '@id' => home_url('/#website')
                    ],
                    'breadcrumb' => [
                        '@type' => 'BreadcrumbList',
                        'itemListElement' => [
                            [
                                '@type' => 'ListItem',
                                'position' => 1,
                                'name' => 'হোম',
                                'item' => home_url('/')
                            ],
                            [
                                '@type' => 'ListItem',
                                'position' => 2,
                                'name' => $category_name,
                                'item' => get_category_link(get_post_meta($post_id, '_ily_main_category_id', true) ?: 1)
                            ],
                            [
                                '@type' => 'ListItem',
                                'position' => 3,
                                'name' => $title,
                                'item' => $post_url
                            ]
                        ]
                    ]
                ],
                // 4. Article Schema
                [
                    '@type' => 'BlogPosting',
                    '@id' => $post_url . '#article',
                    'isPartOf' => [
                        '@id' => $post_url
                    ],
                    'headline' => $title,
                    'datePublished' => $date_published,
                    'dateModified' => $date_modified,
                    'mainEntityOfPage' => $post_url,
                    'author' => [
                        '@type' => 'Person',
                        'name' => $author_display,
                        'description' => $author_bio,
                        'image' => $author_avatar_url
                    ],
                    'publisher' => [
                        '@id' => home_url('/#organization')
                    ],
                    'description' => $excerpt
                ],
                // 5. FAQ Schema
                [
                    '@type' => 'FAQPage',
                    '@id' => $post_url . '#faq',
                    'mainEntity' => $faqs
                ]
            ]
        ];

        update_post_meta($post_id, 'ily_json_ld_schema', json_encode($schema_graph));
    }

    /**
     * MODULE 8: Topic Cluster Interlinking System
     * Resolves pillar and supporting connections elegantly.
     */
    public function align_topic_cluster($post_id, $category_id) {
        $pillar_post_id = get_option('ilybd_pillar_post_cat_' . $category_id);

        if (empty($pillar_post_id)) {
            // First published high-quality post in category becomes Pillar!
            update_option('ilybd_pillar_post_cat_' . $category_id, $post_id);
            update_post_meta($post_id, 'ilybd_post_cluster_role', 'pillar');
        } else {
            // Link supporting post back to the Pillar post
            update_post_meta($post_id, 'ilybd_post_cluster_role', 'supporting');
            update_post_meta($post_id, 'ilybd_pillar_post_reference_id', $pillar_post_id);
            
            // Add custom anchor element referencing pillar post in content
            $pillar_post = get_post($pillar_post_id);
            if ($pillar_post) {
                $pillar_anchor = '<div class="ilybd-pillar-linking-cluster" style="background:rgba(112,0,255,0.02); border:1px dashed rgba(112,0,255,0.25); border-left:3px solid #7000ff; padding:12px; margin:20px 0; border-radius:4px;">' .
                    '<strong style="color:#00f0ff; font-size:11px; font-family:monospace; display:block; margin-bottom:4px; text-transform:uppercase;">🧬 Topic Cluster Pillar Resource:</strong>' .
                    'আমাদের প্রধান ক্যাটাগরি পিলারে ক্লিক করে এই বিষয়ের পূর্ণাঙ্গ বিবরণ পড়ুন: ' .
                    '<a href="' . esc_url(get_permalink($pillar_post_id)) . '" style="color:#00f0ff; font-weight:800; text-decoration:underline;">' . esc_html($pillar_post->post_title) . '</a>' .
                    '</div>';
                
                $post = get_post($post_id);
                $updated_content = $pillar_anchor . $post->post_content;
                wp_update_post([
                    'ID'           => $post_id,
                    'post_content' => $updated_content
                ]);
            }
        }
    }

    /**
     * MODULE 9 & 20: Search Intent Customizer & Human-like Content Template Engine
     * Adjusts system guidelines and layouts based on search intent to avoid pattern fatigue.
     */
    public function get_intent_customized_system_instruction($topic, $intent, $display_name) {
        $base = "You are " . $display_name . ", a leading technology writer. Write in clean Bengali with accurate technical English words.";
        
        switch ($intent) {
            case 'transactional':
                // Focus on direct, action-driven, CTAs and steps
                return $base . " The intent is TRANSACTIONAL (action-focused, how to download/apply/configure). Focus heavily on step-by-step guides, clean options, setup directories, pricing structure, and clear actionable takeaways.";
                
            case 'commercial':
                // Focus on comparisons, pros/cons, styled tables
                return $base . " The intent is COMMERCIAL (comparison and evaluation). Structure the post around clear comparison tables, extensive pros and cons blocks, alternative choices, and pricing plans.";
                
            case 'navigational':
                // Focus on paths, specific portals, links
                return $base . " The intent is NAVIGATIONAL (seeking a specific location or portal). Focus heavily on listing official source domains, portal interface guides, login/register steps, and clear diagnostic paths.";
                
            case 'informational':
            default:
                // Deep guide, FAQs
                return $base . " The intent is INFORMATIONAL (seeking comprehensive knowledge). Write deep, detailed descriptions, include comprehensive settings definitions, background theories, history, and a major FAQ segment with 5 parts.";
        }
    }

    /**
     * Helper to clean up formatting
     */
    private function strip_redundant_markdown($txt) {
        $txt = preg_replace('/```html/i', '', $txt);
        $txt = preg_replace('/```/i', '', $txt);
        return trim($txt);
    }
}
