<?php
/**
 * Template Name: Cyber Ownership Funding Pro
 * Description: Fully Professional E-E-A-T and AdSense Compliant Ownership & Funding Page
 */
get_header();
$neon = get_option('ilybd_main_color', '#00ff41');
?>
<div class="cyber-page-wrapper">
    <div class="container-fluid" style="max-width: 1100px; margin: 0 auto; padding: 40px 20px;">
        
        <header class="cyber-section-header">
            <h1 class="rgb-text-lighting">Ownership & Funding Info</h1>
            <p class="section-subtext">মালিকানা ও তহবিল তথ্য / CORPORATE & FINANCIAL STRUCTURE</p>
            <div class="sticky-rgb-line"></div>
        </header>

        <div class="slim-rgb-container">
            <div class="inner-page-content">
                
                <section class="policy-block">
                    <h2>🇧🇩 মালিকানা ও তহবিলের উৎস সম্পর্কে স্বচ্ছতা</h2>
                    <p>ILOVEYOUBD.COM (IBD Cyber Ecosystem) সম্পূর্ণরূপে একটি স্বাধীন উদ্যোগ। আমাদের ইউজার, পাঠক এবং স্টেকহোল্ডারদের সাথে স্বচ্ছতা বজায় রাখার জন্য আমাদের মালিকানা কাঠামো এবং তহবিলের উৎস সম্পর্কে এখানে বিস্তারিত প্রকাশ করা হলো।</p>
                </section>
                <div class="policy-divider"></div>

                <div class="policy-grid">
                    <!-- 1. Ownership Structure -->
                    <div class="policy-card">
                        <h3><i class="fa-solid fa-building-user"></i> 1. Ownership Structure</h3>
                        <p><strong>Bengali (মালিকানা কাঠামো):</strong> ILOVEYOUBD ওয়েবসাইট এবং এর সাব-ডোমেইনসমূহ সম্পূর্ণভাবে ILYBD Team দ্বারা পরিচালিত ও নিয়ন্ত্রণাধীন। এর পেছনে কোনো রাজনৈতিক দল বা সরকারি প্রতিষ্ঠানের অংশীদারি নেই।</p>
                        <p><strong>English:</strong> ILOVEYOUBD and its subdomains are fully operated and controlled by the independent ILYBD Team. There is no affiliation, partnership, or backing from any political party or government entity.</p>
                    </div>

                    <!-- 2. Funding & Revenue -->
                    <div class="policy-card">
                        <h3><i class="fa-solid fa-money-bill-trend-up"></i> 2. Funding & Revenue Model</h3>
                        <p><strong>Bengali (তহবিল ও আয়):</strong> আমাদের ওয়েবসাইটটি মূলত প্রিমিয়াম অ্যাড নেটওয়ার্ক (যেমন- Google AdSense), স্পন্সরড কন্টেন্ট এবং অ্যাফিলিয়েট মার্কেটিং থেকে আসা আয়ের সাহায্যে পরিচালিত হয়।</p>
                        <p><strong>English:</strong> The platform is primarily funded through premium advertisement networks (e.g., Google AdSense), transparent sponsored content, and affiliate marketing partnerships.</p>
                    </div>
                </div>

                <div class="policy-grid" style="margin-top: 25px;">
                    <!-- 3. Independence of Editors -->
                    <div class="policy-card">
                        <h3><i class="fa-solid fa-newspaper"></i> 3. Editorial Independence</h3>
                        <p><strong>Bengali (স্বাধীন সম্পাদকীয় সত্তা):</strong> আমাদের বিজ্ঞাপনদাতারা বা স্পন্সররা কখনোই আমাদের মূল কন্টেন্ট, নিউজ বা সম্পাদকীয় নীতিতে প্রভাব ফেলতে পারে না।</p>
                        <p><strong>English:</strong> Our advertisers and sponsors have no influence over our editorial decisions, content curation, or news reporting, ensuring complete editorial independence.</p>
                    </div>

                    <!-- 4. Transparency Commitment -->
                    <div class="policy-card">
                        <h3><i class="fa-solid fa-check-double"></i> 4. Transparency Commitment</h3>
                        <p><strong>Bengali (স্বচ্ছতার অঙ্গীকার):</strong> আমরা যেকোনো পেইড রিভিউ বা স্পন্সরড আর্টিকেলের শুরুতেই সুস্পষ্টভাবে ডিসক্লেইমার যুক্ত করে দিই, যাতে পাঠকরা সহজেই তা বুঝতে পারে।</p>
                        <p><strong>English:</strong> We explicitly include clear disclaimers at the beginning of any sponsored article or paid review to ensure complete transparency for our readers.</p>
                    </div>
                </div>
                
                <div class="about-card hero-card" style="margin-top: 30px; background: rgba(0,255,204,0.02); border-color: rgba(0,255,204,0.15); border-radius: 12px; padding: 25px;">
                    <h3 style="color: var(--cyber-neon, #00ff41); margin-top: 0; font-size: 16px; text-transform: uppercase;"><i class="fa-solid fa-building-shield"></i> Transparent Operations</h3>
                    <p style="margin: 0; font-size: 13.5px; line-height: 1.7; color: #a0aec0;">Our corporate and financial structure is designed to sustain the platform without compromising our core values. This transparency aligns with international media credibility standards and E-E-A-T guidelines.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .cyber-page-wrapper {
        background: #070a0f;
        min-height: 100vh;
        color: #e1e7ef;
        font-family: 'Inter', system-ui, -apple-system, sans-serif;
    }
    .cyber-section-header {
        text-align: center;
        margin-bottom: 40px;
    }
    .rgb-text-lighting {
        font-size: 2.8rem;
        font-weight: 900;
        text-transform: uppercase;
        letter-spacing: 3px;
        margin: 0 0 10px 0;
        background: linear-gradient(to right, #ff0000, #ffff00, #00ff00, #00ffff, #0000ff, #ff00ff, #ff0000);
        background-size: 200% auto;
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        animation: rgb_flow 4s linear infinite;
    }
    .section-subtext {
        color: <?php echo $neon; ?>;
        font-size: 11px;
        letter-spacing: 5px;
        margin-bottom: 20px;
    }
    .sticky-rgb-line {
        height: 2px;
        width: 100%;
        background: linear-gradient(to right, #ff0000, #ffff00, #00ff00, #00ffff, #0000ff, #ff00ff, #ff0000);
        background-size: 200% auto;
        animation: rgb_flow 4s linear infinite;
        box-shadow: 0 0 15px <?php echo $neon; ?>dd;
    }
    .slim-rgb-container {
        position: relative;
        padding: 1px;
        background: linear-gradient(var(--angle), #ff0000, #00ff00, #0000ff, #ff0000);
        animation: rotate-border 6s linear infinite;
        border-radius: 20px;        overflow: hidden;
    }
    @property --angle {
        syntax: '<angle>';
        initial-value: 0deg;
        inherits: false;
    }
    @keyframes rotate-border {
        to { --angle: 360deg; }
    }
    .inner-page-content {
        background: #0a0e14;
        border-radius: 19px;
        padding: 40px;
    }
    .policy-block h2 {
        color: #fff;
        font-size: 22px;        margin-top: 0;
        margin-bottom: 15px;
    }
    .policy-block p {
        line-height: 1.8;
        color: #a0aec0;
        font-size: 15px;
    }
    .policy-divider {
        height: 1px;
        background: rgba(255,255,255,0.08);
        margin: 30px 0;
    }
    .policy-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 25px;
    }
    .policy-card {
        background: rgba(255,255,255,0.01);
        border: 1px solid rgba(255,255,255,0.05);
        border-radius: 12px;
        padding: 25px;
        transition: 0.3s;
    }
    .policy-card:hover {
        border-color: <?php echo $neon; ?>;
        box-shadow: 0 0 15px <?php echo $neon; ?>1d;
    }
    .policy-card h3 {
        color: <?php echo $neon; ?>;
        font-size: 16px;        margin-top: 0;
        margin-bottom: 15px;
        text-transform: uppercase;
        letter-spacing: 1px;
        border-bottom: 1px solid rgba(255,255,255,0.05);
        padding-bottom: 8px;
    }
    .policy-card p {
        font-size: 13.5px;
        line-height: 1.7;
        color: #a0aec0;
        margin-bottom: 12px;
    }
    @media (max-width: 768px) {
        .policy-grid {
            grid-template-columns: 1fr;
        }
        .inner-page-content {
            padding: 20px;
        }
    }
    @keyframes rgb_flow {
        0% { background-position: 0% 50%; }
        50% { background-position: 100% 50%; }
        100% { background-position: 0% 50%; }
    }
</style>
<?php get_footer(); ?>
