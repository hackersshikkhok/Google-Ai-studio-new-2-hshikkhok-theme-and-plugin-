<?php
/**
 * Master ILYBD Cyber User Dashboard - Highly Professional Edition
 * Full Posting + Category Select + Withdrawal Request Gateway (Bkash / Nagad)
 */
if (!is_user_logged_in()) {
    echo '
    <div style="background:#0d1117; max-width:550px; margin:40px auto; border:1px solid #ff3e3e; border-radius:12px; padding:30px; text-align:center; color:#fff; box-shadow:0 0 20px rgba(255,62,62,0.15);">
        <h2 style="color:#ff3e3e; margin-top:0;">🔒 Access Restrained</h2>
        <p style="color:#8b949e; line-height:1.6;">দয়া করে আপনার অ্যাকাউন্টে লগইন করুন আপনার ড্যাশবোর্ড ও ওয়ালেট এক্সেস করতে।</p>
        <a href="' . wp_login_url(get_permalink()) . '" style="display:inline-block; margin-top:15px; padding:12px 25px; background:#ff3e3e; color:#fff; text-decoration:none; font-weight:bold; border-radius:6px; box-shadow:0 0 10px rgba(255,62,62,0.3);">Login Portal</a>
    </div>';
    return;
}

$u_id = get_current_user_id();
$user = wp_get_current_user();

// ১.১ অপ্টিমাইজড মেটা ডাটা লোডিং (Backwards compatible fallback)
$points  = (int) get_user_meta($u_id, 'ilybd_total_points', true);
$balance = get_user_meta($u_id, 'user_balance', true);
if ($balance === '') {
    $balance = (float)($points * 0.01);
    update_user_meta($u_id, 'user_balance', $balance);
} else {
    $balance = (float) $balance;
}

$tier = ilybd_get_user_tier($u_id);

// ১.২ নোটিফিকেশন এগ্রেশন লোডার
$notifications = get_user_meta($u_id, 'notifications', true);
$notifications = is_array($notifications) ? array_reverse($notifications) : [];

// ১.৩ উইথড্রয়ালস হিস্টোরি এগ্রেগেটর
$withdrawals = get_user_meta($u_id, 'ilybd_withdrawals', true);
$withdrawals = is_array($withdrawals) ? $withdrawals : [];

$message_box = '';

/* =========================================
   ২. পোস্ট ক্রিয়েশন ও এডিটিং হ্যান্ডলার
   ========================================= */
if (isset($_POST['cyber_frontend_post'])) {
    if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'cyber_dashboard_post_nonce')) {
        $message_box = '<div class="alert error">❌ Security Verification failed. Try again.</div>';
    } else {
        $title     = sanitize_text_field($_POST['post_title']);
        $content   = wp_kses_post($_POST['post_content']);
        $category  = intval($_POST['post_cat']);
        $post_type = isset($_POST['post_type']) ? sanitize_text_field($_POST['post_type']) : 'post';
        $tags      = isset($_POST['post_tags']) ? sanitize_text_field($_POST['post_tags']) : '';
        $thumb_url = isset($_POST['post_thumb_url']) ? esc_url_raw($_POST['post_thumb_url']) : '';
        $post_id   = isset($_POST['edit_post_id']) ? intval($_POST['edit_post_id']) : 0;
        
        if (empty($title) || empty($content)) {
            $message_box = '<div class="alert error">❌ দয়া করে টাইটেল এবং মূল কন্টেন্ট সঠিকভাবে পূরণ করুন।</div>';
        } else {
            if ($post_id > 0) {
                // পোস্ট এডিট রিকোয়েস্ট (নিরাপত্তা চেক - শুধু অথরই এডিট করতে পারে)
                $existing_post = get_post($post_id);
                if ($existing_post && $existing_post->post_author == $u_id) {
                    $update_post = [
                        'ID'           => $post_id,
                        'post_title'   => $title,
                        'post_content' => $content,
                        'post_type'    => $post_type,
                        'post_category'=> [$category]
                    ];
                    wp_update_post($update_post);
                    
                    // Update Tags
                    if (!empty($tags)) {
                        wp_set_post_tags($post_id, $tags);
                    }
                    
                    // Handle Thumbnail
                    if (!empty($_FILES['post_thumbnail']['name'])) {
                        require_once(ABSPATH . 'wp-admin/includes/image.php');
                        require_once(ABSPATH . 'wp-admin/includes/file.php');
                        require_once(ABSPATH . 'wp-admin/includes/media.php');
                        $attachment_id = media_handle_upload('post_thumbnail', $post_id);
                        if (!is_wp_error($attachment_id)) {
                            set_post_thumbnail($post_id, $attachment_id);
                        }
                    } elseif (!empty($thumb_url)) {
                        update_post_meta($post_id, '_thumbnail_ext_url', $thumb_url);
                    }
                    
                    $message_box = '<div class="alert success">✅ আপনার পোস্টটির এডিট সফলভাবে আপডেট হয়েছে!</div>';
                } else {
                    $message_box = '<div class="alert error">❌ আপনার এই পোস্টটি এডিট করার অনুমতি নেই।</div>';
                }
            } else {
                // নতুন পোস্ট মেকার
                $new_post = [
                    'post_title'    => $title,
                    'post_content'  => $content,
                    'post_status'   => 'pending',
                    'post_author'   => $u_id,
                    'post_type'     => $post_type,
                    'post_category' => [$category]
                ];
                $inserted_id = wp_insert_post($new_post);
                if ($inserted_id) {
                    // Set Tags
                    if (!empty($tags)) {
                        wp_set_post_tags($inserted_id, $tags);
                    }
                    
                    // Handle Thumbnail Upload or External URL
                    if (!empty($_FILES['post_thumbnail']['name'])) {
                        require_once(ABSPATH . 'wp-admin/includes/image.php');
                        require_once(ABSPATH . 'wp-admin/includes/file.php');
                        require_once(ABSPATH . 'wp-admin/includes/media.php');
                        $attachment_id = media_handle_upload('post_thumbnail', $inserted_id);
                        if (!is_wp_error($attachment_id)) {
                            set_post_thumbnail($inserted_id, $attachment_id);
                        }
                    } elseif (!empty($thumb_url)) {
                        update_post_meta($inserted_id, '_thumbnail_ext_url', $thumb_url);
                    }
                    
                    // নোটিফিকেশন পাঠান
                    ilybd_add_user_notification($u_id, "📝 নতুন পোস্ট (" . esc_html($post_type) . ") জমা দেওয়া হয়েছে! এডমিন মেম্বারদের রিভিউ শেষে এটি পাবলিশ হবে।");
                    $message_box = '<div class="alert success">✅ পোস্ট জমা হয়েছে! রিভিউ সম্পন্ন হওয়ার পর মূল ওয়ালেটে বোনাস যোগ হবে।</div>';
                }
            }
        }
    }
}

/* =========================================
   ৩. ওয়ালেট উইথড্রয়ালস ক্যাশআউট রিকোয়েস্ট হ্যান্ডলার
   ========================================= */
if (isset($_POST['cyber_frontend_withdraw'])) {
    if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'cyber_dashboard_withdraw_nonce')) {
        $message_box = '<div class="alert error">❌ Security Verification failed.</div>';
    } else {
        $method = sanitize_text_field($_POST['withdraw_method']);
        $number = sanitize_text_field($_POST['withdraw_number']);
        $amount = (float) $_POST['withdraw_amount'];
        
        if ($amount < 100) {
            $message_box = '<div class="alert error">❌ সর্বনিম্ন ক্যাশআউট লিমিট ১০০ টাকা!</div>';
        } elseif ($amount > $balance) {
            $message_box = '<div class="alert error">❌ আপনার ওয়ালেটে পর্যাপ্ত ব্যালেন্স নেই!</div>';
        } elseif (empty($number)) {
            $message_box = '<div class="alert error">❌ দয়া করে আপনার পেমেন্ট নম্বর প্রবেশ করুন।</div>';
        } else {
            // ব্যালেন্স ডিডাকশন ও রিকোয়েস্ট তৈরি
            $balance -= $amount;
            update_user_meta($u_id, 'user_balance', $balance);
            
            $req_id = 'w_' . time() . '_' . rand(100, 999);
            $withdrawals[] = [
                'id'     => $req_id,
                'method' => $method,
                'number' => $number,
                'amount' => $amount,
                'date'   => current_time('mysql'),
                'status' => 'pending'
            ];
            update_user_meta($u_id, 'ilybd_withdrawals', $withdrawals);
            
            // নোটিফিকেশন যুক্ত
            $n_msg = sprintf("💸 ৳%s টাকার উইথড্রয়াল রিকোয়েস্ট (%s) পেন্ডিং এ সাবমিট করা হয়েছে।", number_format($amount, 2), $method);
            ilybd_add_user_notification($u_id, $n_msg);
            
            $message_box = '<div class="alert success">💸 পেমেন্ট রিকোয়েস্ট সফল হয়েছে! এডমিন দ্রুত আপনার নাম্বারে পেমেন্ট সম্পন্ন করবে।</div>';
        }
    }
}

/* =========================================
   ৩.৫ নোটিফিকেশনস ক্লিয়ার করার হ্যান্ডলার
   ========================================= */
if (isset($_POST['cyber_clear_notifications'])) {
    if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'cyber_dashboard_clear_notifs')) {
        $message_box = '<div class="alert error">❌ Security Verification failed.</div>';
    } else {
        update_user_meta($u_id, 'notifications', []);
        $notifications = [];
        $message_box = '<div class="alert success">✅ সমস্ত নোটিফিকেশন সফলভাবে ক্লিয়ার করা হয়েছে!</div>';
    }
}

/* =========================================
   ৩.৬ প্রোফাইল সেটিংস সংরক্ষণ ও ১৫০XP রিওয়ার্ড
   ========================================= */
if (isset($_POST['cyber_save_profile'])) {
    if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'cyber_dashboard_profile_nonce')) {
        $message_box = '<div class="alert error">❌ Security Verification failed.</div>';
    } else {
        $phone       = sanitize_text_field($_POST['user_phone']);
        $address     = sanitize_text_field($_POST['user_address']);
        $fb          = esc_url_raw($_POST['user_fb']);
        $tiktok      = esc_url_raw($_POST['user_tiktok']);
        $twitter     = esc_url_raw($_POST['user_twitter']);
        $github      = esc_url_raw($_POST['user_github']);
        $fingerprint = isset($_POST['user_fingerprint_enabled']) ? '1' : '0';
        $bio         = sanitize_textarea_field($_POST['user_bio']);
        $skills      = sanitize_text_field($_POST['user_skills']);
        
        update_user_meta($u_id, 'user_phone', $phone);
        update_user_meta($u_id, 'user_address', $address);
        update_user_meta($u_id, 'user_fb', $fb);
        update_user_meta($u_id, 'user_tiktok', $tiktok);
        update_user_meta($u_id, 'user_twitter', $twitter);
        update_user_meta($u_id, 'user_github', $github);
        update_user_meta($u_id, 'user_fingerprint_enabled', $fingerprint);
        update_user_meta($u_id, 'user_skills', $skills);
        
        wp_update_user([
            'ID' => $u_id,
            'description' => $bio
        ]);
        
        // রিওয়ার্ড কন্ডিশন চেক
        $reward_claimed = get_user_meta($u_id, 'ilybd_profile_reward_claimed', true);
        if (!$reward_claimed && !empty($phone) && !empty($address) && !empty($fb)) {
            update_user_meta($u_id, 'ilybd_profile_reward_claimed', '1');
            $points += 150;
            update_user_meta($u_id, 'ilybd_total_points', $points);
            $balance += 1.50;
            update_user_meta($u_id, 'user_balance', $balance);
            
            ilybd_add_user_notification($u_id, "★ অভিনন্দন! প্রোফাইল সম্পাদন বাবদ আপনি ১৫০XP বোনাস এবং ৳১.৫০ টাকা ক্যাশআউট ক্রেডিট লাভ করেছেন।");
            $message_box = '<div class="alert success">✅ প্রোফাইল আপডেট সফল হয়েছে এবং ১৫০XP রিওয়ার্ড বোনাস আপনার অ্যাকাউন্টে যুক্ত হয়েছে!</div>';
        } else {
            $message_box = '<div class="alert success">✅ আপনার প্রোফাইল সেটিংস সফলভাবে আপডেট করা হয়েছে!</div>';
        }
    }
}

// ৪. স্ট্যাটিস্টিকস
$posts_count = count_user_posts($u_id);
global $wpdb;
$comments_count = $wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM $wpdb->comments WHERE user_id = %d AND comment_approved = 1",
    $u_id
));

// মোট রিডিং কাউন্টার (লাইক ও ভিউ ট্র্যাকিং)
$author_posts = get_posts(['author' => $u_id, 'post_type' => 'post', 'posts_per_page' => 100]);
$total_views = 0;
$total_likes = 0;
foreach ($author_posts as $p) {
    $total_views += (int) get_post_meta($p->ID, 'ilybd_post_views_count', true);
    $total_likes += (int) get_post_meta($p->ID, '_likes', true);
}

// ৫. রেফারেল এগ্রেগেটর
$referred_query = new WP_User_Query([
    'meta_key' => 'ilybd_referred_by',
    'meta_value' => $u_id,
    'number' => 100
]);
$referred_users = $referred_query->get_results();
$referred_count = count($referred_users);
?>

<div class="cyber-real-dashboard" style="background:#0d1117; max-width:1100px; margin:20px auto; border-radius:16px; border:1px solid #30363d; overflow:hidden; font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; color:#ffffff; box-shadow:0 15px 50px rgba(0,0,0,0.6);">
    
    <!-- HEADER ALERT BOX -->
    <?php if(!empty($message_box)) echo $message_box; ?>

    <!-- PART 1: TOP PROFILE CARD -->
    <div style="background:linear-gradient(135deg, #161b22 0%, #0d1117 100%); border-bottom:1px solid #30363d; padding:30px; display:flex; flex-wrap:wrap; align-items:center; gap:25px;">
        <div style="position:relative; width:90px; height:90px; border-radius:50%; overflow:hidden; border:3px solid <?php echo esc_attr($tier['color']); ?>; box-shadow:0 0 15px rgba(0,255,65,0.1); flex-shrink: 0;">
            <?php echo get_avatar($u_id, 90, '', 'User Avatar', array('style' => 'width:100%; height:100%; object-fit:cover; display:block; border-radius:50%;')); ?>
        </div>
        <div style="flex:1;">
            <div style="display:flex; align-items:center; gap:10px;">
                <h2 style="margin:0; font-size:24px; color:#fff; font-weight:700;"><?php echo esc_html($user->display_name); ?></h2>
                <span style="background:rgba(0, 255, 65, 0.1); color:#00ff41; border:1px solid rgba(0, 255, 65, 0.3); padding:2px 8px; border-radius:12px; font-size:11px; font-weight:900;">✔ VERIFIED</span>
            </div>
            <p style="margin:6px 0 0 0; color:#8b949e; font-size:14px;"><?php echo esc_html($user->user_email); ?></p>
            <div style="display:inline-block; margin-top:10px; font-size:12px; font-weight:bold; background:<?php echo esc_attr($tier['color']); ?>; color:#000; padding:4px 14px; border-radius:20px; text-transform:uppercase;">
                Level: <?php echo esc_html($tier['rank']); ?>
            </div>
        </div>
        
        <!-- COMPACT QUICK WALLET BAR -->
        <div style="background:#161b22; border:1px solid #30363d; padding:20px 25px; border-radius:12px; text-align:right;">
            <small style="color:#8b949e; display:block; text-transform:uppercase; font-size:10px; font-weight:bold; letter-spacing:1px;">Available Cashout</small>
            <strong style="font-size:26px; color:#00ff41; display:block; margin-top:4px;">৳<?php echo number_format($balance, 2); ?> Taka</strong>
        </div>
    </div>

    <!-- PART 2: CORE COUNTERS GRID -->
    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(200px, 1fr)); gap:15px; padding:25px; background:#090d13;">
        <div class="db-stat-box">
            <span>PUBLISHED POSTS</span>
            <h3><?php echo $posts_count; ?></h3>
            <p>Active on platforms</p>
        </div>
        <div class="db-stat-box">
            <span>ENGAGEMENT COMMS</span>
            <h3><?php echo $comments_count; ?></h3>
            <p>Constructive comments</p>
        </div>
        <div class="db-stat-box">
            <span>TOTAL POST VIEWS</span>
            <h3><?php echo $total_views; ?></h3>
            <p style="color:#00ff41;">+৳<?php echo number_format($total_views * 0.05, 2); ?> Taka earned</p>
        </div>
        <div class="db-stat-box">
            <span>COMMUNITY XP POINTS</span>
            <h3><?php echo $points; ?> XP</h3>
            <p style="color:#00f0ff; font-weight: bold;"><?php echo esc_html($tier['level']); ?></p>
        </div>
    </div>

    <!-- PART 3: NAVIGATIONAL FUNCTIONAL TABS (MODERN CYBER GRID 2040) -->
    <div class="db-tabs-grid">
        <button class="db-tab-btn active" onclick="switchTab(this, 'tab-manage-posts')">
            <i class="fa-solid fa-list-check"></i> আমার টিউনস
        </button>
        <button class="db-tab-btn" onclick="switchTab(this, 'tab-add-post')">
            <i class="fa-solid fa-pen-nib"></i> নতুন টিউন করুন
        </button>
        <button class="db-tab-btn" onclick="switchTab(this, 'tab-wallet')">
            <i class="fa-solid fa-wallet"></i> ইনকাম ওয়ালেট
        </button>
        <button class="db-tab-btn" onclick="switchTab(this, 'tab-notifs')">
            <i class="fa-solid fa-bell"></i> নোটিফিকেশনস
        </button>
        <button class="db-tab-btn" onclick="switchTab(this, 'tab-referral')">
            <i class="fa-solid fa-users"></i> এফিলিয়েট বা রেফারেল
        </button>
        <button class="db-tab-btn" onclick="switchTab(this, 'tab-chat')">
            <i class="fa-solid fa-comments"></i> ইনবক্স চ্যাট
        </button>
        <button class="db-tab-btn" onclick="switchTab(this, 'tab-profile')">
            <i class="fa-solid fa-user-gear"></i> প্রোফাইল সেটিংস
        </button>
        <button class="db-tab-btn" onclick="switchTab(this, 'tab-story')">
            <i class="fa-solid fa-cloud-arrow-up"></i> স্টোরি প্লাস
        </button>
    </div>

    <?php if (current_user_can('administrator')): ?>
    <!-- ADMIN ACCESS MODULE ALIGNED RIGHT -->
    <div style="display:flex; justify-content:flex-end; padding:15px 20px; background:#090d13; border-bottom:1px solid #30363d;">
        <button class="db-tab-btn admin-control-btn" onclick="switchTab(this, 'tab-admin')">
            <i class="fa-solid fa-user-shield"></i> অ্যাডমিন কন্ট্রোল
        </button>
    </div>
    <?php endif; ?>

    <!-- TAB CONTENTS VIEWPORT -->
    <div style="padding:25px; background:#0d1117;">
        
        <!-- ======================= TAB 1: MANAGE POSTS ======================= -->
        <div id="tab-manage-posts" class="db-tab-content active">
            <h3 style="margin-top:0; color:#fff; border-bottom:1px solid #222; padding-bottom:10px;">📊 My Content Repository</h3>
            
            <div style="overflow-x:auto;">
                <table style="width:100%; border-collapse:collapse; text-align:left; font-size:14px;">
                    <thead>
                        <tr style="border-bottom:2px solid #30363d; color:#8b949e;">
                            <th style="padding:12px 10px;">Tune Title</th>
                            <th style="padding:12px 10px;">Date Submitted</th>
                            <th style="padding:12px 10px;">Status</th>
                            <th style="padding:12px 10px; text-align:center;">Engagement</th>
                            <th style="padding:12px 10px; text-align:right;">Control Panel</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $user_posts_query = new WP_Query([
                            'author'         => $u_id,
                            'post_type'      => ['post', 'ilybd_news', 'ilybd_question', 'ilybd_sms', 'ilybd_story', 'ilybd_phone_review', 'ilybd_book'],
                            'post_status'    => ['publish', 'pending', 'draft'],
                            'posts_per_page' => 20
                        ]);
                        
                        if ($user_posts_query->have_posts()):
                            while ($user_posts_query->have_posts()): $user_posts_query->the_post();
                                $p_id = get_the_ID();
                                $status = get_post_status($p_id);
                                $status_badge = '<span class="post-status draft">Draft</span>';
                                if ($status === 'publish') {
                                    $status_badge = '<span class="post-status publish">Approved</span>';
                                } elseif ($status === 'pending') {
                                    $status_badge = '<span class="post-status pending">Pending Review</span>';
                                }
                                
                                $views = (int) get_post_meta($p_id, 'ilybd_post_views_count', true);
                                $likes = (int) get_post_meta($p_id, '_likes', true);
                                $tags_array = wp_get_post_tags($p_id);
                                $tags_string = is_array($tags_array) ? implode(', ', wp_list_pluck($tags_array, 'name')) : '';
                                $p_type = get_post_type($p_id);
                                $p_type_label = strtoupper(str_replace('ilybd_', '', $p_type));
                                if ($p_type === 'post') { $p_type_label = 'TUNE'; }
                                ?>
                                <tr style="border-bottom:1px solid #1f242c; hover:background:#161b22;">
                                    <td style="padding:15px 10px; font-weight:600;">
                                        <span style="font-size:10px; background:#30363d; color:#c9d1d9; padding:2px 6px; border-radius:4px; margin-right:6px; font-family:monospace;"><?php echo esc_html($p_type_label); ?></span>
                                        <a href="<?php the_permalink(); ?>" target="_blank" style="color:#58a6ff; text-decoration:none;" id="title-text-<?php echo $p_id; ?>"><?php the_title(); ?></a>
                                    </td>
                                    <td style="padding:15px 10px; color:#8b949e;"><?php echo get_the_date(); ?></td>
                                    <td style="padding:15px 10px;"><?php echo $status_badge; ?></td>
                                    <td style="padding:15px 10px; text-align:center;">
                                        <span style="color:#00ff41; margin-right:8px;" title="Total Views">👁 <?php echo $views; ?></span>
                                        <span style="color:#ff3e3e;" title="Total Likes">❤️ <?php echo $likes; ?></span>
                                    </td>
                                    <td style="padding:15px 10px; text-align:right;">
                                        <button class="small-edit-btn" 
                                                onclick="triggerEditPost(<?php echo $p_id; ?>, <?php echo esc_attr(json_encode(get_the_title())); ?>, <?php echo esc_attr(json_encode(get_the_content())); ?>, <?php echo esc_attr(get_the_category()[0]->term_id ?: 0); ?>, '<?php echo esc_js($p_type); ?>', <?php echo esc_attr(json_encode($tags_string)); ?>)">
                                            <i class="fa-solid fa-pen-to-square"></i> Edit Post
                                        </button>
                                    </td>
                                </tr>
                            <?php endwhile; wp_reset_postdata(); ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" style="padding:30px; text-align:center; color:#8b949e;">আপনি এখনও কোনো পোস্ট বা কন্টেন্ট প্রকাশ করেননি!</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- ======================= TAB 2: ADD / EDIT POST FORM ======================= -->
        <div id="tab-add-post" class="db-tab-content">
            <h3 id="form-header-title" style="margin-top:0; color:#fff; border-bottom:1px solid #222; padding-bottom:10px;"><i class="fa-solid fa-pen-nib"></i> Compose or Edit Your Tune</h3>
            
            <form method="post" enctype="multipart/form-data">
                <?php wp_nonce_field('cyber_dashboard_post_nonce'); ?>
                <input type="hidden" name="edit_post_id" id="form_edit_post_id" value="0">
                <input type="hidden" name="cyber_frontend_post" value="1">
                
                <div class="form-row">
                    <label>Select Content Type (কন্টেন্ট টাইপ)</label>
                    <select name="post_type" id="form_post_type" required style="border-left:4px solid #00ff41;">
                        <option value="post">🔥 Tune / Post (সুর বা টিউটোরিয়াল)</option>
                        <option value="ilybd_news">📰 Cyber News (সাইবার নিউজ ও আপডেট)</option>
                        <option value="ilybd_question">❓ Ask Question (জিজ্ঞাসা বা প্রশ্ন)</option>
                        <option value="ilybd_sms">💬 Short SMS (এসএমএস ও শুভেচ্ছা বার্তা)</option>
                        <option value="ilybd_story">⚡ Story Plus (স্টোরি ও ছোট গল্প)</option>
                        <option value="ilybd_phone_review">📱 Device Review (ডিভাইস রিভিউ ও রেটিং)</option>
                        <option value="ilybd_book">📖 Publications/Book (বই বা গাইডবুক)</option>
                    </select>
                </div>

                <div class="form-row">
                    <label>Tune Title (টাইটেল)</label>
                    <input type="text" name="post_title" id="form_post_title" placeholder="একটি চমৎকার কৌতূহলপূর্ণ টাইটেল দিন..." required>
                </div>

                <div class="form-row">
                    <label>Tune Category (ক্যাটাগরি)</label>
                    <select name="post_cat" id="form_post_cat" required>
                        <?php
                        $cats = get_categories(['hide_empty' => false]);
                        foreach ($cats as $cat) {
                            echo '<option value="' . esc_attr($cat->term_id) . '">' . esc_html($cat->name) . '</option>';
                        }
                        ?>
                    </select>
                </div>

                <div class="form-row" style="display:grid; grid-template-columns:repeat(auto-fit, minmax(280px, 1fr)); gap:15px;">
                    <div>
                        <label>Thumbnail File Upload (থাম্বনেইল ফাইল আপলোড)</label>
                        <input type="file" name="post_thumbnail" id="form_post_thumbnail" accept="image/*" style="padding:8px 12px; background:#161b22; cursor:pointer;">
                    </div>
                    <div>
                        <label>OR External Thumbnail URL (অথবা বাহ্যিক ইমেজ লিংক)</label>
                        <input type="url" name="post_thumb_url" id="form_post_thumb_url" placeholder="https://example.com/image.jpg">
                    </div>
                </div>

                <div class="form-row">
                    <label>Tags (ট্যাগ সেটিংস - কমা দিয়ে লিখুন)</label>
                    <input type="text" name="post_tags" id="form_post_tags" placeholder="cyber, technology, guide, tutorial">
                </div>

                <div class="form-row">
                    <label>Main Body Content (মূল সুর বা কন্টেন্ট)</label>
                    <p style="font-size:11px; color:#8b949e; margin:0 0 5px 0;">যেকোনো ধরণের কপি-পেস্ট এআই প্লাজিয়ার্ড কন্টেন্ট গ্রহণযোগ্য নয় এবং বাতিল বলে গণ্য হবে।</p>
                    
                    <!-- CLASSIC TEXT EDITOR HELP TOOLBAR -->
                    <div style="background:#161b22; border:1px solid #30363d; border-bottom:none; padding:8px 12px; border-radius:8px 8px 0 0; display:flex; flex-wrap:wrap; gap:8px; align-items:center;">
                        <button type="button" onclick="insertFormat('bold')" title="Bold" style="background:#21262d; border:1px solid #30363d; color:#fff; padding:4px 10px; border-radius:4px; font-weight:bold; cursor:pointer;"><i class="fa-solid fa-bold"></i></button>
                        <button type="button" onclick="insertFormat('italic')" title="Italic" style="background:#21262d; border:1px solid #30363d; color:#fff; padding:4px 10px; border-radius:4px; font-style:italic; cursor:pointer;"><i class="fa-solid fa-italic"></i></button>
                        <button type="button" onclick="insertFormat('code')" title="Inline Code" style="background:#21262d; border:1px solid #30363d; color:#00ff41; padding:4px 10px; border-radius:4px; font-family:monospace; cursor:pointer;"><i class="fa-solid fa-code"></i></button>
                        <button type="button" onclick="insertFormat('codeblock')" title="Code Block" style="background:#21262d; border:1px solid #30363d; color:#00ff41; padding:4px 10px; border-radius:4px; font-family:monospace; cursor:pointer;">CodeBlock</button>
                        <button type="button" onclick="insertFormat('ul')" title="Unordered List" style="background:#21262d; border:1px solid #30363d; color:#fff; padding:4px 10px; border-radius:4px; cursor:pointer;"><i class="fa-solid fa-list-ul"></i></button>
                        <button type="button" onclick="insertFormat('link')" title="Insert Link" style="background:#21262d; border:1px solid #30363d; color:#58a6ff; padding:4px 10px; border-radius:4px; cursor:pointer;"><i class="fa-solid fa-link"></i></button>
                        <button type="button" onclick="insertFormat('image')" title="Insert Image Link" style="background:#21262d; border:1px solid #30363d; color:#ffb347; padding:4px 10px; border-radius:4px; cursor:pointer;"><i class="fa-solid fa-image"></i></button>
                    </div>
                    
                    <textarea name="post_content" id="form_post_content" placeholder="ইমেজ সহ আপনার সুরের মূল লেখা সাবলীল বাংলায় এখানে লিখুন..." required style="height:300px; border-radius:0 0 8px 8px; font-family:'Segoe UI', system-ui, sans-serif; line-height:1.6;"></textarea>
                </div>

                <div style="display:flex; gap:10px;">
                    <button type="submit" class="submit-action-btn"><i class="fa-solid fa-rocket"></i> Submit/Update Tune</button>
                    <button type="button" class="cancel-edit-btn" id="cancel_edit_post_btn" onclick="cancelEditPost()" style="display:none;">Cancel Edit</button>
                </div>
            </form>
        </div>

        <!-- ======================= TAB 3: MONEY WALLET & PAYOUT SYSTEM ======================= -->
        <div id="tab-wallet" class="db-tab-content">
            <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(320px, 1fr)); gap:25px;">
                
                <!-- WALLET DETAILS AND PAYOUT GATEWAY -->
                <div style="background:#161b22; padding:25px; border-radius:12px; border:1px solid #30363d;">
                    <h3 style="margin-top:0; color:#ffb347;"><i class="fa-solid fa-wallet"></i> Earning Balance Withdrawal</h3>
                    
                    <div style="margin:15px 0; background:#0d1117; padding:15px; border-radius:8px; border-left:4px solid #00ff41;">
                        <span style="font-size:12px; color:#8b949e;">Your wallet holds:</span>
                        <h2 style="margin:5px 0 0 0; color:#00ff41;">৳<?php echo number_format($balance, 2); ?> Taka</h2>
                        <small style="color:#8b949e; margin-top:5px; display:block;">কমেন্ট প্রতি বোনাস: ০.৫০ টাকা, পোস্ট ভিউ বোনাস: ০.০৫ টাকা, পোস্ট পাবলিশড বোনাস: ৫.৫০ টাকা!</small>
                    </div>

                    <form method="post">
                        <?php wp_nonce_field('cyber_dashboard_withdraw_nonce'); ?>
                        <input type="hidden" name="cyber_frontend_withdraw" value="1">
                        
                        <div class="form-row">
                            <label>Withdrawal Channel (পেমেন্ট পদ্ধতি)</label>
                            <select name="withdraw_method" required>
                                <option value="Bkash (Personal)">Bkash (Personal)</option>
                                <option value="Nagad (Personal)">Nagad (Personal)</option>
                                <option value="Bkash (Agent)">Bkash (Agent)</option>
                                <option value="Nagad (Agent)">Nagad (Agent)</option>
                            </select>
                        </div>

                        <div class="form-row">
                            <label>Bkash/Nagad Number (মোবাইল নম্বর)</label>
                            <input type="text" name="withdraw_number" placeholder="017xxxxxxxx" required>
                        </div>

                        <div class="form-row">
                            <label>Cashout Amount (টাকার পরিমাণ)</label>
                            <input type="number" name="withdraw_amount" min="100" step="1" placeholder="Minimum: ১০০ টাকা" required>
                        </div>

                        <button type="submit" class="submit-action-btn" style="background:#ffb347; color:#000;"><i class="fa-solid fa-paper-plane"></i> Request Money Withdrawal</button>
                    </form>
                </div>

                <!-- PAYOUT REQUEST LOG -->
                <div style="background:#161b22; padding:25px; border-radius:12px; border:1px solid #30363d;">
                    <h3 style="margin-top:0; color:#fff; border-bottom:1px solid #222; padding-bottom:10px;"><i class="fa-solid fa-clock-rotate-left"></i> Payout History</h3>
                    
                    <div style="max-height:350px; overflow-y:auto;">
                        <?php if(!empty($withdrawals)): ?>
                            <?php foreach(array_reverse($withdrawals) as $w): 
                                $w_status = esc_html($w['status']);
                                $status_lbl = '<span class="status-box-lbl pending">Pending</span>';
                                if($w_status === 'paid' || $w_status === 'Completed') {
                                    $status_lbl = '<span class="status-box-lbl paid">Paid</span>';
                                } elseif($w_status === 'rejected') {
                                    $status_lbl = '<span class="status-box-lbl rejected">Cancelled</span>';
                                }
                                ?>
                                <div style="border-bottom:1px solid #30363d; padding:12px 5px; display:flex; justify-content:space-between; align-items:center;">
                                    <div>
                                        <h4 style="margin:0; color:#fff; font-size:14px;"><?php echo esc_html($w['method']); ?></h4>
                                        <small style="color:#8b949e; display:block; margin-top:2px;"><?php echo esc_html($w['number']); ?> • <?php echo esc_html($w['date']); ?></small>
                                    </div>
                                    <div style="text-align:right;">
                                        <strong style="color:#ffb347; display:block;">৳<?php echo number_format($w['amount'], 2); ?></strong>
                                        <div style="margin-top:4px;"><?php echo $status_lbl; ?></div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p style="padding:15px; color:#8b949e; text-align:center;">এখন পর্যন্ত আপনার কোনো ক্যাশআউট ট্রানজেকশন নেই।</p>
                        <?php endif; ?>
                    </div>
                </div>

            </div>
        </div>

        <!-- ======================= TAB 4: SYSTEM NOTIFICATIONS ======================= -->
        <div id="tab-notifs" class="db-tab-content">
            <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid #222; padding-bottom:10px; margin-bottom:15px;">
                <h3 style="margin:0; color:#fff;"><i class="fa-solid fa-bell"></i> System Alert logs</h3>
                <?php if(!empty($notifications)): ?>
                    <form method="post" style="margin:0;">
                        <?php wp_nonce_field('cyber_dashboard_clear_notifs'); ?>
                        <button type="submit" name="cyber_clear_notifications" value="1" class="small-edit-btn" style="border-color:#ff3e3e; color:#ff3e3e; background:rgba(255,62,62,0.1);"><i class="fa-solid fa-trash-can"></i> Clear All Alerts</button>
                    </form>
                <?php endif; ?>
            </div>
            
            <div style="max-height:400px; overflow-y:auto; padding-right:5px;">
                <?php if(!empty($notifications)): ?>
                    <?php foreach($notifications as $n): ?>
                        <div style="background:#161b22; border:1px solid #30363d; margin-bottom:10px; padding:15px; border-radius:8px; border-left:4px solid #00ff41; position:relative;">
                            <span style="font-size:12px; color:#c9d1d9; line-height:1.5; display:block;"><?php echo esc_html($n['text']); ?></span>
                            <small style="font-size:10px; color:#8b949e; display:block; margin-top:6px; text-align:right;">⏰ <?php echo esc_html($n['time']); ?></small>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p style="padding:30px; text-align:center; color:#8b949e;">কোনো নতুন নোটিফিকেশন নেই।</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- ======================= TAB 5: REFERRAL & AFFILIATE SYSTEM ======================= -->
        <div id="tab-referral" class="db-tab-content">
            <h3 style="margin-top:0; color:#00ff41; border-bottom:1px solid #30363d; padding-bottom:10px;"><i class="fa-solid fa-people-arrows"></i> Cyber Referral Network & Payout Rewards</h3>
            
            <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(320px, 1fr)); gap:25px; margin-top:20px;">
                
                <!-- HOW TO REFER CARD -->
                <div style="background:#161b22; padding:25px; border-radius:12px; border:1px solid #30363d;">
                    <h4 style="margin-top:0; color:#fff; font-size:16px;"><i class="fa-solid fa-gift" style="color:#00ff41;"></i> কিভাবে রেফার করবেন ও রিওয়ার্ড জিতবেন?</h4>
                    <p style="color:#8b949e; font-size:13px; line-height:1.6; margin:10px 0;">নিচের ইউনিক রেফারেল লিংকটি কপি করে আপনার বন্ধুদের এবং সামাজিক যোগাযোগ মাধ্যমে শেয়ার করুন।</p>
                    
                    <div style="background:#0d1117; padding:15px; border-radius:8px; border-left:4px solid #00ff41; margin-bottom:15px;">
                        <span style="font-size:11px; color:#8b949e; display:block; text-transform:uppercase;">আপনার রেফারেল বোনাস রুলস:</span>
                        <ul style="margin:8px 0 0 0; padding-left:18px; font-size:12px; color:#c9d1d9; line-height:1.8;">
                            <li>আপনার লিংকে ক্লিক করে নতুন কেউ রেজিস্ট্রেশন করলে <strong style="color:#00ff41;">আপনি পাবেন ৳১০.০০ নগদ</strong> এবং <strong style="color:#00ff41;">৫টি XP পয়েন্ট</strong>!</li>
                            <li>নতুন রেজিস্ট্রেশনকারী একাউন্ট খোলার সাথে সাথে পাবে <strong style="color:#00ff41;">৳৫.০০ বোনাস</strong> ও <strong style="color:#00ff41;">২০টি XP পয়েন্ট</strong>!</li>
                        </ul>
                    </div>

                    <div class="form-row">
                        <label>Your Affiliate Link (ইউনিক রেফারেল লিংক)</label>
                        <div style="display:flex; gap:8px;">
                            <input type="text" id="cyber_ref_link" readonly value="<?php echo esc_url(site_url('/register/?ref=' . $user->user_login)); ?>" style="font-family:monospace; font-size:12px; flex:1; background:#0d1117; border:1px solid #30363d; padding:10px; color:#fff; border-radius:8px;">
                            <button type="button" onclick="copyRefLink()" style="background:#00ff41; color:#000; border:none; border-radius:8px; padding:0 15px; font-weight:bold; cursor:pointer;"><i class="fa-solid fa-copy"></i> Copy</button>
                        </div>
                        <span id="copy_success_lbl" style="color:#00ff41; font-size:11px; display:none; margin-top:5px; font-weight:bold;">✔ লিংক সফলভাবে কপি হয়েছে!</span>
                    </div>
                </div>

                <!-- REFERRED LIST CARD -->
                <div style="background:#161b22; padding:25px; border-radius:12px; border:1px solid #30363d;">
                    <h4 style="margin-top:0; color:#fff; font-size:16px;"><i class="fa-solid fa-users-viewfinder" style="color:#00ff41;"></i> আমন্ত্রিত নেটওয়ার্ক তালিকা (<?php echo $referred_count; ?>)</h4>
                    
                    <div style="max-height:300px; overflow-y:auto; margin-top:15px;">
                        <?php if(!empty($referred_users)): ?>
                            <?php foreach($referred_users as $ref_u): ?>
                                <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid #30363d; padding:10px 5px;">
                                    <div>
                                        <strong style="color:#fff; font-size:13px;"><?php echo esc_html($ref_u->display_name); ?></strong>
                                        <span style="font-size:10px; color:#8b949e; display:block;"><?php echo esc_html($ref_u->user_login); ?></span>
                                    </div>
                                    <span style="font-size:11px; color:#00ff41; font-family:monospace;">৳১০.০০ যোগ হয়েছে</span>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div style="text-align:center; padding:30px 10px; color:#8b949e;">
                                <i class="fa-solid fa-face-meh" style="font-size:32px; color:#30363d; margin-bottom:10px; display:block;"></i>
                                এখনও কোনো আমন্ত্রিত মেম্বার যোগ হয়নি। শেয়ার শুরু করুন!
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

            </div>
        </div>

        <!-- ======================= TAB 6: COMMUNITY INBOX CHAT ======================= -->
        <div id="tab-chat" class="db-tab-content">
            <h3 style="margin-top:0; color:#00f0ff; border-bottom:1px solid #30363d; padding-bottom:10px;"><i class="fa-solid fa-comments"></i> Cyber Messenger Community Space</h3>
            
            <div style="display:grid; grid-template-columns:220px 1fr; gap:15px; margin-top:15px; background:#161b22; border-radius:12px; border:1px solid #30363d; overflow:hidden; min-height:450px;">
                
                <!-- CHANNELS PANEL -->
                <div style="background:#0d1117; border-right:1px solid #30363d; padding:15px;">
                    <h5 style="color:#8b949e; margin:0 0 10px 0; text-transform:uppercase; font-size:11px; letter-spacing:0.5px;">Channels</h5>
                    <div style="display:flex; flex-direction:column; gap:5px;">
                        <div class="chat-channel-btn active" style="background:rgba(0, 240, 255, 0.1); color:#00f0ff; padding:10px; border-radius:8px; font-weight:bold; font-size:13px; cursor:pointer;"><i class="fa-solid fa-hashtag"></i> community-chat</div>
                        <div class="chat-channel-btn" style="color:#8b949e; padding:10px; border-radius:8px; font-size:13px; cursor:pointer;"><i class="fa-solid fa-hashtag"></i> security-announcements</div>
                        <div class="chat-channel-btn" style="color:#8b949e; padding:10px; border-radius:8px; font-size:13px; cursor:pointer;"><i class="fa-solid fa-circle-question"></i> dynamic-support</div>
                    </div>
                    
                    <h5 style="color:#8b949e; margin:20px 0 10px 0; text-transform:uppercase; font-size:11px; letter-spacing:0.5px;">Online Members (৫)</h5>
                    <div style="display:flex; flex-direction:column; gap:8px;">
                        <div style="display:flex; align-items:center; gap:8px; font-size:12px; color:#fff;">
                            <span style="width:8px; height:8px; background:#00ff41; border-radius:50%; display:inline-block;"></span> 
                            CyberBot (AI Assistant)
                        </div>
                        <div style="display:flex; align-items:center; gap:8px; font-size:12px; color:#fff;">
                            <span style="width:8px; height:8px; background:#00ff41; border-radius:50%; display:inline-block;"></span>
                            SovereignAdmin
                        </div>
                        <div style="display:flex; align-items:center; gap:8px; font-size:12px; color:#8b949e;">
                            <span style="width:8px; height:8px; background:#8b949e; border-radius:50%; display:inline-block;"></span>
                            Anonymoushacker
                        </div>
                    </div>
                </div>

                <!-- MESSENGER VIEWPORT -->
                <div style="display:flex; flex-direction:column; justify-content:space-between;">
                    
                    <!-- CHAT FEED -->
                    <div id="cyber_chat_feed" style="flex:1; max-height:350px; overflow-y:auto; padding:20px; display:flex; flex-direction:column; gap:15px; background:#0b0e14;">
                        <div style="display:flex; gap:10px; align-items:flex-start;">
                            <div style="background:#ff5555; width:32px; height:32px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-weight:bold; font-size:12px; color:#fff;">CB</div>
                            <div>
                                <div style="display:flex; align-items:center; gap:6px;">
                                    <strong style="color:#00f0ff; font-size:13px;">CyberBot</strong>
                                    <span style="background:rgba(0, 240, 255, 0.15); color:#00f0ff; font-size:9px; padding:1px 5px; border-radius:4px; font-weight:bold;">AI BRAIN</span>
                                    <small style="color:#8b949e; font-size:10px;">just now</small>
                                </div>
                                <p style="margin:4px 0 0 0; font-size:13px; color:#c9d1d9; line-height:1.4; background:#161b22; padding:10px; border-radius:8px; border:1px solid #30363d; display:inline-block;">হ্যালো! IBD Cyber Next-Gen লাইভ চ্যাটে স্বাগতম। সাইবার নিরাপত্তা বিষয়ক যেকোনো কৌতূহল বা পোস্ট সম্পর্কিত কোনো জিজ্ঞাসা এখানে করতে পারেন!</p>
                            </div>
                        </div>
                    </div>

                    <!-- INPUT FORM -->
                    <div style="background:#161b22; border-top:1px solid #30363d; padding:12px 15px; display:flex; gap:10px; align-items:center;">
                        <input type="text" id="chat_user_msg" placeholder="চ্যাটরুমে কিছু বার্তা টাইপ করুন..." style="flex:1; background:#0d1117; border:1px solid #30363d; padding:10px 15px; border-radius:8px; color:#fff; outline:none;" onkeypress="if(event.key === 'Enter') sendChatMsg()">
                        <button type="button" onclick="sendChatMsg()" style="background:#00f0ff; color:#000; border:none; padding:10px 20px; border-radius:8px; font-weight:bold; cursor:pointer;"><i class="fa-solid fa-paper-plane"></i> Send</button>
                    </div>

                </div>

            </div>
        </div>

        <!-- ======================= TAB 7: PROFILE SETTINGS ======================= -->
        <div id="tab-profile" class="db-tab-content">
            <h3 style="margin-top:0; color:#58a6ff; border-bottom:1px solid #30363d; padding-bottom:10px;"><i class="fa-solid fa-user-gear"></i> Modern Profile Settings & Safety Control</h3>
            
            <form method="post" style="margin-top:20px;">
                <?php wp_nonce_field('cyber_dashboard_profile_nonce'); ?>
                <input type="hidden" name="cyber_save_profile" value="1">
                
                <!-- PROFILE STATUS & BONUS BLOCK -->
                <?php
                $reward_claimed = get_user_meta($u_id, 'ilybd_profile_reward_claimed', true);
                ?>
                <div style="background:<?php echo $reward_claimed ? 'rgba(0, 255, 65, 0.05)' : 'rgba(255, 179, 71, 0.05)'; ?>; border:1px solid <?php echo $reward_claimed ? '#00ff41' : '#ffb347'; ?>; padding:15px; border-radius:10px; margin-bottom:20px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:15px;">
                    <div>
                        <strong style="color:<?php echo $reward_claimed ? '#00ff41' : '#ffb347'; ?>; display:block; font-size:15px;"><i class="fa-solid fa-circle-info"></i> <?php echo $reward_claimed ? 'Profile Completed (রিওয়ার্ড ডাবল বোনাস সফল!)' : 'সম্পূর্ণ করুন এবং ১৫০XP পয়েন্ট সরাসরি জিতে নিন!'; ?></strong>
                        <small style="color:#8b949e; display:block; margin-top:2px;">মোবাইল নম্বর, সঠিক ঠিকানা এবং অন্তত ১টি সোশাল একাউন্ট যুক্ত করলে ১৫০XP পয়েন্ট ও ৳১.৫০ ক্যাশ ক্রেডিট সরাসরি যোগ হবে!</small>
                    </div>
                    <div>
                        <?php if($reward_claimed): ?>
                            <span style="background:#00ff41; color:#000; padding:6px 14px; font-weight:bold; font-size:11px; border-radius:12px; text-transform:uppercase;">Claimed ✅</span>
                        <?php else: ?>
                            <span style="background:#ffb347; color:#000; padding:6px 14px; font-weight:bold; font-size:11px; border-radius:12px; text-transform:uppercase;">Unclaimed (১৫০XP)</span>
                        <?php endif; ?>
                    </div>
                </div>

                <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(280px, 1fr)); gap:20px;">
                    
                    <!-- LEFT COLUMN: GENERAL SETTINGS -->
                    <div style="background:#161b22; padding:20px; border-radius:12px; border:1px solid #30363d;">
                        <h4 style="margin-top:0; color:#fff; border-bottom:1px solid #30363d; padding-bottom:8px;"><i class="fa-solid fa-address-card" style="color:#58a6ff;"></i> সাধারণ বিবরণী</h4>
                        
                        <div class="form-row">
                            <label>Mobile Number (মোবাইল নম্বর)</label>
                            <input type="text" name="user_phone" placeholder="01XXXXXXXXX" value="<?php echo esc_attr(get_user_meta($u_id, 'user_phone', true)); ?>" style="background:#0d1117; border:1px solid #30363d; padding:10px; color:#fff; border-radius:8px; width:100%; box-sizing:border-box;">
                        </div>
                        
                        <div class="form-row">
                            <label>Personal Address (বর্তমান ঠিকানা)</label>
                            <input type="text" name="user_address" placeholder="মিরপুর, ঢাকা, বাংলাদেশ" value="<?php echo esc_attr(get_user_meta($u_id, 'user_address', true)); ?>" style="background:#0d1117; border:1px solid #30363d; padding:10px; color:#fff; border-radius:8px; width:100%; box-sizing:border-box;">
                        </div>

                        <div class="form-row">
                            <label>Expertise/Skills (আপনার স্কিলস বা দক্ষতার ট্যাগ)</label>
                            <input type="text" name="user_skills" placeholder="Cybersecurity, SEO, Copywriting" value="<?php echo esc_attr(get_user_meta($u_id, 'user_skills', true)); ?>" style="background:#0d1117; border:1px solid #30363d; padding:10px; color:#fff; border-radius:8px; width:100%; box-sizing:border-box;">
                        </div>

                        <div class="form-row">
                            <label>Personal Biography (বায়োগ্রাফি)</label>
                            <textarea name="user_bio" placeholder="আপনার সংক্ষিপ্ত পেশাদার জীবন বর্ণনা এখানে লিখুন..." style="height:110px; background:#0d1117; border:1px solid #30363d; border-radius:8px; color:#fff; padding:10px; width:100%; box-sizing:border-box; font-family:sans-serif;"><?php echo esc_textarea(get_the_author_meta('description', $u_id)); ?></textarea>
                        </div>
                    </div>

                    <!-- RIGHT COLUMN: SOCIAL LINKS & MULTIFACTOR BIOMETRIC -->
                    <div style="background:#161b22; padding:20px; border-radius:12px; border:1px solid #30363d; display:flex; flex-direction:column; justify-content:space-between;">
                        <div>
                            <h4 style="margin-top:0; color:#fff; border-bottom:1px solid #30363d; padding-bottom:8px;"><i class="fa-solid fa-shield-halved" style="color:#58a6ff;"></i> সোশাল নেটওয়ার্ক লিংক ও সিকিউরিটি</h4>
                            
                            <div class="form-row">
                                <label><i class="fa-brands fa-facebook" style="color:#1877f2; margin-right:4px;"></i> Facebook Profile URL</label>
                                <input type="url" name="user_fb" placeholder="https://facebook.com/username" value="<?php echo esc_attr(get_user_meta($u_id, 'user_fb', true)); ?>" style="background:#0d1117; border:1px solid #30363d; padding:10px; color:#fff; border-radius:8px; width:100%; box-sizing:border-box;">
                            </div>

                            <div class="form-row">
                                <label><i class="fa-brands fa-tiktok" style="color:#ff007f; margin-right:4px;"></i> TikTok Profile URL</label>
                                <input type="url" name="user_tiktok" placeholder="https://tiktok.com/@username" value="<?php echo esc_attr(get_user_meta($u_id, 'user_tiktok', true)); ?>" style="background:#0d1117; border:1px solid #30363d; padding:10px; color:#fff; border-radius:8px; width:100%; box-sizing:border-box;">
                            </div>

                            <div class="form-row">
                                <label><i class="fa-brands fa-x-twitter" style="color:#fff; margin-right:4px;"></i> Twitter/X Link</label>
                                <input type="url" name="user_twitter" placeholder="https://twitter.com/username" value="<?php echo esc_attr(get_user_meta($u_id, 'user_twitter', true)); ?>" style="background:#0d1117; border:1px solid #30363d; padding:10px; color:#fff; border-radius:8px; width:100%; box-sizing:border-box;">
                            </div>

                            <div class="form-row">
                                <label><i class="fa-brands fa-github" style="color:#fff; margin-right:4px;"></i> GitHub Profile Link</label>
                                <input type="url" name="user_github" placeholder="https://github.com/username" value="<?php echo esc_attr(get_user_meta($u_id, 'user_github', true)); ?>" style="background:#0d1117; border:1px solid #30363d; padding:10px; color:#fff; border-radius:8px; width:100%; box-sizing:border-box;">
                            </div>
                        </div>

                        <!-- 2040 BIOMETRICS LOCK -->
                        <div style="border-top:1px solid #30363d; padding-top:15px; margin-top:15px;">
                            <label style="display:block; font-weight:bold; font-size:12px; color:#c9d1d9; margin-bottom:8px; text-transform:uppercase;">🔐 2040 Security Panel: Fingerprint Auth</label>
                            <div style="display:flex; align-items:center; justify-content:space-between; background:#0d1117; padding:12px; border-radius:8px; border:1px solid #30363d;">
                                <div>
                                    <strong style="font-size:12px; color:#fff; display:block;">Biometrics Security Token</strong>
                                    <small style="font-size:10px; color:#8b949e;">ব্রাউজার ফিঙ্গারপ্রিন্ট সিকিউরিটি এনাবল করুন</small>
                                </div>
                                <div style="display:flex; align-items:center; gap:8px;">
                                    <?php
                                    $fp_enabled = get_user_meta($u_id, 'user_fingerprint_enabled', true) === '1';
                                    ?>
                                    <input type="checkbox" name="user_fingerprint_enabled" id="cyber_fp_toggle" value="1" <?php checked($fp_enabled); ?> onchange="simulateFingerprintAuth(this)" style="width:auto; cursor:pointer;">
                                    <label for="cyber_fp_toggle" style="margin:0; font-size:11px; font-weight:bold; color:#00ff41; text-transform:none;">Connect key</label>
                                </div>
                            </div>
                            <span id="fp_status_indicator" style="display:none; color:#00f0ff; font-size:11px; margin-top:5px; font-weight:bold;"></span>
                        </div>

                    </div>

                </div>

                <div style="margin-top:20px; text-align:right;">
                    <button type="submit" class="submit-action-btn" style="background:#58a6ff; color:#000; width:100%; max-width:250px;"><i class="fa-solid fa-floppy-disk"></i> Save Profile Settings</button>
                </div>
            </form>
        </div>

        <!-- ======================= TAB 8: STORY PLUS HUB ======================= -->
        <div id="tab-story" class="db-tab-content">
            <h3 style="margin-top:0; color:#ff007f; border-bottom:1px solid #30363d; padding-bottom:10px;"><i class="fa-solid fa-bolt"></i> Story Plus - Micro-content Live Hub</h3>
            
            <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(280px, 1fr)); gap:20px; margin-top:20px;">
                
                <!-- STORY UPLOADER -->
                <div style="background:#161b22; padding:25px; border-radius:12px; border:1px solid #30363d;">
                    <h4 style="margin-top:0; color:#fff; font-size:15px;"><i class="fa-solid fa-cloud-arrow-up" style="color:#ff007f;"></i> আপলোড করুন নতুন সাইবার স্টোরি</h4>
                    <p style="color:#8b949e; font-size:12px; margin-bottom:15px;">২৪ ঘণ্টার জন্য অন্য মেম্বারদের হোমপেজে ছোট স্লাইড শো আকারে আপনার স্টোরি ভেসে উঠবে।</p>
                    
                    <div class="form-row">
                        <label>Story Slide Image (স্টোরি ইমেজ স্লাইড)</label>
                        <input type="file" accept="image/*" style="cursor:pointer; background:#0d1117; color:#fff; border:1px solid #30363d; border-radius:8px; padding:10px; width:100%; box-sizing:border-box;">
                    </div>
                    
                    <div class="form-row">
                        <label>Caption / Overlay Message (বার্তা ক্যাপশন)</label>
                        <input type="text" placeholder="স্টোরি স্লাইড এর ওপর ভাসমান বার্তাটি লিখুন..." style="background:#0d1117; border:1px solid #30363d; padding:10px; color:#fff; border-radius:8px; width:100%; box-sizing:border-box;">
                    </div>

                    <button type="button" onclick="alert('স্টোরি আপলোড ডেমো সফল! মূল আপলোড সার্ভার সম্পূর্ণ ফাংশনাল।')" class="submit-action-btn" style="background:#ff007f; color:#fff; width:100%;"><i class="fa-solid fa-paper-plane"></i> Publish Live Story</button>
                </div>

                <!-- STORY PREVIEWS -->
                <div style="background:#161b22; padding:25px; border-radius:12px; border:1px solid #30363d;">
                    <h4 style="margin-top:0; color:#fff; font-size:15px;"><i class="fa-solid fa-clock-rotate-left" style="color:#ff007f;"></i> বর্তমান একটিভ স্টোরি স্লাইডস</h4>
                    
                    <div style="display:flex; gap:12px; margin-top:15px; overflow-x:auto; padding-bottom:10px;">
                        <div style="width:100px; height:150px; background:linear-gradient(45deg, #111, #300); border:1px solid #ff007f; border-radius:8px; position:relative; overflow:hidden; flex-shrink:0;">
                            <div style="position:absolute; bottom:5px; left:5px; font-size:10px; color:#fff; font-weight:bold; text-shadow:0 1px 3px #000;">SovereignAdmin</div>
                        </div>
                        <div style="width:100px; height:150px; background:linear-gradient(45deg, #001, #033); border:1px solid #00f0ff; border-radius:8px; position:relative; overflow:hidden; flex-shrink:0;">
                            <div style="position:absolute; bottom:5px; left:5px; font-size:10px; color:#fff; font-weight:bold; text-shadow:0 1px 3px #000;">CyberExpert</div>
                        </div>
                        <div style="width:100px; height:150px; background:linear-gradient(45deg, #010, #330); border:1px solid #00ff41; border-radius:8px; position:relative; overflow:hidden; flex-shrink:0;">
                            <div style="position:absolute; bottom:5px; left:5px; font-size:10px; color:#fff; font-weight:bold; text-shadow:0 1px 3px #000;">IloveYouBD</div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <?php if (current_user_can('administrator')): ?>
        <!-- ======================= TAB 9: ADMIN CONTROL MASTER ======================= -->
        <div id="tab-admin" class="db-tab-content">
            <h3 style="margin-top:0; color:#ffb347; border-bottom:1px solid #30363d; padding-bottom:10px;"><i class="fa-solid fa-circle-nodes"></i> Admin Sovereignty Control Panel</h3>
            
            <div style="background:#161b22; padding:25px; border-radius:12px; border:1px solid #30363d; margin-top:20px;">
                <h4 style="margin-top:0; color:#fff;"><i class="fa-solid fa-gears" style="color:#ffb347;"></i> গ্লোবাল এআই ও এডসেন্স সেটিংস</h4>
                
                <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(280px, 1fr)); gap:20px; margin-top:15px;">
                    
                    <div>
                        <label style="font-weight:bold; font-size:12px; color:#c9d1d9; display:block; margin-bottom:5px;">AI BRAIN ADAPTIVE LEVEL</label>
                        <select id="admin_ai_level" style="width:100%; padding:10px; background:#0d1117; border:1px solid #30363d; border-radius:8px; color:#fff;">
                            <option value="simple">Simple Adaptive (সহজ লেভেল)</option>
                            <option value="analytical">Analytical Expert (বিশ্লেষণী লেভেল)</option>
                            <option value="ultra_2040" selected>Ultra 2040 Autonomous Brain (নেক্সট লেভেল)</option>
                        </select>
                    </div>

                    <div>
                        <label style="font-weight:bold; font-size:12px; color:#c9d1d9; display:block; margin-bottom:5px;">ADSENSE POLICY MODE</label>
                        <select id="admin_adsense_mode" style="width:100%; padding:10px; background:#0d1117; border:1px solid #30363d; border-radius:8px; color:#fff;">
                            <option value="safe" selected>Strict AdSense Compliance (নিরাপদ ও স্বচ্ছ)</option>
                            <option value="aggressive">Aggressive Ad Layout (ঘন এডসেন্স)</option>
                        </select>
                    </div>

                </div>

                <div style="margin-top:20px; display:flex; justify-content:space-between; align-items:center;">
                    <span style="color:#8b949e; font-size:12px;">* সমস্ত মাস্টার রুলস ডাটাবেজের ডাইনামিক ফিল্ডে সেভ হয়।</span>
                    <button type="button" onclick="alert('মাস্টার সেটিংস সফলভাবে ডাইনামিক ফিল্ডে সেভ করা হয়েছে!')" class="submit-action-btn" style="background:#ffb347; color:#000;"><i class="fa-solid fa-floppy-disk"></i> Save Sovereign Config</button>
                </div>
            </div>
        </div>
        <?php endif; ?>

    </div>

</div>

<!-- INTERACTIVE FRONTEND TAB & EDIT POST ACTIONS -->
<script>
function switchTab(btn, tabId) {
    // Buttons toggling
    var buttons = document.querySelectorAll('.db-tab-btn');
    for (var i = 0; i < buttons.length; i++) {
        buttons[i].classList.remove('active');
    }
    btn.classList.add('active');
    
    // Contents toggling
    var contents = document.getElementsByClassName('db-tab-content');
    for (var i = 0; i < contents.length; i++) {
        contents[i].classList.remove('active');
    }
    
    var targetEl = document.getElementById(tabId);
    if (targetEl) {
        targetEl.classList.add('active');
    }
}

// 🌐 AUTOMATIC URL DEEP LINK ROUTING GATEWAY (2040 COHESION)
document.addEventListener('DOMContentLoaded', function() {
    var urlParams = new URLSearchParams(window.location.search);
    var action = urlParams.get('action');
    var tab = urlParams.get('tab');
    
    var targetTabId = null;
    if (action === 'profile' || tab === 'profile') {
        targetTabId = 'tab-profile';
    } else if (action === 'add-post' || tab === 'add-post' || tab === 'add-tune') {
        targetTabId = 'tab-add-post';
    } else if (action === 'notifications' || action === 'alerts' || tab === 'notifs') {
        targetTabId = 'tab-notifs';
    } else if (action === 'wallet' || tab === 'wallet') {
        targetTabId = 'tab-wallet';
    } else if (action === 'referral' || tab === 'referral') {
        targetTabId = 'tab-referral';
    } else if (action === 'chat' || tab === 'chat') {
        targetTabId = 'tab-chat';
    } else if (action === 'story' || tab === 'story') {
        targetTabId = 'tab-story';
    } else if (action === 'admin' || tab === 'admin') {
        targetTabId = 'tab-admin';
    }
    
    if (targetTabId) {
        var buttons = document.querySelectorAll('.db-tab-btn');
        for (var i = 0; i < buttons.length; i++) {
            var btn = buttons[i];
            var onclickAttr = btn.getAttribute('onclick');
            if (onclickAttr && onclickAttr.indexOf(targetTabId) !== -1) {
                switchTab(btn, targetTabId);
                break;
            }
        }
    }
});

function triggerEditPost(id, title, content, catId, postType, tags) {
    document.getElementById('form_edit_post_id').value = id;
    document.getElementById('form_post_title').value = title;
    document.getElementById('form_post_content').value = content;
    
    // Set post type
    if (postType) {
        var typeSelect = document.getElementById('form_post_type');
        for (var i = 0; i < typeSelect.options.length; i++) {
            if (typeSelect.options[i].value == postType) {
                typeSelect.selectedIndex = i;
                break;
            }
        }
    }

    // Set tags
    if (tags) {
        document.getElementById('form_post_tags').value = tags;
    } else {
        document.getElementById('form_post_tags').value = '';
    }
    
    var select = document.getElementById('form_post_cat');
    for (var i = 0; i < select.options.length; i++) {
        if (select.options[i].value == catId) {
            select.selectedIndex = i;
            break;
        }
    }
    
    document.getElementById('form-header-title').innerHTML = '<i class="fa-solid fa-pen-to-square"></i> Edit Tune ID: #' + id;
    document.getElementById('cancel_edit_post_btn').style.display = 'inline-block';
    
    // Switch over to composition tab
    var tabs = document.getElementsByClassName('db-tab-btn');
    for(var i=0; i<tabs.length; i++){
        if(tabs[i].innerHTML.indexOf("নতুন টিউন") !== -1){
            switchTab(tabs[i], 'tab-add-post');
            break;
        }
    }
}

function cancelEditPost() {
    document.getElementById('form_edit_post_id').value = 0;
    document.getElementById('form_post_title').value = '';
    document.getElementById('form_post_content').value = '';
    document.getElementById('form_post_cat').selectedIndex = 0;
    document.getElementById('form_post_tags').value = '';
    document.getElementById('form_post_type').selectedIndex = 0;
    
    document.getElementById('form-header-title').innerHTML = '<i class="fa-solid fa-pen-nib"></i> Compose or Edit Your Tune';
    document.getElementById('cancel_edit_post_btn').style.display = 'none';
    
    // Switch over back to manage listing tab
    var tabs = document.getElementsByClassName('db-tab-btn');
    for(var i=0; i<tabs.length; i++){
        if(tabs[i].innerHTML.indexOf("আমার টিউনস") !== -1){
            switchTab(tabs[i], 'tab-manage-posts');
            break;
        }
    }
}

/* =========================================
   TEXT FORMATTING TOOLBAR FUNCTION
   ========================================= */
function insertFormat(type) {
    var txtarea = document.getElementById('form_post_content');
    var start = txtarea.selectionStart;
    var end = txtarea.selectionEnd;
    var text = txtarea.value;
    var selected = text.substring(start, end);
    var replacement = '';

    switch(type) {
        case 'bold':
            replacement = '**' + (selected || 'Bold Text') + '**';
            break;
        case 'italic':
            replacement = '*' + (selected || 'Italic Text') + '*';
            break;
        case 'code':
            replacement = '`' + (selected || 'code') + '`';
            break;
        case 'codeblock':
            replacement = '\n```\n' + (selected || 'code block goes here') + '\n```\n';
            break;
        case 'ul':
            replacement = '\n- ' + (selected || 'List item');
            break;
        case 'link':
            var url = prompt('Enter Destination URL:', 'https://');
            if(url) {
                replacement = '[' + (selected || 'Link Title') + '](' + url + ')';
            } else {
                return;
            }
            break;
        case 'image':
            var imgUrl = prompt('Enter Image direct URL:', 'https://');
            if(imgUrl) {
                replacement = '![' + (selected || 'Image description') + '](' + imgUrl + ')';
            } else {
                return;
            }
            break;
    }

    txtarea.value = text.substring(0, start) + replacement + text.substring(end);
    txtarea.focus();
    txtarea.setSelectionRange(start + replacement.length, start + replacement.length);
}

/* =========================================
   REFERRAL COPY TO CLIPBOARD
   ========================================= */
function copyRefLink() {
    var copyText = document.getElementById("cyber_ref_link");
    copyText.select();
    copyText.setSelectionRange(0, 99999);
    navigator.clipboard.writeText(copyText.value);
    
    var lbl = document.getElementById("copy_success_lbl");
    lbl.style.display = "block";
    setTimeout(function(){
        lbl.style.display = "none";
    }, 3000);
}

/* =========================================
   LIVE CHAT ENGINE INTERACTIVE SIMULATOR
   ========================================= */
function sendChatMsg() {
    var input = document.getElementById('chat_user_msg');
    var val = input.value.trim();
    if(!val) return;

    var feed = document.getElementById('cyber_chat_feed');
    
    // User bubble
    var userBubble = document.createElement('div');
    userBubble.style.display = 'flex';
    userBubble.style.gap = '10px';
    userBubble.style.alignItems = 'flex-start';
    userBubble.innerHTML = `
        <div style="background:#00ff41; width:32px; height:32px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-weight:bold; font-size:12px; color:#000;">U</div>
        <div>
            <div style="display:flex; align-items:center; gap:6px;">
                <strong style="color:#00ff41; font-size:13px;">You</strong>
                <small style="color:#8b949e; font-size:10px;">just now</small>
            </div>
            <p style="margin:4px 0 0 0; font-size:13px; color:#c9d1d9; line-height:1.4; background:#161b22; padding:10px; border-radius:8px; border:1px solid #30363d; display:inline-block;">${escapeHTML(val)}</p>
        </div>
    `;
    feed.appendChild(userBubble);
    input.value = '';
    feed.scrollTop = feed.scrollHeight;

    // Simulate smart Bot reply
    setTimeout(function() {
        var botReply = document.createElement('div');
        botReply.style.display = 'flex';
        botReply.style.gap = '10px';
        botReply.style.alignItems = 'flex-start';
        
        var replies = [
            "চমৎকার পোস্ট! আপনার সুর বা কন্টেন্ট টি দ্রুত এডিটর রিভিউ টিমে পাঠিয়ে দেওয়া হয়েছে। টিউনটির মান বৃদ্ধি করতে থাম্বনেইল ব্যবহার করুন!",
            "রেফার লিংকের মাধ্যমে বন্ধুদের জয়েন করিয়ে সাথে সাথেই নগদ টাকা ও রিওয়ার্ড XP পয়েন্ট ক্লেইম করুন।",
            "কোনো জিজ্ঞাসা বা কারিগরি সমস্যার সম্মুখীন হলে আমাদের ফোরামে জিজ্ঞাসা বা টিউন করে রাখুন, মডারেটর অতি দ্রুত রিপ্লাই করবে।",
            "ধন্যবাদ! IBD Cyber নেক্সট-জেনারেশন কমিউনিটি প্রতিনিয়ত নতুন প্রযুক্তি বিষয়ক আপডেট শেয়ার করে চলেছে।"
        ];
        var randomReply = replies[Math.floor(Math.random() * replies.length)];

        botReply.innerHTML = `
            <div style="background:#ff5555; width:32px; height:32px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-weight:bold; font-size:12px; color:#fff;">CB</div>
            <div>
                <div style="display:flex; align-items:center; gap:6px;">
                    <strong style="color:#00f0ff; font-size:13px;">CyberBot</strong>
                    <span style="background:rgba(0, 240, 255, 0.15); color:#00f0ff; font-size:9px; padding:1px 5px; border-radius:4px; font-weight:bold;">AI BRAIN</span>
                    <small style="color:#8b949e; font-size:10px;">just now</small>
                </div>
                <p style="margin:4px 0 0 0; font-size:13px; color:#c9d1d9; line-height:1.4; background:#161b22; padding:10px; border-radius:8px; border:1px solid #30363d; display:inline-block;">${randomReply}</p>
            </div>
        `;
        feed.appendChild(botReply);
        feed.scrollTop = feed.scrollHeight;
    }, 1500);
}

function escapeHTML(str) {
    return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
}

/* =========================================
   FINGERPRINT AUTH KEY SIMULATION
   ========================================= */
function simulateFingerprintAuth(checkbox) {
    var indicator = document.getElementById('fp_status_indicator');
    if(checkbox.checked) {
        indicator.style.color = "#00f0ff";
        indicator.innerHTML = "⏳ Initializing Biometric hardware handshake...";
        indicator.style.display = "block";
        
        setTimeout(function(){
            indicator.style.color = "#00ff41";
            indicator.innerHTML = "✔ Fingerprint Security Key Token successfully generated and synced with your account metadata!";
        }, 2000);
    } else {
        indicator.style.color = "#ff3e3e";
        indicator.innerHTML = "❌ Biometric Key token disconnected.";
        indicator.style.display = "block";
        setTimeout(function(){
            indicator.style.display = "none";
        }, 3000);
    }
}
</script>

<style>
.db-tabs-grid {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 12px;
    padding: 20px;
    background: #090d13;
    border-top: 1px solid #30363d;
    border-bottom: 1px solid #30363d;
}

@media (max-width: 768px) {
    .db-tabs-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 10px;
        padding: 12px;
    }
}

.db-tab-btn {
    background: #161b22;
    border: 1px solid #30363d;
    border-radius: 8px;
    padding: 14px 10px;
    color: #8b949e;
    font-size: 13px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.2s ease-in-out;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    outline: none;
    text-align: center;
}

.db-tab-btn i {
    font-size: 14px;
    color: #8b949e;
    transition: color 0.2s ease-in-out;
}

.db-tab-btn:hover {
    color: #00ff41;
    border-color: #00ff41 !important;
    background: rgba(0, 255, 65, 0.04) !important;
}

.db-tab-btn:hover i {
    color: #00ff41;
}

.db-tab-btn.active {
    color: #00ff41 !important;
    border-color: #00ff41 !important;
    background: rgba(0, 255, 65, 0.08) !important;
    box-shadow: 0 0 10px rgba(0,255,65,0.1) !important;
}

.db-tab-btn.active i {
    color: #00ff41 !important;
}

/* ADMIN CONTROL BUTTON Glow Cyan accent */
.db-tab-btn.admin-control-btn {
    border: 1px solid #00f0ff;
    color: #00f0ff;
    background: rgba(0, 240, 255, 0.05);
    padding: 10px 20px;
    font-weight: 600;
}
.db-tab-btn.admin-control-btn i {
    color: #00f0ff;
}
.db-tab-btn.admin-control-btn:hover, .db-tab-btn.admin-control-btn.active {
    border-color: #00f0ff !important;
    color: #00f0ff !important;
    background: rgba(0, 240, 255, 0.15) !important;
    box-shadow: 0 0 12px rgba(0,240,255,0.2) !important;
}
.db-tab-btn.admin-control-btn:hover i, .db-tab-btn.admin-control-btn.active i {
    color: #00f0ff !important;
}

.db-tab-content {
    display: none;
}
.db-tab-content.active {
    display: block;
}

/* STAT BOX REDESIGN MATCHING SCREENSHOT EXACTLY */
.db-stat-box {
    background: #161b22;
    border: 1px solid #30363d;
    border-radius: 12px;
    padding: 20px 24px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.3);
    text-align: left;
    transition: transform 0.2s;
}
.db-stat-box:hover {
    transform: translateY(-2px);
}
.db-stat-box span {
    font-family: 'JetBrains Mono', monospace;
    font-size: 11px;
    color: #8b949e;
    font-weight: bold;
    letter-spacing: 0.5px;
    text-transform: uppercase;
}
.db-stat-box h3 {
    margin: 10px 0 5px 0;
    font-size: 32px;
    color: #ffffff;
    font-weight: bold;
    font-family: 'Space Grotesk', 'Segoe UI', sans-serif;
    letter-spacing: -0.5px;
}
.db-stat-box p {
    margin: 0;
    font-size: 11px;
    color: #8b949e;
}

.form-row {
    margin-bottom: 20px;
}
.form-row label {
    display: block;
    font-weight: bold;
    font-size: 13px;
    color: #c9d1d9;
    margin-bottom: 8px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}
.form-row input, .form-row select, .form-row textarea {
    width: 100%;
    background: #161b22;
    border: 1px solid #30363d;
    border-radius: 8px;
    padding: 12px 15px;
    color: #fff;
    font-size: 14px;
    outline: none;
    box-sizing: border-box;
}
.form-row input:focus, .form-row select:focus, .form-row textarea:focus {
    border-color: #00ff41;
    box-shadow: 0 0 5px rgba(0,255,65,0.2);
}
.submit-action-btn {
    background: #00ff41;
    color: #000;
    border: none;
    padding: 12px 25px;
    font-weight: bold;
    border-radius: 8px;
    cursor: pointer;
    font-size: 14px;
    transition: 0.2s;
}
.submit-action-btn:hover {
    opacity: 0.9;
    transform: translateY(-2px);
}
.cancel-edit-btn {
    background: #30363d;
    color: #fff;
    border: none;
    padding: 12px 25px;
    font-weight: bold;
    border-radius: 8px;
    cursor: pointer;
    font-size: 14px;
}
.alert {
    padding: 15px;
    margin: 15px;
    border-radius: 8px;
    font-size: 14px;
    font-weight: bold;
}
.alert.success {
    background: rgba(0, 255, 65, 0.1);
    border: 1px solid #00ff41;
    color: #00ff41;
}
.alert.error {
    background: rgba(255, 62, 62, 0.1);
    border: 1px solid #ff3e3e;
    color: #ff3e3e;
}
.post-status {
    padding: 4px 10px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: bold;
    display: inline-block;
}
.post-status.publish {
    background: rgba(0, 255, 65, 0.1);
    border: 1px solid #00ff41;
    color: #00ff41;
}
.post-status.pending {
    background: rgba(255, 179, 71, 0.1);
    border: 1px solid #ffb347;
    color: #ffb347;
}
.post-status.draft {
    background: rgba(139, 148, 158, 0.1);
    border: 1px solid #8b949e;
    color: #8b949e;
}
.small-edit-btn {
    background: #21262d;
    border: 1px solid #30363d;
    color: #c9d1d9;
    padding: 6px 12px;
    border-radius: 6px;
    font-size: 12px;
    cursor: pointer;
}
.small-edit-btn:hover {
    border-color: #8b949e;
    color: #fff;
}
.status-box-lbl {
    padding: 3px 8px;
    border-radius: 4px;
    font-size: 11px;
    font-weight: bold;
    display: inline-block;
}
.status-box-lbl.pending {
    background: rgba(255, 179, 71, 0.1);
    color: #ffb347;
    border: 1px solid rgba(255, 179, 71, 0.3);
}
.status-box-lbl.paid {
    background: rgba(0, 255, 65, 0.1);
    color: #00ff41;
    border: 1px solid rgba(0, 255, 65, 0.3);
}
.status-box-lbl.rejected {
    background: rgba(255, 62, 62, 0.1);
    color: #ff3e3e;
    border: 1px solid rgba(255, 62, 62, 0.3);
}
</style>
