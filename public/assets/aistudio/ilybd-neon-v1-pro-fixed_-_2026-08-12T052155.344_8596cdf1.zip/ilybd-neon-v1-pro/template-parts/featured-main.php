<?php
/**
 * Cinematic Featured Showcase - Bento Grid 2040 Edition
 * Features asymmetrical bento grids, custom-colored glowing sapphire-violet architecture, and complete device responsiveness.
 */

$f_count = get_option('ilybd_featured_count', 4);
$f_source = get_option('featured_source', 'manual');
$neon = esc_attr(get_option('ilybd_main_color', '#00ff41'));

$f_args = [
    'posts_per_page' => $f_count,
    'post_status'    => 'publish'
];

if ($f_source === 'manual') {
    $f_ids = get_option('ilybd_featured_ids', '');
    if (!empty($f_ids)) {
        $f_args['post__in'] = array_map('intval', explode(',', $f_ids));
        $f_args['orderby'] = 'post__in';
    } else {
        $f_args['orderby'] = 'date';
        $f_args['order'] = 'DESC';
    }
} elseif ($f_source === 'views') {
    $f_args['meta_key'] = 'ilybd_post_views_count';
    $f_args['orderby'] = 'meta_value_num';
    $f_args['order'] = 'DESC';
} elseif ($f_source === 'likes') {
    $f_args['meta_key'] = '_likes';
    $f_args['orderby'] = 'meta_value_num';
    $f_args['order'] = 'DESC';
} elseif ($f_source === 'category') {
    $f_cat = get_option('featured_category', '');
    if (!empty($f_cat)) {
        $f_args['cat'] = intval($f_cat);
    }
    $f_args['orderby'] = 'date';
    $f_args['order'] = 'DESC';
} else {
    $f_args['orderby'] = 'date';
    $f_args['order'] = 'DESC';
}

$query = new WP_Query($f_args);

// Fallback if no posts returned
if (!$query->have_posts() && ($f_source === 'views' || $f_source === 'likes' || $f_source === 'manual')) {
    $fallback_args = [
        'posts_per_page' => $f_count,
        'post_status'    => 'publish',
        'orderby'        => 'date',
        'order'          => 'DESC'
    ];
    $query = new WP_Query($fallback_args);
}

// Adaptive Backfilling Logic: only backfills to exactly 4 slots if featured source is of dynamic filter type
$posts_to_show = [];
if ($query->have_posts()) {
    while ($query->have_posts()) {
        $query->the_post();
        $posts_to_show[] = get_post();
    }
    wp_reset_postdata();
}

$count_fetched = count($posts_to_show);
$target_count = max(4, intval($f_count));

// Stop backfilling entirely for 'manual' selection source so other posts from bottom loops do not duplicate under featured posts area
if ($f_source !== 'manual' && $count_fetched > 0 && $count_fetched < $target_count) {
    $exclude_ids = array_map(function($p) { return $p->ID; }, $posts_to_show);
    $backfill_args = [
        'posts_per_page' => $target_count - $count_fetched,
        'post_status'    => 'publish',
        'post__not_in'   => $exclude_ids,
        'orderby'        => 'date',
        'order'          => 'DESC'
    ];
    $backfetch = new WP_Query($backfill_args);
    if ($backfetch->have_posts()) {
        while ($backfetch->have_posts()) {
            $backfetch->the_post();
            $posts_to_show[] = get_post();
        }
        wp_reset_postdata();
    }
}

if (!empty($posts_to_show)) :
?>
<section class="featured-wrapper">
    <!-- ⚡ 2040 NEXT-GEN INTERACTIVE OFFICIAL NOTICE & EARNINGS BLUEPRINT PORTAL ⚡ -->
    <div class="cyber-notice-portal-card">
        <div class="cyber-notice-glow-bar"></div>
        <div class="cyber-notice-body">
            
            <!-- Top Banner Row -->
            <div class="cyber-notice-header">
                <div class="notice-meta-badge">
                    <span class="notice-live-dot animate-pulse"></span>
                    <span class="notice-badge-text"><i class="fa-solid fa-bullhorn"></i> iLoveYouBD Official Notice</span>
                </div>
                <div class="notice-category-tag">iLoveYouBD Notice</div>
            </div>
            
            <div class="notice-main-content-grid">
                
                <!-- Left Hand Side: Portal Illustration & A-Z Interactive Guide -->
                <div class="notice-lhs-guide">
                    <div class="notice-illust-wrapper">
                        <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/cyber_earnings_illustration.jpg'); ?>" alt="Ecosystem Earnings Blueprint" class="notice-hero-img">
                        <div class="illust-overlay-glow"></div>
                        <h3 class="illust-title">iLoveYouBD কন্টেন্ট পাবলিশিং ও আর্নিং গাইডলাইন ২০২৬ (A-Z Complete Guide)</h3>
                    </div>
                    
                    <p class="notice-intro-p">
                        iloveyoubd.com-এ আপনাকে স্বাগতম। এটি একটি সম্পূর্ণ নিরাপদ, গুগল অ্যাডসেন্স ফ্রেন্ডলি এবং উচ্চ-গতির প্রযুক্তি ও মুক্ত তথ্যশালা। আমাদের এই ইউনিক ইকোসিস্টেমে আপনি আপনার আইটি জ্ঞান শেয়ার করে বা টেকনিক্যাল প্রশ্ন-উত্তর সেশনে অংশ নিয়ে বিকাশ বা নগদে সরাসরি উপার্জনের সুবিধা পাবেন। কন্ট্রিবিউটর হিসেবে যুক্ত হতে আমাদের এ থেকে জেড সম্পূর্ণ গাইডলাইন এবং পয়েন্ট হিসাব নিচে দেখে নিনঃ
                    </p>
                    
                    <!-- Interactive Tab Navigation -->
                    <div class="notice-interactive-tabs">
                        <div class="tabs-header-bar">
                            <button class="notice-tab-btn active" onclick="switchNoticeTab(event, 'notice-tab-1')">
                                <i class="fa-solid fa-user-shield"></i> ১. অ্যাকাউন্ট ও লগইন
                            </button>
                            <button class="notice-tab-btn" onclick="switchNoticeTab(event, 'notice-tab-2')">
                                <i class="fa-solid fa-pen-fancy"></i> ২. টিউন বা লেখা
                            </button>
                            <button class="notice-tab-btn" onclick="switchNoticeTab(event, 'notice-tab-3')">
                                <i class="fa-solid fa-comments"></i> ৩. ফোরাম ও নিউজ
                            </button>
                            <button class="notice-tab-btn" onclick="switchNoticeTab(event, 'notice-tab-4')">
                                <i class="fa-solid fa-wallet"></i> ৪. পেমেন্ট ও উইথড্র
                            </button>
                        </div>
                        
                        <div class="tabs-body-viewport">
                            <!-- Tab 1 -->
                            <div id="notice-tab-1" class="notice-tab-pane active-pane">
                                <div class="pane-split-layout">
                                    <div class="pane-icon-large"><i class="fa-solid fa-id-card-clip"></i></div>
                                    <div class="pane-text-desc">
                                        <h4>🔐 ড্যাশবোর্ড অ্যাক্টিভেশন ও সহজ রেজিস্ট্রেশন</h4>
                                        <p>আমাদের পোর্টালে যুক্ত হওয়া অত্যন্ত সহজ এবং ১০০% ফ্রি। অনুগ্রহ করে নিচের ধাপগুলো মেনে অ্যাকাউন্ট সক্রিয় করুনঃ</p>
                                        <ul>
                                            <li><span>■</span><strong>ইনস্ট্যান্ট অ্যাকাউন্ট তৈরি:</strong> সাইটের একদম উপরে ডানদিকের <strong>"লগইন / রেজিস্টার"</strong> বাটনে ক্লিক করে আপনার সচল ইমেইল ও পাসওয়ার্ড প্রদান করে মুহূর্তে অ্যাকাউন্ট রেজিস্টার করুন।</li>
                                            <li><span>■</span><strong>প্রোফাইল সাজানো (EEAT Compliance):</strong> লগইন সম্পন্ন হলে আপনার ড্যাশবোর্ডে প্রবেশ করে একটি সুন্দর বায়ো, আপনার সোশ্যাল মিডিয়া লিংক এবং একটি ইউনিক প্রোফাইল ছবি যুক্ত করুন। এটি গুগল সার্চ ইঞ্জিনে আপনার কন্টেন্টের রিচ ও ট্রাস্ট বহুগুণে বৃদ্ধি করবে।</li>
                                            <li><span>■</span><strong>নিরাপদ সেশন:</strong> আপনার অ্যাকাউন্টটি সম্পূর্ণ এনক্রিপ্টেড এবং স্প্যাম প্রোটেক্টেড। ডাবল সেশন বা বটের মাধ্যমে ফেক ইউজার তৈরি করলে সিস্টেম স্বয়ংক্রিয়ভাবে অ্যাকাউন্ট লক করে দেবে।</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Tab 2 -->
                            <div id="notice-tab-2" class="notice-tab-pane">
                                <div class="pane-split-layout">
                                    <div class="pane-icon-large font-cyan"><i class="fa-solid fa-scroll"></i></div>
                                    <div class="pane-text-desc">
                                        <h4>✍️ টিউন বা ইউনিক কন্টেন্ট লেখার স্পষ্ট নিয়মাবলী</h4>
                                        <p>iloveyoubd.com মানসম্মত ও এডসেন্স-সেফ কন্টেন্ট সবসময় অগ্রাধিকার দেয়। একটি পারফেক্ট টিউন লেখার প্রধান শর্তসমূহঃ</p>
                                        <ul>
                                            <li><span>■</span><strong>সম্পূর্ণ নিজের ভাষায় লেখা (Anti-AI):</strong> ChatGPT বা Gemini দ্বারা জেনারেট করা বা অন্য কোনো ব্লগ থেকে আংশিক বা পুরো কপি-পেস্ট টিউন আমাদের পোর্টালে সম্পূর্ণ নিষিদ্ধ। আপনার টিউন অবশ্যই আপনার নিজস্ব গবেষণার ওপর ভিত্তি করে তৈরি হতে হবে।</li>
                                            <li><span>■</span><strong>কমপক্ষে ৪০০+ শব্দের গঠনমূলক বিশ্লেষণ:</strong> যেকোনো প্রযুক্তি টিউটোরিয়াল, কোড সমাধান বা ট্রাবলশুটিং গাইডলাইন সাবমিট করার সময় বিষয়বস্তু ডিটেইলস সহ সুন্দর প্যারা আকারে উপস্থাপন করুন।</li>
                                            <li><span>■</span><strong>ফিচার ইমেজ ও মিডিয়া রুলস:</strong> টিউনের সাথে মানসম্মত এবং আকর্ষণীয় থাম্বনেইল ছবি সংযুক্ত করুন। এতে কন্টেন্টের ভিজ্যুয়াল রিচ বৃদ্ধি পাবে। কোনো প্রকার বিভ্রান্তিকর বা কপিরাইটযুক্ত ছবি আপলোড করা যাবে না।</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Tab 3 -->
                            <div id="notice-tab-3" class="notice-tab-pane">
                                <div class="pane-split-layout">
                                    <div class="pane-icon-large font-violet"><i class="fa-solid fa-circle-question"></i></div>
                                    <div class="pane-text-desc">
                                        <h4>💬 ফোরাম প্রশ্নোত্তর ও নিউজ আপডেট মডিউল</h4>
                                        <p>কন্টেন্ট রাইটিং ছাড়াও প্ল্যাটফর্মে অতিরিক্ত আর্নিং সেশন জেনারেট করার জন্য নিচের মডিউলগুলো ব্যবহার করুনঃ</p>
                                        <ul>
                                            <li><span>■</span><strong>ফোরাম প্রশ্ন (Asking Questions):</strong> প্রযুক্তি সংক্রান্ত যেকোনো জটিল সমস্যা সমাধানের জন্য আমাদের ফোরামে প্রশ্ন পোস্ট করুন। প্রতি প্রশ্নের জন্য আপনার পয়েন্ট একাউন্ট বৃদ্ধি পাবে।</li>
                                            <li><span>■</span><strong>সঠিক উত্তর প্রদান (Q&A Solutions):</strong> অন্য সদস্যদের প্রযুক্তিগত প্রশ্নের সঠিক সমাধান ও উপকারী উত্তর প্রদান করুন। আপনার উত্তর এক্সেপ্ট হলে আপনি পাবেন চমৎকার রিওয়ার্ড বোনাস।</li>
                                            <li><span>■</span><strong>টেক নিউজ ও আন্তর্জাতিক সংবাদ (News Bulletin):</strong> আইটি বা আন্তর্জাতিক সংবাদ নিজের ভাষায় সংক্ষিপ্ত আকারে লিখে প্রকাশ করতে পারেন। প্রতিটি খবরের আপডেটে আকর্ষণীয় পয়েন্ট রিওয়ার্ড প্রদান করা হবে।</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Tab 4 -->
                            <div id="notice-tab-4" class="notice-tab-pane">
                                <div class="pane-split-layout">
                                    <div class="pane-icon-large font-gold"><i class="fa-solid fa-sack-dollar"></i></div>
                                    <div class="pane-text-desc">
                                        <h4>💰 পয়েন্ট অর্থনীতি ও ১০০% সিকিউরড ক্যাশআউট পলিসি</h4>
                                        <p>iloveyoubd.com-এ প্রতিটি সঠিক কন্ট্রিবিউশন কাজের জন্য আপনি পাবেন সরাসরি নগদ রিওয়ার্ড কনভার্সন মেথডঃ</p>
                                        <ul>
                                            <li><span>■</span><strong>পয়েন্ট বিনিময় হার:</strong> আমাদের সিস্টেমে প্রতি <strong>১,০০০ পয়েন্ট = ১০০ টাকা (৳ ১০০)</strong> হিসেবে কনভার্ট হয়। প্রতিটি সাবমিশন লাইভ এপ্রুভ হওয়ার সাথে সাথে ড্যাশবোর্ডে পয়েন্ট জমা হয়।</li>
                                            <li><span>■</span><strong>উইথড্র থ্রেশহোল্ড:</strong> আপনার অ্যাকাউন্টে ন্যূনতম ৫০০ পয়েন্ট (৫০ টাকা) হলেই আপনি বিকাশ বা নগদ নম্বরে সরাসরি ক্যাশআউট রিকোয়েস্ট সাবমিট করতে পারবেন।</li>
                                            <li><span>■</span><strong>ইনস্ট্যান্ট গেটওয়ে:</strong> প্রতিদিনের ক্যাশআউট রিকোয়েস্টগুলো আমাদের ফিন্যান্স এডমিন প্যানেল দ্বারা সম্পূর্ণ ম্যানুয়ালি ও অত্যন্ত গুরুত্বের সাথে যাচাই করে সর্বোচ্চ ২৪ ঘণ্টার মধ্যে পরিশোধ করা হয়। কোনো প্রকার হিডেন ফিস বা কমিশন কাটা হয় না।</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Right Hand Side: Interactive Earnings Calculator -->
                <div class="notice-rhs-calculator">
                    <div class="calc-card">
                        <div class="calc-neon-top"></div>
                        <h4 class="calc-heading"><i class="fa-solid fa-calculator"></i> লাইভ পয়েন্ট ও আয় ক্যালকুলেটর</h4>
                        <p class="calc-sub">আপনি প্রতিদিন কত কাজ করে কত আয় করতে পারবেন তা লাইভ হিসাব করে দেখুন!</p>
                        
                        <div class="calc-inputs-container">
                            <!-- Input 1 -->
                            <div class="calc-input-row">
                                <div class="calc-label-meta">
                                    <span>✍️ টিউন/কন্টেন্ট সংখ্যা (প্রতিটি ২০ পয়েন্ট)</span>
                                    <span id="calc-val-tunes-txt" class="calc-count-badge">০ টি</span>
                                </div>
                                <input type="range" id="calc-range-tunes" min="0" max="30" value="0" oninput="updateEarningsCalc()" class="calc-slider">
                            </div>
                            
                            <!-- Input 2 -->
                            <div class="calc-input-row">
                                <div class="calc-label-meta">
                                    <span>📰 টেক নিউজ সংখ্যা (প্রতিটি ১০ পয়েন্ট)</span>
                                    <span id="calc-val-news-txt" class="calc-count-badge">০ টি</span>
                                </div>
                                <input type="range" id="calc-range-news" min="0" max="50" value="0" oninput="updateEarningsCalc()" class="calc-slider slider-violet">
                            </div>
                            
                            <!-- Input 3 -->
                            <div class="calc-input-row">
                                <div class="calc-label-meta">
                                    <span>💬 ফোরাম প্রশ্ন/উত্তর (প্রতিটি ৫ পয়েন্ট)</span>
                                    <span id="calc-val-qa-txt" class="calc-count-badge">০ টি</span>
                                </div>
                                <input type="range" id="calc-range-qa" min="0" max="100" value="0" oninput="updateEarningsCalc()" class="calc-slider slider-cyan">
                            </div>
                            
                            <!-- Input 4 -->
                            <div class="calc-input-row">
                                <div class="calc-label-meta">
                                    <span>👁️ আনুমানিক কন্টেন্ট ভিউ (প্রতি হাজার = ১০০ পয়েন্ট)</span>
                                    <span id="calc-val-views-txt" class="calc-count-badge">০K ভিউ</span>
                                </div>
                                <input type="range" id="calc-range-views" min="0" max="100" value="0" oninput="updateEarningsCalc()" class="calc-slider slider-gold">
                            </div>
                        </div>
                        
                        <!-- Reactive Total Display Card -->
                        <div class="calc-result-box">
                            <div class="result-stat">
                                <span class="result-title">মোট অর্জিত পয়েন্ট:</span>
                                <span id="calc-total-points" class="result-val font-cyan">০ পয়েন্ট</span>
                            </div>
                            <div class="result-divider"></div>
                            <div class="result-stat">
                                <span class="result-title text-gold">আনুমানিক আয় (টাকা):</span>
                                <span id="calc-total-taka" class="result-val font-gold">৳ ০.০০ টাকা</span>
                            </div>
                        </div>
                        
                        <!-- bKash / Nagad / Rocket logos custom display -->
                        <div class="gateway-icons-display">
                            <span>পেমেন্ট গেটওয়ে:</span>
                            <span class="gateway-badge badge-bkash">বিকাশ (bKash)</span>
                            <span class="gateway-badge badge-nagad">নগদ (Nagad)</span>
                            <span class="gateway-badge badge-rocket">রকেট (Rocket)</span>
                        </div>
                        
                        <!-- Safe CTA Button link to Register/Dashboard -->
                        <div class="calc-cta-wrapper">
                            <a href="<?php echo is_user_logged_in() ? esc_url(home_url('/dashboard/')) : esc_url(wp_registration_url()); ?>" class="calc-cta-btn">
                                <i class="fa-solid fa-circle-right"></i> <?php echo is_user_logged_in() ? 'আপনার ড্যাশবোর্ডে প্রবেশ করুন' : 'অ্যাকাউন্ট খুলে এখনই আয় শুরু করুন'; ?>
                            </a>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

    <!-- Notice CSS & JS Styles block -->
    <style>
    /* 2040 Next-Gen Notice Portal Card Styles */
    .cyber-notice-portal-card {
        background: linear-gradient(135deg, #070b13 0%, #0d1527 100%) !important;
        border: 1.5px solid rgba(0, 240, 255, 0.25) !important;
        border-radius: 16px !important;
        box-shadow: 0 12px 35px rgba(0, 0, 0, 0.6), inset 0 0 24px rgba(0, 240, 255, 0.05);
        margin-bottom: 35px;
        position: relative;
        overflow: hidden;
        transition: all 0.3s cubic-bezier(0.165, 0.84, 0.44, 1);
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    }
    .cyber-notice-portal-card:hover {
        border-color: #00f0ff !important;
        box-shadow: 0 16px 45px rgba(0, 240, 255, 0.2), inset 0 0 35px rgba(0, 240, 255, 0.08);
    }
    .cyber-notice-glow-bar {
        position: absolute;
        top: 0; left: 0; width: 100%; height: 4px;
        background: linear-gradient(90deg, #00f0ff, #00ff41, #bd00ff);
    }
    .cyber-notice-body {
        padding: 24px;
    }
    .cyber-notice-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-bottom: 1px solid rgba(255, 255, 255, 0.06);
        padding-bottom: 15px;
        margin-bottom: 20px;
    }
    .notice-meta-badge {
        display: inline-flex;
        align-items: center;
        gap: 8px;
    }
    .notice-live-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: #00ff41;
        box-shadow: 0 0 8px #00ff41;
    }
    .notice-badge-text {
        font-family: 'Space Grotesk', sans-serif;
        font-size: 13px;
        font-weight: 850;
        color: #e2e8f0;
        letter-spacing: 0.5px;
        text-transform: uppercase;
    }
    .notice-category-tag {
        font-family: 'JetBrains Mono', monospace;
        background: rgba(189, 0, 255, 0.1);
        border: 1px solid rgba(189, 0, 255, 0.3);
        color: #df80ff;
        padding: 4px 10px;
        border-radius: 6px;
        font-size: 10px;
        font-weight: 800;
        text-transform: uppercase;
    }
    
    .notice-main-content-grid {
        display: grid;
        grid-template-columns: 1.6fr 1.1fr;
        gap: 25px;
        align-items: flex-start;
    }
    
    /* LHS styles */
    .notice-lhs-guide {
        display: flex;
        flex-direction: column;
        gap: 15px;
    }
    .notice-illust-wrapper {
        position: relative;
        border-radius: 12px;
        overflow: hidden;
        height: 180px;
        border: 1px solid rgba(255, 255, 255, 0.08);
    }
    .notice-hero-img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.5s ease;
    }
    .notice-illust-wrapper:hover .notice-hero-img {
        transform: scale(1.04);
    }
    .illust-overlay-glow {
        position: absolute;
        inset: 0;
        background: linear-gradient(180deg, rgba(7, 11, 19, 0.2) 0%, rgba(7, 11, 19, 0.85) 100%);
    }
    .illust-title {
        position: absolute;
        bottom: 15px;
        left: 15px;
        right: 15px;
        margin: 0;
        color: #ffffff;
        font-size: 15.5px;
        font-weight: 800;
        font-family: 'Space Grotesk', sans-serif;
        text-shadow: 0 2px 4px rgba(0,0,0,0.8);
    }
    .notice-intro-p {
        color: #cbd5e1;
        font-size: 13px;
        line-height: 1.65;
        margin: 0;
        text-align: justify;
    }
    
    /* Interactive tabs styles */
    .notice-interactive-tabs {
        background: rgba(4, 7, 18, 0.4);
        border: 1px solid rgba(255, 255, 255, 0.05);
        border-radius: 12px;
        overflow: hidden;
        margin-top: 10px;
    }
    .tabs-header-bar {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        background: rgba(255, 255, 255, 0.02);
        border-bottom: 1px solid rgba(255, 255, 255, 0.06);
    }
    .notice-tab-btn {
        background: transparent;
        border: none;
        color: #94a3b8;
        padding: 12px 6px;
        font-size: 11.5px;
        font-weight: 700;
        cursor: pointer;
        transition: all 0.25s ease;
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 5px;
        border-bottom: 2px solid transparent;
        outline: none;
    }
    .notice-tab-btn i {
        font-size: 13px;
    }
    .notice-tab-btn:hover {
        color: #00f0ff;
        background: rgba(0, 240, 255, 0.03);
    }
    .notice-tab-btn.active {
        color: #00ff41;
        background: rgba(0, 255, 65, 0.03);
        border-bottom-color: #00ff41;
    }
    
    .tabs-body-viewport {
        padding: 18px;
    }
    .notice-tab-pane {
        display: none;
    }
    .notice-tab-pane.active-pane {
        display: block;
        animation: tabFadeIn 0.3s ease-out;
    }
    @keyframes tabFadeIn {
        from { opacity: 0; transform: translateY(5px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    .pane-split-layout {
        display: flex;
        gap: 15px;
        align-items: flex-start;
    }
    .pane-icon-large {
        font-size: 28px;
        color: #00f0ff;
        flex-shrink: 0;
        padding-top: 2px;
    }
    .font-cyan { color: #00f0ff !important; }
    .font-violet { color: #df80ff !important; }
    .font-gold { color: #fbbf24 !important; }
    
    .pane-text-desc h4 {
        margin: 0 0 8px 0;
        color: #ffffff;
        font-size: 14px;
        font-weight: 800;
    }
    .pane-text-desc p {
        margin: 0 0 12px 0;
        font-size: 12.5px;
        line-height: 1.6;
        color: #94a3b8;
    }
    .pane-text-desc ul {
        list-style-type: none;
        padding: 0;
        margin: 0;
        display: flex;
        flex-direction: column;
        gap: 8px;
    }
    .pane-text-desc li {
        font-size: 12.5px;
        line-height: 1.55;
        color: #cbd5e1;
        position: relative;
        padding-left: 15px;
    }
    .pane-text-desc li span {
        position: absolute;
        left: 0;
        color: #00ff41;
        font-size: 9px;
    }
    .pane-text-desc li strong {
        color: #ffffff;
    }
    
    /* RHS style */
    .notice-rhs-calculator {
        height: 100%;
    }
    .calc-card {
        background: rgba(4, 7, 18, 0.45);
        border: 1px solid rgba(0, 240, 255, 0.15);
        border-radius: 12px;
        padding: 18px;
        position: relative;
        overflow: hidden;
    }
    .calc-neon-top {
        position: absolute;
        top: 0; left: 0; width: 100%; height: 2px;
        background: #00f0ff;
    }
    .calc-heading {
        margin: 0 0 5px 0;
        color: #ffffff;
        font-size: 14px;
        font-weight: 850;
        display: flex;
        align-items: center;
        gap: 8px;
        font-family: 'Space Grotesk', sans-serif;
    }
    .calc-sub {
        margin: 0 0 20px 0;
        color: #94a3b8;
        font-size: 11.5px;
        line-height: 1.4;
    }
    
    .calc-inputs-container {
        display: flex;
        flex-direction: column;
        gap: 15px;
        margin-bottom: 22px;
    }
    .calc-input-row {
        display: flex;
        flex-direction: column;
        gap: 6px;
    }
    .calc-label-meta {
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 11px;
        color: #cbd5e1;
        font-weight: 600;
    }
    .calc-count-badge {
        font-family: 'JetBrains Mono', monospace;
        font-size: 11px;
        background: rgba(0, 255, 65, 0.1);
        border: 1px solid rgba(0, 255, 65, 0.25);
        color: #00ff41;
        padding: 2px 6px;
        border-radius: 4px;
        font-weight: 700;
    }
    
    /* Custom Stylings for standard input range slider */
    .calc-slider {
        -webkit-appearance: none;
        width: 100%;
        height: 5px;
        border-radius: 5px;
        background: #161b22;
        outline: none;
        transition: opacity .2s;
    }
    .calc-slider::-webkit-slider-thumb {
        -webkit-appearance: none;
        appearance: none;
        width: 14px;
        height: 14px;
        border-radius: 50%;
        background: #00ff41;
        cursor: pointer;
        box-shadow: 0 0 8px #00ff41;
        transition: transform 0.1s ease;
    }
    .calc-slider::-webkit-slider-thumb:hover {
        transform: scale(1.2);
    }
    
    .slider-violet::-webkit-slider-thumb { background: #bd00ff; box-shadow: 0 0 8px #bd00ff; }
    .slider-cyan::-webkit-slider-thumb { background: #00f0ff; box-shadow: 0 0 8px #00f0ff; }
    .slider-gold::-webkit-slider-thumb { background: #fbbf24; box-shadow: 0 0 8px #fbbf24; }
    
    .calc-input-row:has(.slider-violet) .calc-count-badge {
        background: rgba(189, 0, 255, 0.1); border-color: rgba(189, 0, 255, 0.25); color: #df80ff;
    }
    .calc-input-row:has(.slider-cyan) .calc-count-badge {
        background: rgba(0, 240, 255, 0.1); border-color: rgba(0, 240, 255, 0.25); color: #00f0ff;
    }
    .calc-input-row:has(.slider-gold) .calc-count-badge {
        background: rgba(251, 191, 36, 0.1); border-color: rgba(251, 191, 36, 0.25); color: #fbbf24;
    }
    
    /* Result card */
    .calc-result-box {
        background: rgba(7, 11, 19, 0.8);
        border: 1px solid rgba(255, 255, 255, 0.05);
        border-radius: 8px;
        padding: 14px;
        display: flex;
        flex-direction: column;
        gap: 10px;
        margin-bottom: 18px;
    }
    .result-stat {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    .result-title {
        font-size: 11.5px;
        color: #94a3b8;
        font-weight: 600;
    }
    .result-divider {
        height: 1px;
        background: rgba(255, 255, 255, 0.05);
    }
    .result-val {
        font-family: 'JetBrains Mono', monospace;
        font-size: 14px;
        font-weight: 800;
    }
    .text-gold { color: #fbbf24; }
    
    .gateway-icons-display {
        font-size: 10px;
        color: #94a3b8;
        display: flex;
        flex-wrap: wrap;
        gap: 6px;
        align-items: center;
        margin-bottom: 18px;
    }
    .gateway-badge {
        font-size: 9px;
        font-weight: bold;
        padding: 2px 6px;
        border-radius: 4px;
    }
    .badge-bkash { background: rgba(225, 16, 115, 0.1); border: 1px solid rgba(225, 16, 115, 0.25); color: #e11073; }
    .badge-nagad { background: rgba(247, 148, 29, 0.1); border: 1px solid rgba(247, 148, 29, 0.25); color: #f7941d; }
    .badge-rocket { background: rgba(140, 29, 142, 0.1); border: 1px solid rgba(140, 29, 142, 0.25); color: #c43cc7; }
    
    .calc-cta-wrapper {
        text-align: center;
    }
    .calc-cta-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        width: 100%;
        background: linear-gradient(135deg, #00ff41 0%, #00e5ff 100%);
        color: #000000 !important;
        border: none;
        padding: 11px 18px;
        border-radius: 8px;
        font-weight: 850;
        font-size: 12.5px;
        text-transform: uppercase;
        text-decoration: none !important;
        box-shadow: 0 4px 12px rgba(0, 255, 65, 0.3);
        transition: all 0.25s ease;
    }
    .calc-cta-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 18px rgba(0, 255, 65, 0.5);
    }
    
    /* Responsiveness Rules for Split Grid */
    @media (max-width: 991px) {
        .notice-main-content-grid {
            grid-template-columns: 1fr;
            gap: 20px;
        }
    }
    @media (max-width: 576px) {
        .cyber-notice-body {
            padding: 16px;
        }
        .tabs-header-bar {
            grid-template-columns: repeat(2, 1fr);
        }
        .notice-tab-btn {
            padding: 10px 4px;
            font-size: 11px;
        }
        .pane-split-layout {
            flex-direction: column;
            gap: 10px;
        }
        .pane-icon-large {
            font-size: 24px;
        }
    }
    </style>
    
    <!-- Notice Interactive Scripts -->
    <script>
    function switchNoticeTab(evt, tabId) {
        // Prevent default
        if (evt) evt.preventDefault();
        
        // Remove active class from all buttons inside this notice box
        var buttons = document.getElementsByClassName("notice-tab-btn");
        for (var i = 0; i < buttons.length; i++) {
            buttons[i].classList.remove("active");
        }
        
        // Remove active-pane class from all tab panes
        var panes = document.getElementsByClassName("notice-tab-pane");
        for (var i = 0; i < panes.length; i++) {
            panes[i].classList.remove("active-pane");
        }
        
        // Add active class to clicked button
        if (evt && evt.currentTarget) {
            evt.currentTarget.classList.add("active");
        }
        
        // Add active-pane class to targeted pane
        var activePane = document.getElementById(tabId);
        if (activePane) {
            activePane.classList.add("active-pane");
        }
    }
    
    function updateEarningsCalc() {
        var tunesInput = document.getElementById("calc-range-tunes");
        var newsInput = document.getElementById("calc-range-news");
        var qaInput = document.getElementById("calc-range-qa");
        var viewsInput = document.getElementById("calc-range-views");
        
        if (!tunesInput || !newsInput || !qaInput || !viewsInput) return;
        
        var tunesVal = parseInt(tunesInput.value);
        var newsVal = parseInt(newsInput.value);
        var qaVal = parseInt(qaInput.value);
        var viewsVal = parseInt(viewsInput.value); // 1 unit = 1K views
        
        // Update label text
        document.getElementById("calc-val-tunes-txt").innerText = tunesVal + " টি";
        document.getElementById("calc-val-news-txt").innerText = newsVal + " টি";
        document.getElementById("calc-val-qa-txt").innerText = qaVal + " টি";
        document.getElementById("calc-val-views-txt").innerText = viewsVal + "K ভিউ";
        
        // Calculate points
        // Tunes = 20 pts, News = 10 pts, QA = 5 pts, Views = 100 pts per 1K views (1000 views)
        var totalPoints = (tunesVal * 20) + (newsVal * 10) + (qaVal * 5) + (viewsVal * 100);
        
        // Conversion rate: 1000 points = 100 Taka
        var totalTaka = (totalPoints / 1000) * 100;
        
        // Update results UI
        document.getElementById("calc-total-points").innerText = totalPoints.toLocaleString() + " পয়েন্ট";
        document.getElementById("calc-total-taka").innerText = "৳ " + totalTaka.toFixed(2) + " টাকা";
    }
    </script>

    <h2 class="section-head-featured" style="margin:0; padding:0; border:none; font-weight:normal;">
        <div class="featured-indicator">
            <span class="pulse-dot"></span>
            <span class="label">⭐ FEATURED SHOWCASE</span>
        </div>
        <span class="line-featured"></span>
    </h2>

    <?php if (count($posts_to_show) === 1) : 
        $single_post = $posts_to_show[0];
        setup_postdata($single_post);
        $f_link = get_permalink($single_post->ID);
        $f_author_id = $single_post->post_author;
        $f_views = get_post_meta($single_post->ID, 'ilybd_post_views_count', true) ?: '0';
        $f_likes = get_post_meta($single_post->ID, '_likes', true) ?: '0';
        $f_comments = get_comments_number($single_post->ID);
        $f_cats = get_the_category($single_post->ID);
        $f_cat_name = !empty($f_cats) ? esc_html($f_cats[0]->name) : 'Tech';
        
        // Calculate actual dynamic reading time
        $content = get_post_field('post_content', $single_post->ID);
        $word_count = mb_strlen(strip_tags($content), 'UTF-8');
        $r_time = ceil($word_count / 350);
        if ($r_time < 1) $r_time = 1;
    ?>
        <div class="featured-single-container">
            <article class="bento-card featured-single-card">
                <div class="bento-media">
                    <a href="<?php echo $f_link; ?>">
                        <?php if (has_post_thumbnail($single_post->ID)) : ?>
                            <?php echo get_the_post_thumbnail($single_post->ID, 'large', ['alt' => get_the_title($single_post->ID)]); ?>
                        <?php else : ?>
                            <div class="bento-no-thumb">ILYBD PRO</div>
                        <?php endif; ?>
                    </a>
                    <span class="bento-cat-badge"><?php echo $f_cat_name; ?></span>
                    <div class="bento-accent-pill"><i class="fa-solid fa-crown"></i> TOP FEATURE</div>
                </div>
                <div class="bento-info">
                    <h2 class="bento-title">
                        <a href="<?php echo $f_link; ?>">
                            <?php echo esc_html(wp_trim_words(get_the_title($single_post->ID), 13, '...')); ?>
                        </a>
                    </h2>
                    <p class="bento-excerpt">
                        <?php echo esc_html(wp_trim_words(get_the_excerpt($single_post->ID), 22, '...')); ?>
                    </p>
                    
                    <div class="featured-glass-divider"></div>
                    
                    <div class="bento-footer">
                        <a href="<?php echo esc_url(get_author_posts_url($f_author_id)); ?>" class="bento-author">
                            <?php echo get_avatar($f_author_id, 24, '', '', array('class' => 'bento-avatar')); ?>
                            <span class="bento-author-name"><?php the_author_meta('display_name', $f_author_id); ?></span>
                        </a>
                        <div class="bento-stats">
                            <span class="bento-stat-badge"><i class="fa-regular fa-clock"></i> <?php echo $r_time; ?> Min</span>
                            <span class="bento-stat-badge"><i class="fa-regular fa-eye"></i> <?php echo $f_views; ?></span>
                            <span class="bento-stat-badge"><i class="fa-regular fa-heart"></i> <?php echo $f_likes; ?></span>
                            <span class="bento-stat-badge"><i class="fa-regular fa-comment"></i> <?php echo $f_comments; ?></span>
                        </div>
                    </div>
                </div>
            </article>

            <!-- Cyber Ecosystem Dashboard Widget Panel -->
            <div class="cyber-dashboard-widget">
                <div class="cyber-widget-glow-bar"></div>
                
                <div class="cyber-head">
                    <div class="cyber-title-row">
                        <span class="pulse-dot-cyan"></span>
                        <span class="cyber-panel-title"><i class="fa-solid fa-microchip text-cyan-glow"></i> IBD CYBER REALTIME</span>
                    </div>
                    <span class="cyber-status-text">ONLINE</span>
                </div>
                
                <!-- Dhaka Ticking Clock -->
                <div class="cyber-clock-box">
                    <div class="clock-display-row">
                        <div class="clock-icon-neon"><i class="fa-regular fa-clock"></i></div>
                        <div class="clock-time-vals" id="live-cyber-clock">00:00:00 AM</div>
                    </div>
                    <div class="clock-date-vals" id="live-cyber-date">Friday, 18 June 2026</div>
                </div>

                <!-- Ecosystem Diagnostic Stats -->
                <div class="cyber-diagnostics">
                    <div class="diag-item">
                        <span class="diag-icon-wrapper cyan-bg-glow"><i class="fa-solid fa-server"></i></span>
                        <div class="diag-meta-desc">
                            <span class="diag-title">HOST SYSTEM</span>
                            <span class="diag-value">CLOUD RUN CONTAINER</span>
                        </div>
                    </div>
                    <div class="diag-item">
                        <span class="diag-icon-wrapper violet-bg-glow"><i class="fa-solid fa-shield-halved"></i></span>
                        <div class="diag-meta-desc">
                            <span class="diag-title">COMMN CENTRAL FLOW</span>
                            <span class="diag-value">ACTIVE (SECURED SSL)</span>
                        </div>
                    </div>
                    <div class="diag-item">
                        <span class="diag-icon-wrapper emerald-bg-glow"><i class="fa-solid fa-circle-check"></i></span>
                        <div class="diag-meta-desc">
                            <span class="diag-title">GOOGLE ADSENSE SAFETY</span>
                            <span class="diag-value font-emerald">SAFE & AD-FRIENDLY ✔️</span>
                        </div>
                    </div>
                </div>

                <!-- Quick Tech Tags to Drive Search Traffic -->
                <div class="cyber-tag-index">
                    <div class="tag-title-label"><i class="fa-solid fa-magnifying-glass"></i> QUICK SECURE ACCESS</div>
                    <div class="tag-capsules">
                        <a href="<?php echo home_url('/?s=Android'); ?>" class="tag-cap cap-cyan">#Android</a>
                        <a href="<?php echo home_url('/?s=WordPress'); ?>" class="tag-cap cap-violet">#WordPress</a>
                        <a href="<?php echo home_url('/?s=SEO'); ?>" class="tag-cap cap-gold">#SEO</a>
                        <a href="<?php echo home_url('/?s=Blogging'); ?>" class="tag-cap cap-emerald">#Blogging</a>
                    </div>
                </div>

                <!-- Eco-Notice greeting with pristine Bengali -->
                <div class="cyber-sys-notice">
                    <div class="notice-meta">
                        <span class="notice-sender"><i class="fa-solid fa-user-shield"></i> SYSTEM STATUS</span>
                        <p class="notice-text">আইবিডি সাইবার নেক্সট-জেন ইকোসিস্টেমে স্বাগতম! নিরাপদ জ্ঞান প্রবাহ ও আর্নিং থ্রেশহোল্ড সেশন এখানে সচল রয়েছে।</p>
                    </div>
                </div>
            </div>
        </div>
        
        <script>
        document.addEventListener("DOMContentLoaded", function() {
            function initLiveDashboardClock() {
                var clockEl = document.getElementById('live-cyber-clock');
                var dateEl = document.getElementById('live-cyber-date');
                if (!clockEl || !dateEl) return;
                
                function tick() {
                    var now = new Date();
                    
                    // Format English Dhaka Time
                    var options = { timeZone: 'Asia/Dhaka', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true };
                    var timeString = now.toLocaleTimeString('en-US', options);
                    
                    var dateOptions = { timeZone: 'Asia/Dhaka', weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                    var dateString = now.toLocaleDateString('en-US', dateOptions);
                    
                    // Format Bengali Dhaka Time
                    var numbersBn = {'0':'০','1':'১','2':'২','3':'৩','4':'৪','5':'৫','6':'৬','7':'৭','8':'৮','9':'৯'};
                    var amPmBn = {'AM':'পূর্বাহ্ণ','PM':'অপরাহ্ণ'};
                    
                    var timeBn = timeString.replace(/[0-9]/g, function(w){ return numbersBn[w]; });
                    timeBn = timeBn.replace(/AM|PM/g, function(w){ return amPmBn[w] || w; });
                    
                    var dateBn = now.toLocaleDateString('bn-BD', { timeZone: 'Asia/Dhaka', weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
                    
                    clockEl.innerHTML = timeString + ' | ' + timeBn;
                    dateEl.innerHTML = dateString + ' • ' + dateBn;
                }
                
                tick();
                setInterval(tick, 1000);
            }
            initLiveDashboardClock();
        });
        </script>
    <?php else : ?>
        <div class="featured-bento-grid">
            <?php 
            $post_index = 0;
            global $post;
            foreach ($posts_to_show as $post) :
                setup_postdata($post);
                $post_index++;
                $f_link = get_permalink();
                $f_author_id = get_the_author_meta('ID');
                $f_views = get_post_meta(get_the_ID(), 'ilybd_post_views_count', true) ?: '0';
                $f_likes = get_post_meta(get_the_ID(), '_likes', true) ?: '0';
                $f_cats = get_the_category();
                $f_cat_name = !empty($f_cats) ? esc_html($f_cats[0]->name) : 'Tech';
                
                // Calculate actual dynamic reading time
                $content = get_post_field('post_content', get_the_ID());
                $word_count = mb_strlen(strip_tags($content), 'UTF-8');
                $r_time = ceil($word_count / 350);
                if ($r_time < 1) $r_time = 1;

                if ($post_index === 1) : 
                    // HERO BENTO CARD
                ?>
                    <article class="bento-card bento-hero">
                        <div class="bento-media">
                            <a href="<?php echo $f_link; ?>">
                                <?php if (has_post_thumbnail()) : ?>
                                    <?php the_post_thumbnail('large', ['alt' => get_the_title()]); ?>
                                <?php else : ?>
                                    <div class="bento-no-thumb">ILYBD PRO</div>
                                <?php endif; ?>
                            </a>
                            <span class="bento-cat-badge"><?php echo $f_cat_name; ?></span>
                            <div class="bento-accent-pill"><i class="fa-solid fa-crown"></i> TOP FEATURE</div>
                        </div>
                        <div class="bento-info">
                            <h2 class="bento-title">
                                <a href="<?php echo $f_link; ?>">
                                    <?php echo esc_html(wp_trim_words(get_the_title(), 13, '...')); ?>
                                </a>
                            </h2>
                            <p class="bento-excerpt">
                                <?php echo esc_html(wp_trim_words(get_the_excerpt(), 22, '...')); ?>
                            </p>
                            
                            <div class="featured-glass-divider"></div>
                            
                            <div class="bento-footer">
                                <a href="<?php echo esc_url(get_author_posts_url($f_author_id)); ?>" class="bento-author">
                                    <?php echo get_avatar($f_author_id, 24, '', '', array('class' => 'bento-avatar')); ?>
                                    <span class="bento-author-name"><?php the_author(); ?></span>
                                </a>
                                <div class="bento-stats">
                                    <span class="bento-stat-badge"><i class="fa-regular fa-clock"></i> <?php echo $r_time; ?> Min</span>
                                    <span class="bento-stat-badge"><i class="fa-regular fa-eye"></i> <?php echo $f_views; ?></span>
                                    <span class="bento-stat-badge"><i class="fa-regular fa-heart"></i> <?php echo $f_likes; ?></span>
                                </div>
                            </div>
                        </div>
                    </article>
                <?php else : 
                    // COMPANION ROW/CARD
                ?>
                    <article class="bento-card bento-item">
                        <div class="bento-media">
                            <a href="<?php echo $f_link; ?>">
                                <?php if (has_post_thumbnail()) : ?>
                                    <?php the_post_thumbnail('medium', ['alt' => get_the_title()]); ?>
                                <?php else : ?>
                                    <div class="bento-no-thumb">ILYBD PRO</div>
                                <?php endif; ?>
                            </a>
                            <span class="bento-cat-badge"><?php echo $f_cat_name; ?></span>
                        </div>
                        <div class="bento-info">
                            <h3 class="bento-title-small">
                                <a href="<?php echo $f_link; ?>">
                                    <?php echo esc_html(wp_trim_words(get_the_title(), 11, '...')); ?>
                                </a>
                            </h3>
                            
                            <div class="bento-footer">
                                <a href="<?php echo esc_url(get_author_posts_url($f_author_id)); ?>" class="bento-author">
                                    <?php echo get_avatar($f_author_id, 18, '', '', array('class' => 'bento-avatar')); ?>
                                    <span class="bento-author-name-small"><?php the_author(); ?></span>
                                </a>
                                <div class="bento-stats">
                                    <span class="bento-stat-badge-mini"><i class="fa-regular fa-eye"></i> <?php echo $f_views; ?></span>
                                    <span class="bento-stat-badge-mini"><i class="fa-regular fa-heart"></i> <?php echo $f_likes; ?></span>
                                </div>
                            </div>
                        </div>
                    </article>
                <?php endif; ?>
            <?php endforeach; wp_reset_postdata(); ?>
        </div>
    <?php endif; ?>
</section>

<style>
/* 2040 Cinematic Featured Bento Grid Styling */
.featured-wrapper {
    margin: 40px auto; 
    padding: 0 15px;
    max-width: 100%;
    box-sizing: border-box;
}

.section-head-featured { 
    display: flex; 
    align-items: center; 
    gap: 16px; 
    margin-bottom: 24px; 
}

.featured-indicator {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    background: rgba(189, 0, 255, 0.12);
    border: 1px solid rgba(189, 0, 255, 0.35);
    padding: 6px 14px;
    border-radius: 8px;
    box-shadow: 0 4px 15px rgba(189,0,255,0.15);
}

.section-head-featured .label { 
    color: #df80ff; 
    font-weight: 850; 
    font-size: 13.5px; 
    letter-spacing: 0.8px;
    text-transform: uppercase;
    font-family: 'Space Grotesk', sans-serif;
    text-shadow: 0 0 10px rgba(189,0,255,0.4);
}

.pulse-dot {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: #bd00ff;
    box-shadow: 0 0 8px #bd00ff;
    animation: featuredPulse 1.6s infinite ease-in-out;
}

@keyframes featuredPulse {
    0%, 100% { transform: scale(1); opacity: 1; box-shadow: 0 0 8px #bd00ff; }
    50% { transform: scale(1.3); opacity: 0.6; box-shadow: 0 0 14px #bd00ff; }
}

.section-head-featured .line-featured { 
    flex: 1; 
    height: 1.5px; 
    background: linear-gradient(90deg, #bd00ff, rgba(189, 0, 255, 0.05)); 
}

/* Bento Grid Setup */
.featured-bento-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    grid-gap: 20px;
}

/* Asymmetric Span on Widescreen */
.bento-hero {
    grid-column: span 2;
    grid-row: span 2;
    display: flex;
    flex-direction: column;
}

.bento-card {
    background: #081021 !important; /* Sapphire Deep blue, totally different from black latest-posts */
    border: 1px solid rgba(189, 0, 255, 0.2) !important; /* Elegant Neon Purple gradient glow border */
    border-radius: 16px !important;
    overflow: hidden !important;
    box-shadow: 0 12px 30px rgba(0,0,0,0.65), inset 0 0 20px rgba(189,0,255,0.06);
    transition: all 0.3s cubic-bezier(0.165, 0.84, 0.44, 1) !important;
    display: flex;
    flex-direction: column;
}

.bento-card:hover {
    transform: translateY(-5px) !important;
    border-color: #bd00ff !important;
    box-shadow: 0 16px 35px rgba(189, 0, 255, 0.25), inset 0 0 30px rgba(189,0,255,0.1) !important;
}

/* Media layout */
.bento-media {
    position: relative;
    overflow: hidden;
    background: #040712;
}

/* Maintain distinct aspect ratios */
.bento-hero .bento-media {
    height: 280px;
}

.bento-item .bento-media {
    height: 160px;
}

.bento-media img {
    width: 100% !important;
    height: 100% !important;
    object-fit: cover !important;
    transition: transform 0.6s cubic-bezier(0.165, 0.84, 0.44, 1) !important;
}

.bento-card:hover .bento-media img {
    transform: scale(1.08) !important;
}

.bento-cat-badge {
    position: absolute;
    top: 14px;
    left: 14px;
    background: rgba(8, 16, 33, 0.8);
    backdrop-filter: blur(6px);
    -webkit-backdrop-filter: blur(6px);
    border: 1px solid rgba(189, 0, 255, 0.4);
    color: #df80ff !important;
    font-size: 10px;
    font-weight: 850;
    padding: 3px 10px;
    border-radius: 6px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.bento-accent-pill {
    position: absolute;
    top: 14px;
    right: 14px;
    background: linear-gradient(135deg, #bd00ff 0%, #ff007c 100%) !important;
    color: #fff !important;
    font-size: 9.5px;
    font-weight: 900;
    padding: 4px 10px;
    border-radius: 6px;
    display: inline-flex;
    align-items: center;
    gap: 4px;
    box-shadow: 0 4px 10px rgba(189,0,255,0.4);
}

/* Info structure */
.bento-info {
    padding: 20px;
    flex: 1;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}

.bento-item .bento-info {
    padding: 14px;
}

/* Title system */
.bento-title {
    font-size: 20px !important;
    font-weight: 900 !important;
    line-height: 1.4 !important;
    margin: 0 0 10px 0 !important;
    font-family: 'Space Grotesk', sans-serif !important;
}

.bento-title a, .bento-title-small a {
    color: #ffffff !important;
    text-decoration: none !important;
    transition: color 0.25s ease;
}

.bento-title a:hover, .bento-title-small a:hover {
    color: #df80ff !important;
    text-shadow: 0 0 8px rgba(189,0,255,0.4);
}

.bento-title-small {
    font-size: 14.5px !important;
    font-weight: 800 !important;
    line-height: 1.4 !important;
    margin: 0 0 10px 0 !important;
    overflow: hidden !important;
    display: -webkit-box !important;
    -webkit-line-clamp: 2 !important;
    -webkit-box-orient: vertical !important;
}

.bento-excerpt {
    font-size: 13.5px !important;
    line-height: 1.55 !important;
    color: #94a3b8 !important;
    margin: 0 0 16px 0 !important;
    font-family: 'Hind Siliguri', sans-serif !important;
}

.featured-glass-divider {
    height: 1px;
    width: 100%;
    background: linear-gradient(90deg, transparent, rgba(189, 0, 255, 0.2) 20%, rgba(189, 0, 255, 0.2) 80%, transparent);
    margin-bottom: 16px;
}

/* Footer components */
.bento-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    margin-top: auto;
}

.bento-author {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    text-decoration: none;
    min-width: 0;
}

.bento-avatar {
    border-radius: 50% !important;
    border: 1px solid rgba(189, 0, 255, 0.4) !important;
}

.bento-author-name {
    font-size: 11.5px;
    font-weight: 800;
    color: #cbd5e1;
    white-space: normal; /* wrap instead of truncate */
}

.bento-author-name-small {
    font-size: 10px;
    font-weight: 800;
    color: #94a3b8;
    white-space: normal; /* wrap instead of truncate */
}

.bento-stats {
    display: flex;
    align-items: center;
    gap: 6px;
    flex-shrink: 0;
}

.bento-stat-badge {
    background: rgba(255, 255, 255, 0.03) !important;
    border: 1px solid rgba(255, 255, 255, 0.06) !important;
    font-family: 'JetBrains Mono', monospace !important;
    font-size: 9px !important;
    font-weight: 700;
    color: #94a3b8 !important;
    padding: 3px 6px !important;
    border-radius: 4px !important;
    display: inline-flex !important;
    align-items: center !important;
    gap: 3px;
}

.bento-stat-badge-mini {
    font-family: 'JetBrains Mono', monospace !important;
    font-size: 9px !important;
    font-weight: 700;
    color: #64748b;
    display: inline-flex !important;
    align-items: center !important;
    gap: 2.5px;
}

/* Single Featured Layout (62% Left, 35% Right) styling */
.featured-single-container {
    display: flex;
    flex-wrap: wrap;
    gap: 24px;
    width: 100%;
    align-items: stretch;
}

.featured-single-card {
    flex: 1 1 60%;
    min-width: 320px;
    background: #081021 !important;
    border: 1.5px solid rgba(189, 0, 255, 0.25) !important;
    border-radius: 16px;
    box-shadow: 0 12px 35px rgba(0, 0, 0, 0.65), inset 0 0 20px rgba(189, 0, 255, 0.05);
}

.featured-single-card .bento-media {
    height: 280px;
}

.cyber-dashboard-widget {
    flex: 1 1 35%;
    min-width: 290px;
    background: linear-gradient(135deg, #070b13 0%, #0d1527 100%) !important;
    border: 1.5px solid rgba(0, 240, 255, 0.25) !important;
    border-radius: 16px;
    padding: 20px;
    box-shadow: 0 12px 35px rgba(0,0,0,0.65), inset 0 0 24px rgba(0, 240, 255, 0.05) !important;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    box-sizing: border-box;
    position: relative;
    overflow: hidden;
    transition: all 0.3s cubic-bezier(0.165, 0.84, 0.44, 1);
}

.cyber-dashboard-widget:hover {
    border-color: #00f0ff !important;
    box-shadow: 0 16px 40px rgba(0, 240, 255, 0.2), inset 0 0 30px rgba(0, 240, 255, 0.08) !important;
}

/* Accent neon bar at the top of the widget */
.cyber-widget-glow-bar {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 3px;
    background: linear-gradient(90deg, #00f0ff, #bd00ff);
}

.cyber-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid rgba(255, 255, 255, 0.06);
    padding-bottom: 12px;
    margin-bottom: 12px;
}

.cyber-title-row {
    display: flex;
    align-items: center;
    gap: 8px;
}

.pulse-dot-cyan {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: #00f0ff;
    box-shadow: 0 0 10px #00f0ff;
    animation: cyanPulse 1.8s infinite ease-in-out;
}

@keyframes cyanPulse {
    0%, 100% { transform: scale(1); opacity: 1; box-shadow: 0 0 8px #00f0ff; }
    50% { transform: scale(1.3); opacity: 0.5; box-shadow: 0 0 16px #00f0ff; }
}

.cyber-panel-title {
    font-size: 12.5px;
    font-weight: 850;
    font-family: 'Space Grotesk', sans-serif;
    color: #e2e8f0;
    letter-spacing: 0.5px;
}

.text-cyan-glow {
    color: #00f0ff !important;
    text-shadow: 0 0 8px rgba(0, 240, 255, 0.4);
}

.cyber-status-text {
    font-family: 'JetBrains Mono', monospace;
    font-size: 9px;
    font-weight: 800;
    background: rgba(0, 240, 255, 0.1);
    color: #00f0ff;
    border: 1px solid rgba(0, 240, 255, 0.3);
    padding: 2.5px 6px;
    border-radius: 4px;
}

/* Digital clock stylings */
.cyber-clock-box {
    background: rgba(4, 7, 18, 0.6) !important;
    border: 1px solid rgba(255, 255, 255, 0.05);
    border-radius: 12px;
    padding: 12px 14px;
    margin-bottom: 14px;
    text-align: center;
}

.clock-display-row {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    margin-bottom: 4px;
}

.clock-icon-neon {
    font-size: 14px;
    color: #00f0ff;
    animation: rotateHourglass 4s infinite linear;
}

@keyframes rotateHourglass {
    0%, 90% { transform: rotate(0deg); }
    100% { transform: rotate(180deg); }
}

.clock-time-vals {
    font-family: 'JetBrains Mono', monospace;
    font-size: 15px;
    font-weight: 800;
    color: #ffffff;
    text-shadow: 0 0 10px rgba(0, 240, 255, 0.4);
    letter-spacing: 0.5px;
}

.clock-date-vals {
    font-size: 10px;
    color: #94a3b8;
    font-weight: 600;
}

/* System diagnostics indicators row */
.cyber-diagnostics {
    display: flex;
    flex-direction: column;
    gap: 8.5px;
    margin-bottom: 14px;
}

.diag-item {
    display: flex;
    align-items: center;
    gap: 10px;
    background: rgba(255, 255, 255, 0.02);
    border: 1px solid rgba(255, 255, 255, 0.04);
    padding: 8px 12px;
    border-radius: 10px;
}

.diag-icon-wrapper {
    width: 25px;
    height: 25px;
    border-radius: 6px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 11px;
}

.cyan-bg-glow {
    background: rgba(0, 240, 255, 0.1);
    color: #00f0ff;
    border: 1px solid rgba(0, 240, 255, 0.2);
}

.violet-bg-glow {
    background: rgba(189, 0, 255, 0.1);
    color: #df80ff;
    border: 1px solid rgba(189, 0, 255, 0.2);
}

.emerald-bg-glow {
    background: rgba(16, 185, 129, 0.1);
    color: #34d399;
    border: 1px solid rgba(16, 185, 129, 0.2);
}

.diag-meta-desc {
    display: flex;
    flex-direction: column;
}

.diag-title {
    font-size: 8.5px;
    color: #64748b;
    font-weight: 800;
    letter-spacing: 0.5px;
    font-family: 'Space Grotesk', sans-serif;
}

.diag-value {
    font-size: 11px;
    font-weight: 800;
    color: #cbd5e1;
    font-family: 'JetBrains Mono', monospace;
}

.font-emerald {
    color: #34d399 !important;
}

/* Cyber Tag Capsules */
.cyber-tag-index {
    margin-bottom: 14px;
}

.tag-title-label {
    font-size: 9.5px;
    color: #94a3b8;
    font-weight: 850;
    margin-bottom: 8px;
    display: flex;
    align-items: center;
    gap: 5px;
    font-family: 'Space Grotesk', sans-serif;
}

.tag-capsules {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
}

.tag-cap {
    font-family: 'JetBrains Mono', monospace;
    font-size: 10px;
    font-weight: 700;
    padding: 3.5px 8px;
    border-radius: 6px;
    text-decoration: none !important;
    transition: all 0.2s ease;
}

.cap-cyan { background: rgba(0, 240, 255, 0.05); border: 1px solid rgba(0, 240, 255, 0.15); color: #00f0ff !important; }
.cap-cyan:hover { background: rgba(0, 240, 255, 0.15); border-color: #00f0ff; box-shadow: 0 0 8px rgba(0,240,255,0.3); }

.cap-violet { background: rgba(189, 0, 255, 0.05); border: 1px solid rgba(189, 0, 255, 0.15); color: #df80ff !important; }
.cap-violet:hover { background: rgba(189, 0, 255, 0.15); border-color: #bd00ff; box-shadow: 0 0 8px rgba(189,0,255,0.3); }

.cap-gold { background: rgba(251, 191, 36, 0.05); border: 1px solid rgba(251, 191, 36, 0.15); color: #fbbf24 !important; }
.cap-gold:hover { background: rgba(251, 191, 36, 0.15); border-color: #fbbf24; box-shadow: 0 0 8px rgba(251,191,36,0.3); }

.cap-emerald { background: rgba(16, 185, 129, 0.05); border: 1px solid rgba(16, 185, 129, 0.15); color: #34d399 !important; }
.cap-emerald:hover { background: rgba(16, 185, 129, 0.15); border-color: #34d399; box-shadow: 0 0 8px rgba(16,185,129,0.3); }

/* Greeting custom box */
.cyber-sys-notice {
    background: rgba(18, 24, 38, 0.5) !important;
    border-left: 3px solid #00f0ff;
    border-radius: 0 10px 10px 0;
    padding: 10px 12px;
}

.notice-sender {
    display: flex;
    align-items: center;
    gap: 5px;
    font-size: 8.5px;
    color: #00f0ff;
    font-weight: 850;
    margin-bottom: 3.5px;
    letter-spacing: 0.5px;
}

.notice-text {
    font-size: 11px !important;
    line-height: 1.45 !important;
    color: #94a3b8 !important;
    margin: 0 !important;
    font-family: 'Hind Siliguri', sans-serif !important;
}

/* RESPONSIVE DESIGN BREAKPOINTS */
@media (max-width: 1024px) {
    .featured-bento-grid {
        grid-template-columns: repeat(2, 1fr);
    }
    .bento-hero {
        grid-column: span 2;
        grid-row: span 1;
    }
}

@media (max-width: 900px) {
    .featured-single-card {
        flex: 1 1 100%;
    }
    .cyber-dashboard-widget {
        flex: 1 1 100%;
    }
}

@media (max-width: 768px) {
    .featured-single-card .bento-media {
        height: 185px;
    }
    .featured-bento-grid {
        grid-template-columns: 1fr;
        grid-gap: 16px;
    }
    .bento-hero {
        grid-column: span 1;
    }
    .bento-hero .bento-media {
        height: 180px;
    }
    .bento-title {
        font-size: 16px !important;
    }
    .bento-excerpt {
        font-size: 12.5px !important;
    }
    .bento-item .bento-media {
        height: 140px;
    }
}
</style>
<?php endif; ?>
