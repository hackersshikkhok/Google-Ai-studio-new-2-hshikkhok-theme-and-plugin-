<?php get_header(); ?>

<div class="ilybd-container">
    <div class="cat-archive-header">
        <h1 class="archive-title">
            <span class="glitch-text">CATEGORY:</span> 
            <?php single_cat_title(); ?>
        </h1>
        <div class="archive-description">
            <?php echo category_description(); ?>
        </div>
    </div>

    <?php 
    $cat = get_queried_object();
    if (is_category() && (strtolower($cat->slug) === 'ai' || strtolower($cat->name) === 'ai')) : 
    ?>
    <!-- Maya AI Flagship Suite Banner -->
    <div class="maya-ai-flagship-showcase" style="margin-bottom: 35px; background: linear-gradient(135deg, rgba(13,21,39,0.95), rgba(7,11,19,0.95)); border: 1px solid rgba(0,240,255,0.3); border-radius: 16px; padding: 25px; box-shadow: 0 10px 30px rgba(0,240,255,0.15);">
        <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom: 20px; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 12px; flex-wrap:wrap; gap:10px;">
            <h2 style="color: #00f0ff; margin:0; font-size: 22px; font-weight: 800; display:flex; align-items:center; gap: 10px; font-family: 'Space Grotesk', sans-serif;">
                <span style="font-size:26px;">🤖</span> ILOVEYOUBD Flagship AI Chatbot Workspace
            </h2>
            <span style="background: rgba(0,240,255,0.15); color:#00f0ff; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: bold; border: 1px solid rgba(0,240,255,0.3);">
                Official AI Bots
            </span>
        </div>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 18px;">
            <!-- Card 1: Maya -->
            <a href="<?php echo home_url('/maya/'); ?>" style="text-decoration:none; background: rgba(15,23,42,0.8); border: 1px solid rgba(0,240,255,0.25); border-radius: 12px; padding: 18px; display:flex; flex-direction:column; gap:10px; transition:all 0.3s;">
                <div style="display:flex; align-items:center; justify-content:space-between;">
                    <span style="font-size:24px;">💬</span>
                    <span style="background:#00f0ff22; color:#00f0ff; font-size:11px; padding:2px 8px; border-radius:10px; font-weight:bold;">Standard Bot</span>
                </div>
                <h3 style="color:#fff; margin:0; font-size:18px; font-weight:700;">Maya (মায়া)</h3>
                <p style="color:#94a3b8; margin:0; font-size:13px; line-height:1.5;">বিনামূল্যে বাংলা চ্যাটবট। যেকোনো প্রশ্ন-উত্তর, কন্টেন্ট রাইটিং ও গাইড।</p>
                <span style="color:#00f0ff; font-size:13px; font-weight:bold; margin-top:auto;">চ্যাট শুরু করুন →</span>
            </a>

            <!-- Card 2: Maya AI -->
            <a href="<?php echo home_url('/maya-ai/'); ?>" style="text-decoration:none; background: rgba(15,23,42,0.8); border: 1px solid rgba(168,85,247,0.35); border-radius: 12px; padding: 18px; display:flex; flex-direction:column; gap:10px; transition:all 0.3s;">
                <div style="display:flex; align-items:center; justify-content:space-between;">
                    <span style="font-size:24px;">🔍</span>
                    <span style="background:#a855f722; color:#a855f7; font-size:11px; padding:2px 8px; border-radius:10px; font-weight:bold;">Search Engine</span>
                </div>
                <h3 style="color:#fff; margin:0; font-size:18px; font-weight:700;">Maya AI (মায়া এআই)</h3>
                <p style="color:#94a3b8; margin:0; font-size:13px; line-height:1.5;">গুগল রিয়েল-টাইম লাইভ সার্চ গ্রাউন্ডিং দিয়ে স্মার্ট সার্চ ও এআই আনসার।</p>
                <span style="color:#a855f7; font-size:13px; font-weight:bold; margin-top:auto;">সার্চ করুন →</span>
            </a>

            <!-- Card 3: Maya Pro AI -->
            <a href="<?php echo home_url('/maya-pro/'); ?>" style="text-decoration:none; background: rgba(15,23,42,0.8); border: 1px solid rgba(236,72,153,0.35); border-radius: 12px; padding: 18px; display:flex; flex-direction:column; gap:10px; transition:all 0.3s;">
                <div style="display:flex; align-items:center; justify-content:space-between;">
                    <span style="font-size:24px;">🚀</span>
                    <span style="background:#ec489922; color:#ec4899; font-size:11px; padding:2px 8px; border-radius:10px; font-weight:bold;">Flagship Gemini App</span>
                </div>
                <h3 style="color:#fff; margin:0; font-size:18px; font-weight:700;">Maya Pro AI (মায়া প্রো)</h3>
                <p style="color:#94a3b8; margin:0; font-size:13px; line-height:1.5;">লাইভ ভয়েস চ্যাট, ক্যামেরা ভিশন, কোডিং ও জিমেইল ১-ক্লিক সিঙ্ক।</p>
                <span style="color:#ec4899; font-size:13px; font-weight:bold; margin-top:auto;">প্রো ওয়ার্কস্পেস খুলুন →</span>
            </a>
        </div>
    </div>
    <?php endif; ?>

    <div class="ilybd-feed ilybd-post-grid-system">
        <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
            <?php get_template_part('template-parts/post-card'); ?>
        <?php endwhile; else : ?>
            <div class="no-posts">
                <p>দুঃখিত, এই ক্যাটাগরিতে এখনো কোনো পোস্ট করা হয়নি।</p>
            </div>
        <?php endif; ?>
    </div>

    <div class="cyber-pagination">
        <?php 
        the_posts_pagination(array(
            'mid_size'  => 2,
            'prev_text' => __('« পূর্ববর্তী', 'ilybd-neon'),
            'next_text' => __('পরবর্তী »', 'ilybd-neon'),
        )); 
        ?>
    </div>
</div>

<style>
.ilybd-container {
    max-width: 1100px;
    margin: 30px auto;
    padding: 0 15px;
    color: #fff;
}

.cat-archive-header {
    background: rgba(0, 255, 136, 0.05);
    padding: 30px;
    border-left: 5px solid #00ff88;
    margin-bottom: 40px;
    border-radius: 0 15px 15px 0;
}

.archive-title {
    font-size: 28px;
    margin: 0;
    color: #00ff88;
}

.glitch-text { color: #fff; opacity: 0.7; }

.post-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 25px;
}

.cyber-post-card {
    background: #0d1117;
    border: 1px solid rgba(0, 255, 136, 0.1);
    border-radius: 15px;
    overflow: hidden;
    transition: 0.3s;
}

.cyber-post-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 10px 30px rgba(0, 255, 136, 0.2);
    border-color: #00ff88;
}

.post-thumb img {
    width: 100%;
    height: 200px;
    object-fit: cover;
}

.post-details { padding: 20px; }

.post-title a {
    color: #fff;
    text-decoration: none;
    font-size: 20px;
    font-weight: 700;
}

.post-title a:hover { color: #00ff88; }

.post-meta {
    font-size: 12px;
    color: #888;
    margin: 10px 0;
}

.post-excerpt {
    font-size: 14px;
    line-height: 1.6;
    color: #ccc;
    margin-bottom: 20px;
}

.read-more-btn {
    display: inline-block;
    padding: 8px 20px;
    background: #00ff88;
    color: #000;
    font-weight: 700;
    border-radius: 5px;
    text-decoration: none;
}

.no-posts {
    text-align: center;
    padding: 50px;
    background: #1a1f26;
    border-radius: 15px;
}
</style>

<?php get_footer(); ?>
