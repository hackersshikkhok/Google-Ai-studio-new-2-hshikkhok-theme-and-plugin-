<?php
/**
 * Template Name: Live Sports Pro
 * Description: Fully Professional SEO-Optimized AdSense-Safe Live Sports Scores, Prediction, & Fan Chat Lounge Template
 */

get_header();
$neon = get_option('ilybd_main_color', '#00ff41');
$accent = get_option('ilybd_secondary_color', '#00f0ff');
?>

<style>
/* 2040 Futuristic Sports Center CSS Layout */
.sports-page-wrapper {
    background-color: #070b13;
    color: #e2e8f0;
    font-family: 'Inter', sans-serif;
    padding: 30px 20px;
    margin-top: 110px; /* Safe space below fixed header for desktop */
    position: relative;
    overflow: hidden;
}

.sports-grid-container {
    max-width: 1200px;
    margin: 0 auto;
    display: grid;
    grid-template-columns: 1fr;
    gap: 30px;
}

@media (min-width: 992px) {
    .sports-grid-container {
        grid-template-columns: 350px 1fr;
    }
}

/* ⚡ Mobile-First Order Adjustment & Safe Spacing for Header ⚡ */
@media (max-width: 991px) {
    .sports-page-wrapper {
        margin-top: 140px; /* Safe space for tall mobile navigation menu layout */
        padding: 20px 12px;
    }
    .sports-grid-container {
        display: flex;
        flex-direction: column;
    }
    .sports-main-console {
        order: 1; /* Main active match console gets placed at the absolute top on mobile */
    }
    .sports-left-sidebar {
        order: 2; /* Sidebar (all other matches lists and ads) follows below */
    }
}

/* Header & Accent styles */
.sports-hub-header {
    text-align: left;
    border-bottom: 1px solid rgba(0, 240, 255, 0.15);
    padding-bottom: 25px;
    margin-bottom: 30px;
}

.sports-badge-cyber {
    display: inline-block;
    font-size: 10px;
    font-family: monospace;
    letter-spacing: 2px;
    color: #00f0ff;
    background: rgba(0, 240, 255, 0.08);
    padding: 4px 12px;
    border: 1px solid rgba(0, 240, 255, 0.2);
    border-radius: 4px;
    text-transform: uppercase;
    font-weight: bold;
    margin-bottom: 12px;
}

.sports-hub-title {
    font-size: 28px;
    font-weight: 800;
    margin: 0;
    background: linear-gradient(135deg, #00f0ff, #8b5cf6, #39ff14);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    text-shadow: 0 0 25px rgba(0, 240, 255, 0.15);
}

.sports-hub-subtext {
    font-size: 13px;
    color: #a0aec0;
    margin-top: 6px;
    font-family: 'Hind Siliguri', sans-serif;
}

/* Compliance Banner */
.compliance-shield-box {
    background: rgba(16, 185, 129, 0.05);
    border: 1px solid rgba(16, 185, 129, 0.25);
    border-radius: 10px;
    padding: 18px;
    margin-bottom: 30px;
    display: flex;
    gap: 15px;
    align-items: flex-start;
}

.compliance-shield-icon {
    font-size: 24px;
    color: #39ff14;
    animation: pulse-glow 2s infinite;
}

.compliance-shield-content h4 {
    margin: 0 0 5px 0;
    font-size: 12.5px;
    font-weight: bold;
    text-transform: uppercase;
    letter-spacing: 1.5px;
    color: #39ff14;
    font-family: monospace;
}

.compliance-shield-content p {
    margin: 0;
    font-size: 12.5px;
    line-height: 1.6;
    color: #cbd5e0;
    font-family: 'Hind Siliguri', sans-serif;
}

/* Tabs Bar */
.sports-tab-bar {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.08);
    padding-bottom: 12px;
    margin-bottom: 25px;
}

.sports-tab-btn {
    background: #0d1527;
    border: 1px solid rgba(0, 240, 255, 0.1);
    color: #a0aec0;
    padding: 8px 16px;
    border-radius: 6px;
    font-size: 12.5px;
    font-family: monospace;
    cursor: pointer;
    transition: all 0.3s ease;
}

.sports-tab-btn.active, .sports-tab-btn:hover {
    background: rgba(0, 240, 255, 0.1);
    border-color: #00f0ff;
    color: #fff;
    box-shadow: 0 0 10px rgba(0, 240, 255, 0.1);
}

/* Cards & Layout */
.sports-bento-card {
    background: rgba(13, 21, 39, 0.6);
    border: 1px solid rgba(0, 240, 255, 0.08);
    border-radius: 12px;
    padding: 20px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.4);
    position: relative;
}

.match-item {
    background: rgba(5, 9, 18, 0.7);
    border: 1px solid rgba(255, 255, 255, 0.04);
    border-radius: 8px;
    padding: 14px;
    margin-bottom: 12px;
    cursor: pointer;
    transition: all 0.25s ease;
}

.match-item:hover, .match-item.active {
    background: rgba(12, 22, 36, 0.9);
    border-color: rgba(0, 240, 255, 0.4);
}

.match-header {
    display: flex;
    justify-content: space-between;
    font-size: 10px;
    font-family: monospace;
    color: #718096;
    margin-bottom: 8px;
}

.live-indicator {
    background: rgba(239, 68, 68, 0.15);
    color: #f87171;
    border: 1px solid rgba(239, 68, 68, 0.4);
    padding: 1px 6px;
    border-radius: 3px;
    animation: blink-anim 1.5s infinite;
}

.match-body-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.match-team {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 13px;
    font-weight: 600;
}

.match-score {
    font-size: 16px;
    font-family: monospace;
    font-weight: 800;
    color: #00f0ff;
}

/* Simulation Section & Stats */
.simulation-main-board {
    background: linear-gradient(180deg, rgba(12, 22, 36, 0.8) 0%, rgba(5, 9, 18, 0.9) 100%);
    border: 1px solid rgba(0, 240, 255, 0.15);
    border-radius: 12px;
    padding: 25px;
    text-align: center;
    margin-bottom: 25px;
}

.stats-bar-wrapper {
    margin-top: 20px;
    font-family: monospace;
    font-size: 12px;
}

.stats-label-row {
    display: flex;
    justify-content: space-between;
    color: #cbd5e0;
    margin-bottom: 6px;
}

.stats-bar-outer {
    height: 8px;
    background: #090d16;
    border-radius: 10px;
    overflow: hidden;
    display: flex;
}

.stats-bar-inner-home {
    background: linear-gradient(90deg, #00bcff, #00f0ff);
    transition: width 0.5s ease;
}

.stats-bar-inner-away {
    background: linear-gradient(90deg, #8b5cf6, #d946ef);
    transition: width 0.5s ease;
}

/* Comments Chat Area */
.chat-lounge-box {
    display: flex;
    flex-direction: column;
    height: 380px;
}

.chat-history {
    flex-grow: 1;
    overflow-y: auto;
    padding-right: 5px;
}

.chat-bubble {
    display: flex;
    gap: 12px;
    margin-bottom: 15px;
    align-items: flex-start;
}

.chat-avatar {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    background: #14213d;
    border: 1px solid rgba(0,240,255,0.2);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 16px;
}

.chat-bubble-content {
    background: rgba(5, 9, 18, 0.5);
    border: 1px solid rgba(0, 240, 255, 0.05);
    padding: 12px;
    border-radius: 8px;
    max-width: 85%;
}

.chat-meta {
    display: flex;
    gap: 8px;
    align-items: center;
    font-size: 10px;
    font-family: monospace;
    margin-bottom: 5px;
}

.chat-badge {
    background: linear-gradient(135deg, #00f0ff, #8b5cf6);
    color: #fff;
    font-size: 8px;
    padding: 1px 6px;
    border-radius: 3px;
    font-weight: bold;
}

.chat-text {
    font-size: 13px;
    color: #e2e8f0;
    line-height: 1.5;
    font-family: 'Hind Siliguri', sans-serif;
}

.chat-input-row {
    border-t: 1px solid rgba(255,255,255,0.08);
    padding-top: 12px;
    display: flex;
    gap: 10px;
}

.chat-input-field {
    flex-grow: 1;
    background: #050912;
    border: 1px solid rgba(0,240,255,0.15);
    border-radius: 6px;
    color: #fff;
    padding: 8px 12px;
    font-size: 12.5px;
    font-family: 'Hind Siliguri', sans-serif;
}

.chat-send-btn {
    background: linear-gradient(90deg, #00bcff, #00f0ff);
    color: #070b13;
    border: none;
    font-weight: bold;
    padding: 8px 18px;
    border-radius: 6px;
    cursor: pointer;
    font-size: 12.5px;
    font-family: 'Hind Siliguri', sans-serif;
    transition: opacity 0.2s;
}

.chat-send-btn:hover {
    opacity: 0.9;
}

/* AdSense Banner Styles */
.adsense-placeholder-sports {
    background: rgba(5, 9, 18, 0.8);
    border: 1px dashed rgba(0, 240, 255, 0.15);
    border-radius: 8px;
    padding: 12px;
    text-align: center;
    margin-top: 20px;
}

.adsense-placeholder-inner {
    height: 90px;
    background: rgba(0, 240, 255, 0.02);
    border: 1px solid rgba(0, 240, 255, 0.04);
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: monospace;
    font-size: 10px;
    color: rgba(0, 240, 255, 0.3);
}

/* Animations */
@keyframes blink-anim {
    0% { opacity: 0.4; }
    50% { opacity: 1; }
    100% { opacity: 0.4; }
}

@keyframes pulse-glow {
    0% { transform: scale(1); opacity: 0.9; }
    50% { transform: scale(1.05); opacity: 1; }
    100% { transform: scale(1); opacity: 0.9; }
}
</style>

<div class="sports-page-wrapper">
    <div class="sports-grid-container">
        
        <!-- Left Sidebar: Match Listing -->
        <aside class="sports-left-sidebar" style="display: flex; flex-direction: column; gap: 20px;">
            
            <div class="sports-bento-card">
                <h3 style="font-size: 12px; font-family: monospace; color: #00f0ff; letter-spacing: 1.5px; text-transform: uppercase; margin-top: 0; margin-bottom: 15px;">
                    ⚽ ACTIVE TOURNAMENTS
                </h3>
                
                <!-- Match list items -->
                <div id="match-argentina-egypt" class="match-item active" onclick="selectWordPressMatch('argentina-egypt')">
                    <div class="match-header">
                        <span>FIFA WORLD CUP QUALIFIERS</span>
                        <span class="live-indicator">🔴 LIVE <span id="m1-minutes">74</span>'</span>
                    </div>
                    <div class="match-body-row">
                        <div class="match-team">🇦🇷 Argentina</div>
                        <div class="match-score"><span id="m1-score-home">1</span> - <span id="m1-score-away">1</span></div>
                        <div class="match-team">Egypt 🇪🇬</div>
                    </div>
                </div>

                <div id="match-madrid-barca" class="match-item" onclick="selectWordPressMatch('madrid-barca')">
                    <div class="match-header">
                        <span>LA LIGA - EL CLÁSICO</span>
                        <span class="live-indicator" style="animation: none; background: rgba(0, 240, 255, 0.1); color: #00f0ff; border-color: rgba(0, 240, 255, 0.25);" id="m2-status-badge">UPCOMING</span>
                    </div>
                    <div class="match-body-row">
                        <div class="match-team">🇪🇸 R. Madrid</div>
                        <div class="match-score"><span id="m2-score-home">0</span> - <span id="m2-score-away">0</span></div>
                        <div class="match-team">Barcelona 🇪🇸</div>
                    </div>
                </div>

                <div id="match-mancity-arsenal" class="match-item" onclick="selectWordPressMatch('mancity-arsenal')">
                    <div class="match-header">
                        <span>ENGLISH PREMIER LEAGUE</span>
                        <span style="color: #a0aec0; border: 1px solid rgba(255,255,255,0.1); padding: 1px 6px; border-radius: 3px; font-size: 10px;">FINISHED</span>
                    </div>
                    <div class="match-body-row">
                        <div class="match-team">🏴󠁧󠁢󠁥󠁮󠁧󠁿 Man City</div>
                        <div class="match-score">3 - 2</div>
                        <div class="match-team">Arsenal 🏴󠁧󠁢󠁥󠁮󠁧󠁿</div>
                    </div>
                </div>
            </div>

            <!-- AdSense Banner (Only renders if AdSense code is configured) -->
            <?php 
            if (function_exists('ilybd_get_smart_ad_code')) {
                echo ilybd_get_smart_ad_code('sidebar');
            }
            ?>
            
        </aside>

        <!-- Right Side: Active Console / Subtabs Content -->
        <main class="sports-main-console">
            
            <header class="sports-hub-header">
                <span class="sports-badge-cyber">⚡ 2040 NEXT-GEN SPORT ECOSYSTEM</span>
                <h1 class="sports-hub-title">লাইভ স্পোর্টস ও প্রেডিকশন সেন্টার</h1>
                <p class="sports-hub-subtext">১০০% গুগল এডসেন্স-বান্ধব রিয়েল-টাইম লাইভ ম্যাচ স্কোর ট্র্যাকার, প্রেডিকশন এবং ইন্টারেক্টিভ ফ্যান ফোরাম</p>
            </header>

            <!-- AdSense Policy Compliance Box -->
            <div class="compliance-shield-box">
                <span class="compliance-shield-icon">🛡️</span>
                <div class="compliance-shield-content">
                    <h4>১০০% AdSense-Safe & Zero Copyright Strike Policy</h4>
                    <p>আমরা কোনো অবৈধ লাইভ ভিডিও স্ট্রিম বা পাইরেটেড এম্বেড করি না। এই স্পোর্টস পোর্টালটি রিয়েল-টাইম লাইভ ম্যাচ স্ট্যাটস গ্রাফিক্স, লিলি লাইভ চ্যাট ফোরাম, ইন্টারেক্টিভ পয়েন্ট প্রেডিকশন এবং অফিসিয়াল ব্রডকাস্টারদের ফ্রী ইউটিউব হাইলাইটস ব্যবহার করে ডিজাইন করা হয়েছে যা গুগল পলিসি সম্পূর্ণ অনুমোদন করে এবং SEO র্যাংকিংয়ে সাইটকে শীর্ষে রাখে।</p>
                </div>
            </div>

            <!-- Tabs buttons -->
            <div class="sports-tab-bar">
                <button class="sports-tab-btn active" onclick="switchSportsTab(event, 'tracker')">📊 লাইভ স্কোরবোর্ড (Live Tracker)</button>
                <button class="sports-tab-btn" onclick="switchSportsTab(event, 'predictions')">🏆 প্রেডিকশন এরিনা (Prediction Room)</button>
                <button class="sports-tab-btn" onclick="switchSportsTab(event, 'chat')">💬 ফ্যান চ্যাট লাউঞ্জ (Live Chat)</button>
                <button class="sports-tab-btn" onclick="switchSportsTab(event, 'highlights')">🎥 ম্যাচ হাইলাইটস (Highlights)</button>
            </div>

            <!-- TAB CONTENT: LIVE TRACKER -->
            <div id="tab-content-tracker" class="sports-tab-view">
                <div class="simulation-main-board">
                    <span style="font-size: 10px; font-family: monospace; color: #a0aec0; text-transform: uppercase;">FIFA WORLD CUP QUALIFIERS</span>
                    
                    <div style="display: flex; justify-content: space-around; align-items: center; margin: 20px 0;">
                        <div>
                            <span style="font-size: 40px; display: block; margin-bottom: 5px;">🇦🇷</span>
                            <span style="font-size: 15px; font-weight: bold; color: #fff;">Argentina</span>
                        </div>
                        
                        <div>
                            <span id="display-live-score" style="font-size: 32px; font-family: monospace; font-weight: 800; color: #00f0ff;">1 : 1</span>
                            <span id="display-live-minute" style="display: block; font-size: 10px; font-family: monospace; color: #f87171; background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.2); padding: 2px 8px; border-radius: 4px; margin-top: 8px;">🔴 74' MIN ACTIVE</span>
                        </div>

                        <div>
                            <span style="font-size: 40px; display: block; margin-bottom: 5px;">🇪🇬</span>
                            <span style="font-size: 15px; font-weight: bold; color: #fff;">Egypt</span>
                        </div>
                    </div>

                    <!-- Stats section -->
                    <div class="stats-bar-wrapper">
                        <div class="stats-label-row">
                            <span><span id="val-poss-home">52</span>% Ball Possession</span>
                            <span style="color: #00f0ff;">বল পজিশন</span>
                            <span><span id="val-poss-away">48</span>% Ball Possession</span>
                        </div>
                        <div class="stats-bar-outer">
                            <div id="bar-poss-home" class="stats-bar-inner-home" style="width: 52%;"></div>
                            <div id="bar-poss-away" class="stats-bar-inner-away" style="width: 48%;"></div>
                        </div>
                    </div>

                    <div class="stats-bar-wrapper" style="margin-top: 15px;">
                        <div class="stats-label-row">
                            <span>8 shots</span>
                            <span style="color: #39ff14;">অন-টার্গেট শট</span>
                            <span>7 shots</span>
                        </div>
                        <div class="stats-bar-outer">
                            <div class="stats-bar-inner-home" style="width: 53%;"></div>
                            <div class="stats-bar-inner-away" style="width: 47%;"></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- TAB CONTENT: PREDICTIONS -->
            <div id="tab-content-predictions" class="sports-tab-view" style="display: none;">
                <div class="sports-bento-card">
                    <h3 style="font-size: 15px; color: #fff; margin-top: 0; display: flex; align-items: center; gap: 8px;">
                        🏆 কুইক ম্যাচ প্রেডিকশন ফ্যান এরিনা
                    </h3>
                    <p style="font-size: 13px; color: #a0aec0; line-height: 1.6; font-family: 'Hind Siliguri', sans-serif;">
                        আপনার পছন্দের দলটি আজ জিতবে তো? নিচের অপশন থেকে জয়ী দল প্রেডিক্ট করুন এবং আপনার একাউন্টের XP পয়েন্ট বা রিওয়ার্ড ব্যালেন্স বাড়িয়ে নিন! প্রতি সাবমিশনে ১০ পয়েন্ট যুক্ত বা খরচ হতে পারে।
                    </p>

                    <div id="prediction-interactive-area" style="margin-top: 25px; padding: 20px; background: rgba(5, 9, 18, 0.5); border-radius: 8px; text-align: center;">
                        <h4 style="font-size: 14px; color: #00f0ff; margin-bottom: 15px;">আর্জেন্টিনা বনাম মিশর - ম্যাচ প্রেডিকশন করুন:</h4>
                        
                        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px;">
                            <button class="sports-tab-btn" onclick="submitWordPressPrediction('Argentina')" style="padding: 15px 10px;">
                                <span style="font-size: 20px; display: block; margin-bottom: 5px;">🇦🇷</span>
                                <span>Argentina</span>
                            </button>
                            <button class="sports-tab-btn" onclick="submitWordPressPrediction('Draw')" style="padding: 15px 10px;">
                                <span style="font-size: 20px; display: block; margin-bottom: 5px;">🤝</span>
                                <span>Draw</span>
                            </button>
                            <button class="sports-tab-btn" onclick="submitWordPressPrediction('Egypt')" style="padding: 15px 10px;">
                                <span style="font-size: 20px; display: block; margin-bottom: 5px;">🇪🇬</span>
                                <span>Egypt</span>
                            </button>
                        </div>
                        <div id="prediction-status-msg" style="margin-top: 15px; font-size: 12.5px; color: #39ff14; font-family: 'Hind Siliguri', sans-serif; display: none;"></div>
                    </div>
                </div>
            </div>

            <!-- TAB CONTENT: CHAT -->
            <div id="tab-content-chat" class="sports-tab-view" style="display: none;">
                <div class="sports-bento-card chat-lounge-box">
                    <div class="chat-history" id="wp-sports-chat-history">
                        <div class="chat-bubble">
                            <div class="chat-avatar">🇦🇷</div>
                            <div class="chat-bubble-content">
                                <div class="chat-meta">
                                    <span style="font-weight: bold; color: #00f0ff;">মেসি ফ্যান বিডি</span>
                                    <span class="chat-badge">ELITE FAN</span>
                                    <span style="color: #4a5568;">২ মিনিট আগে</span>
                                </div>
                                <div class="chat-text">আর্জেন্টিনা আজকে জিতবেই! ৭৪ মিনিটেও ম্যাচটি ১-১ ট্র্যাকিং এ আছে, খেলা জোস হচ্ছে!</div>
                            </div>
                        </div>
                        <div class="chat-bubble">
                            <div class="chat-avatar">🇪🇬</div>
                            <div class="chat-bubble-content">
                                <div class="chat-meta">
                                    <span style="font-weight: bold; color: #39ff14;">সালাহ ফ্যান ২০৪০</span>
                                    <span class="chat-badge">GOLD PRO</span>
                                    <span style="color: #4a5568;">১ মিনিট আগে</span>
                                </div>
                                <div class="chat-text">মিশরের শেষ গোলটা চমৎকার ছিল। সালাহ-র দল ডিফেন্স শক্ত রাখলে ৮৫ মিনিটে মিশরের আরেকটি গোল আসবে।</div>
                            </div>
                        </div>
                    </div>

                    <div class="chat-input-row">
                        <input type="text" id="wp-sports-chat-input" class="chat-input-field" placeholder="আপনার ফুটবল কমেন্ট বাংলায় লিখুন...">
                        <button class="chat-send-btn" onclick="sendWordPressSportsComment()">পোস্ট করুন</button>
                    </div>
                </div>
            </div>

            <!-- TAB CONTENT: HIGHLIGHTS -->
            <div id="tab-content-highlights" class="sports-tab-view" style="display: none;">
                <div class="sports-bento-card">
                    <h3 style="font-size: 15px; color: #fff; margin-top: 0;">🎥 অফিসিয়াল ম্যাচ হাইলাইটস (YouTube Official Embed)</h3>
                    <p style="font-size: 13px; color: #a0aec0; margin-bottom: 20px; font-family: 'Hind Siliguri', sans-serif;">
                        ম্যাচ সমাপ্ত হওয়ার সাথে সাথেই বিশ্বস্ত অফিসিয়াল ব্রডকাস্টারদের ফ্রী এম্বেডেড হাইলাইটস দেখুন। কোনো কপিরাইট ঝুঁকি বা আইনি ঝামেলা ছাড়াই হাই-কোয়ালিটি অফিসিয়াল ইউটিউব সোর্স থেকে খেলা উপভোগ করুন।
                    </p>

                    <div style="position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden; border-radius: 8px; border: 1px solid rgba(0,240,255,0.15);">
                        <iframe style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; border:0;" src="https://www.youtube.com/embed/QeS1PjZ3Y0g" allowfullscreen></iframe>
                    </div>
                </div>
            </div>

        </main>

    </div>
</div>

<script>
// Match Data Store for Interactive Selection
var matchesData = {
    'argentina-egypt': {
        tournament: 'FIFA WORLD CUP QUALIFIERS',
        homeTeam: 'Argentina',
        homeFlag: '🇦🇷',
        awayTeam: 'Egypt',
        awayFlag: '🇪🇬',
        homeScore: 1,
        awayScore: 1,
        minute: 74,
        status: 'LIVE',
        possession: 52,
        shotsHome: 8,
        shotsAway: 7,
        predictionText: 'আর্জেন্টিনা বনাম মিশর - ম্যাচ প্রেডিকশন করুন:',
        highlightsUrl: 'https://www.youtube.com/embed/QeS1PjZ3Y0g'
    },
    'madrid-barca': {
        tournament: 'LA LIGA - EL CLÁSICO',
        homeTeam: 'R. Madrid',
        homeFlag: '🇪🇸',
        awayTeam: 'Barcelona',
        awayFlag: '🇪🇸',
        homeScore: 0,
        awayScore: 0,
        minute: 0,
        status: 'UPCOMING',
        possession: 50,
        shotsHome: 0,
        shotsAway: 0,
        predictionText: 'রিয়াল মাদ্রিদ বনাম বার্সেলোনা - ম্যাচ প্রেডিকশন করুন:',
        highlightsUrl: 'https://www.youtube.com/embed/QeS1PjZ3Y0g'
    },
    'mancity-arsenal': {
        tournament: 'ENGLISH PREMIER LEAGUE',
        homeTeam: 'Man City',
        homeFlag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
        awayTeam: 'Arsenal',
        awayFlag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
        homeScore: 3,
        awayScore: 2,
        minute: 90,
        status: 'FINISHED',
        possession: 55,
        shotsHome: 14,
        shotsAway: 11,
        predictionText: 'ম্যান সিটি বনাম আর্সেনাল - প্রেডিকশন বন্ধ (ম্যাচ সমাপ্ত)',
        highlightsUrl: 'https://www.youtube.com/embed/YpXAt2tG_eM'
    }
};

var activeMatchKey = 'argentina-egypt';

// Tab Swapping Logic
function switchSportsTab(e, tabName) {
    document.querySelectorAll('.sports-tab-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('.sports-tab-view').forEach(view => view.style.display = 'none');
    
    // Find matching button safely
    if (e && e.currentTarget) {
        e.currentTarget.classList.add('active');
    } else if (window.event && window.event.srcElement) {
        window.event.srcElement.classList.add('active');
    }
    
    var viewEl = document.getElementById('tab-content-' + tabName);
    if (viewEl) {
        viewEl.style.display = 'block';
    }
}

// Select Active Match
function selectWordPressMatch(matchKey) {
    activeMatchKey = matchKey;
    
    // Toggle active class on list items
    document.querySelectorAll('.match-item').forEach(item => item.classList.remove('active'));
    var selectedItem = document.getElementById('match-' + matchKey);
    if (selectedItem) {
        selectedItem.classList.add('active');
    }
    
    var match = matchesData[matchKey];
    if (!match) return;
    
    // Update Active Scoreboard Card in Tracker Tab
    var trackerTab = document.getElementById('tab-content-tracker');
    if (trackerTab) {
        var tournamentLabel = trackerTab.querySelector('span[style*="text-transform: uppercase"]');
        if (tournamentLabel) {
            tournamentLabel.innerText = match.tournament;
        }
    }
    
    // Update Teams & Flags
    var teamContainers = document.querySelectorAll('#tab-content-tracker div[style*="justify-content: space-around"] > div');
    if (teamContainers.length >= 3) {
        // Home
        var flagHome = teamContainers[0].querySelector('span[style*="font-size: 40px"]');
        var nameHome = teamContainers[0].querySelector('span[style*="font-size: 15px"]');
        if (flagHome) flagHome.innerText = match.homeFlag;
        if (nameHome) nameHome.innerText = match.homeTeam;
        
        // Away
        var flagAway = teamContainers[2].querySelector('span[style*="font-size: 40px"]');
        var nameAway = teamContainers[2].querySelector('span[style*="font-size: 15px"]');
        if (flagAway) flagAway.innerText = match.awayFlag;
        if (nameAway) nameAway.innerText = match.awayTeam;
    }
    
    // Score & Minute Label
    var dispScore = document.getElementById('display-live-score');
    var dispMin = document.getElementById('display-live-minute');
    
    if (dispScore) {
        if (match.status === 'UPCOMING') {
            dispScore.innerText = 'VS';
        } else {
            dispScore.innerText = match.homeScore + ' : ' + match.awayScore;
        }
    }
    
    if (dispMin) {
        if (match.status === 'LIVE') {
            dispMin.innerText = '🔴 ' + match.minute + "' MIN ACTIVE";
            dispMin.style.color = '#f87171';
            dispMin.style.background = 'rgba(239, 68, 68, 0.1)';
            dispMin.style.border = '1px solid rgba(239, 68, 68, 0.2)';
        } else if (match.status === 'UPCOMING') {
            dispMin.innerText = 'UPCOMING';
            dispMin.style.color = '#00f0ff';
            dispMin.style.background = 'rgba(0, 240, 255, 0.1)';
            dispMin.style.border = '1px solid rgba(0, 240, 255, 0.2)';
        } else {
            dispMin.innerText = 'FINISHED';
            dispMin.style.color = '#a0aec0';
            dispMin.style.background = 'rgba(255, 255, 255, 0.05)';
            dispMin.style.border = '1px solid rgba(255, 255, 255, 0.1)';
        }
    }
    
    // Update Possession stats
    var valPossH = document.getElementById('val-poss-home');
    var valPossA = document.getElementById('val-poss-away');
    var barH = document.getElementById('bar-poss-home');
    var barA = document.getElementById('bar-poss-away');
    
    if (valPossH) valPossH.innerText = match.possession;
    if (valPossA) valPossA.innerText = 100 - match.possession;
    if (barH) barH.style.width = match.possession + '%';
    if (barA) barA.style.width = (100 - match.possession) + '%';
    
    // Update prediction area text & buttons
    var predText = document.querySelector('#prediction-interactive-area h4');
    if (predText) {
        predText.innerText = match.predictionText;
    }
    
    var predBtnContainer = document.querySelector('#prediction-interactive-area div[style*="display: grid"]');
    if (predBtnContainer) {
        if (match.status === 'FINISHED') {
            predBtnContainer.style.display = 'none';
        } else {
            predBtnContainer.style.display = 'grid';
            var buttons = predBtnContainer.querySelectorAll('button');
            if (buttons.length >= 3) {
                // Home
                buttons[0].querySelector('span[style*="font-size: 20px"]').innerText = match.homeFlag;
                buttons[0].querySelector('span:not([style])').innerText = match.homeTeam;
                buttons[0].setAttribute('onclick', "submitWordPressPrediction('" + match.homeTeam + "')");
                
                // Away
                buttons[2].querySelector('span[style*="font-size: 20px"]').innerText = match.awayFlag;
                buttons[2].querySelector('span:not([style])').innerText = match.awayTeam;
                buttons[2].setAttribute('onclick', "submitWordPressPrediction('" + match.awayTeam + "')");
            }
        }
    }
    
    // Clear prediction status message
    var statusDiv = document.getElementById('prediction-status-msg');
    if (statusDiv) {
        statusDiv.style.display = 'none';
    }
    
    // Update Youtube Embed Highlight
    var highlightIframe = document.querySelector('#tab-content-highlights iframe');
    if (highlightIframe) {
        if (matchKey === 'mancity-arsenal') {
            highlightIframe.src = "https://www.youtube.com/embed/YpXAt2tG_eM";
        } else {
            highlightIframe.src = "https://www.youtube.com/embed/QeS1PjZ3Y0g";
        }
    }
}

// Live Score Simulation Interval (Runs for all live matches)
setInterval(function() {
    for (var key in matchesData) {
        var m = matchesData[key];
        if (m.status === 'LIVE') {
            if (m.minute < 90) {
                m.minute += 1;
                
                // Random goal chance (3%)
                if (Math.random() < 0.03) {
                    if (Math.random() > 0.5) {
                        m.homeScore += 1;
                    } else {
                        m.awayScore += 1;
                    }
                }
                
                // If this match is currently active, update the tracker board UI
                if (key === activeMatchKey) {
                    var dispScore = document.getElementById('display-live-score');
                    var dispMin = document.getElementById('display-live-minute');
                    
                    if (dispScore) dispScore.innerText = m.homeScore + ' : ' + m.awayScore;
                    if (dispMin) dispMin.innerText = '🔴 ' + m.minute + "' MIN ACTIVE";
                }
                
                // Update Sidebar list items too
                if (key === 'argentina-egypt') {
                    var m1Min = document.getElementById('m1-minutes');
                    var m1H = document.getElementById('m1-score-home');
                    var m1A = document.getElementById('m1-score-away');
                    if (m1Min) m1Min.innerText = m.minute;
                    if (m1H) m1H.innerText = m.homeScore;
                    if (m1A) m1A.innerText = m.awayScore;
                }
                
                // Update Possession slightly
                m.possession = Math.floor(Math.random() * (60 - 40 + 1)) + 40;
                if (key === activeMatchKey) {
                    var valPossH = document.getElementById('val-poss-home');
                    var valPossA = document.getElementById('val-poss-away');
                    var barH = document.getElementById('bar-poss-home');
                    var barA = document.getElementById('bar-poss-away');
                    
                    if (valPossH) valPossH.innerText = m.possession;
                    if (valPossA) valPossA.innerText = 100 - m.possession;
                    if (barH) barH.style.width = m.possession + '%';
                    if (barA) barA.style.width = (100 - m.possession) + '%';
                }
            } else {
                m.status = 'FINISHED';
                if (key === activeMatchKey) {
                    var dispMinEnd = document.getElementById('display-live-minute');
                    if (dispMinEnd) {
                        dispMinEnd.innerText = 'FINISHED';
                        dispMinEnd.style.color = '#a0aec0';
                        dispMinEnd.style.background = 'rgba(255,255,255,0.05)';
                    }
                }
                
                // Update sidebar list item
                if (key === 'argentina-egypt') {
                    var sidebarLiveInd = document.querySelector('#match-argentina-egypt .live-indicator');
                    if (sidebarLiveInd) {
                        sidebarLiveInd.innerText = 'FINISHED';
                        sidebarLiveInd.className = '';
                        sidebarLiveInd.style.color = '#718096';
                        sidebarLiveInd.style.border = 'none';
                    }
                }
            }
        }
    }
}, 12000);

// Prediction Register Handler
function submitWordPressPrediction(team) {
    var statusDiv = document.getElementById('prediction-status-msg');
    if (statusDiv) {
        statusDiv.style.display = 'block';
        statusDiv.innerHTML = '🎉 সফল! আপনি "' + team + '" এর পক্ষে প্রেডিকশন করেছেন। খেলা শেষ হওয়ার পর রেজাল্ট অনুযায়ী ব্যালেন্স আপডেট করা হবে।';
    }
}

// Live Chat Messaging Handler
function sendWordPressSportsComment() {
    var inputEl = document.getElementById('wp-sports-chat-input');
    var textVal = inputEl ? inputEl.value.trim() : '';
    if (!textVal) return;
    
    var historyDiv = document.getElementById('wp-sports-chat-history');
    if (historyDiv) {
        var newBubble = document.createElement('div');
        newBubble.className = 'chat-bubble';
        newBubble.innerHTML = `
            <div class="chat-avatar">👤</div>
            <div class="chat-bubble-content">
                <div class="chat-meta">
                    <span style="font-weight: bold; color: #00f0ff;">ফুটবল অনুরাগী</span>
                    <span class="chat-badge" style="background: #39ff14; color:#000;">ACTIVE MEMBER</span>
                    <span style="color: #4a5568;">সেকেন্ড আগে</span>
                </div>
                <div class="chat-text">${textVal}</div>
            </div>
        `;
        historyDiv.appendChild(newBubble);
        if (inputEl) inputEl.value = '';
        historyDiv.scrollTop = historyDiv.scrollHeight;
    }
}
</script>

<?php
get_footer();
