<?php
/**
 * Custom AI Book Center Single Book Details Page Template (2040 Sovereign Cyber Ecosystem)
 * URL: https://iloveyoubd.com/books/book-name
 * Theme: ilybd-neon-v1-pro
 */
get_header(); 

$post_id = get_the_ID();

// Retrieve Custom Metadata
$isbn         = get_post_meta($post_id, '_book_isbn', true);
$pub_year     = get_post_meta($post_id, '_book_pub_year', true);
$language     = get_post_meta($post_id, '_book_language', true);
$reading_time = get_post_meta($post_id, '_book_reading_time', true);
$rating       = get_post_meta($post_id, '_book_rating', true);
$rating_count = get_post_meta($post_id, '_book_rating_count', true);
$quality      = get_post_meta($post_id, '_book_quality_score', true);

if (empty($isbn)) $isbn = 'N/A';
if (empty($pub_year)) $pub_year = date('Y');
if (empty($language)) $language = 'Bilingual (Bengali & English)';
if (empty($reading_time)) $reading_time = '8 mins';
if (empty($rating)) $rating = '4.8';
if (empty($rating_count)) $rating_count = '120';
if (empty($quality)) $quality = '95';

// Taxonomies terms
$author_terms = wp_get_post_terms($post_id, 'book_author');
$author_name  = !empty($author_terms) && !is_wp_error($author_terms) ? $author_terms[0]->name : 'Unknown Author';
$author_link  = !empty($author_terms) && !is_wp_error($author_terms) ? get_term_link($author_terms[0]) : '#';

$cat_terms    = wp_get_post_terms($post_id, 'book_category');
$cat_name     = !empty($cat_terms) && !is_wp_error($cat_terms) ? $cat_terms[0]->name : 'Self Development';
$cat_link     = !empty($cat_terms) && !is_wp_error($cat_terms) ? get_term_link($cat_terms[0]) : '#';

$pub_terms    = wp_get_post_terms($post_id, 'book_publisher');
$pub_name     = !empty($pub_terms) && !is_wp_error($pub_terms) ? $pub_terms[0]->name : 'Default Publisher';

$topic_terms  = wp_get_post_terms($post_id, 'book_topic');

// Gradient Cover color selection
$grad_index = get_post_meta($post_id, '_book_gradient_color', true);
$gradients = [
    'linear-gradient(135deg, #0f172a 0%, #1e1b4b 50%, #311042 100%)', // Twilight Indigo
    'linear-gradient(135deg, #070b13 0%, #0d1527 50%, #064e3b 100%)', // Emerald Dark
    'linear-gradient(135deg, #08071a 0%, #111827 50%, #1e293b 100%)', // Cosmic Slate
    'linear-gradient(135deg, #180828 0%, #1e1b4b 50%, #1e293b 100%)', // Cyber Violet
    'linear-gradient(135deg, #070b13 0%, #111c30 50%, #581c87 100%)'  // Deep Magic Purple
];
$active_gradient = isset($gradients[$grad_index]) ? $gradients[$grad_index] : $gradients[0];

// Current full URL for share buttons
$current_url = urlencode(get_permalink());
$current_title = urlencode(get_the_title());
?>

<style>
/* Spec details table grid */
.spec-grid {
    display: grid !important;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)) !important;
    gap: 15px !important;
    background: rgba(255, 255, 255, 0.02) !important;
    border: 1px solid rgba(255, 255, 255, 0.05) !important;
    border-radius: 12px !important;
    padding: 16px 20px !important;
    margin-bottom: 25px !important;
}

.spec-item {
    font-size: 13px !important;
    font-family: monospace !important;
    color: #8b949e !important;
}

.spec-item strong {
    color: #e2e8f0 !important;
    display: block !important;
    font-size: 14.5px !important;
    margin-bottom: 3px !important;
}

/* Share icons */
.share-pill {
    display: inline-flex !important;
    align-items: center !important;
    gap: 6px !important;
    padding: 6px 14px !important;
    border-radius: 20px !important;
    font-size: 12px !important;
    font-weight: bold !important;
    color: #fff !important;
    text-decoration: none !important;
    transition: all 0.2s ease !important;
    cursor: pointer !important;
}

.share-fb { background-color: #1877f2 !important; }
.share-wa { background-color: #25d366 !important; }
.share-copy { background-color: #4b5563 !important; }

.share-pill:hover {
    filter: brightness(1.1) !important;
    transform: translateY(-1px) !important;
}

/* Sidebar panel structures */
.cyber-sidebar-box {
    background: rgba(13, 21, 39, 0.7) !important;
    border: 1.5px solid rgba(0, 240, 255, 0.15) !important;
    border-radius: 16px !important;
    padding: 20px !important;
    margin-bottom: 20px !important;
    backdrop-filter: blur(8px) !important;
    -webkit-backdrop-filter: blur(8px) !important;
}

.sidebar-related-item {
    display: flex !important;
    gap: 12px !important;
    align-items: center !important;
    border-bottom: 1px solid rgba(255, 255, 255, 0.05) !important;
    padding-bottom: 10px !important;
    margin-bottom: 10px !important;
}

.sidebar-related-item:last-child {
    border: none !important;
    padding: 0 !important;
    margin: 0 !important;
}

/* Comment Box Custom Styling */
#respond {
    background: rgba(13, 21, 39, 0.5) !important;
    border: 1.5px solid rgba(0, 240, 255, 0.15) !important;
    border-radius: 16px !important;
    padding: 25px !important;
    margin-top: 40px !important;
}

#reply-title {
    color: #fff !important;
    font-family: 'Space Grotesk', sans-serif !important;
    font-size: 18px !important;
    font-weight: bold !important;
    margin-top: 0 !important;
    margin-bottom: 15px !important;
    border-bottom: 1.5px solid rgba(0,240,255,0.2) !important;
    padding-bottom: 8px !important;
}

#commentform textarea {
    width: 100% !important;
    background: #070b13 !important;
    border: 1px solid rgba(255, 255, 255, 0.1) !important;
    color: #fff !important;
    border-radius: 8px !important;
    padding: 12px !important;
    outline: none !important;
    font-family: inherit !important;
}

#commentform textarea:focus {
    border-color: #00f0ff !important;
}

#commentform input[type="submit"] {
    background: linear-gradient(135deg, #00f0ff 0%, #0072ff 100%) !important;
    color: #000 !important;
    font-weight: bold !important;
    border: none !important;
    padding: 11px 24px !important;
    border-radius: 6px !important;
    cursor: pointer !important;
    text-transform: uppercase !important;
    font-family: monospace !important;
    font-size: 13px !important;
}

/* Premium large book cover design */
.premium-book-cover {
    width: 180px !important;
    height: 260px !important;
    border: 2px solid rgba(255, 255, 255, 0.15) !important;
    border-radius: 10px !important;
    box-shadow: 5px 10px 25px rgba(0,0,0,0.6) !important;
    position: relative !important;
    overflow: hidden !important;
    display: flex !important;
    flex-direction: column !important;
    justify-content: space-between !important;
    padding: 15px !important;
    flex-shrink: 0 !important;
}

.premium-book-cover .spine-shadow {
    position: absolute !important;
    left: 0 !important;
    top: 0 !important;
    width: 8px !important;
    height: 100% !important;
    background: rgba(255,255,255,0.15) !important;
    box-shadow: 2px 0 5px rgba(0,0,0,0.4) !important;
}

@media (max-width: 767px) {
    .premium-book-cover {
        width: 130px !important;
        height: 190px !important;
        align-self: center !important;
    }
}
</style>

<!-- STRUCTURED DATA SCHEMAS FOR PERFECT GOOGLE SEO & INDEXATION -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Book",
  "name": "<?php echo esc_attr(get_the_title()); ?>",
  "author": {
    "@type": "Person",
    "name": "<?php echo esc_attr($author_name); ?>"
  },
  "publisher": {
    "@type": "Organization",
    "name": "<?php echo esc_attr($pub_name); ?>"
  },
  "isbn": "<?php echo esc_attr($isbn); ?>",
  "inLanguage": "<?php echo esc_attr($language); ?>",
  "datePublished": "<?php echo esc_attr($pub_year); ?>",
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": "<?php echo esc_attr($rating); ?>",
    "reviewCount": "<?php echo esc_attr($rating_count); ?>"
  }
}
</script>

<div class="nextgen-single-viewport book-details-viewport" style="background: #070b13; color: #c9d1d9; min-height: 100vh; padding: 30px 12px 80px; font-family: 'Inter', sans-serif;">
    <div style="max-width: 1100px; margin: 0 auto; width: 100%;">

        <!-- 1. BREADCRUMB -->
        <nav aria-label="Breadcrumb" style="margin-bottom: 25px; font-size: 12px; font-family: monospace; opacity: 0.85;">
            <a href="<?php echo esc_url(home_url('/')); ?>" style="color: #64748b; text-decoration: none; transition: color 0.2s;">HOME</a>
            <span style="color: #475569; margin: 0 8px;">/</span>
            <a href="<?php echo esc_url(home_url('/books/')); ?>" style="color: #64748b; text-decoration: none; transition: color 0.2s;">BOOKS</a>
            <span style="color: #475569; margin: 0 8px;">/</span>
            <a href="<?php echo esc_url($cat_link); ?>" style="color: #64748b; text-decoration: none; transition: color 0.2s; text-transform: uppercase;"><?php echo esc_html($cat_name); ?></a>
            <span style="color: #475569; margin: 0 8px;">/</span>
            <span style="color: #00f0ff; font-weight: bold; text-transform: uppercase;"><?php the_title(); ?></span>
        </nav>

        <!-- MAIN LAYOUT FLEX/GRID -->
        <div style="display: grid; grid-template-columns: 1fr; md:grid-template-columns: 1fr; lg:grid-template-columns: 1fr 340px; gap: 30px; align-items: start;" class="single-book-layout">
            
            <!-- LEFT AREA: CORE DETAILS, ARTICLES AND REVIEWS -->
            <main style="min-width: 0;">
                
                <!-- HEADER INTRO HERO UNIT -->
                <div style="background: linear-gradient(135deg, #0d1527 0%, #070b13 100%); border: 1.5px solid rgba(0, 240, 255, 0.15); border-radius: 16px; padding: 25px; margin-bottom: 30px; display: flex; flex-direction: column; md:flex-row; gap: 25px; position: relative; overflow: hidden; box-shadow: 0 8px 32px rgba(0,0,0,0.5);" class="hero-flex">
                    <div style="position: absolute; top:0; right:0; width: 150px; height: 150px; background: rgba(0, 240, 255, 0.03); filter: blur(50px); border-radius: 50%;"></div>
                    
                    <!-- Cover image left -->
                    <div class="premium-book-cover" style="background: <?php echo $active_gradient; ?>;">
                        <div style="font-size: 9px; font-family: monospace; color: #00f0ff; text-transform: uppercase; font-weight: bold; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;"><?php echo esc_html($cat_name); ?></div>
                        <div style="font-size: 15px; font-weight: 800; color: #fff; line-height: 1.1; display: -webkit-box; -webkit-line-clamp: 4; -webkit-box-orient: vertical; overflow: hidden; word-break: break-all; text-shadow: 2px 2px 4px rgba(0,0,0,0.8);"><?php the_title(); ?></div>
                        <div style="font-size: 9px; color: rgba(255,255,255,0.7); overflow: hidden; text-overflow: ellipsis; white-space: nowrap;"><?php echo esc_html($author_name); ?></div>
                        <div class="spine-shadow"></div>
                    </div>

                    <!-- Details Right -->
                    <div style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; justify-content: space-between;">
                        <div>
                            <div style="margin-bottom: 10px; display: flex; flex-wrap: wrap; gap: 8px; align-items: center;">
                                <a href="<?php echo esc_url($cat_link); ?>" style="font-size: 10px; background: rgba(0, 240, 255, 0.08); border: 1px solid rgba(0, 240, 255, 0.2); color: #00f0ff; padding: 3px 10px; border-radius: 4px; font-family: monospace; font-weight: bold; text-transform: uppercase; text-decoration: none;"><?php echo esc_html($cat_name); ?></a>
                                <span style="font-size: 10px; background: rgba(192, 132, 252, 0.08); border: 1px solid rgba(192, 132, 252, 0.2); color: #c084fc; padding: 3px 10px; border-radius: 4px; font-family: monospace; font-weight: bold; text-transform: uppercase;">AI Summary Verified</span>
                            </div>

                            <h1 style="color: #fff; font-family: 'Space Grotesk', sans-serif; font-size: 26px; font-weight: 800; line-height: 1.3; margin: 0 0 8px 0;"><?php the_title(); ?></h1>
                            
                            <div style="font-size: 14.5px; color: #cbd5e0; margin-bottom: 12px;">লেখক: <a href="<?php echo esc_url($author_link); ?>" style="color: #00ff41; font-weight: bold; text-decoration: none; border-bottom: 1px dashed rgba(0,255,65,0.3);"><?php echo esc_html($author_name); ?></a></div>
                            
                            <!-- Star ratings bar -->
                            <div style="display: flex; flex-wrap: wrap; gap: 15px; align-items: center; margin-bottom: 15px;">
                                <div style="display: flex; align-items: center; gap: 4px; font-size: 14px; color: #fbbf24;">
                                    <i class="fa-solid fa-star"></i> <strong style="color: #fff; font-size: 15px;"><?php echo esc_html($rating); ?></strong> <span style="color: #64748b; font-size: 11.5px;">/ ৫.০</span>
                                </div>
                                <span style="color: rgba(255,255,255,0.12);">|</span>
                                <span style="font-size: 12.5px; color: #8b949e;"><strong style="color:#fff;"><?php echo esc_html($rating_count); ?></strong> টি রিভিউর উপর ভিত্তি করে</span>
                                <span style="color: rgba(255,255,255,0.12);">|</span>
                                <span style="font-family: monospace; font-size: 11px; color: #38bdf8; background: rgba(56,189,248,0.1); border: 1px solid rgba(56,189,248,0.3); padding: 1px 7px; border-radius: 4px;">Quality Score: <?php echo esc_html($quality); ?>%</span>
                            </div>
                        </div>

                        <!-- Share and timestamps -->
                        <div style="display: flex; flex-wrap: wrap; gap: 8px; align-items: center; border-top: 1px solid rgba(255,255,255,0.06); padding-top: 15px;">
                            <span style="font-family: monospace; font-size: 11px; color: #64748b; margin-right: 5px;">SHARE:</span>
                            <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $current_url; ?>" target="_blank" class="share-pill share-fb"><i class="fa-brands fa-facebook-f"></i> Facebook</a>
                            <a href="https://api.whatsapp.com/send?text=<?php echo $current_title; ?>%20<?php echo $current_url; ?>" target="_blank" class="share-pill share-wa"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
                            <button onclick="navigator.clipboard.writeText('<?php the_permalink(); ?>'); alert('লিঙ্ক সফলভাবে কপি হয়েছে!');" class="share-pill share-copy"><i class="fa-solid fa-copy"></i> Copy Link</button>
                        </div>
                    </div>
                </div>

                <!-- DYNAMIC AD PLACEHOLDER (AdSense Friendly - Only renders if code is set) -->
                <?php 
                if (function_exists('ilybd_get_smart_ad_code')) {
                    echo ilybd_get_smart_ad_code('top');
                }
                ?>

                <!-- SPECIFICATIONS BENTO CARD -->
                <div class="spec-grid">
                    <div class="spec-item">
                        <strong>ISBN কোড</strong>
                        <?php echo esc_html($isbn); ?>
                    </div>
                    <div class="spec-item">
                        <strong>প্রকাশনার বছর</strong>
                        <?php echo esc_html($pub_year); ?>
                    </div>
                    <div class="spec-item">
                        <strong>প্রকাশক</strong>
                        <?php echo esc_html($pub_name); ?>
                    </div>
                    <div class="spec-item">
                        <strong>ভাষা</strong>
                        <?php echo esc_html($language); ?>
                    </div>
                    <div class="spec-item">
                        <strong>পড়ার সময়</strong>
                        <?php echo esc_html($reading_time); ?>
                    </div>
                </div>

                <!-- CORE EDITORIAL CONTENT (Overview, summaries, key takeaways etc) -->
                <article style="background: rgba(13, 21, 39, 0.45); border: 1.5px solid rgba(0, 240, 255, 0.12); border-radius: 16px; padding: 25px 30px; line-height: 1.8; color: #cbd5e0; box-shadow: 0 4px 15px rgba(0,0,0,0.2);">
                    <?php the_content(); ?>
                </article>

                <!-- TOPIC & TARGET TAGS LIST -->
                <?php if (!is_wp_error($topic_terms) && !empty($topic_terms)) : ?>
                    <div style="margin-top: 25px; display: flex; flex-wrap: wrap; gap: 8px; align-items: center;">
                        <span style="font-family: monospace; font-size: 11px; color: #8b949e;"><i class="fa-solid fa-tags" style="color: #c084fc;"></i> TAGS:</span>
                        <?php foreach ($topic_terms as $topic) : ?>
                            <a href="<?php echo esc_url(get_term_link($topic)); ?>" style="font-size: 11px; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); color: #cbd5e0; padding: 3px 10px; border-radius: 6px; text-decoration: none; font-family: monospace; transition: all 0.2s;" onmouseover="this.style.color='#00f0ff'; this.style.borderColor='#00f0ff';" onmouseout="this.style.color='#cbd5e0'; this.style.borderColor='rgba(255,255,255,0.08)';">#<?php echo esc_html($topic->name); ?></a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <!-- DYNAMIC AD PLACEHOLDER AFTER CONTENT (Only renders if code is set) -->
                <?php 
                if (function_exists('ilybd_get_smart_ad_code')) {
                    echo ilybd_get_smart_ad_code('bottom');
                }
                ?>

                <!-- COMMUNITY COMMENTS SECTION -->
                <div class="book-comments-container">
                    <?php 
                    if (comments_open() || get_comments_number()) {
                        comments_template();
                    }
                    ?>
                </div>

            </main>

            <!-- RIGHT AREA: SMART HIGH-ACCURACY SYSTEM RECOMMENDATION ENGINE -->
            <aside style="width: 100%; display: flex; flex-direction: column; gap: 20px;">
                
                <!-- 1. Related Books Box -->
                <div class="cyber-sidebar-box">
                    <h3 style="color: #00f0ff; border-bottom: 2px solid rgba(0,240,255,0.2); padding-bottom: 8px; margin-top: 0; margin-bottom: 15px; font-size: 14.5px; font-family: monospace; display: flex; align-items: center; gap: 6px;">
                        <span>📚 [RELATED BOOKS / অন্যান্য বই]</span>
                    </h3>
                    
                    <?php 
                    $rel_books = get_posts([
                        'post_type'      => 'ilybd_book',
                        'posts_per_page' => 4,
                        'post__not_in'   => [$post_id],
                        'tax_query'      => [
                            [
                                'taxonomy' => 'book_category',
                                'field'    => 'term_id',
                                'terms'    => !empty($cat_terms) && !is_wp_error($cat_terms) ? wp_list_pluck($cat_terms, 'term_id') : []
                            ]
                        ]
                    ]);
                    if (empty($rel_books)) {
                        $rel_books = get_posts([
                            'post_type'      => 'ilybd_book',
                            'posts_per_page' => 4,
                            'post__not_in'   => [$post_id]
                        ]);
                    }

                    if (!empty($rel_books)) :
                        foreach ($rel_books as $rb) :
                            $rb_author_terms = wp_get_post_terms($rb->ID, 'book_author');
                            $rb_author = !empty($rb_author_terms) ? $rb_author_terms[0]->name : 'James Clear';
                            $rb_grad = get_post_meta($rb->ID, '_book_gradient_color', true);
                            $rb_active_grad = isset($gradients[$rb_grad]) ? $gradients[$rb_grad] : $gradients[0];
                    ?>
                        <div class="sidebar-related-item">
                            <!-- Small dynamic cover -->
                            <div style="width: 42px; height: 60px; flex-shrink: 0; background: <?php echo $rb_active_grad; ?>; border: 1px solid rgba(255,255,255,0.12); border-radius: 4px; box-shadow: 2px 2px 6px rgba(0,0,0,0.4); position: relative; overflow: hidden; padding: 4px; display: flex; flex-direction: column; justify-content: space-between;">
                                <div style="font-size: 5px; font-weight: bold; color: #00f0ff; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;"><?php the_title(); ?></div>
                                <div style="font-size: 6.5px; font-weight: 800; color: #fff; line-height: 1.1; overflow: hidden; max-height: 25px;"><?php echo esc_html($rb->post_title); ?></div>
                                <div style="position: absolute; left: 0; top: 0; width: 2px; height: 100%; background: rgba(255,255,255,0.15); box-shadow: 1px 0 2px rgba(0,0,0,0.4);"></div>
                            </div>
                            <div style="min-width: 0;">
                                <h4 style="font-size: 13.5px; font-weight: bold; margin: 0 0 3px 0; line-height: 1.3; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;"><a href="<?php echo esc_url(get_permalink($rb->ID)); ?>" style="color: #fff; text-decoration: none; transition: color 0.15s;" onmouseover="this.style.color='#00f0ff';" onmouseout="this.style.color='#fff';"><?php echo esc_html($rb->post_title); ?></a></h4>
                                <div style="font-size: 11.5px; color: #8b949e;">লেখক: <?php echo esc_html($rb_author); ?></div>
                            </div>
                        </div>
                    <?php 
                        endforeach; 
                    else :
                        echo '<p style="color: #475569; font-size: 12px; margin: 0;">No related books available yet.</p>';
                    endif;
                    ?>
                </div>

                <!-- 2. Related News / Articles Box (Brings SEO freshness linking) -->
                <div class="cyber-sidebar-box">
                    <h3 style="color: #00ff41; border-bottom: 2px solid rgba(0,255,65,0.2); padding-bottom: 8px; margin-top: 0; margin-bottom: 15px; font-size: 14.5px; font-family: monospace;">
                        ⚡ [TRENDING TECH NEWS / টেক নিউজ]
                    </h3>
                    
                    <?php 
                    $rel_news = get_posts([
                        'post_type'      => 'ilybd_news',
                        'posts_per_page' => 4,
                        'post_status'    => 'publish'
                    ]);
                    if (empty($rel_news)) {
                        $rel_news = get_posts([
                            'post_type'      => 'post',
                            'posts_per_page' => 4,
                            'post_status'    => 'publish'
                        ]);
                    }

                    if (!empty($rel_news)) :
                        foreach ($rel_news as $rn) :
                    ?>
                        <div class="sidebar-related-item">
                            <div style="min-width: 0;">
                                <h4 style="font-size: 13.5px; font-weight: bold; margin: 0 0 3px 0; line-height: 1.3; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;"><a href="<?php echo esc_url(get_permalink($rn->ID)); ?>" style="color: #fff; text-decoration: none; transition: color 0.15s;" onmouseover="this.style.color='#00ff41';" onmouseout="this.style.color='#fff';"><?php echo esc_html($rn->post_title); ?></a></h4>
                                <div style="font-size: 10.5px; color: #64748b; font-family: monospace;"><?php echo get_the_date('M d, Y', $rn->ID); ?></div>
                            </div>
                        </div>
                    <?php 
                        endforeach;
                    else :
                        echo '<p style="color: #475569; font-size: 12px; margin: 0;">No related tech news available yet.</p>';
                    endif;
                    ?>
                </div>

                <!-- 3. Related Stories Box -->
                <div class="cyber-sidebar-box">
                    <h3 style="color: #f472b6; border-bottom: 2px solid rgba(244,114,182,0.2); padding-bottom: 8px; margin-top: 0; margin-bottom: 15px; font-size: 14.5px; font-family: monospace;">
                        💖 [DEDICATED STORIES / জনপ্রিয় গল্প]
                    </h3>
                    
                    <?php 
                    $rel_stories = get_posts([
                        'post_type'      => 'ilybd_story',
                        'posts_per_page' => 3,
                        'post_status'    => 'publish'
                    ]);
                    if (!empty($rel_stories)) :
                        foreach ($rel_stories as $rs) :
                    ?>
                        <div class="sidebar-related-item">
                            <div style="min-width: 0;">
                                <h4 style="font-size: 13.5px; font-weight: bold; margin: 0 0 3px 0; line-height: 1.3; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;"><a href="<?php echo esc_url(get_permalink($rs->ID)); ?>" style="color: #fff; text-decoration: none; transition: color 0.15s;" onmouseover="this.style.color='#f472b6';" onmouseout="this.style.color='#fff';"><?php echo esc_html($rs->post_title); ?></a></h4>
                                <div style="font-size: 10.5px; color: #64748b; font-family: monospace;">গল্প ও উপন্যাস হাব</div>
                            </div>
                        </div>
                    <?php 
                        endforeach;
                    endif;
                    ?>
                </div>

            </aside>

        </div>

    </div>
</div>

<?php 
get_footer(); 
?>
