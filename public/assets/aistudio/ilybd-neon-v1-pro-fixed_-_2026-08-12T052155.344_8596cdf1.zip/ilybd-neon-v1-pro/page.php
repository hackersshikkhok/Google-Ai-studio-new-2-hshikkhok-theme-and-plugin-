<?php
/**
 * ILYBD Neon v2 - Rounded RGB Design with Sticky RGB Line
 */

get_header(); ?>

<div class="cyber-page-wrapper">
    <div class="container-fluid" style="max-width: 1200px; margin: 0 auto; padding: 0;">
        
        <?php while ( have_posts() ) : the_post(); ?>
            
            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                
                <header class="ultra-sticky-header">
                    <h1 class="rgb-text-lighting">
                        <?php the_title(); ?>
                    </h1>
                    <div class="sticky-rgb-line"></div>
                </header>

                <div class="slim-rgb-container">
                    <div class="inner-page-content">
                        <?php the_content(); ?>
                    </div>
                </div>

            </article>

        <?php endwhile; ?>

    </div>
</div>

<style>
    /* মেইন ব্যাকগ্রাউন্ড */
    .cyber-page-wrapper {
        background: #0a0a0c;
        min-height: 100vh;
        padding-top: 20px;
    }

    /* ১. পেজ টাইটেল (নন-স্টিকি ও ন্যাচারাল স্ক্রলিং) */
    .ultra-sticky-header,
    .cyber-section-header {
        position: relative;
        z-index: 5;
        background: transparent;
        padding: 15px 0 10px 0;
        margin-bottom: 20px;
        text-align: center;
    }

    /* টাইটেল টেক্সট - পরিচ্ছন্ন ও স্পষ্ট সাইয়ান টাইটেল */
    .rgb-text-lighting {
        font-size: 2.2rem;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: 1.5px;
        margin: 0 0 10px 0;
        color: #00f0ff;
        background: none;
        -webkit-background-clip: unset;
        -webkit-text-fill-color: #00f0ff;
        animation: none;
        text-shadow: 0 0 12px rgba(0, 240, 255, 0.4);
    }

    /* টাইটেলের নিচের সুনির্দিষ্ট লাইন */
    .sticky-rgb-line {
        height: 2px;
        width: 100%;
        background: linear-gradient(90deg, transparent, #00f0ff, transparent);
        animation: none;
        box-shadow: none;
    }

    /* ২. স্লিম আরজিবি বর্ডার বক্স */
    .slim-rgb-container {
        position: relative;
        margin: 5px;
        padding: 1px;
        background: linear-gradient(var(--angle), #ff0000, #00ff00, #0000ff, #ff0000);
        animation: 4s rotate-border linear infinite;
        border-radius: 25px;
        overflow: hidden;
    }

    @property --angle {
        syntax: '<angle>';
        initial-value: 0deg;
        inherits: false;
    }

    @keyframes rotate-border {
        to { --angle: 360deg; }
    }

    /* ভেতরের কন্টেন্ট এরিয়া */
    .inner-page-content {
        background: #0f0f12;
        border-radius: 24px;
        padding: 10px;
        color: #ffffff;
    }

    @keyframes rgb_flow {
        to { background-position: 200% center; }
    }

    /* মোবাইলের জন্য ঠিক করা */
    @media (max-width: 768px) {
        .ultra-sticky-header { padding-top: 8px; margin-bottom: 15px; }
        .rgb-text-lighting { font-size: 1.2rem; }
        .slim-rgb-container { margin: 5px; border-radius: 20px; } 
        .inner-page-content { border-radius: 19px; padding: 5px; }
    }
</style>

<?php
get_footer();
