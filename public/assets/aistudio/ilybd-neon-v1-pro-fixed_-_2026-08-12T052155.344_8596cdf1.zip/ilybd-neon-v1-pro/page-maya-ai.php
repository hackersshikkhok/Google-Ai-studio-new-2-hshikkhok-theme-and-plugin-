<?php
/**
 * Template Name: Maya AI (মায়া এআই) - Google Gemini Search Engine Page
 * Description: Dedicated Live Search Engine & SEO Page for 'Maya AI' (iloveyoubd.com/maya-ai/)
 * Focus Keywords: maya ai, মায়া এআই, iloveyoubd maya ai, bangladesh ai search
 */

if (!defined('ABSPATH')) exit;

// Ensure Maya AI tools renderer is loaded
if (!function_exists('ilybd_render_tool_ai_maya_cloud_assistant')) {
    $ai_tools_file = get_template_directory() . '/inc/tools-suites/ai-tools.php';
    if (file_exists($ai_tools_file)) {
        require_once $ai_tools_file;
    }
}

get_header();
?>

<!-- JSON-LD STRUCTURED DATA SCHEMA FOR 'MAYA AI' -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "SoftwareApplication",
  "name": "Maya AI - Real-Time Knowledge & Search Engine",
  "alternateName": ["Maya AI", "মায়া এআই", "ILOVEYOUBD Maya AI"],
  "keywords": "maya ai, মায়া এআই, iloveyoubd maya ai, bangladesh ai search",
  "url": "https://iloveyoubd.com/maya-ai/",
  "applicationCategory": "SearchEngine",
  "operatingSystem": "All Browsers, Android, iOS, Windows, macOS",
  "description": "বাংলাদেশে তৈরি সর্বাধুনিক রিয়েল-টাইম মায়া এআই (Maya AI)। লাইভ গুগল সার্চ ডাটা ও ফ্যাক্টস ভেরিফিকেশন সহ একদম নিখুঁত উত্তর পাওয়ার এআই সার্চ ইঞ্জিন।",
  "softwareVersion": "2040.1.5",
  "offers": {
    "@type": "Offer",
    "price": "0.00",
    "priceCurrency": "BDT"
  },
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": "4.95",
    "ratingCount": "2150"
  }
}
</script>

<div class="ilybd-container" style="max-width: 1200px; margin: 30px auto; padding: 0 15px; min-height: 80vh;">
    <!-- MAYA AI PAGE BANNER HEADER -->
    <div style="background: linear-gradient(135deg, rgba(13,21,39,0.9), rgba(7,11,19,0.95)); border: 1px solid rgba(56, 189, 248, 0.25); border-radius: 16px; padding: 25px; margin-bottom: 25px; text-align: center; box-shadow: 0 10px 30px rgba(0,0,0,0.5);">
        <div style="display: inline-flex; align-items: center; gap: 10px; background: rgba(56, 189, 248, 0.1); border: 1px solid rgba(56, 189, 248, 0.3); padding: 6px 16px; border-radius: 20px; color: #38bdf8; font-size: 12px; font-weight: bold; margin-bottom: 12px; font-family: 'JetBrains Mono', monospace;">
            <span>🌐</span> MAYA AI SEARCH ENGINE // LIVE KNOWLEDGE GROUNDING
        </div>
        <h1 style="color: #ffffff; font-size: 28px; font-weight: 900; margin: 0 0 10px 0; font-family: 'Space Grotesk', 'Hind Siliguri', sans-serif;">
            মায়া এআই (Maya AI) - লাইভ নলেজ ও রিয়েল-টাইম এআই সার্চ
        </h1>
        <p style="color: #9ca3af; font-size: 14px; max-width: 750px; margin: 0 auto; line-height: 1.6;" class="bangla-font-siliguri">
            খবর, খেলাধুলা, সাম্প্রতিক ঘটনা ও তথ্য ভেরিফিকেশনের জন্য মায়া এআই ব্যবহার করুন। লাইভ ডাটা সোর্স থেকে নিখুঁত উত্তর প্রদান করবে মায়া।
        </p>
    </div>

    <!-- MAIN INTERACTIVE MAYA CHAT CONSOLE -->
    <div style="margin-bottom: 40px;">
        <?php
        if (function_exists('ilybd_render_tool_ai_maya_cloud_assistant')) {
            ilybd_render_tool_ai_maya_cloud_assistant();
        } else {
            echo '<div style="color:#ef4444; padding:20px; background:#111; border-radius:8px;">মায়া এআই সার্ভিসটি লোড হতে সমস্যা হচ্ছে। অনুগ্রহ করে পৃষ্ঠাটি রিফ্রেশ করুন।</div>';
        }
        ?>
    </div>

    <!-- SEO KNOWLEDGE SECTION -->
    <div style="background: rgba(13, 21, 39, 0.6); border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 16px; padding: 30px; margin-bottom: 40px;">
        <h2 style="color: #38bdf8; font-size: 20px; font-weight: 800; margin-top: 0; margin-bottom: 15px;" class="bangla-font-siliguri">
            মায়া এআই (Maya AI) লাইভ সার্চের বৈশিষ্ট্য
        </h2>
        <ul style="color: #cbd5e0; font-size: 14px; line-height: 1.8;" class="bangla-font-siliguri">
            <li><strong>রিয়েল-টাইম তথ্য:</strong> লাইভ ওয়েব ডাটা অ্যানালাইসিস করে সবসময় আপ-টু-ডেট তথ্য প্রদান করে।</li>
            <li><strong>উচ্চ নির্ভুলতা:</strong> তথ্যের সোর্স যাচাই করে সঠিক রেফারেন্স নিশ্চিত করে।</li>
            <li><strong>দ্রুত গতি:</strong> মাত্র এক ক্লিকে যেকোনো প্রশ্নের ইনস্ট্যান্ট রেসপন্স।</li>
        </ul>
    </div>
</div>

<?php
get_footer();
