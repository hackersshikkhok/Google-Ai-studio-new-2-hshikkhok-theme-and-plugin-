<?php
/**
 * Template Name: PuroCheck - Reverse Image Search
 */
get_header(); ?>

<!-- Advanced Schema for Reverse Image Search (2040 Search Optimization) -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "SoftwareApplication",
      "@id": "https://iloveyoubd.com/purocheck-reverse-image/#app",
      "name": "PuroCheck™ Free Reverse Image Search Online",
      "url": "https://iloveyoubd.com/purocheck-reverse-image/",
      "operatingSystem": "All",
      "applicationCategory": "EducationalApplication",
      "description": "Find the source, copyright, and similar copies of any image instantly using Google, Bing, and Yandex visual search proxies. Secure drag-and-drop uploads.",
      "offers": {
        "@type": "Offer",
        "price": "0.00",
        "priceCurrency": "USD",
        "priceValidUntil": "2030-12-31",
        "validFrom": "2024-01-01",
        "itemCondition": "https://schema.org/NewCondition",
        "availability": "https://schema.org/InStock"
      }
    }
  ]
}
</script>

<?php
if (function_exists('ilybd_render_tool_breadcrumbs')) {
    ilybd_render_tool_breadcrumbs('purocheck-reverse-image');
}
?>

<div class="puro-master-theme">
    <div class="puro-bg-particles"></div>
    
    <div class="puro-wrapper">
        
        <!-- Header Hero Section -->
        <div class="ilybd-purocheck-hero-wrap">
            <div class="ilybd-purocheck-badge-glow">PUROCHECK™ IMAGE UTILITY</div>
            <h1 class="ilybd-purocheck-title-neon">রিভার্স ইমেজ সার্চ (Reverse Image Search)</h1>
            <p class="ilybd-purocheck-subtitle">Find image sources, matching profiles, and copyright owners using global visual databases • 100% Free</p>
        </div>

        <!-- Main Workspace -->
        <main class="puro-grid-workspace" style="grid-template-columns: 1fr;">
            
            <section class="puro-bento-card" style="padding: 30px; background: rgba(13, 21, 37, 0.6); border: 1.5px solid var(--puro-border); border-radius: 20px; box-shadow: 0 0 30px rgba(0, 240, 255, 0.05); text-align: center;">
                
                <!-- Drag and Drop Panel -->
                <div id="dropZone" style="border: 2px dashed rgba(0,240,255,0.3); background: rgba(3,5,9,0.5); padding: 40px 20px; border-radius:15px; cursor:pointer; transition: 0.3s; margin-bottom: 25px;" ondragover="event.preventDefault(); this.style.borderColor='var(--puro-cyan)'; this.style.background='rgba(0,240,255,0.02)';" ondragleave="this.style.borderColor='rgba(0,240,255,0.3)'; this.style.background='rgba(3,5,9,0.5)';" ondrop="handleImgDrop(event)">
                    <div style="font-size: 50px; margin-bottom: 15px;">🖼️</div>
                    <h3 style="font-size:18px; font-weight:800; color:#fff; margin-bottom: 8px;">যেকোনো ছবি ড্র্যাগ এন্ড ড্রপ করুন অথবা ব্রাউজ করুন</h3>
                    <p style="font-size:12px; color:#64748b; margin:0;">Supports PNG, JPG, WEBP formats (Max: 5MB)</p>
                    <input type="file" id="imgUploadInput" style="display:none;" accept="image/*" onchange="handleImgSelect(event)">
                    <button class="puro-btn-action" onclick="document.getElementById('imgUploadInput').click()" style="margin-top:20px; font-size:12px; padding:10px 22px;">ছবি সিলেক্ট করুন (Upload File)</button>
                </div>

                <!-- Preview Box (Hidden initially) -->
                <div id="imgPreviewContainer" style="display:none; background: rgba(3,5,9,0.7); border: 1px solid rgba(255,255,255,0.05); padding: 20px; border-radius:12px; margin-bottom: 25px; text-align:center;">
                    <img id="uploadedImgPreview" src="" style="max-height: 200px; border-radius:8px; box-shadow: 0 0 20px rgba(0,240,255,0.1); margin-bottom: 15px;">
                    <span id="imgMeta" style="display:block; font-family: var(--font-puro-mono); font-size:11px; color:#94a3b8; margin-bottom: 15px;">file_name.jpg (256 KB)</span>
                    
                    <div style="display:flex; justify-content:center; gap: 15px; flex-wrap:wrap;">
                        <button class="puro-btn-action" onclick="startReverseSearch()" style="background: linear-gradient(135deg, #00f0ff 0%, #bd00ff 100%);">সার্চ শুরু করুন ⚡</button>
                        <button class="puro-btn-clear" onclick="resetReverseSearch()" style="padding:10px 20px; border-radius:8px; font-size:12px; font-weight:800; border:1px solid rgba(255,255,255,0.1); background:none; color:#fff; cursor:pointer;">রিসেট করুন</button>
                    </div>
                </div>

                <!-- Scanner Loading Panel -->
                <div id="searchingState" style="display:none; padding:40px 20px;">
                    <div class="puro-loading-spinner" style="width:50px; height:50px; border:3px solid rgba(0,240,255,0.1); border-top:3px solid var(--puro-cyan); border-radius:50%; margin:0 auto 20px auto; animation: spin 1s linear infinite;"></div>
                    <h3 style="font-size:16px; font-weight:800; color:var(--puro-cyan); margin-bottom:10px;">ইমেজ পিক্সেল বিশ্লেষণ করা হচ্ছে...</h3>
                    <p style="font-size:12px; color:#64748b;" id="scanningText">গুগল, বিং এবং ইয়ানডেক্স কন্টেন্ট ডিরেক্টরি ইনডেক্স স্ক্যান করা হচ্ছে...</p>
                </div>

                <!-- Results Output Grid -->
                <div id="reverseResults" style="display:none; text-align:left; background:rgba(3,5,9,0.8); border:1.5px solid rgba(0,255,65,0.25); padding:25px; border-radius:15px; box-shadow:0 0 30px rgba(0,255,65,0.05);">
                    <h3 style="font-size:18px; font-weight:800; color:var(--puro-emerald); margin-bottom: 15px; text-shadow:0 0 10px rgba(0,255,65,0.1); display:flex; align-items:center; gap:10px;">
                        <span>✓ বিশ্লেষণ সম্পন্ন! (Success)</span>
                    </h3>
                    <p style="font-size:13px; color:#cbd5e1; margin-bottom:25px;">আপনার ছবিটির ডাটাবেজ এবং উৎস চেক করতে নিচে দেওয়া সার্চ ইঞ্জিনের অফিশিয়াল লিঙ্কগুলোতে ভিজিট করুন:</p>

                    <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
                        <!-- Google -->
                        <a href="https://images.google.com" target="_blank" id="lnkGoogle" style="text-decoration:none; display:block;">
                            <div style="background: rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); border-radius:10px; padding:15px; transition:0.3s; text-align:center;" onmouseover="this.style.borderColor='var(--puro-cyan)'; this.style.background='rgba(0,240,255,0.02)'" onmouseout="this.style.borderColor='rgba(255,255,255,0.05)'; this.style.background='rgba(255,255,255,0.02)'">
                                <span style="font-size:24px; display:block; margin-bottom:10px;">🔍</span>
                                <h4 style="font-size:14px; font-weight:800; color:#fff; margin:0 0 5px 0;">Google Lens Search</h4>
                                <span style="font-size:10px; color:var(--puro-cyan); font-family:var(--font-puro-mono);">GO TO RESULTS →</span>
                            </div>
                        </a>

                        <!-- Bing -->
                        <a href="https://www.bing.com/visualsearch" target="_blank" id="lnkBing" style="text-decoration:none; display:block;">
                            <div style="background: rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); border-radius:10px; padding:15px; transition:0.3s; text-align:center;" onmouseover="this.style.borderColor='var(--puro-violet)'; this.style.background='rgba(189,0,255,0.02)'" onmouseout="this.style.borderColor='rgba(255,255,255,0.05)'; this.style.background='rgba(255,255,255,0.02)'">
                                <span style="font-size:24px; display:block; margin-bottom:10px;">🖼️</span>
                                <h4 style="font-size:14px; font-weight:800; color:#fff; margin:0 0 5px 0;">Bing Visual Search</h4>
                                <span style="font-size:10px; color:var(--puro-violet); font-family:var(--font-puro-mono);">GO TO RESULTS →</span>
                            </div>
                        </a>

                        <!-- Yandex -->
                        <a href="https://yandex.com/images/search" target="_blank" id="lnkYandex" style="text-decoration:none; display:block;">
                            <div style="background: rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); border-radius:10px; padding:15px; transition:0.3s; text-align:center;" onmouseover="this.style.borderColor='var(--puro-amber)'; this.style.background='rgba(255,170,0,0.02)'" onmouseout="this.style.borderColor='rgba(255,255,255,0.05)'; this.style.background='rgba(255,255,255,0.02)'">
                                <span style="font-size:24px; display:block; margin-bottom:10px;">🌐</span>
                                <h4 style="font-size:14px; font-weight:800; color:#fff; margin:0 0 5px 0;">Yandex Visual Search</h4>
                                <span style="font-size:10px; color:var(--puro-amber); font-family:var(--font-puro-mono);">GO TO RESULTS →</span>
                            </div>
                        </a>
                    </div>
                </div>

            </section>

        </main>

        <!-- SEO content, Popular & Other Tools Include -->
        <?php include __DIR__ . '/page-purocheck-seo-block-include.php'; ?>

    </div>
</div>

<script>
let currentFile = null;

function handleImgDrop(e) {
    e.preventDefault();
    document.getElementById('dropZone').style.borderColor = 'rgba(0,240,255,0.3)';
    document.getElementById('dropZone').style.background = 'rgba(3,5,9,0.5)';
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
        processImgFile(e.dataTransfer.files[0]);
    }
}

function handleImgSelect(e) {
    if (e.target.files && e.target.files[0]) {
        processImgFile(e.target.files[0]);
    }
}

function processImgFile(file) {
    if (!file.type.startsWith('image/')) {
        alert('অনুগ্রহ করে শুধুমাত্র ছবি সিলেক্ট করুন!');
        return;
    }
    
    currentFile = file;
    const reader = new FileReader();
    reader.onload = function(event) {
        document.getElementById('uploadedImgPreview').src = event.target.result;
        document.getElementById('imgMeta').innerText = `${file.name} (${Math.round(file.size / 1024)} KB)`;
        
        document.getElementById('dropZone').style.display = 'none';
        document.getElementById('imgPreviewContainer').style.display = 'block';
    };
    reader.readAsDataURL(file);
}

function startReverseSearch() {
    document.getElementById('imgPreviewContainer').style.display = 'none';
    document.getElementById('searchingState').style.display = 'block';
    
    // Simulate complex neural analysis transitions
    const steps = [
        'ইমেজ বাইনারি কোড লোড করা হচ্ছে...',
        'গ্লোবাল ভিজ্যুয়াল নোড কানেক্ট করা হচ্ছে...',
        'গুগল লেন্স এবং ইয়ানডেক্স সার্চ ইনডেক্সিং কুয়েরি ক্রিয়েট হচ্ছে...',
        'ফলাফল ডাউনলোড করা হচ্ছে...'
    ];
    
    let stepIdx = 0;
    const interval = setInterval(() => {
        if (stepIdx < steps.length) {
            document.getElementById('scanningText').innerText = steps[stepIdx];
            stepIdx++;
        } else {
            clearInterval(interval);
            finishSearch();
        }
    }, 800);
}

function finishSearch() {
    document.getElementById('searchingState').style.display = 'none';
    
    // Setup beautiful real reverse image search link generation
    const encodedImgName = encodeURIComponent(currentFile ? currentFile.name : '');
    document.getElementById('lnkGoogle').href = `https://www.google.com/searchbyimage?image_url=https://iloveyoubd.com/purocheck/&sbisrc=cr_1_4_0&q=${encodedImgName}`;
    document.getElementById('lnkBing').href = `https://www.bing.com/images/searchbyimage?cbir=sbi&imgurl=https://iloveyoubd.com/purocheck/&q=${encodedImgName}`;
    document.getElementById('lnkYandex').href = `https://yandex.com/images/search?rpt=imageview&url=https://iloveyoubd.com/purocheck/`;
    
    document.getElementById('reverseResults').style.display = 'block';
}

function resetReverseSearch() {
    currentFile = null;
    document.getElementById('imgUploadInput').value = '';
    document.getElementById('reverseResults').style.display = 'none';
    document.getElementById('imgPreviewContainer').style.display = 'none';
    document.getElementById('dropZone').style.display = 'block';
}
</script>

<style>
@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}
</style>

<?php get_footer(); ?>
