<?php
/**
 * Template Name: PuroCheck - Keyword Density Checker
 */
$preselected_service = 'seo-density';
include __DIR__ . '/page-purocheck.php';
