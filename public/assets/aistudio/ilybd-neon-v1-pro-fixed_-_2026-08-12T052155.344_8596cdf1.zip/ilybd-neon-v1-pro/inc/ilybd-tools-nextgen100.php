<?php
/**
 * 2040 NextGen 100 Premium Tools Registry
 * Adds 100 brand-new, unique, high-value, 100% AdSense & SEO optimized tools.
 */

function ilybd_get_nextgen100_tools() {
    return [
        /* ===================================================
         * CATEGORY A — WEBMASTER & WEBSITE ANALYSIS (10 Tools)
         * =================================================== */
        "meta-tag-analyzer" => [
            "name" => "Website Meta Tag Analyzer",
            "name_bn" => "ওয়েবসাইট মেটা ট্যাগ এনালাইজার",
            "category" => "webmaster-tools",
            "desc_en" => "Analyze meta tags, title length, description pixel bounds, canonicals, and open graph markup instantly.",
            "desc_bn" => "আপনার ওয়েবসাইটের মেটা ট্যাগ, টাইটেল, ডেসক্রিপশন এবং ক্যানোনিকাল ট্যাগ নিখুঁতভাবে চেক করুন।",
            "features" => ["পিক্সেল লিমিট চেক", "ক্যানোনিকাল ভ্যালিডেশন", "ওপেন গ্রাফ রিভিউ"],
            "benefits" => ["এসইও র্যাঙ্কিং বৃদ্ধি", "সার্চ ইঞ্জিনে ভালো পারফরম্যান্স"],
            "faqs" => [["Q" => "মেটা ট্যাগ কি এসইওর জন্য গুরুত্বপূর্ণ?", "A" => "হ্যাঁ, সঠিক মেটা ট্যাগ সার্চ ইঞ্জিনকে পেজের কন্টেন্ট বুঝতে সাহায্য করে।"]]
        ],
        "open-graph-preview" => [
            "name" => "Open Graph Preview Generator",
            "name_bn" => "ওপেন গ্রাফ সোশ্যাল প্রিভিউ মেকার",
            "category" => "webmaster-tools",
            "desc_en" => "Preview how your webpage links appear when shared on Facebook, WhatsApp, LinkedIn, and Discord.",
            "desc_bn" => "ফেসবুক, হোয়াটসঅ্যাপ এবং লিংকডইনে লিংক শেয়ার করলে কেমন দেখাবে তার লাইভ প্রিভিউ দেখুন।",
            "features" => ["লাইভ প্রিভিউ কার্ড", "ইমেজ সাইজ চেক", "সোশ্যাল ট্যাগ সাজেশন"],
            "benefits" => ["সোশ্যাল মিডিয়া সিটিআর বৃদ্ধি", "শেয়ারিং প্রফেশনাল লুক"],
            "faqs" => [["Q" => "ওপেন গ্রাফ ইমেজ সাইজ কত হতে হয়?", "A" => "সাধারণত ১২০০x৬ ৩০ পিক্সেল সবচেয়ে ভালো দেখায়।"]]
        ],
        "twitter-card-preview" => [
            "name" => "Twitter/X Card Preview Generator",
            "name_bn" => "টুইটার এক্স কার্ড প্রিভিউ জেনারেটর",
            "category" => "webmaster-tools",
            "desc_en" => "Generate and preview Twitter Summary Card with Large Image meta tags for maximum X feed engagement.",
            "desc_bn" => "টুইটার বা এক্স প্ল্যাটফর্মে আপনার আর্টিকেলের শেয়ারিং কার্ড লাইভ টেস্ট করুন।",
            "features" => ["Summary Card Large Image Support", "হ্যান্ডেল ভ্যালিডেশন", "ইনস্ট্যান্ট মেটা কোড"],
            "benefits" => ["টুইটারে ক্লিক রেট বৃদ্ধি", "ব্র্যান্ড পরিচিতি তৈরি"],
            "faqs" => [["Q" => "টুইটার কার্ড কাজ না করলে কি করব?", "A" => "টুইটার কার্ড ভ্যালিডেটর দিয়ে মেটা ক্যাশ রিফ্রেশ করতে পারেন।"]]
        ],
        "http-status-checker" => [
            "name" => "HTTP Status Code Checker",
            "name_bn" => "এইচটিটিপি স্ট্যাটাস কোড চেকার",
            "category" => "webmaster-tools",
            "desc_en" => "Analyze HTTP status codes (200 OK, 301 Redirect, 404 Not Found, 500 Error) with SEO implications.",
            "desc_bn" => "যেকোনো সার্ভার রেসপন্স কোড এবং এর এসইও প্রভাব বিশ্লেষণ করুন।",
            "features" => ["সার্ভার কোড মিনিং", "এসইও ইমপ্যাক্ট গাইড", "হেডার অ্যানালাইসিস"],
            "benefits" => ["ব্রোকেন লিংক সনাক্তকরণ", "সার্ভার হেলথ মনিটরিং"],
            "faqs" => [["Q" => "৩০১ এবং ৩০২ এর মধ্যে পার্থক্য কি?", "A" => "৩০১ হলো পার্মানেন্ট রিডাইরেক্ট আর ৩০২ হলো টেম্পোরারি।"]]
        ],
        "redirect-chain-analyzer" => [
            "name" => "Redirect Chain Analyzer",
            "name_bn" => "রিডাইরেক্ট চেইন এনালাইজার",
            "category" => "webmaster-tools",
            "desc_en" => "Identify multi-step URL redirects that slow down page speed and leak PageRank equity.",
            "desc_bn" => "আপনার ওয়েবসাইটের ধীরগতির রিডাইরেক্ট চেইন সনাক্ত করে পেজ স্পিড ঠিক করুন।",
            "features" => ["হপ কাউন্টার", "পেজর্যাঙ্ক লস ইন্ডিকেটর", "স্পিড ইমপ্যাক্ট রিপোর্ট"],
            "benefits" => ["ক্রল বাজেট সাশ্রয়", "পেজ লোডিং স্পিড বাড়ানো"],
            "faqs" => [["Q" => "রিডাইরেক্ট চেইন কেন খারাপ?", "A" => "এটি পেজ লোড টাইম বাড়ায় এবং গুগল ক্রলিং ধীর করে দেয়।"]]
        ],
        "canonical-checker" => [
            "name" => "Canonical URL Checker",
            "name_bn" => "ক্যানোনিকাল ইউআরএল চেকার",
            "category" => "webmaster-tools",
            "desc_en" => "Validate canonical URLs to prevent duplicate content issues and indexing conflicts.",
            "desc_bn" => "ওয়েবসাইটের ডুপ্লিকেট কন্টেন্ট সমস্যা এড়াতে ক্যানোনিকাল লিংক পরীক্ষা করুন।",
            "features" => ["প্রোটোকল ম্যাচিং", "ট্রেইলিং স্ল্যাশ ভ্যালিডেশন", "ক্রস ডোমেইন অডিট"],
            "benefits" => ["গুগল ইনডেক্সিং সুরক্ষা", "ডুপ্লিকেট পেনাল্টি রোধ"],
            "faqs" => [["Q" => "ক্যানোনিকাল ট্যাগ না দিলে কি হয়?", "A" => "গুগল একই কন্টেন্টের একাধিক ভার্সন ইনডেক্স করে পেনাল্টি দিতে পারে।"]]
        ],
        "robots-txt-tester" => [
            "name" => "Robots.txt Tester & Validator",
            "name_bn" => "রোবটস টিএক্সটি টেস্টার",
            "category" => "webmaster-tools",
            "desc_en" => "Test and validate your robots.txt syntax against search engine bots (Googlebot, Bingbot).",
            "desc_bn" => "আপনার সাইটের robots.txt ফাইল টেস্ট করে দেখুন সার্চ বট কোন ইউআরএল ব্লক করছে।",
            "features" => ["বট রুল সিমুলেটর", "লাইন বাই লাইন হাইলাইট", "আলাউ/ডিসআলাউ চেকার"],
            "benefits" => ["গুরুত্বপূর্ণ পেজ গুগল ইনডেক্সে রাখা", "প্রাইভেট পেজ ব্লক নিশ্চিতকরণ"],
            "faqs" => [["Q" => "Robots.txt কোথায় থাকে?", "A" => "ওয়েবসাইটের রুট ডিরেক্টরিতে (Domain.com/robots.txt)।"]]
        ],
        "sitemap-validator" => [
            "name" => "XML Sitemap Validator",
            "name_bn" => "এক্সএমএল সাইটম্যাপ ভ্যালিডেটর",
            "category" => "webmaster-tools",
            "desc_en" => "Check XML sitemap syntax, date formats, priority levels, and location tag structure.",
            "desc_bn" => "আপনার সাইটম্যাপের এক্সএমএল গঠন ও ইউআরএল ফরম্যাট সঠিকভাবে যাচাই করুন।",
            "features" => ["XML সিনট্যাক্স লিন্টার", "লাস্টমড তারিখ ফরম্যাট চেকার", "প্রাইওরিটি ভ্যালিডেটর"],
            "benefits" => ["গুগল সার্চ কনসোলে সাইটম্যাপ এরর মুক্ত রাখা", "দ্রুত ইনডেক্সিং"],
            "faqs" => [["Q" => "সাইটম্যাপে সর্বোচ্চ কত ইউআরএল রাখা যায়?", "A" => "একটি সাইটম্যাপ ফাইলে সর্বোচ্চ ৫০,০০০ ইউআরএল রাখা যায়।"]]
        ],
        "response-header-viewer" => [
            "name" => "Website Response Header Viewer",
            "name_bn" => "ওয়েবসাইট রেসপন্স হেডার ভিউয়ার",
            "category" => "webmaster-tools",
            "desc_en" => "Inspect HTTP response headers including Content-Security-Policy, Cache-Control, and CORS settings.",
            "desc_bn" => "ওয়েবসাইটের সিকিউরিটি হেডার এবং ক্যাশিং সেটিংস বিশ্লেষণ করুন।",
            "features" => ["CSP ও HSTS চেকার", "ক্যাশ কন্ট্রোল অ্যানালাইসিস", "সিকিউরিটি র্যাঙ্কিং"],
            "benefits" => ["সাইটের নিরাপত্তা বৃদ্ধি", "ক্যাশিং সমস্যার সমাধান"],
            "faqs" => [["Q" => "HSTS হেডার কেন দরকার?", "A" => "এটি ব্রাউজারকে শুধুমাত্র HTTPS ব্রাউজ করতে বাধ্য করে সাইট নিরাপদ রাখে।"]]
        ],
        "content-size-analyzer" => [
            "name" => "Website Content Size Analyzer",
            "name_bn" => "ওয়েবসাইট কন্টেন্ট সাইজ এনালাইজার",
            "category" => "webmaster-tools",
            "desc_en" => "Measure HTML document payload, Gzip compression savings, and Text-to-HTML ratio.",
            "desc_bn" => "ওয়েবসাইটের এইচটিএমএল সাইজ এবং টেক্সট-টু-এইচটিএমএল অনুপাত হিসাব করুন।",
            "features" => ["বাইটস সাইজ মেজারমেন্ট", "জিযিপ সেভিংস ক্যালকুলেটর", "টেক্সট অনুপাত স্ক্যানার"],
            "benefits" => ["পেজ লোডিং স্পিড অপ্টিমাইজেশন", "এসইও টেক্সট ডেনসিটি বৃদ্ধি"],
            "faqs" => [["Q" => "উত্তম টেক্সট টু এইচটিএমএল রেশিও কত?", "A" => "১৫% থেকে ২৫% এর উপরে টেক্সট অনুপাত সবচেয়ে ভালো।"]]
        ],

        /* ===================================================
         * CATEGORY B — SEO CONTENT & ON-PAGE (10 Tools)
         * =================================================== */
        "content-outline-generator" => [
            "name" => "SEO Content Outline Generator",
            "name_bn" => "এসইও কন্টেন্ট আউটলাইন জেনারেটর",
            "category" => "seo-tools",
            "desc_en" => "Generate structured H1, H2, H3 article outlines optimized for search intent and topical completeness.",
            "desc_bn" => "যেকোনো টপিকের জন্য সুসংগঠিত H1, H2, H3 হেডিং সহ এসইও আউটলাইন তৈরি করুন।",
            "features" => ["হেডিং হায়ারার্কি প্ল্যানার", "সার্চ ইনটেন্ট ম্যাচিং", "মার্কডাউন কপির অপশন"],
            "benefits" => ["দ্রুত আর্টিকেল রাইটিং", "গুগলে র্যাঙ্কিং এর সম্ভাবনা বাড়ানো"],
            "faqs" => [["Q" => "আউটলাইন কেন দরকার?", "A" => "এটি কন্টেন্ট লেখার সময় সঠিক দিকনির্দেশনা দেয়।"]]
        ],
        "keyword-cluster-builder" => [
            "name" => "Keyword Cluster Builder",
            "name_bn" => "কিওয়ার্ড ক্লাস্টার বিল্ডার",
            "category" => "seo-tools",
            "desc_en" => "Group raw keyword lists into semantic topic clusters to build high topical authority.",
            "desc_bn" => "আপনার কিওয়ার্ডের তালিকা সেমান্টিক টপিক অনুযায়ী ক্লাস্টার বা গ্রুপ তৈরি করুন।",
            "features" => ["অটোমেটিক ক্লাস্টারিং", "ইনটেন্ট গ্রুপিং", "সিএসভি এক্সপোর্ট"],
            "benefits" => ["টপিক্যাল অথরিটি অর্জন", "কন্টেন্ট স্ট্র্যাটেজি সহজ করা"],
            "faqs" => [["Q" => "কিওয়ার্ড ক্লাস্টার কি?", "A" => "একই বিষয়ের সম্পর্কিত কিওয়ার্ডগুলোকে একসাথে সাজানোই হলো ক্লাস্টার।"]]
        ],
        "internal-link-analyzer" => [
            "name" => "Internal Link Opportunity Analyzer",
            "name_bn" => "ইন্টারনাল লিংক অপরচুনিটি এনালাইজার",
            "category" => "seo-tools",
            "desc_en" => "Scan article text to uncover ideal anchor text phrases for internal contextual linking.",
            "desc_bn" => "আপনার আর্টিকেলের ভেতরে ইন্টারনাল লিংকিং এর জন্য সেরা অ্যাঙ্কর টেক্সট খুঁজুন।",
            "features" => ["এনটিটি ফ্রেজ স্ক্যানার", "অ্যাঙ্কর টেক্সট সাজেস্টর", "লিংক ডেনসিটি চেক"],
            "benefits" => ["পেজর্যাঙ্ক শেয়ারিং বৃদ্ধি", "সাইট নেভিগেশন সহজীকরণ"],
            "faqs" => [["Q" => "ইন্টারনাল লিংক কেন দরকার?", "A" => "এটি গুগলের বটকে পুরো সাইটের পেজগুলো সহজে ইনডেক্স করতে সাহায্য করে।"]]
        ],
        "entity-relationship-mapper" => [
            "name" => "SEO Entity Relationship Mapper",
            "name_bn" => "এসইও এনটিটি রিলেশনশিপ ম্যাপার",
            "category" => "seo-tools",
            "desc_en" => "Map primary entities, sub-entities, and semantic attributes for Google Knowledge Graph optimization.",
            "desc_bn" => "গুগল নলেজ গ্রাফ ও সেমান্টিক এসইওর জন্য প্রধান এনটিটি এবং সম্পর্ক ম্যাপিং করুন।",
            "features" => ["সেমান্টিক নোড ম্যাপ", "নলেজ গ্রাফ অ্যালাইনমেন্ট", "স্কিমা এনটিটি জেনারেটর"],
            "benefits" => ["সেমান্টিক র্যাঙ্কিং বুস্ট", "কন্টেন্টের প্রাসঙ্গিকতা বৃদ্ধি"],
            "faqs" => [["Q" => "এনটিটি এসইও কি?", "A" => "গুগল এখন শুধুমাত্র কিওয়ার্ড নয়, রিয়েল-ওয়ার্ল্ড অবজেক্ট বা এনটিটি বুঝে র্যাঙ্ক দেয়।"]]
        ],
        "search-intent-analyzer" => [
            "name" => "Search Intent Breakdown Tool",
            "name_bn" => "সার্চ ইনটেন্ট ব্রেকডাউন টুল",
            "category" => "seo-tools",
            "desc_en" => "Categorize keywords into Informational, Navigational, Commercial, or Transactional intent.",
            "desc_bn" => "কিওয়ার্ডের সার্চ ইনটেন্ট (তথ্যভিত্তিক, ব্যবসায়িক, ক্রয়সংক্রান্ত) নিখুঁতভাবে চিহ্নিত করুন।",
            "features" => ["৪-ধাপের ইনটেন্ট ক্লাসিফায়ার", "কন্টেন্ট টাইপ রেকমেন্ডেশন", "কনভার্সন রেটিং"],
            "benefits" => ["সঠিক ইউজারের কাছে পৌঁছানো", "বাউন্স রেট কমানো"],
            "faqs" => [["Q" => "ইনটেন্ট ভুল হলে কি হয়?", "A" => "ইউজার কাঙ্ক্ষিত তথ্য না পেয়ে পেজ থেকে বেরিয়ে যাবে, ফলে র্যাঙ্কিং কমবে।"]]
        ],
        "serp-title-preview" => [
            "name" => "SERP Title Preview Simulator",
            "name_bn" => "সার্চ রেজাল্ট টাইটেল প্রিভিউ সিমুলেটর",
            "category" => "seo-tools",
            "desc_en" => "Simulate Google SERP title displays with precise pixel width measurement and truncation warnings.",
            "desc_bn" => "গুগল সার্চে আপনার আর্টিকেলের টাইটেল কতটুকু দেখাবে তা পিক্সেল পরিমাপসহ লাইভ দেখুন।",
            "features" => ["৬০০ পিক্সেল গেজ মিটার", "মোবাইল ও ডেক্সটপ ভিউ", "পাওয়ার ওয়ার্ড সাজেস্টর"],
            "benefits" => ["টাইটেল কেটে যাওয়া রোধ", "সার্চে অর্গানিক সিটিআর বাড়ানো"],
            "faqs" => [["Q" => "গুগল টাইটেল কেটে দেয় কেন?", "A" => "টাইটেল যদি ৬০ ক্যারেক্টার বা ৬০০ পিক্সেলের চেয়ে বড় হয় তবে কেটে ডট ডট দেয়।"]]
        ],
        "meta-description-preview" => [
            "name" => "Meta Description Preview Simulator",
            "name_bn" => "মেটা ডেসক্রিপশন প্রিভিউ সিমুলেটর",
            "category" => "seo-tools",
            "desc_en" => "Test meta description snippets against Google desktop (960px) and mobile limits.",
            "desc_bn" => "মেটা ডেসক্রিপশন সার্চ রেজাল্টে কেমন দেখাবে তার পিক্সেল লিমিট ও ডেমো প্রিভিউ দেখুন।",
            "features" => ["৯৬০ পিক্সেল কাউন্টার", "সিটিএ অ্যাকশন মিটার", "কপিরাইটিং সাজেশন"],
            "benefits" => ["সার্চ স্নিপেট আকর্ষণীয় করা", "ক্লিক সংখ্যা বৃদ্ধি"],
            "faqs" => [["Q" => "মেটা ডেসক্রিপশন কত বড় হওয়া উচিত?", "A" => "১৬০ ক্যারেক্টারের মধ্যে রাখা সবচেয়ে ভালো।"]]
        ],
        "content-brief-generator" => [
            "name" => "SEO Content Brief Generator",
            "name_bn" => "এসইও কন্টেন্ট ব্রিফ জেনারেটর",
            "category" => "seo-tools",
            "desc_en" => "Create comprehensive editorial briefs with target word counts, primary/secondary keywords, and target persona.",
            "desc_bn" => "কন্টেন্ট রাইটারদের জন্য সম্পূর্ণ এসইও ব্রিফ এবং নির্দেশিকা তৈরি করুন।",
            "features" => ["ওয়ার্ড কাউন্ট গোল", "কিওয়ার্ড লিস্ট মেকার", "অডিয়েন্স পারসোনা নির্দেশিকা"],
            "benefits" => ["রাইটিং টিম ম্যানেজমেন্ট সহজ করা", "কন্টেন্টের মান নিশ্চিত করা"],
            "faqs" => [["Q" => "কন্টেন্ট ব্রিফ কেন লাগে?", "A" => "রাইটার যেন সঠিক এসইও রুলস মেনে লিখতে পারে তা নিশ্চিত করতে।"]]
        ],
        "topical-coverage-checker" => [
            "name" => "Topical Coverage Checklist",
            "name_bn" => "টপিক্যাল কভারেজ চেকক্লিপ",
            "category" => "seo-tools",
            "desc_en" => "Assess article depth against essential 5W1H core sub-topics for complete topical coverage.",
            "desc_bn" => "আপনার আর্টিকেলটি মূল বিষয়ের সব প্রশ্নের উত্তর দিচ্ছে কিনা তা স্কোরিং সহ চেক করুন।",
            "features" => ["৫W১H প্রশ্ন স্ক্যানার", "টপিক্যাল স্কোর%", "মিসিং গ্যাপ হাইলাইটার"],
            "benefits" => ["গুগলে হেল্পফুল কন্টেন্ট র্যাঙ্ক অর্জন", "সম্পূর্ণ তথ্য প্রদান"],
            "faqs" => [["Q" => "টপিক্যাল কভারেজ কি?", "A" => "একটি বিষয়ের সমস্ত গুরুত্বপূর্ণ দিক কভার করার ক্ষমতা।"]]
        ],
        "content-cannibalization-checker" => [
            "name" => "Content Cannibalization Detector",
            "name_bn" => "কন্টেন্ট ক্যানিব্যালাইজেশন ডিটেক্টর",
            "category" => "seo-tools",
            "desc_en" => "Identify competing URLs targeting identical primary keywords to resolve internal keyword conflicts.",
            "desc_bn" => "আপনার সাইটের একাধিক পেজ একই কিওয়ার্ড নিয়ে প্রতিযোগিতা করছে কিনা তা খুঁজুন।",
            "features" => ["কিওয়ার্ড ওভারল্যাপ স্ক্যানার", "কনসোলিডেশন গাইড", "ইউআরএল কনফ্লিক্ট ফ্ল্যাগ"],
            "benefits" => ["র্যাঙ্কিং ড্রপ ঠেকানো", "সাইট স্ট্রাকচার মজবুত করা"],
            "faqs" => [["Q" => "ক্যানিব্যালাইজেশন হলে কি সমস্যা?", "A" => "গুগল কনফিউজড হয়ে যায় কোন পেজকে র্যাঙ্ক দেবে এবং দুটি পেজই র্যাঙ্ক হারায়।"]]
        ],

        /* ===================================================
         * CATEGORY C — IMAGE & MEDIA (10 Tools)
         * =================================================== */
        "image-metadata-viewer" => [
            "name" => "Image Metadata & EXIF Viewer",
            "name_bn" => "ইমেজ মেটাডেটা ও এক্সিফ ভিউয়ার",
            "category" => "image-tools",
            "desc_en" => "Extract width, height, resolution, color depth, aspect ratio, and file format metadata safely in-browser.",
            "desc_bn" => "ছবির রেজোলিউশন, ফরম্যাট, ফাইল সাইজ ও মেটাডেটা প্রাইভেসির সাথে দেখুন।",
            "features" => ["ইনস্ট্যান্ট ক্যানভাস স্ক্যান", "প্রাইভেট ব্রাউজার প্রসেসিং", "আস্পেক্ট রেশিও ডিটেকশন"],
            "benefits" => ["ছবির সঠিক মাত্রা জানা", "ওয়েব অপ্টিমাইজেশনের সুবিধা"],
            "faqs" => [["Q" => "আমার ছবি কি সার্ভারে সেভ হবে?", "A" => "না, ১০০% ক্লায়েন্ট-সাইড প্রসেসিং হয়।"]]
        ],
        "image-dpi-calculator" => [
            "name" => "Image DPI & Print Calculator",
            "name_bn" => "ইমেজ ডিপিআই ও প্রিন্ট ক্যালকুলেটর",
            "category" => "image-tools",
            "desc_en" => "Calculate maximum high-quality print dimensions in inches and cm based on image pixel dimensions and target DPI.",
            "desc_bn" => "ছবির পিক্সেল অনুযায়ী প্রিন্ট করার সাইজ (ইঞ্চি/সেমি) এবং ডিপিআই হিসাব করুন।",
            "features" => ["৭২, ১৫০, ৩০০ DPI প্রিপ্রোসেসিং", "ইঞ্চি ও সেমি রূপান্তর", "প্রিন্ট কোয়ালিটি গেজ"],
            "benefits" => ["ঝাপসা প্রিন্ট রোধ", "সঠিক রেজোলিউশন নিশ্চিতকরণ"],
            "faqs" => [["Q" => "প্রিন্টিং এর জন্য কত ডিপিআই ভালো?", "A" => "উচ্চমানের প্রিন্টের জন্য ৩০০ DPI আদর্শ।"]]
        ],
        "image-size-estimator" => [
            "name" => "Image File Size Estimator",
            "name_bn" => "ইমেজ ফাইল সাইজ এস্টিমেটর",
            "category" => "image-tools",
            "desc_en" => "Estimate uncompressed vs compressed file sizes for PNG, JPEG, WebP, and AVIF across quality levels.",
            "desc_bn" => "বিভিন্ন ফরম্যাট ও কোয়ালিটিতে ছবির আনুমানিক ফাইল সাইজ অনুমান করুন।",
            "features" => ["কোয়ালিটি স্লাইডার", "ওয়েবপি ও এভিআইএফ তুলনা", "ব্যান্ডউইথ সেভিং%"],
            "benefits" => ["সাইট লোডিং টাইম কমানো", "ওয়েব হোস্টিং স্পেস সাশ্রয়"],
            "faqs" => [["Q" => "ওয়েবের জন্য কোন ফরম্যাট সেরা?", "A" => "WebP এবং AVIF সবচেয়ে ছোট ফাইল সাইজ দেয়।"]]
        ],
        "webp-quality-estimator" => [
            "name" => "WebP Quality & Savings Estimator",
            "name_bn" => "ওয়েবপি কোয়ালিটি ও সেভিংস এস্টিমেটর",
            "category" => "image-tools",
            "desc_en" => "Calculate data storage savings when converting legacy JPEG and PNG images into modern WebP format.",
            "desc_bn" => "ছবি WebP ফরম্যাটে রূপান্তর করলে কত শতাংশ ডাটা ও ফাইল সাইজ বাঁচবে তা হিসাব করুন।",
            "features" => ["৮০%, ৭০%, ৬০% কোয়ালিটি স্কেল", "সেভিংস পারসেন্টেজ", "ব্যান্ডউইথ সাশ্রয়"],
            "benefits" => ["ওয়েবসাইট ফাস্ট করা", "গুগল কোর ওয়েব ভাইটালস ইম্প্রুভমেন্ট"],
            "faqs" => [["Q" => "WebP কি সব ব্রাউজারে কাজ করে?", "A" => "হ্যাঁ, আধুনিক সব ব্রাউজারে WebP সাপোর্ট করে।"]]
        ],
        "avif-converter" => [
            "name" => "AVIF Image Converter Utility",
            "name_bn" => "এভিআইএফ ইমেজ কনভার্টার",
            "category" => "image-tools",
            "desc_en" => "Convert PNG and JPEG images into ultra-compressed AVIF format right inside your browser.",
            "desc_bn" => "আপনার ব্রাউজারেই ছবিকে অত্যন্ত ছোট ফাইল সাইজের AVIF ফরম্যাটে রূপান্তর করুন।",
            "features" => ["ক্লায়েন্ট ক্যানভাস কনভার্সন", "ইনস্ট্যান্ট ডাউনলোড", "প্রাইভেসি সেফ"],
            "benefits" => ["সর্বোচ্চ ৫০% ফাইল সাইজ হ্রাস", "ফাস্ট ইমেজ লোডিং"],
            "faqs" => [["Q" => "AVIF কেন ব্যবহার করব?", "A" => "এটি WebP এর চেয়েও বেশি কমপ্রেস করে ভালো কোয়ালিটি রাখে।"]]
        ],
        "image-crop-ratio" => [
            "name" => "Image Crop Ratio Preset Tool",
            "name_bn" => "ইমেজ ক্রপ রেশিও প্রিসেট টুল",
            "category" => "image-tools",
            "desc_en" => "Calculate exact crop pixels for standard aspect ratios (16:9, 4:3, 1:1, 4:5, 9:16) from target dimensions.",
            "desc_bn" => "বিভিন্ন সোশ্যাল মিডিয়া ও ওয়েব ব্যানারের সঠিক ক্রপ পিক্সেল মাপ হিসাব করুন।",
            "features" => ["১৬:৯, ৪:৩, ১:১, ৯:১৬ প্রিসেট", "পিক্সেল ক্যালকুলেটর", "সেন্টার ক্রপ মেজার"],
            "benefits" => ["সোশ্যাল মিডিয়া পোস্ট পারফেক্ট করা", "ডিজাইন লেআউট ঠিক রাখা"],
            "faqs" => [["Q" => "ইনস্টাগ্রাম রিলসের রেশিও কত?", "A" => "৯:১৬ (১০৮০x১৯২০ পিক্সেল)।"]]
        ],
        "social-thumbnail-safe-zone" => [
            "name" => "Social Thumbnail Safe-Zone Generator",
            "name_bn" => "সোশ্যাল থাম্বনেইল সেফ-জোন জেনারেটর",
            "category" => "image-tools",
            "desc_en" => "Visualize UI overlays and safe zones for YouTube, TikTok, Reels, and Facebook preview thumbnails.",
            "desc_bn" => "ইউটিউব ও সোশ্যাল ভিডিওর থাম্বনেইলে টেক্সট কেটে যাওয়া এড়াতে সেফ-জোন দেখে নিন।",
            "features" => ["ইউটিউব টাইমকোড সেফ-জোন", "টিকটক বাটন ওভারলে", "ভিজ্যুয়াল ক্যানভাস"],
            "benefits" => ["গুরুত্বপূর্ণ তথ্য ঢেকে যাওয়া রোধ", "প্রফেশনাল লুক"],
            "faqs" => [["Q" => "ইউটিউব থাম্বনেইলের ডান কোণায় কি থাকে?", "A" => "ভিডিওর ডিউরেশন বা টাইম কোড থাকে, সেখানে টেক্সট দেওয়া উচিত নয়।"]]
        ],
        "favicon-ico-craft-pro" => [
            "name" => "Favicon & Apple Touch Icon Generator",
            "name_bn" => "ফেভআইকন ও অ্যাপল আইকন জেনারেটর",
            "category" => "image-tools",
            "desc_en" => "Generate multi-size favicons (16x16, 32x32, 48x48) and 180x180 Apple Touch Icons with instant preview.",
            "desc_bn" => "ওয়েবসাইটের ব্রাউজার ট্যাব ও অ্যাপল ডিভাইসের জন্য সকল সাইজের ফেভআইকন জেনারেট করুন।",
            "features" => ["১৬x১৬, ৩২x৩২, ১৮০x১৮০ প্রিসেট", "ক্যানভাস রেন্ডার", "এইচটিএমএল কোড জেনারেটর"],
            "benefits" => ["ব্র্যান্ডিং প্রফেশনাল করা", "মোবাইল বুকমার্ক লুক বাড়ানো"],
            "faqs" => [["Q" => "Favicon ফাইল কোথায় আপলোড করতে হয়?", "A" => "ওয়েবসাইটের রুট ডিরেক্টরিতে বা ওয়ার্ডপ্রেস কাস্টমাইজারে।"]]
        ],
        "app-icon-generator" => [
            "name" => "App Icon Size Generator",
            "name_bn" => "অ্যাপ আইকন সাইজ জেনারেটর",
            "category" => "image-tools",
            "desc_en" => "Calculate and export all required Android (Play Store 512x512, hdpi, xhdpi) and iOS app icon asset sizes.",
            "desc_bn" => "অ্যান্ড্রয়েড প্লে স্টোর ও আইওএস অ্যাপের জন্য সব সাইজের আইকন তৈরি করুন।",
            "features" => ["৫১২x৫১২ প্লে স্টোর মেজার", "আডাপ্টিভ আইকন গাইড", "ডাউনলোড ফরম্যাট"],
            "benefits" => ["অ্যাপ ডেভেলপমেন্ট সময় বাঁচানো", "স্টোর রিজেকশন এড়ানো"],
            "faqs" => [["Q" => "প্লে স্টোরের প্রধান আইকন সাইজ কত?", "A" => "৫১২x৫১২ পিক্সেল PNG।"]]
        ],
        "image-filename-seo" => [
            "name" => "Image Filename SEO Generator",
            "name_bn" => "ইমেজ ফাইলনেম এসইও জেনারেটর",
            "category" => "image-tools",
            "desc_en" => "Convert titles and raw phrases into hyphenated, SEO-friendly image filenames, alt text, and title tags.",
            "desc_bn" => "ছবির শিরোনাম থেকে সার্চ ইঞ্জিনের জন্য উপযোগী ফাইলনেম ও অল্টার টেক্সট জেনারেট করুন।",
            "features" => ["হাইফেন কেসিং", "অল্ট টেক্সট সাজেশন", "HTML Image ট্যাগ মেকার"],
            "benefits" => ["গুগল ইমেজ সার্চে র্যাঙ্কিং", "ওয়েব অ্যাক্সেসেবিলিটি ভালো করা"],
            "faqs" => [["Q" => "ছবির নামে স্পেস দেওয়া যাবে?", "A" => "না, স্পেসের বদলে হাইফেন (-) ব্যবহার করা উচিত।"]]
        ],

        /* ===================================================
         * CATEGORY D — VIDEO & CREATOR (10 Tools)
         * =================================================== */
        "youtube-thumbnail-size" => [
            "name" => "YouTube Thumbnail Size Calculator",
            "name_bn" => "ইউটিউব থাম্বনেইল সাইজ ক্যালকুলেটর",
            "category" => "video-tools",
            "desc_en" => "Verify YouTube thumbnail dimensions (1280x720), 16:9 ratio, and 2MB max file size limits.",
            "desc_bn" => "ইউটিউব থাম্বনেইলের সঠিক সাইজ (১২৮০x৭২০) এবং ফাইল সাইজ চেক করুন।",
            "features" => ["১৬:৯ আস্পেক্ট চেকার", "২ মেগাবাইট লিমিট ভ্যালিডেশন", "ফরম্যাট গাইড"],
            "benefits" => ["ভিডিওতে প্রফেশনাল থাম্বনেইল সেটআপ", "এইচডি কোয়ালিটি বজায় রাখা"],
            "faqs" => [["Q" => "ইউটিউব থাম্বনেইলের বেস্ট সাইজ কত?", "A" => "১২৮০x৭২০ পিক্সেল (সর্বনিম্ন ৬৪০ পিক্সেল চওড়া)।"]]
        ],
        "video-aspect-ratio" => [
            "name" => "Video Aspect Ratio Calculator",
            "name_bn" => "ভিডিও আস্পেক্ট রেশিও ক্যালকুলেটর",
            "category" => "video-tools",
            "desc_en" => "Calculate missing video width or height for 16:9, 9:16, 4:3, 21:9 ultrawide, and 1:1 ratios.",
            "desc_bn" => "ভিডিওর হাইট বা উইডথ পরিবর্তন করলে সঠিক আনুপাতিক মাপ হিসেব করুন।",
            "features" => ["১৬:৯, ৯:১৬, ২১:৯ প্রিসেট", "ইনস্ট্যান্ট পিক্সেল ক্যালকুলেটর", "রেজোলিউশন চেকার"],
            "benefits" => ["ভিডিও চ্যাপ্টা বা বিকৃত হওয়া রোধ", "সোশ্যাল প্ল্যাটফর্ম ফিট করা"],
            "faqs" => [["Q" => "শর্টস ভিডিওর রেশিও কত?", "A" => "৯:১৬ ভ্যাটিক্যাল রেশিও।"]]
        ],
        "video-bitrate-calculator" => [
            "name" => "Video Bitrate & Quality Calculator",
            "name_bn" => "ভিডিও বিটরেট ও কোয়ালিটি ক্যালকুলেটর",
            "category" => "video-tools",
            "desc_en" => "Calculate recommended bitrates for 1080p, 2K, 4K video encoding at 30fps and 60fps.",
            "desc_bn" => "১০৮০পি ও ৪কে ভিডিও এক্সপোর্টের জন্য পারফেক্ট বিটরেট হিসেব করুন।",
            "features" => ["SDR ও HDR স্কেল", "৩০fps/৬০fps অপশন", "ইউটিউব এক্সপোর্ট গাইড"],
            "benefits" => ["ভিডিও ঝাপসা হওয়া বন্ধ করা", "ফাইল সাইজ কন্ট্রোলে রাখা"],
            "faqs" => [["Q" => "১০৮০পি ৩০ফ্রেমে বিটরেট কত রাখা উচিত?", "A" => "৮ থেকে ১২ Mbps রাখা আদর্শ।"]]
        ],
        "video-size-estimator" => [
            "name" => "Video File Size Estimator",
            "name_bn" => "ভিডিও ফাইল সাইজ এস্টিমেটর",
            "category" => "video-tools",
            "desc_en" => "Estimate total exported video file size based on duration, video bitrate, and audio settings.",
            "desc_bn" => "ভিডিওর দৈর্ঘ্য ও বিটরেট থেকে রেন্ডার হওয়ার পর ফাইল সাইজ কত হবে অনুমান করুন।",
            "features" => ["ডিউরেশন মিনিট ক্যালকুলেটর", "অডিও বিটরেট অ্যাডজাস্ট", "মেগাবাইট/গিগাবাইট মেজার"],
            "benefits" => ["স্টোরেজ প্ল্যান করা", "রেন্ডারিং এর আগে ফাইল সাইজ জানা"],
            "faqs" => [["Q" => "১ ঘণ্টার ভিডিও কত জিবির হতে পারে?", "A" => "১০৮০পি তে সাধারণত ২ থেকে ৪ জিবি হতে পারে।"]]
        ],
        "watch-time-calculator" => [
            "name" => "YouTube Watch-Time Calculator",
            "name_bn" => "ইউটিউব ওয়াচ-টাইম ক্যালকুলেটর",
            "category" => "video-tools",
            "desc_en" => "Calculate total watch time in hours from total video views and average view duration.",
            "desc_bn" => "ভিউ সংখ্যা এবং গড় দেখার সময় থেকে মোট ওয়াচ টাইম ঘণ্টা হিসাব করুন।",
            "features" => ["৪০০০ ঘণ্টা ট্র্যাকার", "ভিউ কাউন্টার", "মনিটাইজেশন প্রোগ্রেস%"],
            "benefits" => ["মনিটাইজেশনের লক্ষ্যমাত্রা জানা", "চ্যানেল গ্রোথ পরিমাপ"],
            "faqs" => [["Q" => "মনিটাইজেশনের জন্য কত ঘণ্টা ওয়াচ টাইম লাগে?", "A" => "গত ১২ মাসে ৪,০০০ ঘণ্টা পাবলিক ওয়াচ টাইম।"]]
        ],
        "video-upload-time" => [
            "name" => "Video Upload Time Calculator",
            "name_bn" => "ভিডিও আপলোড টাইম ক্যালকুলেটর",
            "category" => "video-tools",
            "desc_en" => "Estimate video upload completion time based on file size and internet upload speed in Mbps.",
            "desc_bn" => "ইন্টারনেটের আপলোড স্পিড এবং ফাইল সাইজ অনুযায়ী আপলোড হতে কত সময় লাগবে জানুন।",
            "features" => ["Mbps/Kbps স্পিড ইনপুট", "মিনিট ও ঘণ্টা টাইম কাউন্ট", "প্রোগ্রেস এস্টিমেট"],
            "benefits" => ["পাবলিশিং সিডিউল ঠিক রাখা", "সময় অপচয় না করা"],
            "faqs" => [["Q" => "আপলোড স্পিড কিসে মাপা হয়?", "A" => "Megabits per second (Mbps)।"]]
        ],
        "subtitle-density-checker" => [
            "name" => "Subtitle Character Density Checker",
            "name_bn" => "সাবটাইটেল ডেনসিটি চেকার",
            "category" => "video-tools",
            "desc_en" => "Check subtitle reading comfort: calculate Words Per Minute (WPM) and Characters Per Second (CPS).",
            "desc_bn" => "ভিডিও সাবটাইটেল ইউজারদের পড়ার মতো স্পিডে আছে কিনা (CPS/WPM) পরীক্ষা করুন।",
            "features" => ["CPS (Characters Per Sec) মিটার", "WPM কাউন্টার", "পড়ার গতি সতর্কতা"],
            "benefits" => ["দর্শকদের জন্য পড়া সহজ করা", "প্রফেশনাল ক্যাপশন তৈরি"],
            "faqs" => [["Q" => "সর্বোচ্চ CPS কত হওয়া উচিত?", "A" => "প্রতি সেকেন্ডে ১৭ থেকে ২০ ক্যারেক্টারের নিচে রাখা ভালো।"]]
        ],
        "youtube-chapter-generator" => [
            "name" => "YouTube Video Chapter Generator",
            "name_bn" => "ইউটিউব চ্যাপ্টার জেনারেটর",
            "category" => "video-tools",
            "desc_en" => "Format timestamps and section headings into YouTube video chapters with 00:00 validation.",
            "desc_bn" => "ভিডিওর টাইমস্ট্যাম্পগুলোকে সঠিক নিয়মে ইউটিউব চ্যাপ্টারে রূপান্তর করুন।",
            "features" => ["০০:০০ অটো স্টার্ট ভ্যালিডেশন", "ইনস্ট্যান্ট কপি", "টাইম কোড ফরম্যাটার"],
            "benefits" => ["ভিডিওর এসইও বাড়ানো", "দর্শকদের নির্দিষ্ট অংশে দ্রুত নিয়ে যাওয়া"],
            "faqs" => [["Q" => "প্রথম চ্যাপ্টার কি দিয়ে শুরু হতে হবে?", "A" => "অবশ্যই 00:00 দিয়ে শুরু করতে হবে।"]]
        ],
        "video-description-generator" => [
            "name" => "Video Description Structure Generator",
            "name_bn" => "ভিডিও ডেসক্রিপশন স্ট্রাকচার মেকার",
            "category" => "video-tools",
            "desc_en" => "Generate structured YouTube video description templates with hooks, social links, and hashtags.",
            "desc_bn" => "ইউটিউব ভিডিওর জন্য আকর্ষণীয় ডেসক্রিপশন ও হ্যাশট্যাগ টেমপ্লেট তৈরি করুন।",
            "features" => ["হুক লাইন মেকার", "সোশ্যাল লিংক সেকশন", "হ্যাশট্যাগ অপটিমাইজার"],
            "benefits" => ["ভিডিওর সিপিআর ও ভিউ বাড়ানো", "সময় বাঁচানো"],
            "faqs" => [["Q" => "ইউটিউবে কয়টি হ্যাশট্যাগ দেওয়া ভালো?", "A" => "৩ থেকে ৫ টি প্রাসঙ্গিক হ্যাশট্যাগ সবচেয়ে ভালো।"]]
        ],
        "creator-content-calendar" => [
            "name" => "Creator Content Calendar Generator",
            "name_bn" => "ক্রিয়েটর কন্টেন্ট ক্যালেন্ডার মেকার",
            "category" => "video-tools",
            "desc_en" => "Plan weekly content schedules across YouTube, Shorts, TikTok, and Facebook with tracking statuses.",
            "desc_bn" => "আপনার ইউটিউব, ফেসবুক ও টিকটক ভিডিও কন্টেন্টের সাপ্তাহিক রুটিন সাজান।",
            "features" => ["সাপ্তাহিক শিডিউলার", "প্ল্যাটফর্ম ট্যাগিং", "লোকাল সেভ মেমোরি"],
            "benefits" => ["নিয়মিত ভিডিও পাবলিশের শৃঙ্খলা", "কন্টেন্ট আইডিয়া ভুলে না যাওয়া"],
            "faqs" => [["Q" => "সপ্তাহে কয়টি ভিডিও দেওয়া উচিত?", "A" => "কোয়ালিটি ঠিক রেখে ১ থেকে ৩ টি ভিডিও দেওয়া আদর্শ।"]]
        ],

        /* ===================================================
         * CATEGORY E — EDUCATION & STUDENT (10 Tools)
         * =================================================== */
        "gpa-percentage-converter" => [
            "name" => "GPA to Percentage Converter",
            "name_bn" => "জিপিএ থেকে পারসেন্টেজ কনভার্টার",
            "category" => "education-tools",
            "desc_en" => "Convert 4.0 or 5.0 GPA scale to equivalent percentage and letter grade according to international standards.",
            "desc_bn" => "জিপিএ (৪.০ বা ৫.০ স্কেল) থেকে সহজেই শতকরা নম্বর হিসাব করুন।",
            "features" => ["৪.০ ও ৫.০ স্কেল সাপোর্ট", "লেটার গ্রেড ম্যাপ", "ইউএস/গ্লোবাল স্ট্যান্ডার্ড"],
            "benefits" => ["বিদেশী স্কলারশিপ আবেদনের সুবিধা", "সঠিক মার্কস ধারণা"],
            "faqs" => [["Q" => "জিপিএ ৫.০ তে পারসেন্টেজ কত?", "A" => "সাধারণত জিপিএ ৫.০ মানে ৮০% থেকে ১০০% মার্কস।"]]
        ],
        "cgpa-percentage-converter" => [
            "name" => "CGPA to Percentage Converter",
            "name_bn" => "সিজিপিএ থেকে পারসেন্টেজ কনভার্টার",
            "category" => "education-tools",
            "desc_en" => "Convert Varsity CGPA (10.0 or 4.0 scale) to percentage with university division classifications.",
            "desc_bn" => "বিশ্ববিদ্যালয়ের সিজিপিএ থেকে শতাংশ এবং ফার্স্ট/সেকেন্ড ক্লাস ক্লাসিফিকেশন হিসাব করুন।",
            "features" => ["১০.০ ও ৪.০ স্কেল", "ফার্স্ট ক্লাস/ডিভিশন ক্যালকুলেটর", "ইনস্ট্যান্ট রেজাল্ট"],
            "benefits" => ["সিভি ও চাকরির আবেদনে সঠিক তথ্য প্রদান", "বিশ্ববিদ্যালয় নিয়ম অনুসরণ"],
            "faqs" => [["Q" => "৪.০ স্কেলে ফার্স্ট ক্লাস কত সিজিপিএ?", "A" => "সাধারণত ৩.০০ বা তার বেশি সিজিপিএকে ফার্স্ট ক্লাস ধরা হয়।"]]
        ],
        "study-time-planner" => [
            "name" => "Study Time Planner & Allocator",
            "name_bn" => "স্টাডি টাইম প্ল্যানার ও সিডিউল মেকার",
            "category" => "education-tools",
            "desc_en" => "Calculate optimal daily study hours per subject based on credit hours and exam difficulty.",
            "desc_bn" => "কোর্স ক্রেডিট ও বিষয়ের সুস্থতার ওপর ভিত্তি করে প্রতিদিনের পড়ার সময় রুটিন তৈরি করুন।",
            "features" => ["কোর্স ক্রেডিট ক্যালকুলেটর", "দৈনিক সময় বণ্টন", "প্রিন্টেবল শিডিউল"],
            "benefits" => ["পরীক্ষায় ভালো রেজাল্ট নিশ্চিতকরণ", "পড়াশোনায় শৃঙ্খলা আনা"],
            "faqs" => [["Q" => "১ ক্রেডিট কোর্সের জন্য কত ঘণ্টা পড়া উচিত?", "A" => "সাধারণত সপ্তাহে ২ থেকে ৩ ঘণ্টা অতিরিক্ত পড়া উচিত।"]]
        ],
        "exam-countdown" => [
            "name" => "Exam Countdown & Progress Calculator",
            "name_bn" => "পরীক্ষার কাউন্টডাউন ও প্রস্তুতি ট্র্যাকার",
            "category" => "education-tools",
            "desc_en" => "Live real-time countdown timer to your exam date with remaining days, hours, and syllabus tracker.",
            "desc_bn" => "পরীক্ষার তারিখের কাউন্টডাউন এবং সিলেবাস শেষের শতাংশ ট্র্যাকার।",
            "features" => ["লাইভ কাউন্টডাউন ঘড়ি", "দিন ও ঘণ্টা কাউন্টার", "সিলেবাস ট্র্যাকার%"],
            "benefits" => ["পরীক্ষার আগে মানসিক প্রস্তুতি", "সময়মত পড়া শেষ করা"],
            "faqs" => [["Q" => "কাউন্টডাউন কি পেজ বন্ধ করলেও চলবে?", "A" => "হ্যাঁ, এটি আপনার লোকাল ডেটে সেভ থাকবে।"]]
        ],
        "grade-percentage-calculator" => [
            "name" => "Grade Percentage Calculator",
            "name_bn" => "গ্রেড পারসেন্টেজ ক্যালকুলেটর",
            "category" => "education-tools",
            "desc_en" => "Calculate overall course grade percentage from test scores, assignments, and weighted midterms.",
            "desc_bn" => "পরীক্ষার প্রাপ্ত নম্বর ও মোট নম্বর থেকে শতকরা পারসেন্টেজ ও গ্রেড নির্ণয় করুন।",
            "features" => ["ওয়েটেড মার্কস মেজার", "লেটার গ্রেড আউটপুট", "মাল্টি-এসাইনমেন্ট সাপোর্ট"],
            "benefits" => ["কোর্সের ফাইনাল স্কোর আগে থেকে জানা", "কম্পিউটেশনাল নির্ভুলতা"],
            "faqs" => [["Q" => "ওয়েটেড গ্রেড কীভাবে হিসাব করে?", "A" => "প্রতিটি পরীক্ষার পারসেন্টেজ ওয়েট গুণ করে যোগ করা হয়।"]]
        ],
        "attendance-calculator" => [
            "name" => "Class Attendance Percentage Calculator",
            "name_bn" => "ক্লাস এটেনডেন্স পারসেন্টেজ ক্যালকুলেটর",
            "category" => "education-tools",
            "desc_en" => "Calculate current attendance percentage and determine required future classes to reach 75% or 80%.",
            "desc_bn" => "উপস্থিতির শতকরা হার এবং ৭৫%/৮০% উপস্থিতির জন্য আর কয়টি ক্লাস করতে হবে জানুন।",
            "features" => ["৭৫% ও ৮০% বেঞ্চমার্ক", "প্রয়োজনীয় ক্লাস সংখ্যা", "সর্বোচ্চ মিস ক্লাস লিমিট"],
            "benefits" => ["পরীক্ষায় বসতে না পারার ঝুঁকি এড়ানো", "ক্লাস উপস্থিতির পরিকল্পনা"],
            "faqs" => [["Q" => "৭৫% উপস্থিতি না থাকলে কি হয়?", "A" => "বেশিরভাগ কলেজ ও বিশ্ববিদ্যালয়ে পরীক্ষায় বসতে দেওয়া হয় না।"]]
        ],
        "required-exam-score" => [
            "name" => "Required Exam Score Calculator",
            "name_bn" => "প্রয়োজনীয় এক্সাম স্কোর ক্যালকুলেটর",
            "category" => "education-tools",
            "desc_en" => "Calculate the exact minimum score needed in your final exam to achieve your target overall grade.",
            "desc_bn" => "কাঙ্ক্ষিত গ্রেড পেতে ফাইনাল পরীক্ষায় কত নম্বর পেতে হবে তা হিসাব করুন।",
            "features" => ["টার্গেট গ্রেড গোল", "কারেন্ট স্কোরের ওপর নির্ভরতা", "ইনস্ট্যান্ট টার্গেট মার্কস"],
            "benefits" => ["ফাইনাল পরীক্ষার লক্ষ্য নির্ধারণ", "অপ্রয়োজনীয় মানসিক চাপ কমানো"],
            "faqs" => [["Q" => "যদি ১০০% এর বেশি মার্কস দেখায়?", "A" => "তারমানে বর্তমান স্কোর দিয়ে কাঙ্ক্ষিত গ্রেড পাওয়া সম্ভব নয়।"]]
        ],
        "semester-gpa-planner" => [
            "name" => "Semester GPA (SGPA) Planner",
            "name_bn" => "সেমিস্টার জিপিএ (SGPA) প্ল্যানার",
            "category" => "education-tools",
            "desc_en" => "Plan multi-course target grades and credit hours to calculate estimated semester SGPA.",
            "desc_bn" => "চলতি সেমিস্টারের বিষয়সমূহ ও ক্রেডিটের ওপর ভিত্তি করে আনুমানিক SGPA হিসাব করুন।",
            "features" => ["মাল্টিপল কোর্স অ্যাড", "ক্রেডিট ওয়েটেড ক্যালকুলেশন", "ক্লিন টেবিল ইউআই"],
            "benefits" => ["সেমিস্টার শেষে ভালো সিজিপিএ ধরা", "পড়াশোনার টার্গেট ঠিক করা"],
            "faqs" => [["Q" => "SGPA কি?", "A" => "Semester Grade Point Average বা একক সেমিস্টারের গড় রেজাল্ট।"]]
        ],
        "assignment-deadline" => [
            "name" => "Assignment Deadline & Pace Calculator",
            "name_bn" => "অ্যাসাইনমেন্ট ডেডলাইন ও পেস ক্যালকুলেটর",
            "category" => "education-tools",
            "desc_en" => "Calculate remaining working days for assignment submissions and estimated daily writing word target.",
            "desc_bn" => "অ্যাসাইনমেন্টের বাকি দিন এবং প্রতিদিন কত শব্দ লিখতে হবে তা হিসাব করুন।",
            "features" => ["ওয়ার্কিং ডে কাউন্ট", "দৈনিক ওয়ার্ড টার্গেট", "সপ্তাহান্ত বাদ দেওয়ার অপশন"],
            "benefits" => ["শেষ মুহূর্তে তাড়াহুড়ো না করা", "মানসম্মত অ্যাসাইনমেন্ট প্রস্তুত"],
            "faqs" => [["Q" => "প্রতিদিন কত শব্দ লেখা সহজ?", "A" => "প্রতিদিন ৫০০ থেকে ১০০০ শব্দ লেখা স্বাভাবিক ও আরামদায়ক।"]]
        ],
        "citation-generator" => [
            "name" => "Academic Citation Generator (APA/MLA)",
            "name_bn" => "একাডেমিক সাইটেশন জেনারেটর",
            "category" => "education-tools",
            "desc_en" => "Generate properly formatted academic citations in APA 7th, MLA 9th, Chicago, and Harvard formats.",
            "desc_bn" => "বই, ওয়েবসাইট ও গবেষণা পত্রের জন্য APA, MLA ও Harvard সাইটেশন জেনারেট করুন।",
            "features" => ["APA, MLA, Harvard, Chicago", "বুক/ওয়েবসাইট অপশন", "ইনস্ট্যান্ট সাইটেশন কপি"],
            "benefits" => ["প্লেজারিজ বা চুরি এড়ানো", "রিসার্চ পেপারের মান বৃদ্ধি"],
            "faqs" => [["Q" => "APA ৭ম সংস্করণে লেখকের নাম কীভাবে লেখে?", "A" => "সর্বশেষ নাম আগে, তারপর প্রথম নামের প্রথম অক্ষর (যেমন: Smith, J.)।"]]
        ],

        /* ===================================================
         * CATEGORY F — BUSINESS & E-COMMERCE (10 Tools)
         * =================================================== */
        "profit-margin-calculator" => [
            "name" => "Profit Margin Calculator",
            "name_bn" => "প্রফিট মার্জিন ক্যালকুলেটর",
            "category" => "business-tools",
            "desc_en" => "Calculate gross profit, net profit margin percentage, and optimal selling price from cost data.",
            "desc_bn" => "পণ্য বা সেবার কেনা দাম থেকে লাভ এবং প্রফিট মার্জিন শতাংশ হিসাব করুন।",
            "features" => ["গ্রস ও নেট প্রফিট মার্জিন", "সেলিং প্রাইস সাজেশন", "মার্জিন%", "লাভের পরিমাণ"],
            "benefits" => ["সঠিক বিক্রয়মূল্য নির্ধারণ", "ব্যবসায় লস এড়ানো"],
            "faqs" => [["Q" => "প্রফিট মার্জিন ও মার্কআপ কি এক?", "A" => "না, মার্জিন হিসাব করা হয় বিক্রয়মূল্যের ওপর, আর মার্কআপ কেনা দামের ওপর।"]]
        ],
        "markup-calculator" => [
            "name" => "Business Markup Calculator",
            "name_bn" => "বিজনেস মার্কআপ ক্যালকুলেটর",
            "category" => "business-tools",
            "desc_en" => "Calculate markup percentage and final retail price based on wholesale cost and profit goals.",
            "desc_bn" => "পণ্য কেনা দামের ওপর কত শতাংশ মার্কআপ যোগ করলে কত লাভ হবে হিসাব করুন।",
            "features" => ["মার্কআপ পারসেন্টেজ", "গ্রস প্রফিট", "রিটেল প্রাইস আউটপুট"],
            "benefits" => ["পাইকারি ও খুচরা দামের পার্থক্য বোঝা", "ব্যবসায়িক লাভ নিশ্চিতকরণ"],
            "faqs" => [["Q" => "৫০% মার্কআপ দিলে মার্জিন কত হয়?", "A" => "৫০% মার্কআপ দিলে প্রফিট মার্জিন হয় ৩৩.৩৩%।"]]
        ],
        "break-even-calculator" => [
            "name" => "Break-Even Point Calculator",
            "name_bn" => "ব্রেক-ইভেন পয়েন্ট (লাভ-ক্ষতিহীন) ক্যালকুলেটর",
            "category" => "business-tools",
            "desc_en" => "Determine the exact sales volume and revenue required to cover fixed and variable business costs.",
            "desc_bn" => "ব্যবসায় লাভ বা ক্ষতি না হওয়ার জন্য ন্যূনতম কয়টি পণ্য বিক্রি করতে হবে জানুন।",
            "features" => ["ব্রেক-ইভেন ইউনিট", "রেভিনিউ টার্গেট", "ফিক্সড ও ভ্যারিয়েবল কস্ট ইনপুট"],
            "benefits" => ["ব্যবসায়িক ঝুঁকি কমানো", "বিক্রয় লক্ষ্যমাত্রা নির্ধারণ"],
            "faqs" => [["Q" => "ব্রেক-ইভেন পয়েন্ট কি?", "A" => "যে পয়েন্টে মোট আয় এবং মোট খরচ সমান হয়, অর্থাৎ লাভ বা ক্ষতি কোনটিই হয় না।"]]
        ],
        "cac-calculator" => [
            "name" => "Customer Acquisition Cost (CAC) Calculator",
            "name_bn" => "কাস্টমার একুইজিশন কস্ট (CAC) ক্যালকুলেটর",
            "category" => "business-tools",
            "desc_en" => "Calculate total cost spent to acquire a single paying customer across marketing and sales channels.",
            "desc_bn" => "একজন নতুন ক্রেতা পেতে আপনার কত টাকা মার্কেটিং ও সেলসে খরচ হচ্ছে তা জানুন।",
            "features" => ["মার্কেটিং স্পেন্ড ইনপুট", "সেলস কস্ট মেজার", "কাস্টমার প্রতি খরচ"],
            "benefits" => ["বিজ্ঞাপন বাজেট অপ্টিমাইজেশন", "মার্কেটিং কার্যকারিতা যাচাই"],
            "faqs" => [["Q" => "ভালো CAC কত হওয়া উচিত?", "A" => "CAC কাস্টমারের লাইফটাইম ভ্যালু (CLV) এর ৩ ভাগের ১ ভাগ বা তার কম হওয়া ভালো।"]]
        ],
        "clv-calculator" => [
            "name" => "Customer Lifetime Value (CLV) Calculator",
            "name_bn" => "কাস্টমার লাইফটাইম ভ্যালু (CLV) ক্যালকুলেটর",
            "category" => "business-tools",
            "desc_en" => "Estimate total net profit a customer generates throughout their entire relationship with your business.",
            "desc_bn" => "একজন কাস্টমার সারা জীবনে আপনার ব্যবসা থেকে গড়ে কত টাকার কেনাকাটা করে জানুন।",
            "features" => ["অ্যাভারেজ অর্ডার ভ্যালু", "পারচেজ ফ্রিকোয়েন্সি", "কাস্টমার লাইফস্প্যান"],
            "benefits" => ["কাস্টমার রিটেনশনের গুরুত্ব বোঝা", "মার্কেটিং বাজেট বাড়ানো"],
            "faqs" => [["Q" => "CLV বাড়ানো যায় কীভাবে?", "A" => "ভালো কাস্টমার সার্ভিস ও রিপিট সেলস অর্ডারের মাধ্যমে।"]]
        ],
        "roas-calculator" => [
            "name" => "Return on Ad Spend (ROAS) Calculator",
            "name_bn" => "রিটার্ন অন এড স্পেন্ড (ROAS) ক্যালকুলেটর",
            "category" => "business-tools",
            "desc_en" => "Calculate ROAS percentage and revenue multiplier (e.g., 400% / 4x) generated from advertising campaigns.",
            "desc_bn" => "বিজ্ঞাপনে খরচ করা ১ টাকার বিপরীতে আপনার কত টাকা সেলস রেভিনিউ আসছে হিসাব করুন।",
            "features" => ["ROAS পারসেন্টেজ", "রেভিনিউ মাল্টিপ্লায়ার (X)", "প্রফিটেবিলিটি ইন্ডিকেটর"],
            "benefits" => ["লাভজনক এড ক্যাম্পেইন চালানো", "লস এড বন্ধ করা"],
            "faqs" => [["Q" => "ভালো ROAS কত?", "A" => "সাধারণত ৪০০% বা ৪X (১ টাকা খরচে ৪ টাকা রেভিনিউ) ভালো ধরা হয়।"]]
        ],
        "conversion-rate-calculator" => [
            "name" => "Conversion Rate Calculator",
            "name_bn" => "কনভার্সন রেট ক্যালকুলেটর",
            "category" => "business-tools",
            "desc_en" => "Calculate conversion rate percentage and required site visitors to reach target sales goals.",
            "desc_bn" => "ওয়েবসাইট ভিজিটরদের মধ্যে কত শতাংশ কেনাকাটা করছে (কনভার্সন রেট) হিসাব করুন।",
            "features" => ["কনভার্সন%", "ভিজিটর রিকোয়ারমেন্ট", "সেলস গোল প্রেডিকশন"],
            "benefits" => ["ওয়েবসাইট পারফরম্যান্স মূল্যায়ন", "সেলস ফানেল উন্নত করা"],
            "faqs" => [["Q" => "ই-কমার্সে গড় কনভার্সন রেট কত?", "A" => "সাধারণত ১% থেকে ৩% এর মধ্যে থাকে।"]]
        ],
        "shipping-cost-calculator" => [
            "name" => "Dimensional Weight & Shipping Calculator",
            "name_bn" => "ডাইমেনশনাল ওয়েট ও শিপিং ক্যালকুলেটর",
            "category" => "business-tools",
            "desc_en" => "Calculate volumetric dimensional weight versus actual weight for parcel delivery pricing.",
            "desc_bn" => "পার্সেলের সাইজ (দৈর্ঘ্যxপ্রস্থxউচ্চতা) থেকে ডাইমেনশনাল ওজন ও চার্জ হিসাব করুন।",
            "features" => ["DIM ওয়েট ফর্মুলা (L*W*H / 5000)", "একচুয়াল ওয়েট তুলনা", "বিলিং ওয়েট"],
            "benefits" => ["শিপিং খরচে অতিরিক্ত টাকা দেওয়া বন্ধ করা", "সঠিক পার্সেল বক্স নির্বাচন"],
            "faqs" => [["Q" => "ডাইমেনশনাল ওজন কেন ধরা হয়?", "A" => "বড় কিন্তু হালকা পার্সেলের ক্ষেত্রে কুরিয়ার কোম্পানি ভলিউমেট্রিক ওজন চার্জ করে।"]]
        ],
        "wholesale-retail-price" => [
            "name" => "Wholesale & Retail Price Calculator",
            "name_bn" => "পাইকারি ও খুচরা দাম ক্যালকুলেটর",
            "category" => "business-tools",
            "desc_en" => "Calculate recommended wholesale price (50% margin) and keystone retail price from production cost.",
            "desc_bn" => "উৎপাদন খরচ থেকে পাইকারি দাম এবং খুচরা বিক্রয়মূল্য নির্ধারণ করুন।",
            "features" => ["কিস্টোন প্রাইসিং (২X)", "হোলসেল মার্জিন%", "রিটেল মার্জিন%"],
            "benefits" => ["ডিস্ট্রিবিউটর ও খুচরা বিক্রেতা উভয়ের জন্য লাভজনক দাম রাখা", "মার্কেট স্ট্যান্ডার্ড মেনে চলা"],
            "faqs" => [["Q" => "কিস্টোন প্রাইসিং কি?", "A" => "পাইকারি বা উৎপাদন খরচের দ্বিগুণ দামে খুচরা বিক্রি করাকে কিস্টোন প্রাইসিং বলে।"]]
        ],
        "inventory-turnover" => [
            "name" => "Inventory Turnover Ratio Calculator",
            "name_bn" => "ইনভেন্টরি টার্নওভার রেশিও ক্যালকুলেটর",
            "category" => "business-tools",
            "desc_en" => "Calculate inventory turnover ratio and average days required to sell off stock.",
            "desc_bn" => "বছরে কতবার আপনার স্টকের পণ্য বিক্রি ও পরিবর্তন হচ্ছে (টার্নওভার) তা জানুন।",
            "features" => ["টার্নওভার রেশিও", "ডেজ টু সেল (DSI)", "স্টক এফিসিয়েন্সি"],
            "benefits" => ["পণ্য আটকে থাকা বা ডেড স্টক কমানো", "ক্যাশ ফ্লো ঠিক রাখা"],
            "faqs" => [["Q" => "উচ্চ ইনভেন্টরি টার্নওভারের অর্থ কি?", "A" => "আপনার পণ্য দ্রুত বিক্রি হচ্ছে এবং স্টোরেজ খরচ কম লাগছে।"]]
        ],

        /* ===================================================
         * CATEGORY G — FREELANCING & CAREER (10 Tools)
         * =================================================== */
        "freelance-quote-calculator" => [
            "name" => "Freelance Project Quote Calculator",
            "name_bn" => "ফ্রিল্যান্স প্রজেক্ট কোট ক্যালকুলেটর",
            "category" => "career-tools",
            "desc_en" => "Calculate accurate project quotes based on estimated hours, hourly rate, risk factor, and revisions.",
            "desc_bn" => "ফ্রিল্যান্স কাজের জন্য ক্লায়েন্টকে কত প্রাইস কোট পাঠাবেন তা নির্ভুলভাবে হিসাব করুন।",
            "features" => ["ঘণ্টা হিসাব", "কমপ্লেক্সিটি চার্জ", "রিভিশন বাফার%", "ট্যাক্স মেজার"],
            "benefits" => ["কম দামে কাজ না করা", "প্রজেক্টে সঠিক লাভ রাখা"],
            "faqs" => [["Q" => "প্রজেক্ট কোটে বাফার টাইম কেন রাখবেন?", "A" => "অপ্রত্যাশিত সমস্যা বা ক্লায়েন্টের অতিরিক্ত পরিবর্তনের ক্ষতিপূরণ পেতে।"]]
        ],
        "freelance-income-target" => [
            "name" => "Freelance Monthly Income Target Calculator",
            "name_bn" => "ফ্রিল্যান্স মাসিক ইনকাম টার্গেট ক্যালকুলেটর",
            "category" => "career-tools",
            "desc_en" => "Calculate required hourly rate and daily billable hours to reach your net monthly income goal.",
            "desc_bn" => "মাসিক কাঙ্ক্ষিত আয় পেতে আপনার প্রতি ঘণ্টার রেট কত হওয়া উচিত হিসাব করুন।",
            "features" => ["মাসিক ইনকাম গোল", "বিলঅ্যাবল আওয়ার্স%", "ওভারহেড খরচ ইনপুট"],
            "benefits" => ["নিজের শ্রমের সঠিক মূল্য পাওয়া", "আর্থিক লক্ষ্য নিশ্চিত করা"],
            "faqs" => [["Q" => "সব ঘণ্টা কি বিল করা যায়?", "A" => "না, ক্লায়েন্ট খোঁজা বা শেখার সময় নন-বিলঅ্যাবল ধরা হয়।"]]
        ],
        "hourly-monthly-income" => [
            "name" => "Hourly-to-Monthly Income Converter",
            "name_bn" => "আওয়ারলি থেকে মান্থলি ইনকাম কনভার্টার",
            "category" => "career-tools",
            "desc_en" => "Convert hourly wage to daily, weekly, bi-weekly, monthly, and yearly income statements.",
            "desc_bn" => "ঘণ্টাপ্রতি মজুরি থেকে দৈনিক, সাপ্তাহিক, মাসিক ও বার্ষিক আয় রূপান্তর করুন।",
            "features" => ["দৈনিক, সাপ্তাহিক, মাসিক, বার্ষিক হিসাব", "সাপ্তাহিক কর্মঘণ্টা ইনপুট"],
            "benefits" => ["ফুল-টাইম ও ফ্রিল্যান্স বেতনের তুলনা করা", "বাজেট সাজানো"],
            "faqs" => [["Q" => "বছরে কত কর্মঘণ্টা ধরা হয়?", "A" => "সপ্তাহে ৪০ ঘণ্টা হিসাবে বছরে ২০৮০ ঘণ্টা ধরা হয়।"]]
        ],
        "job-application-tracker" => [
            "name" => "Job Application Tracker",
            "name_bn" => "জব অ্যাপ্লিকেশন ট্র্যাকার",
            "category" => "career-tools",
            "desc_en" => "Track job applications, interview schedules, status progression, and follow-up reminders.",
            "desc_bn" => "আপনার বিভিন্ন কোম্পানিতে আবেদনের স্ট্যাটাস ও ইন্টারভিউ তারিখ ফ্রিতে ট্র্যাক করুন।",
            "features" => ["লোকাল সেভ মেমোরি", "স্ট্যাটাস (Applied, Interview, Offer)", "ফলো-আপ রিমাইন্ডার"],
            "benefits" => ["আবেদনের তথ্য ভুলে না যাওয়া", "চাকরি খোঁজার সুশৃঙ্খল পরিবেশ"],
            "faqs" => [["Q" => "ডাটা কি সেভ থাকবে?", "A" => "হ্যাঁ, আপনার ব্রাউজারের লোকাল স্টোরেজে সুরক্ষিত থাকবে।"]]
        ],
        "interview-checklist" => [
            "name" => "Interview Preparation Checklist",
            "name_bn" => "ইন্টারভিউ প্রিপারেশন চেকলিস্ট",
            "category" => "career-tools",
            "desc_en" => "Interactive checklist covering company research, STAR method answers, resume copies, and thank-you notes.",
            "desc_bn" => "চাকরির ইন্টারভিউয়ের আগে ও পরে করণীয় কাজের একটি সম্পূর্ণ চেকলিস্ট।",
            "features" => ["STAR মেথড প্রিপারেশন", "কোম্পানি রিসার্চ গাইড", "প্রোগ্রেস বার%"],
            "benefits" => ["ইন্টারভিউতে আত্মবিশ্বাস অর্জন", "ভুল এড়ানো"],
            "faqs" => [["Q" => "STAR মেথড কি?", "A" => "Situation, Task, Action, Result — প্রশ্নের উত্তর দেওয়ার সেরা পদ্ধতি।"]]
        ],
        "resume-keyword-checker" => [
            "name" => "Resume Keyword Match Checker",
            "name_bn" => "রিজিউম কিওয়ার্ড ম্যাচ চেকার",
            "category" => "career-tools",
            "desc_en" => "Compare resume text against job descriptions to calculate keyword match scores and identify missing ATS keywords.",
            "desc_bn" => "আপনার রিজিউম বা সিভির সাথে চাকরির সার্কুলারের কিওয়ার্ড কতটা মিলছে তা স্ক্যান করুন।",
            "features" => ["ATS ম্যাচ স্কোর%", "মিসিং কিওয়ার্ড লিস্ট", "অ্যাকশন ভার্ব সাজেস্টর"],
            "benefits" => ["ATS ফিল্টারে সিভি নির্বাচিত হওয়া", "ইন্টারভিউ পাওয়ার সুযোগ বৃদ্ধি"],
            "faqs" => [["Q" => "ATS কি?", "A" => "Applicant Tracking System — যা সফটওয়্যারের মাধ্যমে অটোমেটিক সিভি বাছাই করে।"]]
        ],
        "salary-comparison" => [
            "name" => "Job Offer & Salary Comparison Calculator",
            "name_bn" => "জব অফার ও স্যালারি তুলনা ক্যালকুলেটর",
            "category" => "career-tools",
            "desc_en" => "Compare two job offers by factoring in base salary, bonuses, benefits, commuting cost, and working hours.",
            "desc_bn" => "দুটি ভিন্ন চাকরির অফারের বেতন, যাতায়াত খরচ ও সুযোগ-সুবিধা তুলনা করুন।",
            "features" => ["যাতায়াত খরচ বিয়োগ", "বোনাস ও বেনিফিট ম্যাপ", "নেট টেক-হোম পে"],
            "benefits" => ["সঠিক চাকরি বেছে নেওয়ার সিদ্ধান্ত", "লুকানো খরচ জানা"],
            "faqs" => [["Q" => "শুধুমাত্র মূল বেতন দেখে চাকরি বেছে নেওয়া উচিত?", "A" => "না, যাতায়াত সময়, বোনাস এবং কাজের পরিবেশ বিবেচনা করা উচিত।"]]
        ],
        "notice-period-calculator" => [
            "name" => "Notice Period & Last Working Day Calculator",
            "name_bn" => "নোটিশ পিরিয়ড ও শেষ কর্মদিবস ক্যালকুলেটর",
            "category" => "career-tools",
            "desc_en" => "Calculate exact last working day, total calendar days, and working days based on resignation notice rules.",
            "desc_bn" => "পদত্যাগপত্র জমা দেওয়ার তারিখ ও নোটিশ দিন থেকে শেষ কর্মদিবস হিসাব করুন।",
            "features" => ["ক্যালেন্ডার ও ওয়ার্কিং ডে", "ছুটি অ্যাডজাস্টমেন্ট", "ইনস্ট্যান্ট ডেট"],
            "benefits" => ["কোম্পানি থেকে রিলিজ পাওয়া সহজ করা", "নতুন কোম্পানিতে জয়েনিং নিশ্চিত করা"],
            "faqs" => [["Q" => "নোটিশ পিরিয়ড সাধারণত কত দিন হয়?", "A" => "সাধারণত ৩০ দিন থেকে ৯০ দিন পর্যন্ত হয়ে থাকে।"]]
        ],
        "workday-calculator" => [
            "name" => "Workday & Business Day Calculator",
            "name_bn" => "ওয়ার্কিং ডে ও অফিস ডে ক্যালকুলেটর",
            "category" => "career-tools",
            "desc_en" => "Calculate business working days between two dates, automatically excluding weekends and custom holidays.",
            "desc_bn" => "দুটি তারিখের মধ্যবর্তী অফিস বা কর্মদিবসের সংখ্যা (সাপ্তাহিক ছুটি বাদ দিয়ে) হিসাব করুন।",
            "features" => ["শুক্রবার/শনিবার/রবিবার ফিল্টার", "কাস্টম হলিডে বাদ", "টোটাল ডেজ বিয়োগ"],
            "benefits" => ["প্রজেক্ট ডেলিভারি ডেট জানা", "ছুটির হিসাব রাখা"],
            "faqs" => [["Q" => "বাংলাদেশে সাপ্তাহিক ছুটি কোন কোন দিন?", "A" => "সাধারণত শুক্রবার ও শনিবার।"]]
        ],
        "freelance-workload-planner" => [
            "name" => "Freelance Workload & Burnout Planner",
            "name_bn" => "ফ্রিল্যান্স ওয়ার্কলোড ও বার্নআউট প্ল্যানার",
            "category" => "career-tools",
            "desc_en" => "Assess weekly task hours against available time to prevent freelancer capacity overload and burnout.",
            "desc_bn" => "আপনার ক্লায়েন্ট কাজের চাপের অতিরিক্ত মানসিক ও শারীরিক ক্লান্তি (বার্নআউট) ঝুঁকি মাপুন।",
            "features" => ["ওয়ার্কলোড ক্যাপাসিটি%", "বার্নআউট রিস্ক মেজার", "আওয়ারলি বাফার সাজেশন"],
            "benefits" => ["স্বাস্থ্য ঠিক রাখা", "কাজের কোয়ালিটি বজায় রাখা"],
            "faqs" => [["Q" => "বার্নআউট এড়ানোর উপায় কি?", "A" => "অতিরিক্ত কাজের চাপ না নেওয়া এবং নিয়মিত বিরতি নেওয়া।"]]
        ],

        /* ===================================================
         * CATEGORY H — PROGRAMMING & DATA (10 Tools)
         * =================================================== */
        "json-schema-generator" => [
            "name" => "JSON Schema Generator",
            "name_bn" => "জেসন (JSON) স্কিমা জেনারেটর",
            "category" => "developer-tools",
            "desc_en" => "Paste raw JSON data to instantly generate Draft-07 valid JSON Schema with types and required fields.",
            "desc_bn" => "আপনার জেসন ডাটা থেকে স্বয়ংক্রিয়ভাবে জেসন স্কিমা (JSON Schema) তৈরি করুন।",
            "features" => ["Draft-07 কম্প্যাটিবল", "টাইপ ডিটেকশন", "নেস্টেড অবজেক্ট সাপোর্ট"],
            "benefits" => ["এপিআই ডাটা ভ্যালিডেশন সহজ করা", "ডেভেলপমেন্ট স্পিড বাড়ানো"],
            "faqs" => [["Q" => "JSON Schema কেন ব্যবহার করা হয়?", "A" => "এপিআই রিকোয়েস্ট ও রেসপন্সের ডাটা ফরম্যাট সঠিক আছে কিনা তা চেক করতে।"]]
        ],
        "json-path-tester" => [
            "name" => "JSONPath Evaluator & Tester",
            "name_bn" => "জেসন পাথ (JSONPath) টেস্টার",
            "category" => "developer-tools",
            "desc_en" => "Test and evaluate JSONPath expressions ($.store.book[*].author) live against complex JSON payloads.",
            "desc_bn" => "কমপ্লেক্স জেসন ডাটা থেকে নির্দিষ্ট ভ্যালু বের করতে JSONPath কুয়েরি টেস্ট করুন।",
            "features" => ["লাইভ ইভালুয়েশন", "ম্যাচিং রেজাল্ট লিস্ট", "সিনট্যাক্স এরর হাইলাইটার"],
            "benefits" => ["এপিআই রেসপন্স ফিল্টারিং", "কোডিং সহজ করা"],
            "faqs" => [["Q" => "JSONPath এ $ দিয়ে কি বোঝায়?", "A" => "রুট অবজেক্ট বা এলিমেন্টকে নির্দেশ করে।"]]
        ],
        "regex-pattern-tester-pro" => [
            "name" => "RegEx Pattern Tester & Debugger",
            "name_bn" => "রেগুলার এক্সপ্রেশন (RegEx) টেস্টার",
            "category" => "developer-tools",
            "desc_en" => "Test regular expressions with flags (g, i, m), live match highlighting, and group extraction.",
            "desc_bn" => "রেগুলার এক্সপ্রেশন (RegEx) প্যাটার্ন লাইভ ম্যাচিং ও গ্রুপ টেস্ট করুন।",
            "features" => ["গ্লোবাল, কেস-ইনসেনসিটিভ ফ্ল্যাগ", "ম্যাচ হাইলাইটার", "ক্যাপচার গ্রুপ ভিউ"],
            "benefits" => ["ফর্ম ভ্যালিডেশন কোড নিখুঁত করা", "বাগ ফিক্স করা"],
            "faqs" => [["Q" => "RegEx এ \\d বলতে কি বোঝায়?", "A" => "যেকোনো একটি ডিজিট বা সংখ্যা (0-9)।"]]
        ],
        "regex-explainer" => [
            "name" => "RegEx Explanation Generator",
            "name_bn" => "রেজেক্স (RegEx) এক্সপ্লেইনার",
            "category" => "developer-tools",
            "desc_en" => "Break down complex regular expressions token by token into plain English explanations.",
            "desc_bn" => "জটিল রেগুলার এক্সপ্রেশনের কোড ভেঙে সহজ ভাষায় তার অর্থ বুঝে নিন।",
            "features" => ["টোকেন বাই টোকেন ব্রেকডাউন", "কোয়ান্টিফায়ার অ্যানালাইসিস", "সহজ ব্যাখ্যা"],
            "benefits" => ["অন্যের লেখা রেজেক্স কোড বোঝা", "শেখার প্রক্রিয়া দ্রুত করা"],
            "faqs" => [["Q" => "সহজে রেজেক্স শেখার উপায় কি?", "A" => "টোকেনগুলো আলাদা করে নিয়ে একটি একটি করে অর্থ বোঝা।"]]
        ],
        "epoch-unix-time-converter" => [
            "name" => "Unix Timestamp & Epoch Converter",
            "name_bn" => "ইউনিফাইড ইউনিক্স টাইমস্ট্যাম্প কনভার্টার",
            "category" => "developer-tools",
            "desc_en" => "Convert Unix Epoch seconds/milliseconds to human-readable UTC/local date time and vice-versa.",
            "desc_bn" => "ইউনিক্স টাইমস্ট্যাম্প (Seconds/Milliseconds) থেকে তারিখ ও সময়ে পরিবর্তন করুন।",
            "features" => ["সেকেন্ডস ও মিলিসেকেন্ডস সাপোর্ট", "লাইভ কারেন্ট টাইমস্ট্যাম্প", "UTC ও লোকাল টাইম"],
            "benefits" => ["ডাটাবেজ টাইমস্ট্যাম্প বোঝা", "এপিআই ডেট ডিবাগিং"],
            "faqs" => [["Q" => "Unix Epoch সময় কি?", "A" => "১ জানুয়ারি ১৯৭০ থেকে অতিবাহিত হওয়া মোট সেকেন্ডের সংখ্যা।"]]
        ],
        "v4-uuid-guid-generator" => [
            "name" => "Random UUID v4 / GUID Generator",
            "name_bn" => "র্যান্ডম UUID v4 জেনারেটর",
            "category" => "developer-tools",
            "desc_en" => "Generate cryptographically secure Version-4 UUID / GUID unique identifiers in bulk.",
            "desc_bn" => "ডাটাবেজ প্রাইমারি কি এর জন্য ইউনিক UUID v4 হ্যাশ কোড জেনারেট করুন।",
            "features" => ["বুল্ক জেনারেটর (১-১০০)", "আপারকেস/লোয়ারকেস অপশন", "ইনস্ট্যান্ট কপি অল"],
            "benefits" => ["ডাটাবেজে প্রাইমারি কি কনফ্লিক্ট না হওয়া", "নিরাপদ ইউনিক আইডি"],
            "faqs" => [["Q" => "UUID v4 ডুপ্লিকেট হওয়ার সম্ভাবনা কত?", "A" => "সম্ভাবনা প্রায় শূন্যের কোঠায় (১ এর পর ৩৭ টি শূন্য)।"]]
        ],
        "html-entity-encoder" => [
            "name" => "HTML Entity Encoder & Decoder",
            "name_bn" => "এইচটিএমএল এনটিটি এনকোডার ও ডিকোডার",
            "category" => "developer-tools",
            "desc_en" => "Convert special characters (&, <, >, quotes) to HTML entities and decode escaped HTML back.",
            "desc_bn" => "বিশেষ ক্যারেক্টারগুলোকে নিরাপদ এইচটিএমএল এনটিটি কোডে এনকোড করুন।",
            "features" => ["এনকোড ও ডিকোড মোড", "XSS ফিল্টার প্রিভিউ", "ক্লিন আউটপুট"],
            "benefits" => ["ওয়েবসাইটে XSS আক্রমণ রোধ", "কোড ফরম্যাট ঠিক রাখা"],
            "faqs" => [["Q" => "< চিহ্নের HTML Entity কি?", "A" => "&lt; হলো এর এনটিটি কোড।"]]
        ],
        "url-encoder" => [
            "name" => "URL Encoder & Decoder Pro",
            "name_bn" => "ইউআরএল এনকোডার ও ডিকোডার",
            "category" => "developer-tools",
            "desc_en" => "Encode query strings and URLs safely using encodeURIComponent and decode encoded web addresses.",
            "desc_bn" => "ইউআরএল কোড এনকোড করে ব্রাউজার ফ্রেন্ডলি এবং ডিকোড করে মূল রূপ দেখুন।",
            "features" => ["encodeURIComponent ও encodeURI", "কুয়েরি প্যারাম ব্রেকডাউন", "ইনস্ট্যান্ট ডিকোড"],
            "benefits" => ["ইউআরএল এ স্পেস বা বিশেষ চিহ্নের এরর দূর করা", "এপিআই লিংক সেফ করা"],
            "faqs" => [["Q" => "স্পেস ইউআরএলে এনকোড হলে কি দেখায়?", "A" => "%20 অথবা + চিহ্ন দেখায়।"]]
        ],
        "base64-encoder" => [
            "name" => "Base64 Encoder & Decoder Utility",
            "name_bn" => "বেস৬৪ এনকোডার ও ডিকোডার",
            "category" => "developer-tools",
            "desc_en" => "Encode plain UTF-8 text or binary strings into Base64 format and decode Base64 data accurately.",
            "desc_bn" => "টেক্সট বা ডাটা নিরাপদ Base64 স্ট্রিপে এনকোড এবং ডিকোড করুন।",
            "features" => ["UTF-8 সেফ এনকোডিং", "ইনস্ট্যান্ট ফাইল/টেক্সট ডিকোড", "এরর হ্যান্ডলিং"],
            "benefits" => ["ডাটা ট্রান্সমিশন নিরাপদ করা", "ইমেল ও এপিআই পে লোড সেফ করা"],
            "faqs" => [["Q" => "Base64 কি পাসওয়ার্ড এনক্রিপশন?", "A" => "না, এটি এনকোডিং, এনক্রিপশন নয়। এটি সহজে ডিকোড করা যায়।"]]
        ],
        "jwt-viewer" => [
            "name" => "JWT Token Structure Viewer & Decoder",
            "name_bn" => "জেডব্লিউটি (JWT) টোকেন ডিকোডার",
            "category" => "developer-tools",
            "desc_en" => "Decode JSON Web Tokens (Header, Payload, Signature) and check token expiration times locally.",
            "desc_bn" => "JWT টোকেন না পাঠিয়েই ব্রাউজারে এর হেডার, পে-লোড এবং মেয়াদ টেস্ট করুন।",
            "features" => ["১০০% লোকাল ক্লায়েন্ট প্রসেসিং", "এক্সপাইরেশন (exp) চেকার", "কালার কোডেড পে-লোড"],
            "benefits" => ["অ্যAuthentication টোকেন ডিবাগিং", "সিকিউরিটি ভ্যালিডেশন"],
            "faqs" => [["Q" => "আমার টোকেন কি কোনো সার্ভারে সেভ হবে?", "A" => "না, সম্পূর্ণ ডিকোডিং প্রক্রিয়া ব্রাউজারেই সম্পন্ন হয়।"]]
        ],

        /* ===================================================
         * CATEGORY I — TEXT, WRITING & PRODUCTIVITY (10 Tools)
         * =================================================== */
        "text-diff-viewer" => [
            "name" => "Text Diff & Comparison Viewer",
            "name_bn" => "টেক্সট ডিফারেন্স ও ডিফ ভিউয়ার",
            "category" => "text-tools",
            "desc_en" => "Compare two text versions side-by-side or line-by-line to highlight added, removed, or changed lines.",
            "desc_bn" => "দুইটি লেখার মধ্যে কোথায় কোথায় পরিবর্তন বা পার্থক্য আছে তা হাইলাইট সহ দেখুন।",
            "features" => ["লাইন বাই লাইন ডিফ", "হাইলাইটেড যুক্ত/বিযুক্ত লাইন", "স্পেস নরম্যালাইজার"],
            "benefits" => ["আর্টিকেলের রিভিশন তুলনা করা", "কোডের ভুল ধরা"],
            "faqs" => [["Q" => "সবুজ ও লাল রং কি নির্দেশ করে?", "A" => "সবুজ মানে নতুন যুক্ত হওয়া আর লাল মানে মুছে ফেলা শব্দ।"]]
        ],
        "sentence-counter" => [
            "name" => "Sentence & Readability Counter",
            "name_bn" => "সেন্টেন্স ও প্যারাগ্রাফ কাউন্টার",
            "category" => "text-tools",
            "desc_en" => "Count sentences, total words, average sentence length, and estimated readability scores.",
            "desc_bn" => "লেখায় কতটি বাক্য আছে, বাক্যের গড় দৈর্ঘ্য এবং রিডেবিলিটি পয়েন্ট বের করুন।",
            "features" => ["সেন্টেন্স কাউন্ট", "অ্যাভারেজ ওয়ার্ডস/সেন্টেন্স", "পড়ার সহযোজ্যতা পয়েন্ট"],
            "benefits" => ["লেখা আরও সহজ ও প্রাঞ্জল করা", "এসইও কন্টেন্ট কোয়ালিটি বাড়ানো"],
            "faqs" => [["Q" => "একটি বাক্যে কত শব্দ রাখা ভালো?", "A" => "১৫ থেকে ২০ শব্দের মধ্যে রাখা সবচেয়ে প্রাঞ্জল।"]]
        ],
        "paragraph-counter" => [
            "name" => "Paragraph & Structure Analytics",
            "name_bn" => "প্যারাগ্রাফ ও কন্টেন্ট স্ট্রাকচার চেকার",
            "category" => "text-tools",
            "desc_en" => "Analyze paragraph counts, average words per paragraph, empty line spacing, and density.",
            "desc_bn" => "আর্টিকেলের প্যারাগ্রাফ সংখ্যা এবং অনুচ্ছেদের দৈর্ঘ্য বিশ্লেষণ করুন।",
            "features" => ["প্যারাগ্রাফ সংখ্যা", "গড় শব্দ/অনুচ্ছেদ", "লংগেস্ট প্যারা মেজার"],
            "benefits" => ["পাঠকদের জন্য কন্টেন্ট দৃষ্টিবান্ধব করা", "বাউন্স রেট কমানো"],
            "faqs" => [["Q" => "একটি প্যারাগ্রাফ কত বড় হওয়া উচিত?", "A" => "৩ থেকে ৫ লাইনের মধ্যে অনুচ্ছেদ রাখা গুগলে রিডার ফ্রেন্ডলি।"]]
        ],
        "reading-time-language" => [
            "name" => "Multi-Language Reading Time Calculator",
            "name_bn" => "বহুভাষিক রিডিং টাইম ক্যালকুলেটর",
            "category" => "text-tools",
            "desc_en" => "Calculate estimated reading and speaking time based on language speeds (Bengali ~150 wpm, English ~200 wpm).",
            "desc_bn" => "বাংলা বা ইংরেজি আর্টিকেল পড়তে বা বলতে কত মিনিট লাগবে তা জানুন।",
            "features" => ["বাংলা, ইংরেজি, স্প্যানিশ স্পিড স্কেল", "রিডিং বনাম স্পিকিং টাইম", "পডকাস্ট মেজার"],
            "benefits" => ["ব্লগ পেজে রিডিং টাইম যুক্ত করা", "ভাষণের সময় নির্ধারণ"],
            "faqs" => [["Q" => "বাংলা লেখার পড়ার গতি কত ধরা হয়?", "A" => "বাংলায় গড়ে প্রতি মিনিটে ১৫০ শব্দ পড়ার স্বাভাবিক গতি।"]]
        ],
        "text-cleaner" => [
            "name" => "Text Cleanup & Whitespace Normalizer",
            "name_bn" => "টেক্সট ক্লিনআপ ও হোয়াইটস্পেস নরম্যালাইজার",
            "category" => "text-tools",
            "desc_en" => "Strip HTML tags, normalize multiple spaces, remove empty lines, and format raw pasted text.",
            "desc_bn" => "লেখার অনাকাঙ্ক্ষিত স্পেস, ফাঁকা লাইন এবং এইচটিএমএল ট্যাগ এক ক্লিকে মুছে দিন।",
            "features" => ["HTML ট্যাগ রিমুভার", "ডুপ্লিকেট স্পেস ক্লিনার", "ট্রিম লাইনস"],
            "benefits" => ["সুন্দর ও পরিচ্ছন্ন কন্টেন্ট তৈরি", "কপি-পেস্ট ঝামেলা দূর করা"],
            "faqs" => [["Q" => "ওয়ার্ড ফাইল থেকে পেস্ট করলে কি স্পেস এরর হয়?", "A" => "হ্যাঁ, এই টুল এক ক্লিকে সকল কাস্টম স্পেস ঠিক করে দেয়।"]]
        ],
        "line-sorter" => [
            "name" => "Text Line Sorter & Deduplicator",
            "name_bn" => "টেক্সট লাইন সর্টার ও ডুপ্লিকেট রিমুভার",
            "category" => "text-tools",
            "desc_en" => "Sort text lines alphabetically (A-Z, Z-A), by length, or numerically, and strip duplicate lines.",
            "desc_bn" => "লেখার লাইনগুলোকে বর্ণানুক্রমিকভাবে (A-Z) সাজান এবং ডুপ্লিকেট লাইন রিমুভ করুন।",
            "features" => ["A-Z এবং Z-A সর্ট", "ডুপ্লিকেট লাইন রিমুভার", "রিভার্স লাইনস"],
            "benefits" => ["তালিকা ও ডাটা গোছানো", "কাজের সময় বাঁচানো"],
            "faqs" => [["Q" => "ডুপ্লিকেট লাইন কি অটোমেটিক মুছে যাবে?", "A" => "হ্যাঁ, রিমুভ ডুপ্লিকেট অপশনে ক্লিক করলেই হবে।"]]
        ],
        "csv-text-extractor" => [
            "name" => "CSV Text Column Extractor",
            "name_bn" => "সিএসভি (CSV) টেক্সট কলাম এক্সট্রাক্টর",
            "category" => "text-tools",
            "desc_en" => "Paste CSV data, pick target column by header or index, and extract unique text lists with delimiters.",
            "desc_bn" => "CSV ফাইলের যেকোনো নির্দিষ্ট কলামের তথ্য আলাদা করে তালিকা তৈরি করুন।",
            "features" => ["কলাম চয়েস", "কমা/নিউলাইন ডেলিমিটার", "ইউনিক ফিল্টার"],
            "benefits" => ["ইমেল বা ফোন নম্বর লিস্ট বের করা", "ডাটা প্রসেসিং সহজ করা"],
            "faqs" => [["Q" => "CSV ফাইল কি আপলোড করতে হবে?", "A" => "না, শুধু কপি করে পেস্ট করলেই এক্সট্রাক্ট করা যাবে।"]]
        ],
        "markdown-table-generator" => [
            "name" => "Markdown Table Generator",
            "name_bn" => "মার্কডাউন টেবিল জেনারেটর",
            "category" => "text-tools",
            "desc_en" => "Interactive visual table builder that outputs properly aligned Markdown syntax.",
            "desc_bn" => "সহজেই কলাম ও রো যুক্ত করে মার্কডাউন সিনট্যাক্স টেবিল তৈরি করুন।",
            "features" => ["রো ও কলাম অ্যাড/রিমুভ", "অ্যালাইনমেন্ট (Left, Center, Right)", "কপি সিনট্যাক্স"],
            "benefits" => ["GitHub ও আর্টিকেলে সুন্দর টেবিল যোগ করা", "কোডিং ছাড়া টেবিল তৈরি"],
            "faqs" => [["Q" => "মার্কডাউন টেবিল কোথায় ব্যবহার করা যায়?", "A" => "গিটহাব, নেশন এবং যেকোনো মার্কডাউন সাপোর্টেড ব্লগে।"]]
        ],
        "html-table-generator" => [
            "name" => "Responsive HTML Table Generator",
            "name_bn" => "রেসপন্সিভ এইচটিএমএল টেবিল মেকার",
            "category" => "text-tools",
            "desc_en" => "Generate clean, accessible, responsive HTML table code with inline CSS options.",
            "desc_bn" => "ওয়েবসাইটের জন্য রেসপন্সিভ ও সুন্দর এইচটিএমএল টেবিল কোড তৈরি করুন।",
            "features" => ["বর্ডার ও প্যাডিং স্টাইল", "রেসপন্সিভ র‍্যাপার", "লাইভ এইচটিএমএল প্রিভিউ"],
            "benefits" => ["মোবাইলে টেবিল ভেঙে যাওয়া বন্ধ করা", "ক্লিন কোড মেকিং"],
            "faqs" => [["Q" => "মোবাইলে টেবিল সুন্দর দেখাবে?", "A" => "হ্যাঁ, এটি রেসপন্সিভ টেবিল র‍্যাপার কোড যুক্ত করে দেয়।"]]
        ],
        "lorem-ipsum-custom" => [
            "name" => "Custom Lorem Ipsum Generator (EN & BN)",
            "name_bn" => "কাস্টম লরেম ইপসাম (বাংলা ও ইংরেজি) মেকার",
            "category" => "text-tools",
            "desc_en" => "Generate custom placeholder dummy text in English or authentic Bengali dummy text.",
            "desc_bn" => "ওয়েব ডিজাইনের ডেমো টেক্সটের জন্য বাংলা বা ইংরেজি লরেম ইপসাম জেনারেট করুন।",
            "features" => ["বাংলা ও ইংরেজি ডামি টেক্সট", "প্যারাগ্রাফ ও সেন্টেন্স কাউন্ট", "কপি বাটন"],
            "benefits" => ["ডিজাইনে সঠিক টেক্সট ব্যবহার", "বাংলা ডেমো কন্টেন্টের সুবিধা"],
            "faqs" => [["Q" => "বাংলা ডামি টেক্সট কি পাওয়া যাবে?", "A" => "হ্যাঁ, সম্পূর্ণ অর্থপূর্ণ বাংলা ডেমো প্যারাগ্রাফ পাওয়া যাবে।"]]
        ],

        /* ===================================================
         * CATEGORY J — EVERYDAY, SCIENCE & ENGINEERING (10 Tools)
         * =================================================== */
        "percentage-change" => [
            "name" => "Percentage Change & Difference Calculator",
            "name_bn" => "পারসেন্টেজ চেঞ্জ ও বৃদ্ধি/হ্রাস ক্যালকুলেটর",
            "category" => "utility-tools",
            "desc_en" => "Calculate percentage increase, decrease, percentage difference, and X percent of Y.",
            "desc_bn" => "দুইটি সংখ্যার মধ্যে শতকরা বৃদ্ধি বা হ্রাসের পরিমাণ এবং পরিবর্তন হিসাব করুন।",
            "features" => ["পারসেন্টেজ ইன்க্রিজ/ডিক্রিজ", "X% of Y", "পারসেন্টেজ ডিফারেন্স"],
            "benefits" => ["ব্যবসা ও গণিতের জটিল হিসাব সহজ করা", "নির্ভুল ফলাফল"],
            "faqs" => [["Q" => "৫০ থেকে ৭৫ হলে বৃদ্ধি কত%?", "A" => "৫০% বৃদ্ধি পাবে।"]]
        ],
        "ratio-calculator" => [
            "name" => "Ratio & Proportion Calculator",
            "name_bn" => "অনুপাত ও সমানুপাত ক্যালকুলেটর",
            "category" => "utility-tools",
            "desc_en" => "Solve ratio proportions (A : B = C : D) to find missing values and simplify complex ratios.",
            "desc_bn" => "অনুপাত (A:B = C:D) এর অজানা মান বের করুন এবং অনুপাত লঘুকরণ করুন।",
            "features" => ["অনুপাত লঘুকরণ (Simplify)", "সমানুপাত মিসিং ভ্যালু", "স্কেলিং ফ্যাক্টর"],
            "benefits" => ["রেসিপি বা ডিজাইনের অনুপাত ঠিক রাখা", "সহজ সমাধান"],
            "faqs" => [["Q" => "অনুপাত লঘুকরণ কি?", "A" => "অনুপাতের সংখ্যাগুলোকে ছোটতম পূর্ণসংখ্যার রূপে প্রকাশ করা।"]]
        ],
        "average-calculator" => [
            "name" => "Average, Median & Mode Calculator",
            "name_bn" => "গড়, মধ্যক ও প্রচুরক (Average) ক্যালকুলেটর",
            "category" => "utility-tools",
            "desc_en" => "Calculate Mean (Average), Median, Mode, Range, and Standard Deviation for any set of numbers.",
            "desc_bn" => "সংখ্যার সেট থেকে গড় (Mean), মধ্যক (Median) ও প্রচুরক (Mode) হিসাব করুন।",
            "features" => ["গড় (Mean)", "মধ্যক (Median)", "প্রচুরক (Mode)", "রেঞ্জ ও যোগফল"],
            "benefits" => ["পরিসংখ্যানের হিসাব দ্রুত করা", "ডাটা এনালাইসিস সহজ করা"],
            "faqs" => [["Q" => "Mean এবং Median এর মধ্যে পার্থক্য কি?", "A" => "Mean হলো গাণিতিক গড়, আর Median হলো মাঝখানের সংখ্যা।"]]
        ],
        "date-add-subtract" => [
            "name" => "Date Add / Subtract Calculator",
            "name_bn" => "তারিখ যোগ ও বিয়োগ ক্যালকুলেটর",
            "category" => "utility-tools",
            "desc_en" => "Add or subtract days, weeks, months, or years from a starting date to find the target date.",
            "desc_bn" => "যেকোনো নির্দিষ্ট তারিখের সাথে দিন, মাস বা বছর যোগ বা বিয়োগ করে নতুন তারিখ পান।",
            "features" => ["দিন, সপ্তাহ, মাস, বছর যোগ/বিয়োগ", "দিনের নাম (Bar)", "ইনস্ট্যান্ট ডেট"],
            "benefits" => ["চুক্তি বা প্রজেক্টের মেয়াদ শেষ হওয়ার তারিখ জানা", "পরিকল্পনা করা"],
            "faqs" => [["Q" => "অধিবর্ষ (Leap Year) কি হিসাব করা হয়?", "A" => "হ্যাঁ, এটি সঠিক লিফ ইয়ার গণনা করে।"]]
        ],
        "time-duration" => [
            "name" => "Time Duration & Difference Calculator",
            "name_bn" => "সময়কাল ও ডিউরেশন ক্যালকুলেটর",
            "category" => "utility-tools",
            "desc_en" => "Calculate precise duration between two times or dates in hours, minutes, seconds, and total decimal hours.",
            "desc_bn" => "দুইটি নির্দিষ্ট সময় বা তারিখের মধ্যবর্তী ঘণ্টার পার্থক্য ও মিনিট হিসাব করুন।",
            "features" => ["ঘণ্টা, মিনিট ও সেকেন্ড", "দশমিক আওয়ার আউটপুট", "ডেট ডিফারেন্স"],
            "benefits" => ["ডিউটি বা কাজের মোট সময় বের করা", "ওভারটাইম হিসাব করা"],
            "faqs" => [["Q" => "১০:১৫ AM থেকে ৪:৪৫ PM পর্যন্ত কত ঘণ্টা?", "A" => "৬ ঘণ্টা ৩০ মিনিট (৬.৫ ঘণ্টা)।"]]
        ],
        "speed-distance-time" => [
            "name" => "Speed Distance Time Calculator",
            "name_bn" => "গতিবেগ, দূরত্ব ও সময় ক্যালকুলেটর",
            "category" => "utility-tools",
            "desc_en" => "Calculate Speed (km/h, mph), Distance (km, miles), or Time (hours, mins) from any two known variables.",
            "desc_bn" => "গতিবেগ, দূরত্ব ও সময়ের যেকোনো দুইটি জানা থাকলে তৃতীয় অজানা মান বের করুন।",
            "features" => ["Speed (km/h, mph)", "Distance (km, m, miles)", "Time (hrs, mins)"],
            "benefits" => ["ভ্রমণের সময় অনুমান করা", "পদার্থবিজ্ঞানের হিসাব সহজ করা"],
            "faqs" => [["Q" => "৬০ কিমি/ঘণ্টা বেগে ১২০ কিমি যেতে কত সময় লাগবে?", "A" => "২ ঘণ্টা সময় লাগবে।"]]
        ],
        "temperature-converter" => [
            "name" => "Temperature Unit Converter Pro",
            "name_bn" => "তাপমাত্রা ইউনিট কনভার্টার",
            "category" => "utility-tools",
            "desc_en" => "Convert temperature instantly between Celsius (°C), Fahrenheit (°F), Kelvin (K), and Rankine.",
            "desc_bn" => "সেলসিয়াস, ফারেনহাইট ও কেলভিনের মধ্যে তাৎক্ষণিক রূপান্তর করুন।",
            "features" => ["°C, °F, Kelvin, Rankine", "কনভার্সন সূত্র প্রদর্শন", "ইনস্ট্যান্ট রেজাল্ট"],
            "benefits" => ["জ্বরের তাপমাত্রা ফারেনহাইটে রূপান্তর", "বিজ্ঞানের হিসাব সহজ করা"],
            "faqs" => [["Q" => "মানবদেহের স্বাভাবিক তাপমাত্রা কত?", "A" => "৯৮.৬° ফারেনহাইট বা ৩৭° সেলসিয়াস।"]]
        ],
        "area-converter" => [
            "name" => "Area Unit Converter (Land & Web)",
            "name_bn" => "ক্ষেত্রফল ও জমি পরিমাপ কনভার্টার",
            "category" => "utility-tools",
            "desc_en" => "Convert land and surface area between Square Meters, Square Feet, Acres, Hectares, Bigha, and Katha.",
            "desc_bn" => "স্কয়ার ফিট, একর, শতাংশ, বিঘা ও কাঠার মধ্যে জমির পরিমাপ হিসাব করুন।",
            "features" => ["স্কয়ার ফিট, মিটার, একর, শতাংশ", "বিঘা ও কাঠা অপশন", "ইনস্ট্যান্ট মান"],
            "benefits" => ["জমি কেনাবেচায় সঠিক পরিমাপ পাওয়া", "ভুল এড়ানো"],
            "faqs" => [["Q" => "১ একরে কত শতাংশ?", "A" => "১ একর = ১০০ শতাংশ (বা ৪৩,৫৬০ বর্গফুট)।"]]
        ],
        "volume-converter" => [
            "name" => "Volume & Liquid Unit Converter",
            "name_bn" => "আয়তন ও তরল পরিমাপ কনভার্টার",
            "category" => "utility-tools",
            "desc_en" => "Convert liquid volume between Liters, Milliliters, Gallons (US/UK), Cubic Meters, and Fluid Ounces.",
            "desc_bn" => "লিটার, মিলিলিটার, গ্যালন এবং ফ্লুইড আউন্সের মধ্যে পরিমাপ পরিবর্তন করুন।",
            "features" => ["Liters, ML, Gallons (US/UK)", "Cubic Feet ও Meters", "আউন্স অপশন"],
            "benefits" => ["জ্বালানি বা তরল পরিমাপ সহজ করা", "রান্না ও রসায়নের সুবিধা"],
            "faqs" => [["Q" => "১ ইউএস গ্যালনে কত লিটার?", "A" => "প্রায় ৩.৭৮৫ লিটার।"]]
        ],
        "engineering-unit-converter" => [
            "name" => "Engineering Unit Converter Pro",
            "name_bn" => "ইঞ্জিনিয়ারিং ইউনিট কনভার্টার",
            "category" => "utility-tools",
            "desc_en" => "Convert engineering units for Pressure (Pascal, Bar, PSI), Energy (Joule, kWh, BTU), and Power (Watt, HP).",
            "desc_bn" => "প্রেশার (PSI, Bar), শক্তি (Joule, kWh) ও ক্ষমতার (Watt, HP) কনভার্টার।",
            "features" => ["Pressure (PSI, Bar, Pa)", "Energy (Joule, kWh, BTU)", "Power (Watt, HP)"],
            "benefits" => ["ইঞ্জিনিয়ারিং পঠন ও হিসাব সহজ করা", "সঠিক ইউনিট রূপান্তর"],
            "faqs" => [["Q" => "১ হর্সপাওয়ার (HP) সমান কত ওয়াট?", "A" => "৭৪৬ ওয়াট।"]]
        ],
    
        /* ===================================================
         * ADDITIONAL UNIQUE ENTERPRISE & UTILITY TOOLS (60 Tools)
         * =================================================== */
        'pdf-to-word-converter-info' => [
            'name' => 'PDF to Word Converter Guide & Tool',
            'name_bn' => 'পিডিএফ টু ওয়ার্ড কনভার্টার',
            'category' => 'utility-tools',
            'desc_en' => 'Convert PDF documents into editable Word DOCX files with text formatting intact.',
            'desc_bn' => 'আপনার পিডিএফ ফাইলকে সহজে এডিটেবল ওয়ার্ড ফাইলে রূপান্তর করার গাইড ও টুল।',
            'features' => ['১০০% ফ্রি ও দ্রুত', 'লেআউট ঠিক রাখে', 'ব্রাউজার সেফ'],
            'benefits' => ['ডকুমেন্ট সহজে এডিট করা', 'সময় সাশ্রয়'],
            'faqs' => [['Q' => 'এটি কি ফ্রি?', 'A' => 'হ্যাঁ, ১০০% ফ্রি।']]
        ],
        'word-to-pdf-converter-info' => [
            'name' => 'Word to PDF Converter Pro',
            'name_bn' => 'ওয়ার্ড টু পিডিএফ কনভার্টার',
            'category' => 'utility-tools',
            'desc_en' => 'Convert DOCX and DOC files to high-quality PDF documents instantly.',
            'desc_bn' => 'ওয়ার্ড ফাইলকে প্রিন্ট ফ্রেন্ডলি পিডিএফ ফাইলে কনভার্ট করুন।',
            'features' => ['হাই কোয়ালিটি পিডিএফ', 'ইনস্ট্যান্ট প্রসেসিং', 'নিরাপদ'],
            'benefits' => ['প্রফেশনাল ডকুমেন্ট শেয়ারিং'],
            'faqs' => [['Q' => 'ফরম্যাটিং ঠিক থাকবে?', 'A' => 'হ্যাঁ, হুবহু ফন্ট ও ডিজাইন বজায় থাকে।']]
        ],
        'pdf-merge-tool-online' => [
            'name' => 'PDF Merger Online Free',
            'name_bn' => 'পিডিএফ মার্জার - একাধিক পিডিএফ একত্রীকরণ',
            'category' => 'utility-tools',
            'desc_en' => 'Merge multiple PDF files into one single organized PDF document.',
            'desc_bn' => 'একাধিক পিডিএফ ফাইলকে একটি ফাইলে যুক্ত করুন।',
            'features' => ['একাধিক ফাইল নির্বাচন', 'সহজ অর্ডার সাজানো', 'দ্রুত মার্জ'],
            'benefits' => ['ডকুমেন্ট গুছিয়ে রাখা'],
            'faqs' => [['Q' => 'কয়টি ফাইল মার্জ করা যায়?', 'A' => 'যত খুশি ফাইল মার্জ করতে পারবেন।']]
        ],
        'pdf-split-tool-online' => [
            'name' => 'PDF Splitter Online Free',
            'name_bn' => 'পিডিএফ স্প্লিটার - পৃষ্ঠা আলাদা করার টুল',
            'category' => 'utility-tools',
            'desc_en' => 'Split specific pages or ranges from any PDF document into individual files.',
            'desc_bn' => 'পিডিএফ থেকে নির্দিষ্ট পেজ কেটে আলাদা ফাইলে রূপান্তর করুন।',
            'features' => ['পেজ রেঞ্জ সিলেকশন', 'সিঙ্গেল পেজ এক্সট্রাক্ট', 'হাই স্পিড'],
            'benefits' => ['প্রয়োজনীয় পেজ বেছে নেওয়া'],
            'faqs' => [['Q' => 'পেজ নম্বর দেওয়া যায়?', 'A' => 'হ্যাঁ, নির্দিষ্ট পেজ নম্বর উল্লেখ করা যায়।']]
        ],
        'pdf-compressor-online-free' => [
            'name' => 'PDF Compressor Online Free',
            'name_bn' => 'পিডিএফ কম্প্রেসর - ফাইল সাইজ ছোট করুন',
            'category' => 'utility-tools',
            'desc_en' => 'Reduce PDF file size without sacrificing document text clarity and image resolution.',
            'desc_bn' => 'পিডিএফ কোয়ালিটি ঠিক রেখে ফাইলের সাইজ ছোট করুন।',
            'features' => ['স্মার্ট মেমোরি রিডাকশন', 'টেক্সট ক্ল্যারিটি', 'ফাস্ট ডাউনলোড'],
            'benefits' => ['ইমেইলে সহজে সেন্ড করা'],
            'faqs' => [['Q' => 'কোয়ালিটি নষ্ট হবে?', 'A' => 'না, ভিজ্যুয়াল কোয়ালিটি ঠিক থাকবে।']]
        ],
        'jpg-to-pdf-converter-pro' => [
            'name' => 'JPG to PDF Converter Pro',
            'name_bn' => 'জেপিজি টু পিডিএফ কনভার্টার',
            'category' => 'image-tools',
            'desc_en' => 'Convert JPG, JPEG, and PNG images into a professional PDF file.',
            'desc_bn' => 'ছবিগুলোকে একসাথে সুন্দর পিডিএফ ফাইলে পরিণত করুন।',
            'features' => ['একাধিক পিকচার আপলোড', 'মার্জিন কাস্টমাইজেশন', 'ওয়ান ক্লিক ডাউনলোড'],
            'benefits' => ['ডকুমেন্ট স্ক্যান তৈরি করা'],
            'faqs' => [['Q' => 'মোবাইলে কাজ করবে?', 'A' => 'হ্যাঁ, অ্যান্ড্রয়েড ও আইফোনে সমানভাবে কাজ করে।']]
        ],
        'png-to-pdf-converter-pro' => [
            'name' => 'PNG to PDF Converter Pro',
            'name_bn' => 'পিএনজি টু পিডিএফ কনভার্টার',
            'category' => 'image-tools',
            'desc_en' => 'Convert transparent PNG images to clean PDF files instantly.',
            'desc_bn' => 'পিএনজি ফাইল সহজে পিডিএফে কনভার্ট করুন।',
            'features' => ['ট্রান্সপারেন্সি সাপোর্ট', 'ফাস্ট রেসপন্স'],
            'benefits' => ['ডিজিটাল কপি সংরক্ষণ'],
            'faqs' => [['Q' => 'নিরাপদ কি?', 'A' => 'হ্যাঁ, ১০০% নিরাপদ।']]
        ],
        'pdf-page-numberer' => [
            'name' => 'PDF Page Numbering Tool',
            'name_bn' => 'পিডিএফ পেজ নম্বর জেনারেটর',
            'category' => 'utility-tools',
            'desc_en' => 'Add custom page numbers to top or bottom headers/footers of any PDF file.',
            'desc_bn' => 'পিডিএফ ফাইলের পেজের নিচে বা উপরে পেজ নম্বর যুক্ত করুন।',
            'features' => ['হেডার ও ফুটার পজিশন', 'ফন্ট স্টাইল', 'কাস্টম স্টার্ট নম্বর'],
            'benefits' => ['অফিসিয়াল ডকুমেন্টিং'],
            'faqs' => [['Q' => 'নম্বর কাস্টম করা যায়?', 'A' => 'হ্যাঁ, পছন্দের ফরম্যাটে দেওয়া যায়।']]
        ],
        'pdf-watermark-generator' => [
            'name' => 'PDF Watermark Generator Pro',
            'name_bn' => 'পিডিএফ ওয়াটারমার্ক মেকার',
            'category' => 'utility-tools',
            'desc_en' => 'Protect your PDF content by embedding custom text or logo watermarks.',
            'desc_bn' => 'আপনার পিডিএফে নিজস্ব ওয়াটারমার্ক বা লোগো যোগ করে কপিরাইট সুরক্ষিত করুন।',
            'features' => ['কাস্টম টেক্সট', 'অপাসিটি এডজাস্ট', 'অ্যাঙ্গেল রোটেশন'],
            'benefits' => ['কপিরাইট সুরক্ষা'],
            'faqs' => [['Q' => 'লোগো সাপোর্ট করে?', 'A' => 'হ্যাঁ, ছবি ও টেক্সট দুটোই ওয়াটারমার্ক হিসেবে দেওয়া যায়।']]
        ],
        'pdf-password-protector' => [
            'name' => 'PDF Password Protector Pro',
            'name_bn' => 'পিডিএফ পাসওয়ার্ড প্রোটেক্টর',
            'category' => 'security-tools',
            'desc_en' => 'Encrypt and set strong password protection on confidential PDF documents.',
            'desc_bn' => 'আপনার গুরুত্বপূর্ণ পিডিএফে পাসওয়ার্ড লক যুক্ত করুন।',
            'features' => ['AES ২৫৬ এনক্রিপশন', 'সহজ লক অপশন', 'গোপনীয়তা নিশ্চিত'],
            'benefits' => ['তথ্য চুরি রোধ করা'],
            'faqs' => [['Q' => 'পাসওয়ার্ড কি খোলা সম্ভব?', 'A' => 'সঠিক পাসওয়ার্ড ছাড়া ফাইল খোলা যাবে না।']]
        ],
        'image-resizer-online-free' => [
            'name' => 'Image Resizer Online Free',
            'name_bn' => 'ইমেজ রিসাইজার - ছবির সাইজ পরিবর্তন',
            'category' => 'image-tools',
            'desc_en' => 'Resize pixel width and height of JPG, PNG, WEBP images easily.',
            'desc_bn' => 'পিক্সেল ও সেন্টিমিটার মেপে ছবির আকার পরিবর্তন করুন।',
            'features' => ['পিক্সেল ও পার্সেন্টেজ মোড', 'অ্যাসপেক্ট রেশিও লক', 'ফাস্ট ডাউনলোড'],
            'benefits' => ['অনলাইন ফর্মের জন্য ছবি রেডি করা'],
            'faqs' => [['Q' => 'পাসপোর্ট সাইজ করা যাবে?', 'A' => 'হ্যাঁ, কাস্টম ডায়মেনশন দিয়ে তৈরি করা যায়।']]
        ],
        'image-cropper-online-pro' => [
            'name' => 'Image Cropper Online Pro',
            'name_bn' => 'ইমেজ ক্রপার - ছবি কাটার টুল',
            'category' => 'image-tools',
            'desc_en' => 'Crop unwanted borders from photos with precise aspect ratio presets.',
            'desc_bn' => 'ছবির অপ্রয়োজনীয় অংশ সুন্দরভাবে কেটে বাদ দিন।',
            'features' => ['১:১, ১৬:৯, ৪:৩ প্রিসেট', 'ফ্রিহ্যান্ড ক্রপ', 'হাই রেজুলেশন'],
            'benefits' => ['সোশ্যাল মিডিয়া প্রোফাইল পিকচার তৈরি'],
            'faqs' => [['Q' => 'কোয়ালিটি ঠিক থাকবে?', 'A' => 'হ্যাঁ, অরিজিনাল পিক্সেল বজায় থাকে।']]
        ],
        'svg-to-png-converter' => [
            'name' => 'SVG to PNG Converter Pro',
            'name_bn' => 'এসভিজি টু পিএনজি কনভার্টার',
            'category' => 'image-tools',
            'desc_en' => 'Convert vector SVG files to high-resolution transparent PNG images.',
            'desc_bn' => 'ভেক্টর এসভিজি ফাইলকে পিএনজি ছবিতে কনভার্ট করুন।',
            'features' => ['ট্রান্সপারেন্ট ব্যাকগ্রাউন্ড', 'স্কেল ফ্যাক্টর এডজাস্ট', 'ফাস্ট প্রসেস'],
            'benefits' => ['ওয়েব ডিজাইন ও গ্রাফিক্স ইউজে সুবিধা'],
            'faqs' => [['Q' => 'ব্যাকগ্রাউন্ড কি স্বচ্ছ থাকবে?', 'A' => 'হ্যাঁ, ট্রান্সপারেন্সি বজায় থাকে।']]
        ],
        'webp-to-jpg-converter' => [
            'name' => 'WEBP to JPG Converter Pro',
            'name_bn' => 'ওয়েবপি টু জেপিজি কনভার্টার',
            'category' => 'image-tools',
            'desc_en' => 'Convert modern WEBP web images to universally compatible JPG format.',
            'desc_bn' => 'ওয়েবপি ছবিগুলোকে জেপিজি ফরম্যাটে বদলে নিন।',
            'features' => ['ইউনিভার্সাল কম্প্যাটিবিলিটি', 'ব্যাচ সাপোর্ট', 'ক্লিন আউটপুট'],
            'benefits' => ['সব ডিভাইসে সহজে দেখা'],
            'faqs' => [['Q' => 'কেন জেপিজি করব?', 'A' => 'পুরাতন সফটওয়্যারে WEBP সাপোর্ট না করলে JPG দরকার হয়।']]
        ],
        'gif-maker-online-free' => [
            'name' => 'Animated GIF Maker Online',
            'name_bn' => 'এনিমেটেড জিআইএফ মেকার',
            'category' => 'image-tools',
            'desc_en' => 'Combine multiple static images into a smooth animated GIF graphic.',
            'desc_bn' => 'একাধিক ছবি মিলিয়ে মজার এনিমেটেড জিআইএফ তৈরি করুন।',
            'features' => ['ফ্রেমিং স্পিড কন্ট্রোল', 'লুপ সেটিংস', 'ক্লিন এনিমেশন'],
            'benefits' => ['সোশ্যাল মিডিয়া পোস্ট আকর্ষনীয় করা'],
            'faqs' => [['Q' => 'স্পিড কমানো বাড়ানো যায়?', 'A' => 'হ্যাঁ, ফ্রেম ডিলে কাস্টমাইজ করা যায়।']]
        ],
        'favicon-generator-pro' => [
            'name' => 'Website Favicon Generator Pro',
            'name_bn' => 'ওয়েবসাইট ফেভআইকন জেনারেটর',
            'category' => 'developer-tools',
            'desc_en' => 'Generate 16x16, 32x32, and Apple Touch icon sets for websites from any image.',
            'desc_bn' => 'আপনার ওয়েবসাইটের ব্রাউজার আইকন বা ফেভআইকন তৈরি করুন।',
            'features' => ['১৬x১৬, ৩২x৩২ প্রিসেট', 'ICO ফাইল সাপোর্ট', 'HTML ট্যাগ কোড'],
            'benefits' => ['ওয়েবসাইটের প্রফেশনাল ব্র্যান্ডিং'],
            'faqs' => [['Q' => 'আইকো (ICO) ফাইল দেবে?', 'A' => 'হ্যাঁ, 표준 favicon.ico জেনারেট করে।']]
        ],
        'color-palette-generator-ai' => [
            'name' => 'Color Palette Generator Pro',
            'name_bn' => 'কালার প্যালেট জেনারেটর',
            'category' => 'image-tools',
            'desc_en' => 'Generate harmonized HEX, RGB, and HSL web color combinations.',
            'desc_bn' => 'ওয়েবসাইট ও ডিজাইনের জন্য সুন্দর কালার কম্বিনেশন তৈরি করুন।',
            'features' => ['HEX, RGB, HSL কোড', 'হারমোনিয়াস কালার', 'কপি টু ক্লিপবোর্ড'],
            'benefits' => ['আই-ক্যাচিং ডিজাইন তৈরি'],
            'faqs' => [['Q' => 'কোড কপি করা যায়?', 'A' => 'ওয়ান ক্লিকে হেক্স কোড কপি হয়।']]
        ],
        'image-color-extractor' => [
            'name' => 'Image Color Picker & Extractor',
            'name_bn' => 'ইমেজ কালার পিকার ও এক্সট্রাক্টর',
            'category' => 'image-tools',
            'desc_en' => 'Extract dominant color palettes and HEX codes from uploaded pictures.',
            'desc_bn' => 'যেকোনো ছবির ওপর ক্লিক করে হেক্স কালার কোড বের করুন।',
            'features' => ['লাইভ আইড্রপার', 'ডমিন্যান্ট প্যালেট', 'ইনস্ট্যান্ট কোড'],
            'benefits' => ['ডিজাইনে সঠিক কালার ম্যাচিং'],
            'faqs' => [['Q' => 'কোনো ফাইলের ছবি দেওয়া যাবে?', 'A' => 'হ্যাঁ, যেকোনো JPG/PNG দেওয়া যাবে।']]
        ],
        'photo-enhancer-online' => [
            'name' => 'Photo Brightness & Contrast Enhancer',
            'name_bn' => 'ছবি ব্রাইটনেস ও কনট্রাস্ট এনহ্যান্সার',
            'category' => 'image-tools',
            'desc_en' => 'Adjust contrast, brightness, saturation, and sharpness of photos in browser.',
            'desc_bn' => 'ছবির আলো, কনট্রাস্ট ও শার্পনেস বাড়িয়ে ছবি সুন্দর করুন।',
            'features' => ['ব্রাইটনেস স্লাইডার', 'কনট্রাস্ট কন্ট্রোল', 'লাইভ প্রিভিউ'],
            'benefits' => ['ছবি দ্রুত আকর্ষণীয় করা'],
            'faqs' => [['Q' => 'কোনো ফিল্টার আছে?', 'A' => 'হ্যাঁ, অটো এনহ্যান্সমেন্ট সাপোর্ট করে।']]
        ],
        'image-flipper-rotator' => [
            'name' => 'Image Flipper & Rotator',
            'name_bn' => 'ছবি ফিপ ও রোটেট টুল',
            'category' => 'image-tools',
            'desc_en' => 'Rotate images 90, 180, 270 degrees or flip horizontally and vertically.',
            'desc_bn' => 'ছবি ৯০ বা ১৮০ ডিগ্রিতে ঘোরাতে এবং মিরর ইমেজ তৈরি করতে সাহায্য করে।',
            'features' => ['হরিজোন্টাল ও ভার্টিকাল ফ্লিপ', '৯০° রোটেশন', 'ইনস্ট্যান্ট সেভ'],
            'benefits' => ['উল্টো ছবি সোজা করা'],
            'faqs' => [['Q' => 'মিরর পিকচার করা যাবে?', 'A' => 'হ্যাঁ, ফ্লিপ বাটন দিয়ে মিরর করা যায়।']]
        ],
        'json-to-xml-converter-pro' => [
            'name' => 'JSON to XML Converter Pro',
            'name_bn' => 'জেসন টু এক্সএমএল কনভার্টার',
            'category' => 'developer-tools',
            'desc_en' => 'Convert JSON payload objects into structured XML documents seamlessly.',
            'desc_bn' => 'ডেভেলপারদের জন্য জেসন ডেটাকে এক্সএমএল ফরম্যাটে কনভার্ট করার টুল।',
            'features' => ['সিনট্যাক্স ভ্যালিডেশন', 'বিউটিফাই অপশন', 'ফাস্ট প্রসেসিং'],
            'benefits' => ['এপিআই ডাটা ফরম্যাটিং সুবিধা'],
            'faqs' => [['Q' => 'ভুল জেসন হলে কি হবে?', 'A' => 'সিনট্যাক্স এরর অ্যালার্ট দেখাবে।']]
        ],
        'xml-to-json-converter-pro' => [
            'name' => 'XML to JSON Converter Pro',
            'name_bn' => 'এক্সএমএল টু জেসন কনভার্টার',
            'category' => 'developer-tools',
            'desc_en' => 'Convert XML structure into lightweight JSON format for frontend apps.',
            'desc_bn' => 'এক্সএমএল ফাইলকে সহজে লাইটওয়েট জেসন ডেটায় রূপান্তর করুন।',
            'features' => ['নেস্টেড নেমস্পেস সাপোর্ট', 'ইনডেন্ট ইনসপেকশন', 'ক্লিন ডিকশনারি'],
            'benefits' => ['ফ্রন্টএন্ড অ্যাপলিকেশনে ডাটা বাইন্ডিং'],
            'faqs' => [['Q' => 'অ্যাট্রিবিউটগুলো ঠিক থাকবে?', 'A' => 'হ্যাঁ, জেসন কি হিসেবে ম্যাপ হয়ে যায়।']]
        ],
        'html-entity-encoder-decoder' => [
            'name' => 'HTML Entity Encoder & Decoder',
            'name_bn' => 'এইচটিএমএল এনটিটি এনকোডার ও ডিকোডার',
            'category' => 'developer-tools',
            'desc_en' => 'Encode reserved HTML characters into safe HTML entities (&lt;, &gt;) and decode back.',
            'desc_bn' => 'স্পেশাল ক্যারেক্টারকে সেফ এইচটিএমএল এনটিটিতে এনকোড ও ডিকোড করুন।',
            'features' => ['স্পেশাল সিম্বল এনকোডিং', 'এক্সএসএস সেফগার্ড', 'ইনস্ট্যান্ট ডিকোড'],
            'benefits' => ['কোড সেফলি ব্রাউজারে রেন্ডার করা'],
            'faqs' => [['Q' => 'XSS আটকাতে সাহায্য করবে?', 'A' => 'হ্যাঁ, এইচটিএমএল ইনজেকশন প্রতিরোধ করে।']]
        ],
        'jwt-decoder-debugger' => [
            'name' => 'JWT Token Decoder & Inspector',
            'name_bn' => 'জেডাব্লিউটি (JWT) টোকেন ডিকোডার',
            'category' => 'developer-tools',
            'desc_en' => 'Decode and inspect JSON Web Token (JWT) headers, payloads, and expiration timestamps.',
            'desc_bn' => 'জেডাব্লিউটি টোকেনের হেডার, পেলোড ও এক্সপায়ারি ডেটা ডিকোড করে দেখুন।',
            'features' => ['হেডার ও পেলোড ভিউ', 'এক্সপায়ারি কাউন্টডাউন', 'ক্লায়েন্ট সাইড সেফ'],
            'benefits' => ['অথেন্টিকেশন ডিবাগিং সহজ করা'],
            'faqs' => [['Q' => 'টোকেন কি সার্ভারে সেভ হয়?', 'A' => 'না, সম্পূর্ণ ব্রাউজার ক্লায়েন্ট সাইডে প্রসেস হয়।']]
        ],
        'regex-tester-debugger' => [
            'name' => 'Regular Expression (Regex) Tester',
            'name_bn' => 'রেগুলার এক্সপ্রেশন (Regex) টেস্ট টুল',
            'category' => 'developer-tools',
            'desc_en' => 'Test and debug JavaScript, PHP, and Python Regex patterns with live string matching.',
            'desc_bn' => 'আপনার রেগুলার এক্সপ্রেশন প্যাটার্ন লাইভ টেস্ট ও ম্যাচিং যাচাই করুন।',
            'features' => ['লাইভ হাইলাইটিং', 'ফ্ল্যাগস গ্লোবাল/মাল্টিলাইন', 'ম্যাচ গ্রুপিং'],
            'benefits' => ['কোডিংয়ে ফর্ম ভ্যালিডেশন সহজ করা'],
            'faqs' => [['Q' => 'কোন কোন ল্যাঙ্গুয়েজ সাপোর্ট করে?', 'A' => 'JS, PHP, Python এর 표준 রেজেক্স সাপোর্ট করে।']]
        ],
        'cron-job-expression-generator' => [
            'name' => 'Cron Job Schedule Generator',
            'name_bn' => 'ক্রন জব শিডিউল জেনারেটর',
            'category' => 'developer-tools',
            'desc_en' => 'Generate standard 5-part cron job expressions for Linux, cPanel, and WordPress crons.',
            'desc_bn' => 'সার্ভার ও সিপ্যানেলের ক্রন জব সময় নির্ধারণের পাঁচ ডিজিট কোড জেনারেট করুন।',
            'features' => ['মিনিট, ঘণ্টা, দিন, মাস সিলেকশন', 'হিউম্যান রিডেবল বিবরণ', 'সিপ্যানেল রেডি'],
            'benefits' => ['সার্ভার অটোমেশন সঠিক করা'],
            'faqs' => [['Q' => 'প্রতি ৫ মিনিটে চালাতে কি কোড দেব?', 'A' => '*/5 * * * * টাইপ করবেন।']]
        ],
        'sql-query-formatter-pro' => [
            'name' => 'SQL Query Formatter & Beautifier',
            'name_bn' => 'এসকিউএল কুয়েরি ফরম্যাটার',
            'category' => 'developer-tools',
            'desc_en' => 'Format, indent, and clean raw SQL queries for MySQL, PostgreSQL, and SQLite.',
            'desc_bn' => 'অগোছালো এসকিউএল কোডকে সুন্দর ইনডেন্ট করে পড়ার উপযোগী করুন।',
            'features' => ['কীওয়ার্ড আপারকেস', 'স্মার্ট ইনডেন্টেশন', 'এরর ভ্যালিডেশন'],
            'benefits' => ['ডাটাবেজ কুয়েরি রিডেবিলিটি বাড়ানো'],
            'faqs' => [['Q' => 'কোন ডাটাবেজ সাপোর্ট করে?', 'A' => 'MySQL, PostgreSQL, MariaDB, SQLite.']]
        ],
        'css-minifier-unminifier' => [
            'name' => 'CSS Minifier & Formatter Pro',
            'name_bn' => 'সিএসএস মিনিফায়ার ও ফরম্যাটার',
            'category' => 'developer-tools',
            'desc_en' => 'Compress CSS code by removing whitespace or format minified CSS into clean readable lines.',
            'desc_bn' => 'সিএসএস কোড কম্প্রেস করে ওয়েবসাইটের স্পিড বাড়ান।',
            'features' => ['কম্প্রেশন রেশিও মিটার', 'বিউটিফাই মোড', 'ওয়ান ক্লিক কপি'],
            'benefits' => ['পেজ লোডিং টাইম কমানো'],
            'faqs' => [['Q' => 'কোড কি নষ্ট হবে?', 'A' => 'না, শুধুমাত্র স্পেস ও কমেন্ট বাদ যায়।']]
        ],
        'javascript-minifier-pro' => [
            'name' => 'JavaScript Minifier Pro',
            'name_bn' => 'জাভাস্ক্রিপ্ট কোড মিনিফায়ার',
            'category' => 'developer-tools',
            'desc_en' => 'Minify JavaScript files to reduce bundle size and speed up script execution.',
            'desc_bn' => 'জেএস কোডের বাড়তি স্পেস কেটে কোড ছোট করুন।',
            'features' => ['স্পেস ও কমেন্ট রিমুভাল', 'ব্যান্ডউইথ সেভার', 'সেফ মিনিফিকেশন'],
            'benefits' => ['ওয়েবসাইট পারফরম্যান্স বাড়ানো'],
            'faqs' => [['Q' => 'ব্রাউজার স্পিড বাড়বে?', 'A' => 'হ্যাঁ, স্ক্রিপ্ট ডাউনলোড ফাস্ট হয়।']]
        ],
        'htaccess-redirect-generator' => [
            'name' => '.htaccess 301 Redirect Generator',
            'name_bn' => 'এইচটিএক্সেস ৩০১ রিডাইরেক্ট কোড মেকার',
            'category' => 'developer-tools',
            'desc_en' => 'Generate Apache .htaccess 301 redirect rules for domain migrations and URL updates.',
            'desc_bn' => 'সার্ভারের জন্য নিরাপদ ৩০১ রিডাইরেক্ট কোড জেনারেট করুন।',
            'features' => ['HTTP to HTTPS', 'WWW to non-WWW', 'URL to URL rule'],
            'benefits' => ['এসইও জুস ও র‍্যাংক ধরে রাখা'],
            'faqs' => [['Q' => '৩০১ রিডাইরেক্ট কি পার্মানেন্ট?', 'A' => 'হ্যাঁ, এটি পার্মানেন্ট রিডাইরেক্ট কোড।']]
        ],
        'markdown-to-html-converter' => [
            'name' => 'Markdown to HTML Converter',
            'name_bn' => 'মার্কডাউন টু এইচটিএমএল কনভার্টার',
            'category' => 'developer-tools',
            'desc_en' => 'Convert GitHub flavored Markdown (.md) to clean semantic HTML markup.',
            'desc_bn' => 'মার্কডাউন টেক্সটকে এইচটিএমএল কোডে রূপান্তর করুন।',
            'features' => ['লাইভ এইচটিএমএল প্রিভিউ', 'কোড ব্লক হাইলাইটিং', 'সহজ কপি'],
            'benefits' => ['ডকুমেন্টেশন দ্রুত ওয়েবে দেওয়া'],
            'faqs' => [['Q' => 'GitHub Markdown সাপোর্ট করবে?', 'A' => 'হ্যাঁ, GFM স্পেসিফিকেশন মেনে চলে।']]
        ],
        'percentage-change-calculator' => [
            'name' => 'Percentage Increase & Decrease Calculator',
            'name_bn' => 'শতকরা বৃদ্ধি ও হ্রাস ক্যালকুলেটর',
            'category' => 'finance-tools',
            'desc_en' => 'Calculate percentage difference, increase, or decrease between two values.',
            'desc_bn' => 'দুইটি মানের মধ্যে শতকরা হার কত বাড়লো বা কমলো তা বের করুন।',
            'features' => ['পার্সেন্টেজ গ্রোথ হিসাব', 'পজিটিভ/নেগেটিভ ডিফারেন্স', 'সহজ ইনপুট'],
            'benefits' => ['ব্যবসার প্রবৃদ্ধি পরিমাপ করা'],
            'faqs' => [['Q' => 'নেগেটিভ পার্সেন্টেজ কি লস নির্দেশ করে?', 'A' => 'হ্যাঁ, মান কমলে শতকরা হ্রাস দেখায়।']]
        ],
        'discount-savings-calculator' => [
            'name' => 'Shopping Discount & Savings Calculator',
            'name_bn' => 'ডিসকাউন্ট ও সাশ্রয় ক্যালকুলেটর',
            'category' => 'finance-tools',
            'desc_en' => 'Calculate final discounted price and net savings amount from percentage offers.',
            'desc_bn' => 'কেনাকাটায় ছাড়ের পর আসল দাম কত হবে এবং কত টাকা বাঁচলো হিসাব করুন।',
            'features' => ['অরিজিনাল প্রাইজ ও ডিসকাউন্ট %', 'নিট দাম ও সেভিংস', 'ট্যাক্স ইনক্লুশন'],
            'benefits' => ['কেনাকাটায় সঠিক দাম বের করা'],
            'faqs' => [['Q' => 'অতিরিক্ত ট্যাক্স যোগ করা যাবে?', 'A' => 'হ্যাঁ, সেলস ট্যাক্স অপশন আছে।']]
        ],
        'profit-margin-calculator' => [
            'name' => 'Business Profit Margin Calculator',
            'name_bn' => 'লাভের হার বা প্রফিট মার্জিন ক্যালকুলেটর',
            'category' => 'finance-tools',
            'desc_en' => 'Calculate gross margin percentage, net profit, and markup price for products.',
            'desc_bn' => 'পণ্য বিক্রি করে শতকরা কত লাভ হলো এবং মার্জিন কত তা নির্ণয় করুন।',
            'features' => ['কস্ট প্রাইজ ও সেলিং প্রাইজ', 'মার্জিন % ও মার্কআপ %', 'গ্রস প্রফিট'],
            'benefits' => ['পণ্যের সঠিক দাম নির্ধারণ করা'],
            'faqs' => [['Q' => 'মার্জিন ও মার্কআপের তফাৎ কি?', 'A' => 'মার্জিন হিসাব হয় বিক্রয়মূল্যের ওপর, আর মার্কআপ কেনামূল্যের ওপর।']]
        ],
        'loan-interest-calculator-pro' => [
            'name' => 'Simple & Compound Interest Calculator',
            'name_bn' => 'সরল ও চক্রবৃদ্ধি সুদ ক্যালকুলেটর',
            'category' => 'finance-tools',
            'desc_en' => 'Calculate simple interest and compound interest accumulated over time.',
            'desc_bn' => 'টাকা ব্যাংকে বা লোনে রাখলে চক্রবৃদ্ধি বা সরল সুদে কত টাকা দাঁড়াবে হিসাব করুন।',
            'features' => ['Simple vs Compound Mode', 'কম্পাউন্ডিং ফ্রিকোয়েন্সি', 'টোটাল অ্যামাউন্ট'],
            'benefits' => ['দীর্ঘমেয়াদী সঞ্চয়ের হিসাব করা'],
            'faqs' => [['Q' => 'চক্রবৃদ্ধি সুদ কি?', 'A' => 'সুদের ওপর সুদ যোগ হয়ে লাভ বাড়ার পদ্ধতি।']]
        ],
        'age-calculator-bangla' => [
            'name' => 'Exact Age Calculator (Years, Months, Days)',
            'name_bn' => 'বয়স ক্যালকুলেটর - সঠিক বয়স নির্ণয়',
            'category' => 'utility-tools',
            'desc_en' => 'Calculate exact age in years, months, weeks, days, hours, and minutes from birthdate.',
            'desc_bn' => 'জন্মতারিখ দিয়ে নিখুঁত বছর, মাস, দিন, ঘণ্টা ও মিনিট হিসাব করুন।',
            'features' => ['বছর, মাস, দিন, ঘণ্টা ব্রেকডাউন', 'পরবর্তী জন্মদিনের কাউন্টডাউন', 'বাংলা ক্যালেন্ডার ম্যাচ'],
            'benefits' => ['সরকারি চাকরির আবেদনের বয়স বের করা'],
            'faqs' => [['Q' => 'পরবর্তী জন্মদিন কতদিন পর দেখাবে?', 'A' => 'হ্যাঁ, কতদিন কত ঘণ্টা বাকি তা দেখাবে।']]
        ],
        'bmi-health-calculator-bn' => [
            'name' => 'Body Mass Index (BMI) Health Calculator',
            'name_bn' => 'বিএমআই (BMI) স্বাস্থ্য ক্যালকুলেটর',
            'category' => 'health-tools',
            'desc_en' => 'Calculate Body Mass Index (BMI) and check ideal body weight status according to WHO standards.',
            'desc_bn' => 'উচ্চতা ও ওজন দিয়ে আপনার স্বাস্থ্য স্বাভাবিক কিনা এবং বিএমআই কত তা জানুন।',
            'features' => ['ডব্লিউএইচও স্ট্যান্ডার্ড চার্ট', 'আদর্শ ওজন রিকমেন্ডেশন', 'সহজ ইউনিট কেজি/ফিট'],
            'benefits' => ['স্বাস্থ্যের ফিটনেস ট্রাক রাখা'],
            'faqs' => [['Q' => 'স্বাভাবিক বিএমআই কত হওয়া উচিত?', 'A' => '১৮.৫ থেকে ২৪.৯ হলো স্বাভাবিক বিএমআই।']]
        ],
        'calorie-intake-calculator-bn' => [
            'name' => 'Daily Calorie Intake Calculator',
            'name_bn' => 'দৈনিক ক্যালরি চাহিদা ক্যালকুলেটর',
            'category' => 'health-tools',
            'desc_en' => 'Calculate daily BMR and total daily energy expenditure (TDEE) needed to gain or lose weight.',
            'desc_bn' => 'ওজন কমাতে বা বাড়াতে দৈনিক কত ক্যালরি খাবার খাওয়া দরকার তা হিসাব করুন।',
            'features' => ['BMR & TDEE ক্যালকুলেশন', 'ওয়েট লস/গেইন গোল', 'এক্টিভিটি লেভেল'],
            'benefits' => ['সঠিক ডায়েট চার্ট তৈরি করা'],
            'faqs' => [['Q' => 'BMR কি?', 'A' => 'শারীরিক নিষ্ক্রিয় অবস্থায় শরীর চালাতে যে সর্বনিম্ন শক্তি লাগে।']]
        ],
        'water-intake-calculator-bn' => [
            'name' => 'Daily Water Intake Goal Calculator',
            'name_bn' => 'দৈনিক পানি পানের পরিমাণ ক্যালকুলেটর',
            'category' => 'health-tools',
            'desc_en' => 'Calculate recommended daily water consumption in liters based on body weight and activity.',
            'desc_bn' => 'আপনার শরীরের ওজন ও কাজের ধরন অনুযায়ী প্রতিদিন কত লিটার পানি খাওয়া উচিত জানুন।',
            'features' => ['ওজন ও আবহাওয়া সমন্বয়', 'গ্লাস ও লিটার গণনা', 'স্বাস্থ্য টিপস'],
            'benefits' => ['ডিহাইড্রেশন প্রতিরোধ করা'],
            'faqs' => [['Q' => 'একজন মানুষের গড়ে কত লিটার পানি লাগে?', 'A' => 'সাধারণত ২.৫ থেকে ৩.৫ লিটার।']]
        ],
        'word-counter-bangla-english' => [
            'name' => 'Live Word & Character Counter (Bangla & EN)',
            'name_bn' => 'ওয়ার্ড ও ক্যারেক্টার কাউন্টার (বাংলা ও ইংরেজি)',
            'category' => 'text-tools',
            'desc_en' => 'Count words, characters, sentences, paragraphs, and reading time in real-time.',
            'desc_bn' => 'বাংলা ও ইংরেজি টেক্সটের শব্দসংখ্যা, অক্ষর, প্যারাগ্রাফ ও পড়ার সময় পরিমাপ করুন।',
            'features' => ['লাইভ টাইপিং কাউন্ট', 'পড়ার সময় অনুমান', 'স্পেস সহ/ছাড়া ক্যারেক্টার'],
            'benefits' => ['আর্টিকেল ও অ্যাসাইনমেন্টের শব্দসীমা ঠিক রাখা'],
            'faqs' => [['Q' => 'বাংলা যুক্তবর্ণ কি সঠিক গণে?', 'A' => 'হ্যাঁ, ইউনিকোড ক্যারেক্টার নিখুঁতভাবে গণনা করে।']]
        ],
        'case-converter-upper-lower' => [
            'name' => 'Text Case Converter (UPPER, lower, Title, Sentence)',
            'name_bn' => 'টেক্সট কেস কনভার্টার (বড় হাত, ছোট হাত)',
            'category' => 'text-tools',
            'desc_en' => 'Convert text case into UPPERCASE, lowercase, Title Case, Sentence case, and Capitalized Words.',
            'desc_bn' => 'লেখাগুলোকে এক ক্লিকে ক্যাপিটাল লেটার, স্মল লেটার বা টাইটেল কেসে পরিবর্তন করুন।',
            'features' => ['UPPERCASE, lowercase, Title Case', 'Sentence Case Correction', 'ইনস্ট্যান্ট কপি'],
            'benefits' => ['টাইপিং ভুল ঠিক করা'],
            'faqs' => [['Q' => 'ক্যাপস লক ভুলে চাপলে সোজা করা যাবে?', 'A' => 'হ্যাঁ, এক ক্লিকে স্মল লেটার করা যাবে।']]
        ],
        'duplicate-line-remover' => [
            'name' => 'Duplicate Line Remover Tool',
            'name_bn' => 'ডুপ্লিকেট লাইন রিমুভার - একই লাইন বাদ দিন',
            'category' => 'text-tools',
            'desc_en' => 'Remove duplicate lines from text lists while preserving case sensitivity and order.',
            'desc_bn' => 'আপনার তালিকা বা টেক্সট থেকে বারবার আসা লাইনগুলো এক ক্লিকে মুছে ফেলুন।',
            'features' => ['কেস সেনসিটিভ অপশন', 'এম্পটি লাইন ক্লিনিং', 'ইনস্ট্যান্ট ফিল্টার'],
            'benefits' => ['ইমেইল বা ডেটা লিস্ট ক্লিন করা'],
            'faqs' => [['Q' => 'লাইনগুলোর অর্ডার ঠিক থাকবে?', 'A' => 'হ্যাঁ, প্রথম লাইনের ক্রমানুসারে থাকে।']]
        ],
        'text-alphabetizer-sorter' => [
            'name' => 'Text & List Alphabetizer Sorter',
            'name_bn' => 'টেক্সট ও লিস্ট আলফাবেটাইজার - ক্রমানুসারে সাজানো',
            'category' => 'text-tools',
            'desc_en' => 'Sort text lists alphabetically (A-Z, Z-A) or numerically in ascending/descending order.',
            'desc_bn' => 'যেকোনো তালিকাকে বর্ণানুক্রমিক (A-Z) বা সংখ্যা অনুযায়ী ক্রমানুসারে সাজান।',
            'features' => ['A-Z ও Z-A সোর্টিং', 'সংখ্যা অনুযায়ী সোর্ট', 'রিভার্স অর্ডার'],
            'benefits' => ['ইন্ডেক্স ও নামের তালিকা গুছানো'],
            'faqs' => [['Q' => 'বাংলা নাম কি অ-অঁ অনুযায়ী সাজায়?', 'A' => 'হ্যাঁ, ইউনিকোড বর্ণমালা অনুযায়ী সাজায়।']]
        ],
        'lorem-ipsum-generator-bn' => [
            'name' => 'Lorem Ipsum Placeholder Text Generator',
            'name_bn' => 'লরেম ইপসাম ডামি টেক্সট জেনারেটর',
            'category' => 'text-tools',
            'desc_en' => 'Generate custom paragraphs, words, or lists of dummy Lorem Ipsum text for web mockups.',
            'desc_bn' => 'ডিজাইন ও ওয়েব লেআউটের জন্য লরেম ইপসাম ডামি টেক্সট তৈরি করুন।',
            'features' => ['প্যারাগ্রাফ ও ওয়ার্ড কাউন্ট', 'HTML p ট্যাগ অপশন', 'সহজ কপি'],
            'benefits' => ['ওয়েবসাইট প্রোটোটাইপিং সহজ করা'],
            'faqs' => [['Q' => 'লরেম ইপসাম কেন ব্যবহার করা হয়?', 'A' => 'ডিজাইনের ভিজ্যুয়াল লেআউট পরীক্ষা করার জন্য।']]
        ],
        'hash-generator-sha256-md5' => [
            'name' => 'MD5, SHA-1, SHA-256 Hash Generator',
            'name_bn' => 'এমডি৫ ও এসএইচএ২৫৬ হ্যাশ জেনারেটর',
            'category' => 'security-tools',
            'desc_en' => 'Generate cryptographic MD5, SHA-1, SHA-256, and SHA-512 hashes from input strings.',
            'desc_bn' => 'টেক্সটের জন্য ক্রিপ্টোগ্রাফিক এমডি৫ ও এসএইচএ-২৫৬ হ্যাশ কোড তৈরি করুন।',
            'features' => ['MD5, SHA1, SHA256, SHA512', 'ওয়ান ওয়ে এনক্রিপশন', 'ইনস্ট্যান্ট হ্যাশ'],
            'benefits' => ['ডাটা ভ্যালিডেশন ও সিকিউরিটি চেক'],
            'faqs' => [['Q' => 'হ্যারা কি আবার আগের লেখায় নেওয়া যায়?', 'A' => 'না, হ্যাশ হলো ওয়ান-ওয়ে সিকিউরিটি অ্যালগরিদম।']]
        ],
        'random-password-generator-pro' => [
            'name' => 'Strong Random Password Generator Pro',
            'name_bn' => 'স্ট্রং পাসওয়ার্ড জেনারেটর',
            'category' => 'security-tools',
            'desc_en' => 'Generate ultra-secure random passwords with symbols, numbers, and custom lengths.',
            'desc_bn' => 'হ্যাকিং থেকে বাঁচতে অত্যন্ত শক্তিশালী ও জটিল পাসওয়ার্ড তৈরি করুন।',
            'features' => ['দৈর্ঘ্য ৮ থেকে ৬৪ ক্যারেক্টার', 'স্পেশাল সিম্বল ও নম্বর', 'সিকিউরিটি মিটার'],
            'benefits' => ['অ্যাকাউন্ট হ্যাক প্রতিরোধ করা'],
            'faqs' => [['Q' => 'পাসওয়ার্ড কি সার্ভারে সেভ হয়?', 'A' => 'না, ব্রাউজারে তৈরি হয় এবং কোথাও জমা হয় না।']]
        ],
        'base64-encode-decode-pro' => [
            'name' => 'Base64 Encoder & Decoder Pro',
            'name_bn' => 'বেস৬৪ এনকোডার ও ডিকোডার',
            'category' => 'security-tools',
            'desc_en' => 'Encode plain text strings into Base64 format or decode Base64 back to original text.',
            'desc_bn' => 'টেক্সটকে বেস৬৪ কোডে এনকোড করুন অথবা বেস৬৪ কোড থেকে মূল টেক্সটে ফেরান।',
            'features' => ['ইউনিকোড UTF-8 সাপোর্ট', 'ইনস্ট্যান্ট এনকোড/ডিকোড', 'ক্লিন আউটপুট'],
            'benefits' => ['ডাটা ট্রান্সমিশন নিরাপদ করা'],
            'faqs' => [['Q' => 'বাংলা লেখা কি এনকোড হবে?', 'A' => 'হ্যাঁ, UTF-8 ইউনিকোড সাপোর্ট করে।']]
        ],
        'uuid-v4-generator-online' => [
            'name' => 'UUID / GUID v4 Generator Online',
            'name_bn' => 'ইউইউআইডি (UUID v4) জেনারেটর',
            'category' => 'developer-tools',
            'desc_en' => 'Generate universally unique identifiers (UUID v4) for databases and software keys.',
            'desc_bn' => 'ডাটাবেজ ও এপিআই ট্র্যাকিংয়ের জন্য ইউনিক ইউইউআইডি (UUID v4) কোড জেনারেট করুন।',
            'features' => ['RFC4122 v4 কমপ্লায়েন্ট', 'ব্যাচ জেনারেট (১-৫০)', 'ক্লিন ফরম্যাট'],
            'benefits' => ['ডাটাবেজে প্রাইমারি কি সলিড রাখা'],
            'faqs' => [['Q' => 'UUID কি রিপিট হতে পারে?', 'A' => 'UUID রিপিট হওয়ার সম্ভাবনা প্রায় অসম্ভব।']]
        ],
        'youtube-thumbnail-downloader-hd' => [
            'name' => 'YouTube HD Thumbnail Downloader',
            'name_bn' => 'ইউটিউব থাম্বনেল ডাউনলোডার (HD/4K)',
            'category' => 'social-tools',
            'desc_en' => 'Download high-resolution HD, 1080p, and 4K thumbnail images from any YouTube video URL.',
            'desc_bn' => 'যেকোনো ইউটিউব ভিডিওর লিংক দিয়ে ফুল এইচডি থাম্বনেল ডাউনলোড করুন।',
            'features' => ['HD (1080p), SD, HQ অপশন', 'ওয়ান ক্লিক ছবি সেভ', 'দ্রুত প্রসেস'],
            'benefits' => ['ডিজাইন আইডিয়া নেওয়া ও কন্টেন্ট রিপ্রসেস করা'],
            'faqs' => [['Q' => 'এটি কি ফ্রি?', 'A' => 'হ্যাঁ, সম্পূর্ণ ফ্রি ও ওয়াটারমার্ক ছাড়া।']]
        ],
        'youtube-tag-extractor-pro' => [
            'name' => 'YouTube Video Tag Extractor & Inspector',
            'name_bn' => 'ইউটিউব ভিডিও ট্যাগ এক্সট্রাক্টর',
            'category' => 'seo-tools',
            'desc_en' => 'Extract SEO keywords and ranking tags used in any YouTube video.',
            'desc_bn' => 'অন্যান্য ভাইরাল ইউটিউব ভিডিওতে ব্যবহৃত কি-ওয়ার্ড ও ট্যাগগুলো বের করুন।',
            'features' => ['ট্যাগ লিস্ট উইথ কপি', 'এসইও কি-ওয়ার্ড ইনসাইট', 'ফাস্ট ক্যাচ'],
            'benefits' => ['নিজের ভিডিওর এসইও বৃদ্ধি করা'],
            'faqs' => [['Q' => 'ট্যাগগুলো কি কপি করা যাবে?', 'A' => 'হ্যাঁ, কমা সেপারেটেড হিসেবে কপি করা যায়।']]
        ],
        'tik-tok-caption-hashtags' => [
            'name' => 'Viral TikTok Caption & Hashtag Generator',
            'name_bn' => 'টিকটক ক্যাপশন ও হ্যাশট্যাগ জেনারেটর',
            'category' => 'social-tools',
            'desc_en' => 'Generate high-engagement viral TikTok video captions and trending hashtags.',
            'desc_bn' => 'টিকটক ভিডিও ভাইরাল করার জন্য ট্রেন্ডিং ক্যাপশন ও হ্যাশট্যাগ তৈরি করুন।',
            'features' => ['ট্রেন্ডিং হ্যাশট্যাগ প্যাক', 'ক্যাচি ক্যাপশন আইডিয়া', 'ইমোজি এনহ্যান্সড'],
            'benefits' => ['ভিডিও ফর-ইউ পেজে যাওয়ার সুযোগ বৃদ্ধি'],
            'faqs' => [['Q' => 'হ্যাশট্যাগ কয়টি দেব?', 'A' => 'সাধারণত ৩ থেকে ৫টি প্রাসঙ্গিক হ্যাশট্যাগ ভালো।']]
        ],
        'instagram-caption-generator-bn' => [
            'name' => 'Instagram Post Caption & Bio Generator',
            'name_bn' => 'ইনস্টাগ্রাম ক্যাপশন ও বায়ো মেকার',
            'category' => 'social-tools',
            'desc_en' => 'Create aesthetic Instagram captions, bios, and font styles for higher likes and followers.',
            'desc_bn' => 'ইনস্টাগ্রাম পোস্টের জন্য চমৎকার সুন্দর ক্যাপশন ও বায়ো সাজেশন পান।',
            'features' => ['এস্টেটিক ফন্ট ও স্টাইল', 'হ্যাশট্যাগ ইন্টিগ্রেশন', 'বাংলা ও ইংরেজি ক্যাপশন'],
            'benefits' => ['প্রোফাইল ফলোয়ার বৃদ্ধি করা'],
            'faqs' => [['Q' => 'বায়ো ফন্ট কি ইনস্টাগ্রামে দেখাবে?', 'A' => 'হ্যাঁ, ইউনিকোড ফন্ট হুবহু সাপোর্ট করে।']]
        ],
        'whois-domain-lookup-pro' => [
            'name' => 'Domain WHOIS Record Inspector',
            'name_bn' => 'ডোমেইন হু-ইজ (WHOIS) রেকর্ড ইন্সপেক্টর',
            'category' => 'network-tools',
            'desc_en' => 'Check WHOIS registration info, registrar name, creation date, and expiration date of domains.',
            'desc_bn' => 'যেকোনো ডোমেইনের মালিকানা তথ্য, রেজিস্টার কোম্পানি ও মেয়াদ শেষ হওয়ার তারিখ দেখুন।',
            'features' => ['রেজিস্ট্রার ইনফো', 'ক্রিয়েশন ও এক্সপায়ারি ডেট', 'নেমসার্ভার তথ্য'],
            'benefits' => ['ডোমেইন কেনাবেচায় সঠিক তথ্য জানা'],
            'faqs' => [['Q' => 'গোপন হু-ইজ দেখা যায়?', 'A' => 'প্রাইভেসি প্রোটেকশন থাকলে প্রাইভেসি সার্ভিস দেখাবে।']]
        ],
        'dns-record-checker-pro' => [
            'name' => 'DNS Record Lookup (A, MX, CNAME, TXT)',
            'name_bn' => 'ডিএনএস (DNS) রেকর্ড লুকআপ টুল',
            'category' => 'network-tools',
            'desc_en' => 'Inspect domain DNS records including A, AAAA, MX, CNAME, TXT, and NS records.',
            'desc_bn' => 'ডোমেইনের আইপি (A Record), ইমেইল সার্ভার (MX Record) ও টিএক্সটি রেকর্ড পরীক্ষা করুন।',
            'features' => ['A, MX, CNAME, TXT, NS', 'সার্ভার রেসপন্স টাইম', 'গ্লোবাল ডিএনএস ক্যানভাস'],
            'benefits' => ['ইমেইল ও ওয়েব সার্ভার ইস্যু সমাধান'],
            'faqs' => [['Q' => 'এমএক্স রেকর্ড কিসের জন্য?', 'A' => 'ইমেইল সার্ভিস ঠিকমতো আদান-প্রদানের জন্য।']]
        ],
        'my-ip-address-location' => [
            'name' => 'My IP Address & Location Inspector',
            'name_bn' => 'আমার আইপি ঠিকানা ও লোকেশন টুল',
            'category' => 'network-tools',
            'desc_en' => 'Detect your public IP address (IPv4/IPv6), ISP provider, city, and country origin.',
            'desc_bn' => 'আপনার বর্তমান পাবলিক আইপি এড্রেস, ইন্টারনেট প্রোভাইডার ও লোকেশন জানুন।',
            'features' => ['IPv4 & IPv6 ডিটেকশন', 'আইএসপি প্রোভাইডার', 'লোকেশন ম্যাপ তথ্য'],
            'benefits' => ['ভিপিএন ও সিকিউরিটি চেক করা'],
            'faqs' => [['Q' => 'আমার আইপি কি গোপন?', 'A' => 'আপনার এই টুলসে দেখানো আইপি আপনার ইন্টারনেটের পাবলিক আইপি।']]
        ],
        'bangla-date-converter-today' => [
            'name' => 'English to Bangla Date Converter',
            'name_bn' => 'ইংরেজি থেকে বাংলা তারিখ রূপান্তরক',
            'category' => 'utility-tools',
            'desc_en' => 'Convert English Gregorian dates to official Bengali Calendar dates (Bangla San & Season).',
            'desc_bn' => 'ইংরেজি তারিখ থেকে সঠিক বঙ্গাব্দ বাংলা সন, মাস, দিন ও ঋতু বের করুন।',
            'features' => ['বাংলা সন ও মাস', 'ঋতু পরিচয়', 'আজকের বাংলা তারিখ'],
            'benefits' => ['সরকারি ও সামাজিক কাজে বাংলা তারিখ জানা'],
            'faqs' => [['Q' => 'পহেলা বৈশাখ কবে নির্ধারণ হয়?', 'A' => 'সাধারণত ইংরেজি ১৪ এপ্রিলে।']]
        ],
        'bangla-number-to-word-converter' => [
            'name' => 'Bangla Number to Word Converter (টাকা কথায়)',
            'name_bn' => 'সংখ্যা থেকে বাংলা কথায় প্রকাশ (টাকা কথায়)',
            'category' => 'utility-tools',
            'desc_en' => 'Convert numerical amounts into Bengali written words (e.g., 1250 -> এক হাজার দুইশত ৫০ টাকা).',
            'desc_bn' => 'টাকার পরিমাণ বা সংখ্যাকে বাংলায় কথায় লিখুন (যেমন: ব্যাংক চেক ও রসিদের জন্য)।',
            'features' => ['লাখ, কোটি হিসাব সাপোর্ট', 'ব্যাংক চেক ফরম্যাট', 'নিখুঁত উচ্চারণ'],
            'benefits' => ['ব্যাংক চেকে বানান ভুল এড়ানো'],
            'faqs' => [['Q' => 'কত কোটি পর্যন্ত সাপোর্ট করে?', 'A' => 'যেকোনো বড় অংকের কোটি পর্যন্ত হিসাব করে।']]
        ],
        'bangla-typo-checker-pro' => [
            'name' => 'Bangla Spelling & Typo Helper',
            'name_bn' => 'বাংলা বানান ও যুক্তবর্ণ সহায়িকা',
            'category' => 'text-tools',
            'desc_en' => 'Check common Bengali spelling mistakes and get correct Unicode dictionary suggestions.',
            'desc_bn' => 'বাংলা লেখার সাধারণ বানান ভুল এবং সঠিক যুক্তবর্ণের নির্দেশনা পান।',
            'features' => ['প্রমিত বাংলা বানান নিয়ম', 'যুক্তবর্ণ গাইড', 'ইনস্ট্যান্ট কারেকশন'],
            'benefits' => ['শুদ্ধ বাংলায় লেখার দক্ষতা অর্জন'],
            'faqs' => [['Q' => 'বাংলা একাডেমি নিয়ম কি অনুসরণ করা হয়?', 'A' => 'হ্যাঁ, প্রমিত বাংলা বানানের নিয়ম অনুসরণ করে।']]
        ],
        'ecommerce-profit-calculator' => [
            'name' => 'E-Commerce Order Profit Calculator',
            'name_bn' => 'ই-কমার্স অর্ডার প্রফিট ক্যালকুলেটর',
            'category' => 'finance-tools',
            'desc_en' => 'Calculate net profit per order after product cost, delivery fee, ad spend, and return charges.',
            'desc_bn' => 'অনলাইন শপ বা ই-কমার্সে প্রোডাক্টের কেনাদাম, ডেলিভারি চার্জ ও অ্যাড খরচ বাদ দিয়ে নিট লাভ হিসাব করুন।',
            'features' => ['প্রোডাক্ট কস্ট ও অ্যাড স্পেন্ড', 'ডেলিভারি চার্জ ও রিটার্ন রেশিও', 'নিট প্রফিট মার্জিন'],
            'benefits' => ['অনলাইন ব্যবসার আসল লাভ বের করা'],
            'faqs' => [['Q' => 'রিটার্ন চার্জ হিসাব করা যায়?', 'A' => 'হ্যাঁ, আনুমানিক রিটার্ন পার্সেন্টেজ দিয়ে লস হিসাব করা যায়।']]
        ],
        'crypto-roi-calculator-pro' => [
            'name' => 'Cryptocurrency Investment ROI Calculator',
            'name_bn' => 'ক্রিপ্টো ও ইনভেস্টমেন্ট আরওআই (ROI) ক্যালকুলেটর',
            'category' => 'finance-tools',
            'desc_en' => 'Calculate Return on Investment (ROI) percentage and net profit for crypto or stock assets.',
            'desc_bn' => 'ক্রিপ্টো বা শেয়ারে বিনিয়োগে কত পার্সেন্ট লাভ বা আরওআই (ROI) হলো হিসাব করুন।',
            'features' => ['বাই প্রাইজ ও সেল প্রাইজ', 'নেট প্রফিট & ROI %', 'ফি কাস্টমাইজেশন'],
            'benefits' => ['বিনিয়োগের লাভজনকতা বিচার করা'],
            'faqs' => [['Q' => 'ROI এর পূর্ণরূপ কি?', 'A' => 'Return on Investment (বিনিয়োগের ওপর আয়)।']]
        ],


        'bangla-font-generator-cyber' => [
            'name' => 'Bangla Stylist Font & Text Decorator',
            'name_bn' => 'বাংলা স্টাইলিশ ফন্ট জেনারেটর',
            'category' => 'text-tools',
            'desc_en' => 'Generate fancy Bengali stylized text and decorative symbols for social media bios.',
            'desc_bn' => 'সোশ্যাল মিডিয়া বায়ো ও ক্যাপশনের জন্য স্টাইলিশ বাংলা লেখা তৈরি করুন।',
            'features' => ['ইউনিকোড স্টাইলিশ ফন্ট', 'আকর্ষণীয় ডেকোরেশন', 'ওয়ান ক্লিক কপি'],
            'benefits' => ['সোশ্যাল মিডিয়া প্রোফাইল নজরকাড়া করা'],
            'faqs' => [['Q' => 'ফন্ট কি সোশ্যাল মিডিয়ায় কাজ করবে?', 'A' => 'হ্যাঁ, ফেসবুক ও ইনস্টাগ্রামে সাপোর্ট করবে।']]
        ],
        'website-speed-test-info' => [
            'name' => 'Website PageSpeed & Performance Inspector',
            'name_bn' => 'ওয়েবসাইট স্পিড ও পারফরম্যান্স টেস্ট',
            'category' => 'webmaster-tools',
            'desc_en' => 'Analyze website loading speed, Core Web Vitals, and TTFB server response times.',
            'desc_bn' => 'আপনার ওয়েবসাইটের লোডিং স্পিড ও কোর ওয়েব ভাইটালস পারফরম্যান্স যাচাই করুন।',
            'features' => ['Core Web Vitals বিশ্লেষণ', 'TTFB সার্ভার চেক', 'স্পিড গাইডলাইন'],
            'benefits' => ['গুগল র‍্যাংকিং উন্নত করা'],
            'faqs' => [['Q' => 'স্পিড কত হওয়া উচিত?', 'A' => '২ সেকেন্ডের নিচে পেজ লোড হওয়া আদর্শ।']]
        ],
        'ad-block-detector-test' => [
            'name' => 'AdBlocker Detection & Tester Tool',
            'name_bn' => 'অ্যাডব্লকার ডিটেক্টর ও টেস্ট টুল',
            'category' => 'developer-tools',
            'desc_en' => 'Test whether your web browser is actively blocking Google AdSense or banner scripts.',
            'desc_bn' => 'আপনার ব্রাউজারে কোনো অ্যাডব্লকার বা ব্যানার ব্লক স্ক্রিপ্ট চালু আছে কিনা টেস্ট করুন।',
            'features' => ['লাইব অ্যাডব্লক ডিটেকশন', 'অ্যাড রেসপন্স ভ্যালিডেশন', 'সার্ভার স্টেট'],
            'benefits' => ['অ্যাডসেন্স রেভিনিউ প্রটেক্ট করা'],
            'faqs' => [['Q' => 'অ্যাডব্লকার চালু থাকলে কি করবেন?', 'A' => 'টুলসের সুবিধা নিতে অ্যাডব্লকার বন্ধ করতে পারেন।']]
        ],
        'loan-eligibility-calculator-bn' => [
            'name' => 'Bank Loan Eligibility & FOIR Calculator',
            'name_bn' => 'ব্যাংক লোন এলিজিবিলিটি ক্যালকুলেটর',
            'category' => 'finance-tools',
            'desc_en' => 'Calculate maximum bank loan eligibility based on monthly income and existing obligation ratio (FOIR).',
            'desc_bn' => 'আপনার মাসিক আয় ও খরচের ভিত্তিতে ব্যাংক থেকে কত টাকা লোন পেতে পারেন হিসাব করুন।',
            'features' => ['FOIR রেশিও হিসাব', 'ম্যাক্সিমাম লোন অ্যামাউন্ট', 'ইএমআই ক্যাপ'],
            'benefits' => ['লোন আবেদনের আগে পূর্বাভাস পাওয়া'],
            'faqs' => [['Q' => 'FOIR কি?', 'A' => 'Fixed Obligation to Income Ratio বা আয়ের কত শতাংশ কিস্তিতে যায়।']]
        ],
        'carbon-footprint-calculator-bn' => [
            'name' => 'Personal Carbon Footprint Calculator',
            'name_bn' => 'কার্বন ফুটপ্রিন্ট পরিবেশ ক্যালকুলেটর',
            'category' => 'utility-tools',
            'desc_en' => 'Estimate your annual personal carbon dioxide (CO2) emissions from travel and electricity usage.',
            'desc_bn' => 'আপনার দৈনিক যাতায়াত ও বিদ্যুৎ ব্যবহারের ফলে বছরে কত কার্বন নির্গমন হয় হিসাব করুন।',
            'features' => ['CO2 নির্গমন টন হিসাব', 'পরিবেশ টিপস', 'ইকো ফ্রেন্ডলি গাইড'],
            'benefits' => ['পরিবেশ সচেতনতা বৃদ্ধি'],
            'faqs' => [['Q' => 'কার্বন ফুটপ্রিন্ট কিভাবে কমাবো?', 'A' => 'বিদ্যুৎ সাশ্রয় ও গণপরিবহন ব্যবহার করে।']]
        ]

];
}
