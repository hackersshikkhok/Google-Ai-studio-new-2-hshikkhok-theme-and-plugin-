<?php
/**
 * IBD Cyber Community Q&A - Enterprise 7.0 Isolated Solution & Engine
 * Path: inc/ilybd-qna-engine-v7.php
 * Fully decoupled from standard WordPress comment templates, offering premium 2040 cyber bento layout,
 * custom ajax submission, voting decks, accepted solutions, structured QAPage schema, and anti-spam measures.
 */

if (!defined('ABSPATH')) exit;

/**
 * 1. Output the Isolated Q&A Discussion Board
 */
function ilybd_render_qna_discussion_board() {
    $post_id = get_the_ID();
    $current_user_id = get_current_user_id();
    $current_user = wp_get_current_user();
    
    // Fetch Answers (parent comments, depth = 1)
    $answers = get_comments(array(
        'post_id' => $post_id,
        'parent'  => 0,
        'status'  => 'approve',
        'order'   => 'ASC' // we will sort them in PHP to pin verified solution
    ));
    
    $accepted_answer_id = intval(get_post_meta($post_id, 'accepted_answer_id', true));
    
    // Custom sort: verified solution goes first, then sort by votes desc, then date asc
    usort($answers, function($a, $b) use ($accepted_answer_id) {
        $a_is_sol = ($a->comment_ID == $accepted_answer_id);
        $b_is_sol = ($b->comment_ID == $accepted_answer_id);
        
        if ($a_is_sol) return -1;
        if ($b_is_sol) return 1;
        
        $a_votes = intval(get_comment_meta($a->comment_ID, '_comment_votes', true) ?: 0);
        $b_votes = intval(get_comment_meta($b->comment_ID, '_comment_votes', true) ?: 0);
        
        if ($a_votes != $b_votes) {
            return $b_votes - $a_votes; // higher votes first
        }
        
        return strtotime($a->comment_date) - strtotime($b->comment_date); // older first
    });
    
    $answers_count = count($answers);
    
    // Render dynamic schema JSON-LD
    ?>
    <div id="ilybd-qna-isolated-engine" class="ilybd-qna-isolated-engine-container" style="margin-top: 40px; text-align: left; font-family: 'Space Grotesk', system-ui, -apple-system, sans-serif;">
        
        <!-- Header Section -->
        <div class="qna-v7-header" style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 30px; border-bottom: 2px solid rgba(0, 240, 255, 0.15); padding-bottom: 12px; flex-wrap: wrap; gap: 15px;">
            <h3 class="qna-v7-title" style="color: #fff; font-size: clamp(16px, 4vw, 19px); margin: 0; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; display: flex; align-items: center; gap: 10px;">
                <span style="background: rgba(0, 240, 255, 0.1); color: #00f0ff; border: 1.2px solid #00f0ff; padding: 2px 10px; border-radius: 20px; font-size: 12px; font-weight: bold; box-shadow: 0 0 10px rgba(0,240,255,0.15); font-family: monospace;">
                    <i class="fa-solid fa-graduation-cap"></i> KNOWLEDGE HUB
                </span>
                <?php echo $answers_count; ?> টি সমাধান ও প্রযুক্তি বিশ্লেষণ
            </h3>
            
            <div class="qna-v7-sort-info" style="font-size: 12px; color: #8b949e; display: flex; align-items: center; gap: 6px; font-family: monospace;">
                <i class="fa-solid fa-arrow-down-wide-narrow" style="color: #00ff41;"></i> Pinned Verified & Highest Voted
            </div>
        </div>

        <!-- Answers List Container -->
        <div class="qna-v7-answers-list" style="display: flex; flex-direction: column; gap: 24px; margin-bottom: 40px;">
            <?php if (empty($answers)) : ?>
                <div class="qna-v7-empty-state" style="background: #0d1527; border: 1.5px dashed rgba(255,255,255,0.06); border-radius: 12px; padding: 40px 20px; text-align: center; color: #8b949e;">
                    <i class="fa-regular fa-comment-dots" style="font-size: 32px; color: #00f0ff; margin-bottom: 12px; display: block;"></i>
                    <p style="margin: 0; font-size: 14.5px; font-weight: 500;">এখনো কোনো সমাধান বা উত্তর সাবমিট করা হয়নি।</p>
                    <p style="margin: 5px 0 0 0; font-size: 12.5px; color: #57606a;">প্রথম সঠিক সমাধান সাবমিট করে ৫০ XP এবং ৳২.০০ বোনাস লাভ করুন!</p>
                </div>
            <?php else : ?>
                <?php 
                foreach ($answers as $answer) : 
                    $comment_id = $answer->comment_ID;
                    $is_solution = ($comment_id == $accepted_answer_id);
                    $comment_votes = intval(get_comment_meta($comment_id, '_comment_votes', true) ?: 0);
                    $is_ai = get_comment_meta($comment_id, '_is_ai_moderator_comment', true);
                    
                    $post_author_id = get_post_field('post_author', $post_id);
                    $can_accept = ($current_user_id && ($current_user_id == $post_author_id || current_user_can('manage_options')));
                    
                    // Card Border & Background styling following the 2040 dark design guidelines
                    if ($is_solution) {
                        $card_style = 'border: 2px solid #00ff41; box-shadow: 0 0 25px rgba(0, 255, 65, 0.12); background: linear-gradient(135deg, #070e0a 0%, #0d1c13 100%);';
                        $avatar_border = 'border: 2px solid #00ff41; box-shadow: 0 0 8px rgba(0,255,65,0.3);';
                    } elseif ($is_ai) {
                        $card_style = 'border: 1.5px solid rgba(0, 240, 255, 0.3); box-shadow: 0 4px 15px rgba(0, 240, 255, 0.05); background: linear-gradient(135deg, #070c14 0%, #0a1324 100%);';
                        $avatar_border = 'border: 2px solid #00f0ff; box-shadow: 0 0 8px rgba(0,240,255,0.3);';
                    } else {
                        $card_style = 'border: 1.5px solid rgba(255, 255, 255, 0.05); background: #0d1527;';
                        $avatar_border = 'border: 1.5px solid rgba(255, 255, 255, 0.15);';
                    }
                    ?>
                    <div class="qna-v7-answer-card" id="qna-answer-<?php echo $comment_id; ?>" style="border-radius: 14px; padding: 22px; position: relative; transition: all 0.25s; <?php echo esc_attr($card_style); ?>">
                        <div class="qna-v7-layout" style="display: flex; gap: 20px; align-items: flex-start; flex-wrap: wrap; sm:flex-nowrap;">
                            
                            <!-- Left: Vertical Voting Deck -->
                            <div class="qna-v7-voting-deck" style="display: flex; flex-direction: column; align-items: center; background: rgba(7, 10, 16, 0.7); border: 1.2px solid rgba(255,255,255,0.04); border-radius: 10px; padding: 10px; min-width: 52px; box-shadow: inset 0 2px 8px rgba(0,0,0,0.6); flex-shrink: 0; align-self: flex-start; margin: 0 auto sm:0;">
                                <button class="qna-v7-vote-trigger" data-comment-id="<?php echo $comment_id; ?>" data-type="up" style="background: transparent; border: none; color: #8b949e; font-size: 20px; cursor: pointer; transition: all 0.2s; outline: none; padding: 2px;" title="Upvote Solution">▲</button>
                                <span class="qna-v7-vote-count" style="font-size: 17px; font-weight: 800; color: #fff; margin: 4px 0; font-family: monospace;"><?php echo $comment_votes; ?></span>
                                <button class="qna-v7-vote-trigger" data-comment-id="<?php echo $comment_id; ?>" data-type="down" style="background: transparent; border: none; color: #8b949e; font-size: 20px; cursor: pointer; transition: all 0.2s; outline: none; padding: 2px;" title="Downvote Solution">▼</button>
                            </div>

                            <!-- Right: Content & Metadata -->
                            <div class="qna-v7-main-content" style="flex: 1; min-width: 0; text-align: left;">
                                
                                <!-- Meta bar -->
                                <div class="qna-v7-meta-bar" style="display: flex; flex-wrap: wrap; gap: 12px; align-items: center; border-bottom: 1.5px solid rgba(255,255,255,0.04); padding-bottom: 12px; margin-bottom: 15px;">
                                    <div class="avatar" style="<?php echo esc_attr($avatar_border); ?> border-radius: 50%; overflow: hidden; width: 40px; height: 40px; flex-shrink: 0; background: #070b13;">
                                        <?php echo get_avatar($answer, 40); ?>
                                    </div>
                                    
                                    <div class="info" style="display: flex; flex-direction: column; gap: 2px;">
                                        <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
                                            <b style="color: #fff; font-size: 14.5px; font-weight: 700;"><?php echo esc_html($answer->comment_author); ?></b>
                                            
                                            <!-- Specialized 2040 Badges -->
                                            <?php if ($is_solution) : ?>
                                                <span style="background: linear-gradient(135deg, #00ff41 0%, #008000 100%); color: #000; font-size: 8.5px; font-weight: 900; padding: 2px 7px; border-radius: 4px; border: 1px solid #00ff41; font-family: monospace; letter-spacing: 0.5px; box-shadow: 0 0 10px rgba(0,255,65,0.2);"><i class="fa-solid fa-circle-check"></i> VERIFIED SOLUTION</span>
                                            <?php elseif ($is_ai) : ?>
                                                <span style="background: rgba(0, 240, 255, 0.12); color: #00f0ff; font-size: 8.5px; font-weight: 900; padding: 2px 7px; border-radius: 4px; border: 1px solid rgba(0,240,255,0.25); font-family: monospace; letter-spacing: 0.5px; box-shadow: 0 0 10px rgba(0,240,255,0.15);"><i class="fa-solid fa-robot"></i> AI ASSISTANT</span>
                                            <?php elseif ($answer->user_id == $post_author_id) : ?>
                                                <span style="background: rgba(255, 174, 0, 0.12); color: #ffae00; font-size: 8.5px; font-weight: 900; padding: 2px 7px; border-radius: 4px; border: 1px solid rgba(255,174,0,0.25); font-family: monospace;"><i class="fa-solid fa-user"></i> QUESTIONER</span>
                                            <?php elseif (!empty($answer->user_id) && intval($answer->user_id) > 0 && (user_can(intval($answer->user_id), 'administrator') || user_can(intval($answer->user_id), 'editor'))) : ?>
                                                <span style="background: rgba(168, 85, 247, 0.12); color: #a855f7; font-size: 8.5px; font-weight: 900; padding: 2px 7px; border-radius: 4px; border: 1px solid rgba(168,85,247,0.25); font-family: monospace;"><i class="fa-solid fa-shield-halved"></i> EXPERT MODERATOR</span>
                                            <?php endif; ?>
                                        </div>
                                        
                                        <div style="color: #8b949e; font-size: 11.5px; display: flex; align-items: center; gap: 4px;">
                                            <i class="fa-regular fa-clock" style="font-size: 10px;"></i>
                                            <?php printf(__('%s আগে সাবমিট করা হয়েছে'), human_time_diff(strtotime($answer->comment_date), current_time('timestamp'))); ?>
                                        </div>
                                    </div>

                                    <!-- Top Right Action Panel (Solution Marker & Edit) -->
                                    <div class="qna-v7-top-right-actions" style="margin-left: auto; display: flex; gap: 8px; align-items: center;">
                                        <?php if ($can_accept) : ?>
                                            <button class="qna-v7-accept-trigger" data-comment-id="<?php echo $comment_id; ?>" style="background: <?php echo $is_solution ? '#00ff41' : 'rgba(0, 255, 65, 0.08)'; ?>; border: 1.5px solid <?php echo $is_solution ? '#00ff41' : 'rgba(0, 255, 65, 0.3)'; ?>; color: <?php echo $is_solution ? '#000' : '#00ff41'; ?>; padding: 5px 14px; border-radius: 20px; font-size: 11px; font-weight: 800; cursor: pointer; transition: all 0.25s; display: inline-flex; align-items: center; gap: 5px;">
                                                <i class="fa-solid <?php echo $is_solution ? 'fa-check-double' : 'fa-circle-check'; ?>"></i>
                                                <span><?php echo $is_solution ? 'Verified Solution' : 'Mark as Solution'; ?></span>
                                            </button>
                                        <?php elseif ($is_solution) : ?>
                                            <span style="background: rgba(0, 255, 65, 0.1); border: 1.2px solid #00ff41; color: #00ff41; padding: 4px 12px; border-radius: 20px; font-size: 10.5px; font-weight: bold; display: inline-flex; align-items: center; gap: 4.5px; box-shadow: 0 0 10px rgba(0,255,65,0.15); font-family: monospace;">
                                                <i class="fa-solid fa-circle-check"></i> VERIFIED SOLUTION
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <!-- Solution Body Content -->
                                <div class="qna-v7-body-text" style="color: #cbd5e1; font-size: 14.5px; line-height: 1.75; word-break: break-word; font-family: 'Space Grotesk', system-ui, sans-serif;">
                                    <?php 
                                    // Custom code block detection and nice visual styling
                                    $comment_text = get_comment_text($comment_id);
                                    
                                    // Render custom code snippet meta field if present
                                    $code_snippet = get_comment_meta($comment_id, '_qna_code_snippet', true);
                                    if (!empty($code_snippet)) {
                                        $comment_text .= "\n\n<div class='qna-v7-code-block-container' style='background: #070b13; border: 1.2px solid rgba(0,240,255,0.15); border-radius: 8px; margin-top: 15px; overflow: hidden; font-family: monospace; box-shadow: inset 0 2px 10px rgba(0,0,0,0.5);'>
                                            <div style='background: rgba(255,255,255,0.03); border-bottom: 1px solid rgba(255,255,255,0.05); padding: 8px 15px; display: flex; justify-content: space-between; align-items: center;'>
                                                <span style='color: #8b949e; font-size: 11.5px; font-weight: bold; text-transform: uppercase;'><i class='fa-solid fa-code' style='color:#00f0ff;'></i> CODE CONSOLE</span>
                                                <button class='copy-code-btn' onclick=\"navigator.clipboard.writeText(this.closest('.qna-v7-code-block-container').querySelector('code').innerText); this.innerHTML='<i class=\'fa-solid fa-check\'></i> Copied!'; setTimeout(()=>this.innerHTML='<i class=\'fa-solid fa-copy\'></i> Copy', 2000);\" style='background: transparent; border: none; color: #8b949e; font-size: 11px; cursor: pointer; transition: 0.2s;' onmouseover=\"this.style.color='#00f0ff';\" onmouseout=\"this.style.color='#8b949e';\"><i class='fa-regular fa-copy'></i> Copy</button>
                                            </div>
                                            <pre style='margin: 0; padding: 15px; overflow-x: auto; font-size: 13px; line-height: 1.6; color: #a5d6ff;'><code style='font-family: \"JetBrains Mono\", monospace; white-space: pre-wrap; word-break: break-all;'>" . esc_html($code_snippet) . "</code></pre>
                                        </div>";
                                    }
                                    
                                    echo wp_kses_post(wpautop($comment_text)); 
                                    ?>
                                </div>

                                <!-- Action bar & meta items -->
                                <div class="qna-v7-footer-actions" style="margin-top: 15px; border-top: 1px solid rgba(255,255,255,0.04); padding-top: 12px; display: flex; gap: 18px; align-items: center; flex-wrap: wrap; font-size: 12px;">
                                    <?php $likes = get_comment_meta($comment_id, '_comment_likes', true) ?: 0; ?>
                                    <a href="javascript:void(0)" class="comment-like-btn" data-comment-id="<?php echo $comment_id; ?>" style="color: #8b949e; text-decoration: none; display: flex; align-items: center; gap: 5px; transition: 0.2s; font-weight: 500;" onmouseover="this.style.color='#00ff41';" onmouseout="this.style.color='#8b949e';">
                                        <i class="fa-solid fa-heart" style="font-size: 11px;"></i> সহায়ক মনে হয়েছে (<span class="like-count" style="font-weight: 700;"><?php echo $likes; ?></span>)
                                    </a>
                                    
                                    <span class="qna-v7-share-btn" data-link="<?php echo esc_url(get_comment_link($answer)); ?>" style="color: #8b949e; cursor: pointer; display: flex; align-items: center; gap: 5px; transition: 0.2s; font-weight: 500;" onmouseover="this.style.color='#00f0ff';" onmouseout="this.style.color='#8b949e';"><i class="fa-solid fa-share-nodes"></i> শেয়ার লিঙ্ক</span>
                                    
                                    <span class="qna-v7-report-btn" data-comment-id="<?php echo $comment_id; ?>" style="color: #8b949e; cursor: pointer; display: flex; align-items: center; gap: 5px; transition: 0.2s; font-weight: 500;" onmouseover="this.style.color='#ff3e3e';" onmouseout="this.style.color='#8b949e';"><i class="fa-regular fa-flag"></i> রিপোর্ট</span>
                                    
                                    <?php if (!$is_ai && $current_user_id && ($current_user_id == $answer->user_id || current_user_can('moderate_comments'))) : ?>
                                        <button class="comment-edit-trigger-btn" onclick="openCommentEdit(<?php echo $comment_id; ?>, event)" style="background: transparent; border: none; color: #00f0ff; font-size: 12px; font-weight: bold; cursor: pointer; padding: 0; display: inline-flex; align-items: center; gap: 4px; transition: 0.2s;" onmouseover="this.style.color='#fff';" onmouseout="this.style.color='#00f0ff';">
                                            <i class="fa-solid fa-pen-to-square"></i> এডিট
                                        </button>
                                    <?php endif; ?>
                                    
                                    <button class="qna-v7-reply-toggle-btn" data-comment-id="<?php echo $comment_id; ?>" style="background: rgba(0, 240, 255, 0.08); border: 1.2px solid rgba(0, 240, 255, 0.2); color: #00f0ff; padding: 3px 12px; border-radius: 6px; font-size: 11px; font-weight: bold; cursor: pointer; display: inline-flex; align-items: center; gap: 4.5px; margin-left: auto; transition: all 0.2s;">
                                        <i class="fa-solid fa-reply"></i> মন্তব্য করুন
                                    </button>
                                </div>

                                <!-- Sub-comment/Reply Threads under this specific Answer -->
                                <?php
                                $replies = get_comments(array(
                                    'post_id' => $post_id,
                                    'parent'  => $comment_id,
                                    'status'  => 'approve',
                                    'order'   => 'ASC'
                                ));
                                ?>
                                <div class="qna-v7-replies-thread-container" id="qna-replies-container-<?php echo $comment_id; ?>" style="margin-top: 15px; display: flex; flex-direction: column; gap: 12px; border-left: 2px solid rgba(255,255,255,0.05); padding-left: 15px; margin-left: 10px;">
                                    <?php foreach ($replies as $reply) : 
                                        $reply_id = $reply->comment_ID;
                                        $reply_is_ai = get_comment_meta($reply_id, '_is_ai_moderator_comment', true);
                                        
                                        if ($reply_is_ai) {
                                            $reply_bg = 'background: rgba(10, 19, 36, 0.55); border: 1px solid rgba(0, 240, 255, 0.25);';
                                            $reply_avatar_border = 'border: 1px solid #00f0ff;';
                                        } else {
                                            $reply_bg = 'background: rgba(13, 19, 31, 0.45); border: 1px solid rgba(255, 255, 255, 0.04);';
                                            $reply_avatar_border = 'border: 1px solid rgba(255, 255, 255, 0.15);';
                                        }
                                        ?>
                                        <div class="qna-v7-reply-card" id="qna-reply-<?php echo $reply_id; ?>" style="border-radius: 10px; padding: 12px 16px; position: relative; <?php echo esc_attr($reply_bg); ?>">
                                            <div style="display: flex; gap: 12px; align-items: flex-start; text-align: left;">
                                                <div class="avatar" style="<?php echo esc_attr($reply_avatar_border); ?> border-radius: 50%; overflow: hidden; width: 30px; height: 30px; flex-shrink: 0; background: #070b13;">
                                                    <?php echo get_avatar($reply, 30); ?>
                                                </div>
                                                <div style="flex: 1; min-width: 0;">
                                                    <div style="display: flex; flex-wrap: wrap; gap: 8px; align-items: center; border-bottom: 1px solid rgba(255,255,255,0.03); padding-bottom: 6px; margin-bottom: 8px;">
                                                        <b style="color: #fff; font-size: 13px; font-weight: 700;"><?php echo esc_html($reply->comment_author); ?></b>
                                                        
                                                        <?php if ($reply_is_ai) : ?>
                                                            <span style="background: rgba(0, 240, 255, 0.12); color: #00f0ff; font-size: 8px; font-weight: 900; padding: 1px 5px; border-radius: 3px; border: 1px solid rgba(0,240,255,0.25); font-family: monospace;"><i class="fa-solid fa-robot"></i> AI BOT</span>
                                                        <?php elseif ($reply->user_id == $post_author_id) : ?>
                                                            <span style="background: rgba(255, 174, 0, 0.1); color: #ffae00; font-size: 8px; font-weight: 900; padding: 1px 5px; border-radius: 3px; border: 1px solid rgba(255,174,0,0.25); font-family: monospace;"><i class="fa-solid fa-user"></i> QUESTIONER</span>
                                                        <?php endif; ?>

                                                        <span style="color: #6e7681; font-size: 11px; display: flex; align-items: center; gap: 3px; margin-left: auto; font-family: monospace;">
                                                            <i class="fa-regular fa-clock" style="font-size: 9px;"></i>
                                                            <?php echo human_time_diff(strtotime($reply->comment_date), current_time('timestamp')); ?> আগে
                                                        </span>
                                                    </div>
                                                    <div style="color: #cbd5e1; font-size: 13px; line-height: 1.6; font-family: 'Space Grotesk', system-ui, sans-serif;">
                                                        <?php echo wp_kses_post(wpautop(get_comment_text($reply_id))); ?>
                                                    </div>
                                                    
                                                    <div style="display: flex; gap: 12px; align-items: center; justify-content: flex-end; margin-top: 8px; font-size: 11px;">
                                                        <?php $reply_likes = get_comment_meta($reply_id, '_comment_likes', true) ?: 0; ?>
                                                        <a href="javascript:void(0)" class="comment-like-btn" data-comment-id="<?php echo $reply_id; ?>" style="color: #8b949e; text-decoration: none; display: flex; align-items: center; gap: 4px; transition: 0.2s;" onmouseover="this.style.color='#00ff41';" onmouseout="this.style.color='#8b949e';">
                                                            <i class="fa-solid fa-heart" style="font-size: 9px;"></i> সহায়ক (<span class="like-count"><?php echo $reply_likes; ?></span>)
                                                        </a>
                                                        <?php if ($current_user_id && ($current_user_id == $reply->user_id || current_user_can('moderate_comments'))) : ?>
                                                            <button onclick="openCommentEdit(<?php echo $reply_id; ?>, event)" style="background: transparent; border: none; color: #00f0ff; font-size: 11px; cursor: pointer; padding: 0; display: inline-flex; align-items: center; gap: 3px;">
                                                                <i class="fa-solid fa-pen-to-square"></i> এডিটর
                                                            </button>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>

                                <!-- Inline Reply form, opens under click -->
                                <div class="qna-v7-inline-reply-form-wrapper" id="qna-reply-form-for-<?php echo $comment_id; ?>" style="display: none; margin-top: 15px; margin-left: 10px;">
                                    <div style="background: #0d1527; border: 1.2px solid rgba(0, 240, 255, 0.2); border-radius: 10px; padding: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.4);">
                                        <h5 style="color:#fff; font-size: 12.5px; margin-top:0; margin-bottom:10px; display:flex; align-items:center; gap:5px;"><i class="fa-solid fa-comment-dots" style="color:#00f0ff;"></i> এই সমাধানের ওপর মতামত বা জেরা করুন:</h5>
                                        <textarea class="qna-v7-reply-input" style="width: 100%; background: #070b13; color: #fff; border: 1.2px solid rgba(255,255,255,0.08); border-radius: 6px; padding: 10px; font-size: 13px; line-height: 1.5; min-height: 70px; resize: vertical; focus: outline: none; focus: border-color: #00f0ff;" placeholder="আপনার সংক্ষিপ্ত আলোচনা এখানে লিখুন... স্প্যামিং এড়িয়ে চলুন।"></textarea>
                                        <div style="display: flex; justify-content: flex-end; gap: 8px; margin-top: 10px;">
                                            <button class="qna-v7-reply-cancel-btn" data-comment-id="<?php echo $comment_id; ?>" style="background: transparent; border: 1px solid rgba(255,255,255,0.15); color: #8b949e; font-size: 11.5px; font-weight: bold; padding: 4px 12px; border-radius: 4px; cursor: pointer;">বাতিল</button>
                                            <button class="qna-v7-reply-submit-btn" data-parent-id="<?php echo $comment_id; ?>" data-post-id="<?php echo $post_id; ?>" style="background: #00f0ff; border: none; color: #000; font-size: 11.5px; font-weight: bold; padding: 4px 15px; border-radius: 4px; cursor: pointer; display: flex; align-items: center; gap: 4px;">প্রকাশ করুন <i class="fa-solid fa-paper-plane"></i></button>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!-- Sleek Custom Q&A Answer Submission Form -->
        <div class="qna-v7-submit-section" style="background: linear-gradient(145deg, #0d1527 0%, #070b13 100%); border: 1.5px solid rgba(0, 240, 255, 0.15); border-radius: 14px; padding: 25px; box-shadow: 0 10px 40px rgba(0,0,0,0.8); position: relative; overflow: hidden;">
            <div style="position: absolute; bottom: -50px; left: -50px; width: 150px; height: 150px; background: radial-gradient(circle, rgba(0,240,255,0.05) 0%, transparent 70%); pointer-events: none;"></div>
            
            <h4 style="color:#fff; font-size: 16.5px; margin-top:0; margin-bottom:12px; font-weight: 700; display:flex; align-items:center; gap:8px; font-family: 'Space Grotesk', sans-serif;">
                <i class="fa-solid fa-code" style="color: #00f0ff;"></i> 
                আপনার সমাধান বা উত্তর বিস্তারিত বিশ্লেষণ করুন
            </h4>
            <p style="color: #8b949e; font-size: 12.5px; margin-top: 0; margin-bottom: 20px; line-height: 1.5;">
                গঠনমূলক, সঠিক সমাধান প্রদানের মাধ্যমে কমিউনিটিতে আপনার খ্যাতি বা রেপুটেশন বাড়ান। প্রতিটি ভেরিফাইড সমাধানের জন্য 
                <span style="color:#00ff41; font-weight:bold;">৫০ XP</span> ও <span style="color:#ffae00; font-weight:bold;">৳২.০০</span> বোনাস প্রদান করা হবে।
            </p>

            <?php if (is_user_logged_in()) : ?>
                <form id="qna-v7-answer-form" style="display: flex; flex-direction: column; gap: 15px;">
                    <input type="hidden" name="action" value="ilybd_submit_qna_answer">
                    <input type="hidden" name="post_id" value="<?php echo $post_id; ?>">
                    <input type="hidden" name="parent_id" value="0">
                    
                    <!-- Code Snippet Area (Hidden inside toggle) -->
                    <div style="display: flex; justify-content: flex-end; align-items: center; margin-bottom: -5px;">
                        <button type="button" id="toggle-code-field-btn" style="background: rgba(255,255,255,0.03); border: 1.2px solid rgba(255,255,255,0.08); color: #00f0ff; font-family: monospace; font-size: 11px; font-weight: bold; padding: 5px 12px; border-radius: 6px; cursor: pointer; display: flex; align-items: center; gap: 5px; transition: 0.2s;" onmouseover="this.style.borderColor='rgba(0,240,255,0.3)';" onmouseout="this.style.borderColor='rgba(255,255,255,0.08)';">
                            <i class="fa-solid fa-terminal"></i> ADD CODE CONSOLE
                        </button>
                    </div>

                    <div id="code-snippet-wrapper" style="display: none; transition: all 0.3s;">
                        <label style="display: block; color: #8b949e; font-size: 11.5px; font-weight: bold; margin-bottom: 6px; font-family: monospace;">CODE / CYPHER OUTPUT PANEL:</label>
                        <textarea name="code_snippet" style="width: 100%; background: #070b13; color: #a5d6ff; border: 1px solid rgba(0,240,255,0.25); border-radius: 8px; padding: 15px; font-family: 'JetBrains Mono', monospace; font-size: 13px; line-height: 1.5; min-height: 120px; outline: none; box-shadow: inset 0 2px 10px rgba(0,0,0,0.5);" placeholder="এখানে আপনার সোর্স কোড বা টার্মিনাল লগ পেস্ট করুন..."></textarea>
                    </div>

                    <!-- Main Answer input -->
                    <div>
                        <textarea name="answer_content" required style="width: 100%; background: #070b13; color: #fff; border: 1.2px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 15px; font-size: 14.5px; line-height: 1.7; min-height: 140px; resize: vertical; outline: none; transition: 0.2s; font-family: 'Space Grotesk', system-ui, sans-serif; box-shadow: inset 0 2px 10px rgba(0,0,0,0.5);" placeholder="আপনার বিস্তারিত টেকনিক্যাল বা সল্যুশন গাইডলাইন বাংলা অথবা ইংরেজিতে লিখুন..."></textarea>
                    </div>

                    <!-- Submit action row -->
                    <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 15px;">
                        <div class="user-meta" style="display: flex; align-items: center; gap: 8px; font-size: 12.5px; color: #8b949e;">
                            <img src="<?php echo esc_url(get_avatar_url($current_user_id, array('size' => 24))); ?>" style="width:24px; height:24px; border-radius:50%; border: 1px solid rgba(255,255,255,0.15);" alt="<?php echo esc_attr($current_user->display_name); ?>">
                            <span>Posting as <b style="color: #fff;"><?php echo esc_html($current_user->display_name); ?></b></span>
                        </div>
                        
                        <button type="submit" id="qna-v7-submit-btn" style="background: #00f0ff; color: #000; border: none; padding: 11px 25px; border-radius: 30px; font-weight: 800; font-size: 13px; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; transition: all 0.25s; box-shadow: 0 4px 15px rgba(0,240,255,0.25);" onmouseover="this.style.background='#fff'; this.style.boxShadow='0 0 15px #fff';" onmouseout="this.style.background='#00f0ff'; this.style.boxShadow='0 4px 15px rgba(0,240,255,0.25)';">
                            <span>সমাধান প্রকাশ করুন 🚀</span>
                        </button>
                    </div>
                </form>
            <?php else : ?>
                <div class="qna-v7-login-required" style="text-align: center; padding: 15px 0;">
                    <p style="color: #8b949e; margin-bottom: 15px; font-size: 14px;">উত্তর সাবমিট এবং বোনাস পয়েন্ট লাভ করতে সিস্টেমে লগইন করুন।</p>
                    <a href="<?php echo esc_url(wp_login_url(get_permalink())); ?>" style="background: #00f0ff; color: #000; padding: 8px 24px; border-radius: 30px; font-weight: 800; text-decoration: none; font-size: 12.5px; display: inline-block; transition: 0.25s; box-shadow: 0 4px 15px rgba(0,240,255,0.25);" onmouseover="this.style.background='#fff'; this.style.boxShadow='0 0 15px #fff';" onmouseout="this.style.background='#00f0ff'; this.style.boxShadow='0 4px 15px rgba(0,240,255,0.25)';">Login to Knowledge Hub</a>
                </div>
            <?php endif; ?>
        </div>

    </div>

    <!-- AJAX Client Logic Script for Isolated Engine -->
    <script>
    jQuery(document).ready(function($) {
        
        // 1. Voting System
        $('.qna-v7-vote-trigger').on('click', function(e) {
            e.preventDefault();
            var btn = $(this);
            var commentId = btn.data('comment-id');
            var type = btn.data('type');
            
            btn.css('opacity', '0.5');
            
            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'ilybd_vote_comment_qna',
                    comment_id: commentId,
                    vote_type: type
                },
                success: function(response) {
                    btn.css('opacity', '1');
                    if (response.success) {
                        var counter = btn.siblings('.qna-v7-vote-count');
                        counter.text(response.data.votes);
                        
                        // Flash neon color feedback
                        counter.css('color', type === 'up' ? '#00ff41' : '#ff3e3e');
                        setTimeout(function() {
                            counter.css('color', '#fff');
                        }, 600);
                    } else if (response.data && response.data.message) {
                        alert(response.data.message);
                    }
                }
            });
        });

        // 2. Verified Solution Selection
        $('.qna-v7-accept-trigger').on('click', function(e) {
            e.preventDefault();
            var btn = $(this);
            var commentId = btn.data('comment-id');
            
            btn.css('opacity', '0.5');
            
            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'ilybd_accept_solution',
                    comment_id: commentId
                },
                success: function(response) {
                    btn.css('opacity', '1');
                    if (response.success) {
                        alert(response.data.message);
                        location.reload(); // Refresh to update bento grid ordering and schema
                    } else if (response.data && response.data.message) {
                        alert(response.data.message);
                    }
                }
            });
        });

        // 3. Toggle inline reply forms
        $('.qna-v7-reply-toggle-btn, .qna-v7-reply-cancel-btn').on('click', function(e) {
            e.preventDefault();
            var commentId = $(this).data('comment-id');
            var form = $('#qna-reply-form-for-' + commentId);
            form.slideToggle(200);
        });

        // 4. Submit inline reply (sub-comment) via AJAX
        $('.qna-v7-reply-submit-btn').on('click', function(e) {
            e.preventDefault();
            var btn = $(this);
            var parentId = btn.data('parent-id');
            var postId = btn.data('post-id');
            var textarea = btn.closest('.qna-v7-inline-reply-form-wrapper').find('.qna-v7-reply-input');
            var content = textarea.val().trim();
            
            if (content === '') {
                alert('অনুগ্রহ করে আপনার মন্তব্য লিখুন!');
                return;
            }
            
            btn.prop('disabled', true).css('opacity', '0.6').text('সাবমিট হচ্ছে...');
            
            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'ilybd_submit_qna_answer',
                    post_id: postId,
                    parent_id: parentId,
                    answer_content: content
                },
                success: function(response) {
                    btn.prop('disabled', false).css('opacity', '1').text('প্রকাশ করুন');
                    if (response.success) {
                        textarea.val('');
                        $('#qna-reply-form-for-' + parentId).slideUp(200);
                        alert('আপনার উত্তর বা মতামত সফলভাবে প্রকাশ করা হয়েছে!');
                        location.reload();
                    } else {
                        alert(response.data || 'কোনো ভুল হয়েছে, আবার চেষ্টা করুন।');
                    }
                }
            });
        });

        // 5. Toggle optional Code block field in the primary Answer submission
        $('#toggle-code-field-btn').on('click', function(e) {
            e.preventDefault();
            var wrapper = $('#code-snippet-wrapper');
            wrapper.slideToggle(250);
            $(this).toggleClass('code-field-active');
            if ($(this).hasClass('code-field-active')) {
                $(this).html("<i class='fa-solid fa-xmark' style='color:#ff3e3e;'></i> REMOVE CODE");
            } else {
                $(this).html("<i class='fa-solid fa-terminal'></i> ADD CODE CONSOLE");
            }
        });

        // 6. Submit Primary Answer via AJAX
        $('#qna-v7-answer-form').on('submit', function(e) {
            e.preventDefault();
            var form = $(this);
            var btn = $('#qna-v7-submit-btn');
            var content = form.find('textarea[name="answer_content"]').val().trim();
            
            if (content === '') {
                alert('অনুগ্রহ করে উত্তরের বিবরণ যুক্ত করুন!');
                return;
            }
            
            btn.prop('disabled', true).css('opacity', '0.6').find('span').text('বিশ্লেষণ পোস্ট হচ্ছে...');
            
            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: form.serialize(),
                success: function(response) {
                    btn.prop('disabled', false).css('opacity', '1').find('span').text('সমাধান প্রকাশ করুন 🚀');
                    if (response.success) {
                        form.find('textarea').val('');
                        $('#code-snippet-wrapper').slideUp(100);
                        $('#toggle-code-field-btn').removeClass('code-field-active').html("<i class='fa-solid fa-terminal'></i> ADD CODE CONSOLE");
                        alert('আপনার সমাধানটি সফলভাবে প্রকাশ করা হয়েছে এবং পয়েন্ট যুক্ত করা হয়েছে!');
                        location.reload();
                    } else {
                        alert(response.data || 'সিস্টেমে ত্রুটি ঘটেছে, আবার চেষ্টা করুন।');
                    }
                },
                error: function() {
                    btn.prop('disabled', false).css('opacity', '1').find('span').text('সমাধান প্রকাশ করুন 🚀');
                    alert('সার্ভার রেসপন্স ব্যর্থ হয়েছে।');
                }
            });
        });

        // 7. General like button click
        $('.comment-like-btn').on('click', function(e) {
            e.preventDefault();
            var btn = $(this);
            var commentId = btn.data('comment-id');
            
            btn.css('opacity', '0.6');
            
            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'ilybd_like_comment',
                    comment_id: commentId
                },
                success: function(response) {
                    btn.css('opacity', '1');
                    if (response.success) {
                        btn.find('.like-count').text(response.data.likes);
                        btn.css('color', '#00ff41');
                    }
                }
            });
        });

        // 8. Share button helper
        $('.qna-v7-share-btn').on('click', function() {
            var link = $(this).data('link');
            navigator.clipboard.writeText(link);
            var origHtml = $(this).html();
            $(this).html("<i class='fa-solid fa-check' style='color:#00f0ff;'></i> Copied!");
            var btn = $(this);
            setTimeout(function() {
                btn.html(origHtml);
            }, 1500);
        });

        // 9. Report helper
        $('.qna-v7-report-btn').on('click', function() {
            var commentId = $(this).data('comment-id');
            if (confirm('আপনি কি নিশ্চিত যে এই মন্তব্যটি মডারেটরদের কাছে রিপোর্ট করতে চান?')) {
                $.ajax({
                    url: '<?php echo admin_url('admin-ajax.php'); ?>',
                    type: 'POST',
                    data: {
                        action: 'ilybd_handle_report',
                        item_id: commentId,
                        item_type: 'comment'
                    },
                    success: function(response) {
                        if (response.success) {
                            alert('রিপোর্ট মডারেশন সেন্টারে পাঠানো হয়েছে। ধন্যবাদ!');
                        } else {
                            alert(response.data || 'ইতিমধ্যে রিপোর্ট করা হয়েছে!');
                        }
                    }
                });
            }
        });
        
    });

    // 10. Open Comment Edit modal or handler (existing theme feature)
    function openCommentEdit(commentId, e) {
        if (e) e.preventDefault();
        var origText = jQuery('#comment-text-container-' + commentId).text().trim();
        var newText = prompt('আপনার উত্তর বা মন্তব্য সংশোধন করুন:', origText);
        if (newText && newText.trim() !== '' && newText.trim() !== origText) {
            jQuery.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'ilybd_edit_comment',
                    comment_id: commentId,
                    comment_content: newText
                },
                success: function(response) {
                    if (response.success) {
                        alert('সফলভাবে এডিট করা হয়েছে!');
                        location.reload();
                    } else {
                        alert(response.data.message || 'ব্যর্থ হয়েছে!');
                    }
                }
            });
        }
    }
    </script>
    <?php
}

/**
 * 2. AJAX Submission Handler for Answers & Replies
 */
add_action('wp_ajax_ilybd_submit_qna_answer', 'ilybd_handle_submit_qna_answer_ajax');
add_action('wp_ajax_nopriv_ilybd_submit_qna_answer', 'ilybd_handle_submit_qna_answer_ajax');

function ilybd_handle_submit_qna_answer_ajax() {
    $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
    $parent_id = isset($_POST['parent_id']) ? intval($_POST['parent_id']) : 0;
    $content = isset($_POST['answer_content']) ? trim($_POST['answer_content']) : '';
    $code_snippet = isset($_POST['code_snippet']) ? trim($_POST['code_snippet']) : '';

    if (!$post_id || empty($content)) {
        wp_send_json_error('প্রয়োজনীয় ডাটা পাওয়া যায়নি অথবা ফর্ম খালি।');
    }

    $post = get_post($post_id);
    if (!$post || $post->post_type !== 'ilybd_question') {
        wp_send_json_error('অবৈধ পোস্ট আইডি বা প্রশ্ন পাওয়া যায়নি।');
    }

    // Rate Limiting & Spam Filter
    $current_user_id = get_current_user_id();
    $author_name = '';
    $author_email = '';
    $author_url = '';

    if ($current_user_id) {
        $user = wp_get_current_user();
        $author_name = $user->display_name;
        $author_email = $user->user_email;
        $author_url = $user->user_url;
    } else {
        // Non-logged in users should not be submitting Q&A answers to maintain high crawlability/integrity
        wp_send_json_error('সমাধান সাবমিট করতে দয়া করে লগইন করুন।');
    }

    // Anti-spam length check
    if (strlen($content) < 8) {
        wp_send_json_error('সমাধানটি অত্যন্ত সংক্ষিপ্ত! অনুগ্রহ করে অন্তত ৮টি ক্যারেক্টার লিখুন।');
    }

    // Insert Comment using wp_new_comment
    $comment_data = array(
        'comment_post_ID'      => $post_id,
        'comment_author'       => $author_name,
        'comment_author_email' => $author_email,
        'comment_author_url'   => $author_url,
        'comment_content'      => wp_kses_post($content),
        'comment_type'         => 'comment',
        'comment_parent'       => $parent_id,
        'user_id'              => $current_user_id,
        'comment_approved'     => 1 // Auto-approve to maintain active micro-engagement inside the safe cyber environment
    );

    $comment_id = wp_new_comment($comment_data);

    if ($comment_id && !is_wp_error($comment_id)) {
        // If code snippet is included, store as comment meta
        if (!empty($code_snippet)) {
            update_comment_meta($comment_id, '_qna_code_snippet', wp_kses_post($code_snippet));
        }

        // economy rewards integration (Standard answer gets +15 XP and +0.50 Tk instantly!)
        if ($parent_id == 0 && function_exists('ilybd_update_user_economy')) {
            $msg = "📝 ফোরামে প্রযুক্তি সমাধান বিশ্লেষণ প্রদান করার জন্য ১৫ XP এবং ৳০.৫০ বোনাস ক্রেডিট যোগ করা হয়েছে।";
            ilybd_update_user_economy($current_user_id, 15, 0.50, $msg);
        } elseif ($parent_id > 0 && function_exists('ilybd_update_user_economy')) {
            $msg = "💬 ফোরামের উত্তরে গঠনমূলক মতামত প্রদানের জন্য ৫ XP এবং ৳০.১০ বোনাস ক্রেডিট যোগ করা হয়েছে।";
            ilybd_update_user_economy($current_user_id, 5, 0.10, $msg);
        }

        wp_send_json_success('উত্তর সফলভাবে সংরক্ষিত হয়েছে!');
    } else {
        wp_send_json_error('মন্তব্য সংরক্ষণ ব্যর্থ হয়েছে। দয়া করে পুনরায় চেষ্টা করুন।');
    }
}

/**
 */
