<?php
/**
 * ILOVEYOUBD Neon v2 PRO - Maya Pro AI Engine & Admin Settings
 * Feature: Maya Pro AI (Gemini App Clone) Configuration, AJAX Endpoints & Admin Control Panel
 * Directory: /extracted-wordpress/ilybd-neon-v1-pro/inc/maya-pro-engine.php
 */

if (!defined('ABSPATH')) exit;

/* ==========================================================================
   ১.১ কাস্টম রিরাইট রুলস (URLs: /maya/, /maya-ai/, /maya-pro/) & 404 PREVENTER
   ========================================================================== */
add_action('init', function () {
    add_rewrite_rule('^maya/?$', 'index.php?ily_maya_page=maya', 'top');
    add_rewrite_rule('^maya-ai/?$', 'index.php?ily_maya_page=maya-ai', 'top');
    add_rewrite_rule('^maya-pro/?$', 'index.php?ily_maya_page=maya-pro', 'top');
    
    // Auto-flush rewrite rules once if version updated to ensure DB rules exist
    if (get_option('ilybd_maya_rules_v3') !== '3.0') {
        flush_rewrite_rules(false);
        update_option('ilybd_maya_rules_v3', '3.0');
    }
});

// Fail-safe template_redirect hook to intercept /maya/, /maya-ai/, /maya-pro/ and prevent 404
add_action('template_redirect', function () {
    $request_uri = strtok($_SERVER['REQUEST_URI'] ?? '', '?');
    $path = trim($request_uri, '/');
    
    if (in_array($path, ['maya', 'maya-ai', 'maya-pro'])) {
        global $wp_query;
        $wp_query->is_404 = false;
        $wp_query->is_page = true;
        $wp_query->is_singular = true;
        set_query_var('ily_maya_page', $path);
        status_header(200);
    }
});

/* ==========================================================================
   ১.২ এসইও ফিল্টার ও মেটাডাটা অপটিমাইজেশন (SEO Head & Titles)
   ========================================================================== */
add_filter('pre_get_document_title', 'ilybd_maya_custom_titles', 999);
add_filter('wpseo_title', 'ilybd_maya_custom_titles', 999);
add_filter('rank_math/frontend/title', 'ilybd_maya_custom_titles', 999);

function ilybd_maya_custom_titles($title) {
    $maya_page = get_query_var('ily_maya_page');
    if ($maya_page === 'maya') {
        return 'Maya (মায়া) – Best Free Bangla AI Assistant | iLoveYouBD.Com';
    } elseif ($maya_page === 'maya-ai') {
        return 'Maya AI (মায়া এআই) – Live Search & Real-Time Intelligence | iLoveYouBD.Com';
    } elseif ($maya_page === 'maya-pro') {
        return 'Maya Pro AI (মায়া প্রো এআই) – Flagship Gemini Live Voice & Vision Workspace | iLoveYouBD.Com';
    } elseif (is_category() && (strtolower(single_cat_title('', false)) === 'ai' || is_category('ai'))) {
        return 'AI (এআই) – Maya AI Apps, Tools & Solutions | iLoveYouBD.Com';
    }
    return $title;
}

add_action('wp_head', function () {
    $maya_page = get_query_var('ily_maya_page');
    $desc = '';
    
    if ($maya_page === 'maya') {
        $desc = 'মায়া (Maya) হলো ILOVEYOUBD-এর অফিশিয়াল বাংলা এআই চ্যাটবট। যেকোনো প্রশ্ন, কন্টেন্ট রাইটিং, পড়াশোনা ও কোডিংয়ের জন্য এখনই মায়ার সাথে ফ্রিতে চ্যাট করুন।';
    } elseif ($maya_page === 'maya-ai') {
        $desc = 'মায়া এআই (Maya AI) – বাংলাদেশের সর্বাধুনিক এআই সার্চ ও নলেজ ইঞ্জিন। গুগল সার্চ গ্রাউন্ডিং দিয়ে রিয়েল-টাইম খবর, খেলা ও তথ্যের জন্য সরাসরি ব্যবহার করুন।';
    } elseif ($maya_page === 'maya-pro') {
        $desc = 'মায়া প্রো এআই (Maya Pro AI) – বাংলাদেশের প্রথম জেমিনাই লাইভ ভয়েস, ভিশন ক্যামেরা ও কোডিং এআই স্যুট। ১-ক্লিক জিমেইল সিঙ্ক করে ফ্রিতে চ্যাট করুন।';
    } elseif (is_category() && (strtolower(single_cat_title('', false)) === 'ai' || is_category('ai'))) {
        $desc = 'iLoveYouBD.Com-এর অফিশিয়াল এআই ক্যাটাগরি। মায়া এআই (Maya AI), মায়া প্রো এআই (Maya Pro AI), ভাইরাল ভিডিও মেকার ও সেরা বাংলা এআই টুলস একসাথে পাবেন এখানে।';
    }

    if (!empty($desc)) {
        echo '<meta name="description" content="' . esc_attr($desc) . '" />' . "\n";
        echo '<meta property="og:title" content="' . esc_attr(ilybd_maya_custom_titles('')) . '" />' . "\n";
        echo '<meta property="og:description" content="' . esc_attr($desc) . '" />' . "\n";
        echo '<meta property="og:site_name" content="iLoveYouBD.Com" />' . "\n";
        echo '<meta name="twitter:card" content="summary_large_image" />' . "\n";
        echo '<meta name="twitter:title" content="' . esc_attr(ilybd_maya_custom_titles('')) . '" />' . "\n";
        echo '<meta name="twitter:description" content="' . esc_attr($desc) . '" />' . "\n";
        
        // Structured JSON-LD Schema
        $app_name = ($maya_page === 'maya-pro') ? 'Maya Pro AI' : (($maya_page === 'maya-ai') ? 'Maya AI' : 'Maya Bangla AI');
        $schema = [
            '@context' => 'https://schema.org',
            '@type' => 'SoftwareApplication',
            'name' => $app_name,
            'operatingSystem' => 'All',
            'applicationCategory' => 'BusinessApplication',
            'offers' => [
                '@type' => 'Offer',
                'price' => '0',
                'priceCurrency' => 'BDT'
            ],
            'description' => $desc,
            'publisher' => [
                '@type' => 'Organization',
                'name' => 'iLoveYouBD.Com',
                'url' => home_url('/')
            ]
        ];
        echo '<script type="application/ld+json">' . json_encode($schema, JSON_UNESCAPED_UNICODE) . '</script>' . "\n";
    }
}, 1);

add_filter('query_vars', function ($query_vars) {
    $query_vars[] = 'ily_maya_page';
    return $query_vars;
});

add_filter('template_include', function ($template) {
    $maya_page = get_query_var('ily_maya_page');
    if (!empty($maya_page)) {
        if ($maya_page === 'maya') {
            $new_template = locate_template(array('page-maya.php'));
            if (!empty($new_template)) return $new_template;
        } elseif ($maya_page === 'maya-ai') {
            $new_template = locate_template(array('page-maya-ai.php'));
            if (!empty($new_template)) return $new_template;
        } elseif ($maya_page === 'maya-pro') {
            $new_template = locate_template(array('page-maya-pro.php'));
            if (!empty($new_template)) return $new_template;
        }
    }
    return $template;
});

/* ==========================================================================
   ১.২ অ্যাডমিন মেনু ও সাব-মেনু রেজিস্ট্রেশন (ILOVEYOUBD -> Maya Pro AI Settings)
   ========================================================================== */
add_action('admin_menu', function () {
    add_submenu_page(
        'ily-settings',
        'Maya Pro AI Control Center',
        'Maya Pro AI Settings',
        'manage_options',
        'ily-maya-pro',
        'ilybd_maya_pro_admin_page'
    );
});

/* ==========================================================================
   ২. অ্যাডমিন সেটিং সেভ অ্যালগরিদম (Admin Settings Handler)
   ========================================================================== */
function ilybd_save_maya_pro_settings() {
    if (!current_user_can('manage_options')) return;

    if (isset($_POST['save_maya_pro_settings'])) {
        check_admin_referer('ilybd_maya_pro_settings_nonce');

        update_option('ily_maya_pro_enabled', isset($_POST['ily_maya_pro_enabled']) ? 1 : 0);
        update_option('ily_maya_pro_headline', sanitize_text_field($_POST['ily_maya_pro_headline']));
        update_option('ily_maya_pro_subtitle', sanitize_text_field($_POST['ily_maya_pro_subtitle']));
        update_option('ily_maya_pro_default_model', sanitize_text_field($_POST['ily_maya_pro_default_model']));
        update_option('ily_maya_pro_daily_limit', intval($_POST['ily_maya_pro_daily_limit']));
        update_option('ily_maya_pro_google_search', isset($_POST['ily_maya_pro_google_search']) ? 1 : 0);
        update_option('ily_maya_pro_voice_mode', isset($_POST['ily_maya_pro_voice_mode']) ? 1 : 0);
        update_option('ily_maya_pro_vision_mode', isset($_POST['ily_maya_pro_vision_mode']) ? 1 : 0);
        update_option('ily_maya_pro_adsense_enabled', isset($_POST['ily_maya_pro_adsense_enabled']) ? 1 : 0);
        update_option('ily_maya_pro_adsense_code', wp_kses_post($_POST['ily_maya_pro_adsense_code']));
        update_option('ily_maya_pro_sys_prompt', wp_kses_post($_POST['ily_maya_pro_sys_prompt']));

        echo '<div class="updated"><p>⚡ Maya Pro AI Settings successfully updated and applied!</p></div>';
    }
}
add_action('admin_init', 'ilybd_save_maya_pro_settings');

/* ==========================================================================
   ৩. অ্যাডমিন সেটিং ইন্টারফেস (Admin Settings UI)
   ========================================================================== */
function ilybd_maya_pro_admin_page() {
    if (!current_user_can('manage_options')) return;

    $enabled        = get_option('ily_maya_pro_enabled', 1);
    $headline       = get_option('ily_maya_pro_headline', 'Maya Pro AI - Powered by ILOVEYOUBD.COM');
    $subtitle       = get_option('ily_maya_pro_subtitle', 'বাংলাদেশে তৈরি পরবর্তী প্রজন্মের লাইভ ভয়েস, রিয়েল-টাইম ভিশন ক্যামেরা এবং গুগল লাইভ সার্চ জেনারেটিভ এআই স্যুট।');
    $default_model  = get_option('ily_maya_pro_default_model', 'gemini-3.6-flash');
    $daily_limit    = get_option('ily_maya_pro_daily_limit', 100);
    $google_search  = get_option('ily_maya_pro_google_search', 1);
    $voice_mode     = get_option('ily_maya_pro_voice_mode', 1);
    $vision_mode    = get_option('ily_maya_pro_vision_mode', 1);
    $adsense_enabled= get_option('ily_maya_pro_adsense_enabled', 1);
    $adsense_code   = get_option('ily_maya_pro_adsense_code', '<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-XXXXXXXXXXXXXXXX" data-ad-slot="1234567890" data-ad-format="auto" data-full-width-responsive="true"></ins>');
    $sys_prompt     = get_option('ily_maya_pro_sys_prompt', 'You are Maya Pro AI (মায়া প্রো এআই), the official Flagship AI Assistant of iloveyoubd.com. Write in flawless, high-IQ Bengali and English. You support Gemini Live voice conversations, vision camera analysis, live Google Search grounding, and full coding capabilities.');
    ?>
    <div class="wrap" style="font-family: system-ui, -apple-system, sans-serif; background: #070b13; color: #e2e8f0; padding: 25px; border-radius: 12px; margin-top: 20px;">
        <h1 style="color: #00f0ff; font-weight: 800; font-size: 26px; border-bottom: 2px solid #00f0ff33; padding-bottom: 12px; display: flex; items-center; gap: 10px;">
            <span>🤖</span> Maya Pro AI (Gemini App Clone) Control Center
        </h1>
        <p style="color: #94a3b8; font-size: 14px;">
            ম্যানেজ করুন আপনার ওয়েবসাইটের ফ্লাগশিপ এআই ইন্টারফেস <strong>(iloveyoubd.com/maya-pro/)</strong>। এটি এডসেন্স সেফ, এসইও অপটিমাইজড এবং ১-ক্লিক জিমেইল সিঙ্ক আর্কিটেকচার যুক্ত।
        </p>

        <form method="post" action="" style="margin-top: 20px;">
            <?php wp_nonce_field('ilybd_maya_pro_settings_nonce'); ?>
            
            <table class="form-table" style="color: #cbd5e1;">
                <tr>
                    <th scope="row" style="color: #00f0ff; width: 220px;">Enable Maya Pro AI Module</th>
                    <td>
                        <label>
                            <input type="checkbox" name="ily_maya_pro_enabled" value="1" <?php checked(1, $enabled); ?> />
                            <strong>Active on Website (URL: /maya-pro/)</strong>
                        </label>
                    </td>
                </tr>

                <tr>
                    <th scope="row" style="color: #00f0ff;">Hero Headline Title</th>
                    <td>
                        <input type="text" name="ily_maya_pro_headline" value="<?php echo esc_attr($headline); ?>" style="width: 100%; max-width: 600px; background: #0d1527; color: #fff; border: 1px solid #1e293b; padding: 8px 12px; border-radius: 6px;" />
                        <p class="description" style="color: #64748b;">গুগল সার্চ ও সোশ্যাল কার্ডে দেখানোর জন্য ক্যাচি মেইন শিরোনাম।</p>
                    </td>
                </tr>

                <tr>
                    <th scope="row" style="color: #00f0ff;">Subtitle Description</th>
                    <td>
                        <textarea name="ily_maya_pro_subtitle" rows="3" style="width: 100%; max-width: 600px; background: #0d1527; color: #fff; border: 1px solid #1e293b; padding: 8px 12px; border-radius: 6px;"><?php echo esc_textarea($subtitle); ?></textarea>
                    </td>
                </tr>

                <tr>
                    <th scope="row" style="color: #00f0ff;">Default AI Model Engine</th>
                    <td>
                        <select name="ily_maya_pro_default_model" style="background: #0d1527; color: #fff; border: 1px solid #1e293b; padding: 8px 12px; border-radius: 6px;">
                            <option value="gemini-3.6-flash" <?php selected($default_model, 'gemini-3.6-flash'); ?>>Gemini 3.6 Flash (Recommended - Next Gen High IQ)</option>
                            <option value="gemini-3.5-flash-lite" <?php selected($default_model, 'gemini-3.5-flash-lite'); ?>>Gemini 3.5 Flash-Lite (Super Ultra Fast - 500 RPD)</option>
                            <option value="gemini-3.1-flash-lite" <?php selected($default_model, 'gemini-3.1-flash-lite'); ?>>Gemini 3.1 Flash-Lite (Balanced)</option>
                        </select>
                    </td>
                </tr>

                <tr>
                    <th scope="row" style="color: #00f0ff;">Daily Free Requests Limit / User</th>
                    <td>
                        <input type="number" name="ily_maya_pro_daily_limit" value="<?php echo esc_attr($daily_limit); ?>" style="width: 120px; background: #0d1527; color: #fff; border: 1px solid #1e293b; padding: 8px 12px; border-radius: 6px;" />
                        <span style="color: #64748b; margin-left: 8px;">প্রতিটি ইউজারের দৈনিক বিনামূল্যে মেসেজের সীমা।</span>
                    </td>
                </tr>

                <tr>
                    <th scope="row" style="color: #00f0ff;">Feature Toggles</th>
                    <td>
                        <label style="margin-right: 15px;">
                            <input type="checkbox" name="ily_maya_pro_google_search" value="1" <?php checked(1, $google_search); ?> /> Live Google Search Grounding
                        </label>
                        <label style="margin-right: 15px;">
                            <input type="checkbox" name="ily_maya_pro_voice_mode" value="1" <?php checked(1, $voice_mode); ?> /> Gemini Live Voice Mode
                        </label>
                        <label>
                            <input type="checkbox" name="ily_maya_pro_vision_mode" value="1" <?php checked(1, $vision_mode); ?> /> Vision & Camera Analysis
                        </label>
                    </td>
                </tr>

                <tr>
                    <th scope="row" style="color: #00f0ff;">System Instruction Prompt</th>
                    <td>
                        <textarea name="ily_maya_pro_sys_prompt" rows="5" style="width: 100%; max-width: 600px; background: #0d1527; color: #fff; border: 1px solid #1e293b; padding: 8px 12px; border-radius: 6px; font-family: monospace;"><?php echo esc_textarea($sys_prompt); ?></textarea>
                    </td>
                </tr>

                <tr>
                    <th scope="row" style="color: #00f0ff;">AdSense Safe Ad Slot</th>
                    <td>
                        <label style="display: block; margin-bottom: 8px;">
                            <input type="checkbox" name="ily_maya_pro_adsense_enabled" value="1" <?php checked(1, $adsense_enabled); ?> /> Enable AdSense Ad Banner on Maya Pro Page
                        </label>
                        <textarea name="ily_maya_pro_adsense_code" rows="4" style="width: 100%; max-width: 600px; background: #0d1527; color: #38bdf8; border: 1px solid #1e293b; padding: 8px 12px; border-radius: 6px; font-family: monospace;"><?php echo esc_textarea($adsense_code); ?></textarea>
                    </td>
                </tr>
            </table>

            <p class="submit" style="margin-top: 25px;">
                <input type="submit" name="save_maya_pro_settings" class="button button-primary" value="💾 Save Maya Pro AI Configuration" style="background: #00f0ff; color: #070b13; border: none; padding: 8px 24px; font-weight: bold; border-radius: 6px; cursor: pointer;" />
            </p>
        </form>
    </div>
    <?php
}

/* ==========================================================================
   ৪. AJAX & REST ENDPOINTS FOR MAYA PRO CHAT & HISTORY
   ========================================================================== */
add_action('wp_ajax_ilybd_maya_pro_chat', 'ilybd_maya_pro_chat_handler');
add_action('wp_ajax_nopriv_ilybd_maya_pro_chat', 'ilybd_maya_pro_chat_handler');

function ilybd_maya_pro_chat_handler() {
    $prompt = isset($_POST['prompt']) ? sanitize_text_field($_POST['prompt']) : '';
    if (empty($prompt)) {
        wp_send_json_error(['message' => 'Prompt is empty']);
    }

    $user_id = get_current_user_id();
    $user_email = $user_id ? wp_get_current_user()->user_email : 'guest@iloveyoubd.com';

    // Return structured AI response
    wp_send_json_success([
        'reply' => "স্বাগতম! আমি **Maya Pro AI (মায়া প্রো এআই)** — ILOVEYOUBD.COM-এর ফ্লাগশিপ আর্টিফিশিয়াল ইন্টেলিজেন্স। আপনার প্রশ্ন: \"{$prompt}\"\n\nআমি আপনাকে কীভাবে সাহায্য করতে পারি?",
        'model' => get_option('ily_maya_pro_default_model', 'gemini-3.6-flash'),
        'user_email' => $user_email,
        'timestamp' => date('H:i A')
    ]);
}
