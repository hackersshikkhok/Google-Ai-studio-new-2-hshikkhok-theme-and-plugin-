<?php
if (!defined('ABSPATH')) exit;

function ilybd_get_manual_seo_content($slug) {
    $tools = ilybd_get_all_tools();
    $tool = $tools[$slug] ?? [];
    if(empty($tool)) return '';

    $name = esc_html($tool['name_bn'] ?? $tool['name']);
    $name_en = esc_html($tool['name']);
    $desc = esc_html($tool['desc_bn'] ?? '');

    $articles = [
        'keyword-density-checker' => '
            <div class="manual-seo-article space-y-10 font-sans text-gray-200">
                <div class="header-badge inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-xs font-mono uppercase tracking-wider">
                    ⚡ 2040 PRO SEO Utility
                </div>
                
                <section>
                    <h2 class="text-3xl md:text-4xl font-extrabold text-white bangla-font-siliguri leading-snug mb-6">
                        ' . $name . ' (' . $name_en . ') - এ টু জেড কমপ্লিট গাইডলাইনস
                    </h2>
                    <p class="text-base md:text-lg leading-relaxed text-gray-300 bangla-font-siliguri text-justify">
                        <strong>' . $name_en . '</strong> হলো সার্চ ইঞ্জিন অপটিমাইজেশন (SEO) এবং কন্টেন্ট ক্রিয়েটরদের জন্য একটি অতি গুরুত্বপূর্ণ নেক্সট-জেনারেশন ডিজিটাল টুল। এটি একটি স্মার্ট অ্যালগরিদম ইঞ্জিন যা আপনার সম্পূর্ণ আর্টিকেল স্ক্যান করে শব্দগুলোর ব্যবহার ও ঘনত্ব (Density) পরিমাপ করে। গুগল অ্যাডসেন্স অ্যাপ্রুভাল পাওয়া এবং সার্চ ইঞ্জিনের প্রথম পাতায় র‍্যাংক করার জন্য অতিরিক্ত কিওয়ার্ড স্টাফিং (Keyword Stuffing) থেকে বিরত থাকা অপরিহার্য। এই টুলটি আপনার আর্টিকেলের প্রতিটি শব্দকে বিশ্লেষণ করে রিয়েল-টাইম রিপোর্ট প্রদান করবে।
                    </p>
                </section>

                <section class="grid grid-cols-1 md:grid-cols-2 gap-6 my-8">
                    <div class="p-6 rounded-xl bg-white/5 border border-white/10 hover:border-emerald-500/30 transition-all">
                        <h3 class="text-xl font-bold text-emerald-400 mb-3 bangla-font-siliguri flex items-center gap-2">
                            <span class="text-2xl">🤔</span> কেন ব্যবহার করবেন? (Why Use It?)
                        </h3>
                        <p class="text-sm text-gray-300 bangla-font-siliguri leading-relaxed">
                            আপনি যখন কোনো টপিকের উপর আর্টিকেল লিখেন, তখন নির্দিষ্ট কিওয়ার্ড কতবার ব্যবহার করা হয়েছে তা ম্যানুয়ালি গোনা অসম্ভব। অতিরিক্ত কিওয়ার্ড ব্যবহার করলে গুগলের স্প্যাম আপডেটে আপনার সাইট পেনাল্টি খাবে। এই টুলটি স্বয়ংক্রিয়ভাবে কিওয়ার্ডের পার্সেন্টেজ বের করে আপনাকে স্প্যামিং থেকে রক্ষা করবে এবং অর্গানিক র‍্যাংকিং নিশ্চিত করবে।
                        </p>
                    </div>
                    <div class="p-6 rounded-xl bg-white/5 border border-white/10 hover:border-cyan-400/30 transition-all">
                        <h3 class="text-xl font-bold text-cyan-400 mb-3 bangla-font-siliguri flex items-center gap-2">
                            <span class="text-2xl">💡</span> করলে কি লাভ? (Core Benefits)
                        </h3>
                        <ul class="list-disc pl-5 text-sm text-gray-300 bangla-font-siliguri space-y-2">
                            <li>গুগল সার্চ অ্যালগরিদম পেনাল্টি থেকে ১০০% মুক্তি।</li>
                            <li>খুব দ্রুত অ্যাডসেন্স (Google AdSense) পলিসি কমপ্লায়েন্স অর্জন।</li>
                            <li>আপনার প্রতিযোগীদের তুলনায় কন্টেন্ট কোয়ালিটি নেক্সট লেভেলে নিয়ে যাওয়া।</li>
                            <li>আর্টিকেলের রিডিবিলিটি (Readability) ও ন্যাচারাল ফ্লো ঠিক রাখা।</li>
                        </ul>
                    </div>
                </section>

                <section class="p-6 md:p-8 rounded-2xl bg-gradient-to-br from-blue-900/20 to-purple-900/20 border border-white/10">
                    <h3 class="text-2xl font-bold text-white mb-6 bangla-font-siliguri flex items-center gap-2">
                        <span class="text-purple-400">⚙️</span> কিভাবে কাজ করবেন? (Step-by-Step Guide)
                    </h3>
                    <div class="space-y-4">
                        <div class="flex items-start gap-4">
                            <div class="w-8 h-8 rounded-full bg-purple-500/20 flex items-center justify-center text-purple-400 font-bold shrink-0">১</div>
                            <p class="text-gray-300 bangla-font-siliguri pt-1">প্রথমে আপনার লেখা সম্পূর্ণ ব্লগ পোস্ট বা আর্টিকেলটি কপি করে নিন।</p>
                        </div>
                        <div class="flex items-start gap-4">
                            <div class="w-8 h-8 rounded-full bg-purple-500/20 flex items-center justify-center text-purple-400 font-bold shrink-0">২</div>
                            <p class="text-gray-300 bangla-font-siliguri pt-1">উপরের ইনপুট বক্সে আপনার কপি করা টেক্সট পেস্ট করুন।</p>
                        </div>
                        <div class="flex items-start gap-4">
                            <div class="w-8 h-8 rounded-full bg-purple-500/20 flex items-center justify-center text-purple-400 font-bold shrink-0">৩</div>
                            <p class="text-gray-300 bangla-font-siliguri pt-1">"ANALYZE KEYWORD DENSITY" বাটনে ক্লিক করুন।</p>
                        </div>
                        <div class="flex items-start gap-4">
                            <div class="w-8 h-8 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-400 font-bold shrink-0">৪</div>
                            <p class="text-gray-300 bangla-font-siliguri pt-1">ডানপাশে তৈরি হওয়া রিপোর্টে দেখুন কোনো কিওয়ার্ড <strong>৩%</strong> এর বেশি ব্যবহার হয়েছে কিনা। হলে সেটি লাল রঙের ওয়ার্নিং দেখাবে, তখন টেক্সট এডিট করে ওই শব্দের সমার্থক শব্দ ব্যবহার করুন।</p>
                        </div>
                    </div>
                </section>
                
                <section>
                    <p class="text-sm text-gray-400 bangla-font-siliguri text-center italic mt-4">
                        নোট: ILoveYouBD.com এর এই টুলটি সম্পূর্ণ প্রাইভেসি বজায় রেখে আপনার ব্রাউজারেই কাজ করে, কোনো ডাটা আমাদের সার্ভারে সংরক্ষণ করা হয় না।
                    </p>
                </section>
            </div>
        ',
        'ai-blog-title-generator' => '
            <div class="manual-seo-article space-y-10 font-sans text-gray-200">
                <div class="header-badge inline-flex items-center gap-2 px-3 py-1 rounded-full bg-pink-500/10 border border-pink-500/30 text-pink-400 text-xs font-mono uppercase tracking-wider">
                    🤖 AI Neural Creator Engine
                </div>
                
                <section>
                    <h2 class="text-3xl md:text-4xl font-extrabold text-white bangla-font-siliguri leading-snug mb-6">
                        ' . $name . ' (' . $name_en . ') - প্রফেশনাল ব্লগিং গাইডলাইনস
                    </h2>
                    <p class="text-base md:text-lg leading-relaxed text-gray-300 bangla-font-siliguri text-justify">
                        বর্তমান ডিজিটাল যুগে একটি ব্লগের সফলতা সবচেয়ে বেশি নির্ভর করে তার টাইটেলের উপর। <strong>' . $name_en . '</strong> হলো একটি আর্টিফিশিয়াল ইন্টেলিজেন্স (AI) চালিত স্মার্ট টুল, যা আপনার আর্টিকেলের মূল টপিকের উপর ভিত্তি করে অত্যন্ত আকর্ষণীয়, ক্লিক-যোগ্য (Click-worthy) এবং এসইও (SEO) ফ্রেন্ডলি টাইটেল স্বয়ংক্রিয়ভাবে জেনারেট করে। গুগল সার্চ রেজাল্ট এবং সোশ্যাল মিডিয়ায় মানুষের মনোযোগ আকর্ষণ করার জন্য এটি ২০৪০ স্ট্যান্ডার্ড অনুযায়ী ডিজাইন করা হয়েছে।
                    </p>
                </section>

                <section class="grid grid-cols-1 md:grid-cols-2 gap-6 my-8">
                    <div class="p-6 rounded-xl bg-white/5 border border-white/10 hover:border-pink-500/30 transition-all">
                        <h3 class="text-xl font-bold text-pink-400 mb-3 bangla-font-siliguri flex items-center gap-2">
                            <span class="text-2xl">🤔</span> কেন ব্যবহার করবেন? (Why Use It?)
                        </h3>
                        <p class="text-sm text-gray-300 bangla-font-siliguri leading-relaxed">
                            আপনি হয়তো খুব দারুণ একটি আর্টিকেল লিখেছেন, কিন্তু টাইটেল বোরিং হলে কেউ সেখানে ক্লিক করবে না (Low CTR)। নিজে থেকে ইউনিক টাইটেল ভাবা সময়সাপেক্ষ। এই এআই টুলটি কয়েক সেকেন্ডের মধ্যে মানুষের সাইকোলজি এবং গুগল সার্চ ট্রেন্ড বিশ্লেষণ করে আপনাকে সেরা অপশনগুলো সাজেস্ট করবে। এটি আপনার সময় বাঁচায় এবং ব্রেইনস্টর্মিংয়ের ঝামেলা দূর করে।
                        </p>
                    </div>
                    <div class="p-6 rounded-xl bg-white/5 border border-white/10 hover:border-cyan-400/30 transition-all">
                        <h3 class="text-xl font-bold text-cyan-400 mb-3 bangla-font-siliguri flex items-center gap-2">
                            <span class="text-2xl">💡</span> করলে কি লাভ? (Core Benefits)
                        </h3>
                        <ul class="list-disc pl-5 text-sm text-gray-300 bangla-font-siliguri space-y-2">
                            <li>সার্চ ইঞ্জিনের প্রথম পাতায় র‍্যাংক করার জন্য অপ্টিমাইজড কি-ওয়ার্ড সমৃদ্ধ টাইটেল পাওয়া যায়।</li>
                            <li>অর্গানিক ক্লিক-থ্রু-রেট (CTR) ১০০% পর্যন্ত বৃদ্ধি পায়।</li>
                            <li>ইউটিউব ভিডিও এবং ফেসবুক পোস্টের ক্যাপশন হিসেবেও ব্যবহার করা যায়।</li>
                            <li>গুগল অ্যাডসেন্স আয়ের সুযোগ বৃদ্ধি পায় কারণ ভিজিটর এঙ্গেজমেন্ট বাড়ে।</li>
                        </ul>
                    </div>
                </section>

                <section class="p-6 md:p-8 rounded-2xl bg-gradient-to-br from-pink-900/20 to-rose-900/20 border border-white/10">
                    <h3 class="text-2xl font-bold text-white mb-6 bangla-font-siliguri flex items-center gap-2">
                        <span class="text-rose-400">⚙️</span> কিভাবে কাজ করবেন? (Step-by-Step Guide)
                    </h3>
                    <div class="space-y-4">
                        <div class="flex items-start gap-4">
                            <div class="w-8 h-8 rounded-full bg-rose-500/20 flex items-center justify-center text-rose-400 font-bold shrink-0">১</div>
                            <p class="text-gray-300 bangla-font-siliguri pt-1">প্রথমে আপনার ব্লগের মূল টপিক বা কিওয়ার্ড ইনপুট বক্সে লিখুন (যেমন: "Online Income" বা "Weight Loss")।</p>
                        </div>
                        <div class="flex items-start gap-4">
                            <div class="w-8 h-8 rounded-full bg-rose-500/20 flex items-center justify-center text-rose-400 font-bold shrink-0">২</div>
                            <p class="text-gray-300 bangla-font-siliguri pt-1">আপনার কাঙ্ক্ষিত ভাষা (বাংলা বা ইংরেজি) নির্বাচন করুন।</p>
                        </div>
                        <div class="flex items-start gap-4">
                            <div class="w-8 h-8 rounded-full bg-rose-500/20 flex items-center justify-center text-rose-400 font-bold shrink-0">৩</div>
                            <p class="text-gray-300 bangla-font-siliguri pt-1">"Generate Titles" বাটনে ক্লিক করুন এবং নিউরাল ইঞ্জিনের জাদুর অপেক্ষা করুন।</p>
                        </div>
                        <div class="flex items-start gap-4">
                            <div class="w-8 h-8 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-400 font-bold shrink-0">৪</div>
                            <p class="text-gray-300 bangla-font-siliguri pt-1">ফলাফল থেকে আপনার পছন্দের সবচেয়ে আকর্ষণীয় টাইটেলটি কপি করে আপনার ব্লগে ব্যবহার করুন।</p>
                        </div>
                    </div>
                </section>
            </div>
        ',
        'html-minifier' => '
            <div class="manual-seo-article space-y-10 font-sans text-gray-200">
                <div class="header-badge inline-flex items-center gap-2 px-3 py-1 rounded-full bg-orange-500/10 border border-orange-500/30 text-orange-400 text-xs font-mono uppercase tracking-wider">
                    ⚡ Web Performance Optimizer
                </div>
                
                <section>
                    <h2 class="text-3xl md:text-4xl font-extrabold text-white bangla-font-siliguri leading-snug mb-6">
                        ' . $name . ' (' . $name_en . ') - স্পিড অপ্টিমাইজেশন গাইড
                    </h2>
                    <p class="text-base md:text-lg leading-relaxed text-gray-300 bangla-font-siliguri text-justify">
                        <strong>' . $name_en . '</strong> ডেভেলপার এবং ওয়েবমাস্টারদের জন্য একটি এসেন্সিয়াল টুল। ওয়েবসাইটের সোর্স কোডে থাকা অতিরিক্ত স্পেস, লাইন ব্রেক এবং কমেন্টগুলো রিমুভ করে ফাইলের সাইজ ছোট করার প্রক্রিয়াকে মিনিফিকেশন (Minification) বলা হয়। এটি আপনার HTML ফাইলের অপ্রয়োজনীয় অংশ ছেঁটে ফেলে ব্রাউজার রেন্ডারিং স্পিড ফাস্ট করতে সাহায্য করে।
                    </p>
                </section>

                <section class="grid grid-cols-1 md:grid-cols-2 gap-6 my-8">
                    <div class="p-6 rounded-xl bg-white/5 border border-white/10 hover:border-orange-500/30 transition-all">
                        <h3 class="text-xl font-bold text-orange-400 mb-3 bangla-font-siliguri flex items-center gap-2">
                            <span class="text-2xl">🤔</span> কেন ব্যবহার করবেন? (Why Use It?)
                        </h3>
                        <p class="text-sm text-gray-300 bangla-font-siliguri leading-relaxed">
                            গুগল সব সময় ফাস্ট লোডিং ওয়েবসাইট পছন্দ করে (Core Web Vitals)। ম্যানুয়ালি কোড থেকে স্পেস রিমুভ করা অনেক কঠিন এবং ভুল হওয়ার সম্ভাবনা থাকে। এই টুলটি স্বয়ংক্রিয়ভাবে ১০০% নির্ভুলভাবে কোড মিনিফাই করে আপনার পেজের লোডিং স্পিড বুস্ট করে।
                        </p>
                    </div>
                    <div class="p-6 rounded-xl bg-white/5 border border-white/10 hover:border-cyan-400/30 transition-all">
                        <h3 class="text-xl font-bold text-cyan-400 mb-3 bangla-font-siliguri flex items-center gap-2">
                            <span class="text-2xl">💡</span> করলে কি লাভ? (Core Benefits)
                        </h3>
                        <ul class="list-disc pl-5 text-sm text-gray-300 bangla-font-siliguri space-y-2">
                            <li>ওয়েবসাইটের ফাইল সাইজ ২০-৩০% কমে যায়।</li>
                            <li>সার্ভারের ব্যান্ডউইথ খরচ সাশ্রয় হয়।</li>
                            <li>গুগল পেজস্পিড ইনসাইট (PageSpeed Insights) স্কোর বৃদ্ধি পায়।</li>
                            <li>ভিজিটররা দ্রুত সাইট অ্যাক্সেস করতে পারে, বাউন্স রেট কমে।</li>
                        </ul>
                    </div>
                </section>

                <section class="p-6 md:p-8 rounded-2xl bg-gradient-to-br from-orange-900/20 to-red-900/20 border border-white/10">
                    <h3 class="text-2xl font-bold text-white mb-6 bangla-font-siliguri flex items-center gap-2">
                        <span class="text-orange-400">⚙️</span> কিভাবে কাজ করবেন? (Step-by-Step Guide)
                    </h3>
                    <div class="space-y-4">
                        <div class="flex items-start gap-4">
                            <div class="w-8 h-8 rounded-full bg-orange-500/20 flex items-center justify-center text-orange-400 font-bold shrink-0">১</div>
                            <p class="text-gray-300 bangla-font-siliguri pt-1">আপনার র (Raw) HTML কোড কপি করুন।</p>
                        </div>
                        <div class="flex items-start gap-4">
                            <div class="w-8 h-8 rounded-full bg-orange-500/20 flex items-center justify-center text-orange-400 font-bold shrink-0">২</div>
                            <p class="text-gray-300 bangla-font-siliguri pt-1">টুলের ইনপুট বক্সে কোডগুলো পেস্ট করুন।</p>
                        </div>
                        <div class="flex items-start gap-4">
                            <div class="w-8 h-8 rounded-full bg-orange-500/20 flex items-center justify-center text-orange-400 font-bold shrink-0">৩</div>
                            <p class="text-gray-300 bangla-font-siliguri pt-1">"Minify HTML" বাটনে ক্লিক করুন।</p>
                        </div>
                        <div class="flex items-start gap-4">
                            <div class="w-8 h-8 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-400 font-bold shrink-0">৪</div>
                            <p class="text-gray-300 bangla-font-siliguri pt-1">আউটপুট বক্সে মিনিফাইড কোড জেনারেট হবে, "Copy" বাটনে ক্লিক করে সরাসরি প্রোডাকশন সার্ভারে ব্যবহার করুন।</p>
                        </div>
                    </div>
                </section>
            </div>
        '
    ];

    if (isset($articles[$slug])) {
        return $articles[$slug];
    }
    return '';
}
