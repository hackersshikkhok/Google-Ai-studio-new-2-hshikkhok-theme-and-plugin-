<?php
/**
 * Standalone Device & Phone Reviews Autopilot Engine
 * Path: inc/device-reviews-autopilot.php
 * Handles AI-driven smartphone & laptop review generation, display markups, fallbacks, and admin management console.
 */

if (!defined('ABSPATH')) exit;

/**
 * 1. Admin Dashboard Menu & Panel Handler
 */
if (!function_exists('ilybd_register_device_reviews_menu')) {
    function ilybd_register_device_reviews_menu() {
        $parent_slugs = array('ilybd-settings', 'ily-settings', 'ily-seo-dashboard');
        foreach ($parent_slugs as $parent) {
            add_submenu_page(
                $parent,
                'Device Reviews Autopilot Console',
                '📱 Device Review Autopilot',
                'manage_options',
                'ilybd-review-autopilot',
                'ilybd_render_review_autopilot_page'
            );
        }
    }
}
add_action('admin_menu', 'ilybd_register_device_reviews_menu', 22);

/**
 * 2. Render Admin Page for Device Reviews Autopilot
 */
if (!function_exists('ilybd_render_review_autopilot_page')) {
    function ilybd_render_review_autopilot_page() {
        $message = function_exists('ilybd_handle_autopilot_manual_trigger') ? ilybd_handle_autopilot_manual_trigger() : '';
        $review_enabled = get_option('ilybd_enable_phone_review_section', 'yes');
        $review_pilot = get_option('ilybd_phone_review_autopilot_enabled', 'yes');
        $review_count = intval(get_option('ilybd_phone_review_daily_count', 1));
        $review_frequency = get_option('ilybd_phone_review_frequency', 'daily');
        $review_display_count = intval(get_option('ilybd_phone_review_display_count', 5));
        ?>
        <div class="wrap" style="background:#070b13; color:#c9d1d9; padding:25px; border-radius:14px; border:1px solid #3fb950; font-family:system-ui; max-width:900px; margin-top:20px; box-shadow:0 0 25px rgba(63,185,80,0.15);">
            <h1 style="color:#3fb950; text-align:center; font-weight:800; text-transform:uppercase; letter-spacing:1px; margin-bottom:5px;">📱 Phone & Device Reviews Autopilot Control</h1>
            <p style="text-align:center; color:#8b949e; margin-bottom:25px;">Standalone Autopilot Module for Smartphones & Laptops Specifications, Prices, and Pros/Cons Reviews</p>

            <?php if (!empty($message)) : ?>
                <div style="background:rgba(63,185,80,0.1); border:1.5px solid #3fb950; color:#3fb950; padding:15px; border-radius:8px; margin-bottom:20px; font-weight:bold; font-size:14px;">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <form method="post" action="options.php">
                <?php settings_fields('ilybd_nextgen_group'); ?>
                <div style="background:#0d1527; border: 1px solid rgba(63,185,80,0.25); border-radius:12px; padding:25px; margin-bottom:20px;">
                    <div style="margin-bottom:20px;">
                        <label style="display:block; font-size:13px; font-weight:bold; color:#fff; margin-bottom:8px;">Section Visibility (Show/Hide in Site):</label>
                        <select name="ilybd_enable_phone_review_section" style="width:100%; background:#070b13; color:#3fb950; border:1px solid rgba(63,185,80,0.3); padding:12px; border-radius:6px; font-weight:bold;">
                            <option value="yes" <?php selected($review_enabled, 'yes'); ?>>Visible (SHOW)</option>
                            <option value="no" <?php selected($review_enabled, 'no'); ?>>Hidden (HIDE)</option>
                        </select>
                    </div>

                    <div style="margin-bottom:20px;">
                        <label style="display:block; font-size:13px; font-weight:bold; color:#fff; margin-bottom:8px;">Autopilot AI Writer Status:</label>
                        <select name="ilybd_phone_review_autopilot_enabled" style="width:100%; background:#070b13; color:#00f0ff; border:1px solid rgba(0,240,255,0.3); padding:12px; border-radius:6px; font-weight:bold;">
                            <option value="yes" <?php selected($review_pilot, 'yes'); ?>>Enabled / ON (Auto Posts Active)</option>
                            <option value="no" <?php selected($review_pilot, 'no'); ?>>Disabled / OFF (No Auto Posts)</option>
                        </select>
                    </div>

                    <div style="margin-bottom:20px;">
                        <label style="display:block; font-size:13px; font-weight:bold; color:#fff; margin-bottom:8px;">Autopilot Frequency (কতক্ষণ পর পর রিভিউ তৈরি হবে):</label>
                        <select name="ilybd_phone_review_frequency" style="width:100%; background:#070b13; color:#fff; border:1px solid rgba(255,255,255,0.2); padding:12px; border-radius:6px; font-weight:bold;">
                            <option value="daily" <?php selected($review_frequency, 'daily'); ?>>Every 24 Hours (প্রতিদিন ১ বার)</option>
                            <option value="custom_12_hours" <?php selected($review_frequency, 'custom_12_hours'); ?>>Every 12 Hours (প্রতি ১২ ঘণ্টায় ১ বার)</option>
                            <option value="custom_6_hours" <?php selected($review_frequency, 'custom_6_hours'); ?>>Every 6 Hours (প্রতি ৬ ঘণ্টায় ১ বার)</option>
                            <option value="custom_4_hours" <?php selected($review_frequency, 'custom_4_hours'); ?>>Every 4 Hours (প্রতি ৪ ঘণ্টায় ১ বার)</option>
                            <option value="custom_3_hours" <?php selected($review_frequency, 'custom_3_hours'); ?>>Every 3 Hours (প্রতি ৩ ঘণ্টায় ১ বার)</option>
                            <option value="custom_2_hours" <?php selected($review_frequency, 'custom_2_hours'); ?>>Every 2 Hours (প্রতি ২ ঘণ্টায় ১ বার)</option>
                            <option value="hourly" <?php selected($review_frequency, 'hourly'); ?>>Every 1 Hour (প্রতি ১ ঘণ্টায় ১ বার)</option>
                        </select>
                    </div>

                    <div style="margin-bottom:20px;">
                        <label style="display:block; font-size:13px; font-weight:bold; color:#fff; margin-bottom:8px;">Posts Count per Cycle (প্রতি চক্রে কয়টি জেনারেট হবে):</label>
                        <select name="ilybd_phone_review_daily_count" style="width:100%; background:#070b13; color:#fff; border:1px solid rgba(255,255,255,0.2); padding:12px; border-radius:6px; font-weight:bold;">
                            <?php for($n=1; $n<=10; $n++): ?>
                                <option value="<?php echo $n; ?>" <?php selected($review_count, $n); ?>><?php echo $n; ?> Review Posts / Cycle</option>
                            <?php endfor; ?>
                        </select>
                    </div>

                    <div style="margin-bottom:20px;">
                        <label style="display:block; font-size:13px; font-weight:bold; color:#fff; margin-bottom:8px;">Homepage Display Limit (হোমপেজে ডিসপ্লে সংখ্যা):</label>
                        <select name="ilybd_phone_review_display_count" style="width:100%; background:#070b13; color:#3fb950; border:1px solid rgba(63,185,80,0.3); padding:12px; border-radius:6px; font-weight:bold;">
                            <?php for($n=1; $n<=20; $n++): ?>
                                <option value="<?php echo $n; ?>" <?php selected($review_display_count, $n); ?>><?php echo $n; ?> Reviews (Default 5)</option>
                            <?php endfor; ?>
                        </select>
                    </div>

                    <div style="display:flex; gap:15px; margin-top:25px;">
                        <button type="submit" class="button button-primary" style="flex:1; background:linear-gradient(90deg, #3fb950 0%, #2ea043 100%); color:#000; border:none; padding:12px; border-radius:6px; font-weight:800; font-size:13px; cursor:pointer;">💾 SAVE REVIEW SETTINGS</button>
                        <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=ilybd-review-autopilot&trigger_pilot=review'), 'ilybd_trigger_pilot_action'); ?>" class="button button-secondary" style="flex:1; text-align:center; background:#0d2818; color:#3fb950; border:1px solid #3fb950; padding:12px; border-radius:6px; font-weight:800; font-size:13px; text-decoration:none;">⚡ TRIGGER DEVICE REVIEW GENERATOR NOW</a>
                    </div>
                </div>
            </form>
        </div>
        <?php
    }
}

/**
 * 3. Device Review Autopilot Trigger Generator
 */
if (!function_exists('ilybd_trigger_phone_review_autopilot')) {
    function ilybd_trigger_phone_review_autopilot() {
        $api_keys = function_exists('ily_get_all_rotated_api_keys') ? ily_get_all_rotated_api_keys() : [];
        if (empty($api_keys)) {
            return new WP_Error('no_keys', 'কোনো সচল Gemini API Key পাওয়া যায়নি।');
        }

        $terms = get_terms(['taxonomy' => 'phone_brand', 'hide_empty' => false]);
        if (!is_wp_error($terms) && !empty($terms)) {
            $selected_term = $terms[array_rand($terms)];
            $brand_name = $selected_term->name;
            $brand_slug = $selected_term->slug;
            $brand_id = $selected_term->term_id;
        } else {
            $brand_name = 'Samsung';
            $brand_slug = 'samsung';
            $brand_id = 0;
        }

        if ($brand_id == 0) {
            $term = term_exists($brand_slug, 'phone_brand');
            if ($term) {
                $brand_id = is_array($term) ? $term['term_id'] : $term;
            } else {
                $inserted = wp_insert_term($brand_name, 'phone_brand', ['slug' => $brand_slug]);
                if (!is_wp_error($inserted)) {
                    $brand_id = $inserted['term_id'];
                }
            }
        }

        $device_models = [
            'Apple'   => ['iPhone 17 Pro Max', 'iPhone SE 4', 'MacBook Air M4', 'MacBook Pro M4 Max', 'iPad Pro M4', 'iPhone 16 Pro'],
            'Samsung' => ['Galaxy S26 Ultra', 'Galaxy Z Fold 8', 'Galaxy A57 5G', 'Galaxy Book5 Ultra', 'Galaxy S25 FE'],
            'Xiaomi'  => ['Xiaomi 15 Ultra', 'Redmi Note 15 Pro+', 'Poco F8 GT', 'Xiaomi Book 14', 'RedmiBook Pro 15'],
            'OnePlus' => ['OnePlus 13 Pro', 'OnePlus Nord 5', 'OnePlus Pad 2', 'OnePlus 13R'],
            'Realme'  => ['Realme GT Neo 7', 'Realme 13 Pro+', 'Realme Book Slim', 'Realme GT 6'],
            'Vivo'    => ['Vivo X100 Pro', 'Vivo V40 Pro', 'Vivo Pad 3', 'Vivo V50 Ultra'],
            'Oppo'    => ['Oppo Find X8 Pro', 'Oppo Reno 13 Pro', 'Oppo Find N4 Flip', 'Oppo K13'],
            'Infinix' => ['Infinix GT 30 Pro', 'Infinix Zero 40', 'Infinix Note 50 Pro+', 'Infinix Hot 50'],
            'Motorola'=> ['Motorola Edge 60 Ultra', 'Moto G84', 'Motorola Razr 50 Ultra', 'Moto G Power'],
            'Nothing' => ['Nothing Phone 3', 'Nothing Phone 2a', 'Nothing Phone 3 Pro'],
            'Tecno'   => ['Tecno Camon 30 Premier', 'Tecno Phantom V Fold 2', 'Tecno Spark 30 Pro'],
            'Huawei'  => ['Huawei Pura 70 Ultra', 'Huawei Mate 70 Pro', 'Huawei Nova 13'],
            'Google'  => ['Google Pixel 9 Pro XL', 'Google Pixel 9a', 'Google Pixel Fold 2'],
            'Honor'   => ['Honor Magic 7 Pro', 'Honor 200 Pro', 'Honor X100'],
            'HP'      => ['HP Spectre x360', 'HP Victus 16', 'HP Pavilion Plus 14', 'HP Omen Transcend 14', 'HP Envy x360'],
            'Dell'    => ['Dell XPS 13 Plus', 'Dell Inspiron 16', 'Dell G15 Gaming', 'Dell Alienware m16', 'Dell Latitude 7440'],
            'Lenovo'  => ['Lenovo ThinkPad X1 Carbon', 'Lenovo Legion Pro 7i', 'Lenovo Yoga Book 9i', 'Lenovo IdeaPad Slim 5'],
            'Asus'    => ['Asus ROG Zephyrus G14', 'Asus Zenbook S 13 OLED', 'Asus TUF Gaming A15', 'Asus Vivobook Pro 15'],
            'Acer'    => ['Acer Predator Helios 16', 'Acer Swift Go 14', 'Acer Nitro V 15', 'Acer Aspire 5'],
            'MSI'     => ['MSI Raider GE78', 'MSI Cyborg 15', 'MSI Prestige 16 AI', 'MSI Modern 14']
        ];

        if (isset($device_models[$brand_name])) {
            $models = $device_models[$brand_name];
            $selected_device = $models[array_rand($models)];
        } else {
            $fallback_prompt = "Name exactly one popular, highly searched smartphone model for the brand '{$brand_name}' that is trending in Bangladesh. Example format: '{$brand_name} Model 12 Pro'. STRICT RULE: Return ONLY the exact model name, no quotes, no labels.";
            $fallback_res = ily_call_gemini_api_direct($api_keys, $fallback_prompt, 100);
            $selected_device = !is_wp_error($fallback_res) ? trim($fallback_res, "\"'#\n\r ") : $brand_name . " Pro Max 5G";
            $selected_device = preg_replace('/^Model:\s*/i', '', $selected_device);
        }

        $device_type = 'smartphone';
        $laptop_identifiers = ['MacBook', 'Laptop', 'Book', 'Spectre', 'Victus', 'Pavilion', 'Omen', 'Envy', 'XPS', 'Inspiron', 'Alienware', 'Latitude', 'ThinkPad', 'Legion', 'Yoga', 'IdeaPad', 'Zephyrus', 'Zenbook', 'TUF', 'Vivobook', 'Predator', 'Swift', 'Nitro', 'Aspire', 'Raider', 'Cyborg', 'Prestige', 'Modern', 'HP', 'Dell', 'Lenovo', 'Acer', 'MSI'];
        
        foreach ($laptop_identifiers as $identifier) {
            if (stripos($selected_device, $identifier) !== false || in_array($brand_name, ['HP', 'Dell', 'Lenovo', 'Acer', 'MSI'])) {
                $device_type = 'laptop';
                break;
            }
        }

        $title_prompt = "Generate a highly viral, professional tech review title for the device: '{$selected_device}'. It must include the model name and 'Price in Bangladesh' or 'Review' (e.g. 'Oppo Find X8 Pro Review & Price in Bangladesh - ফুল স্পেসিফিকেশন ও চূড়ান্ত রিভিউ'). STRICT RULE: Return ONLY the exact title under 15 words, nothing else. No quotes, no labels, no hashtags.";
        $title_res = ily_call_gemini_api_direct($api_keys, $title_prompt, 150);
        $title = !is_wp_error($title_res) ? trim($title_res, "\"'#\n\r ") : "{$selected_device} Review & Price in BD - ফুল স্পেসিফিকেশন ও চূড়ান্ত রিভিউ";
        $title = preg_replace('/^Title:\s*/i', '', $title);
        if (function_exists('ily_clean_ai_title_for_seo')) {
            $title = ily_clean_ai_title_for_seo($title);
        }

        if ($device_type === 'laptop') {
            $prompt = "You are a professional Hardware Laptop Reviewer and Chief Technology Editor. Write an advanced, comprehensive, highly engaging, and SEO-optimized review. MUST be written from a 100% human perspective, sharing practical insights, avoiding robotic filler text, passing AI detectors completely. Keep it strictly AdSense safe for '{$selected_device}'.\n\n" .
                      "STRUCTURE REQUIRED (HTML format, no markdown block wrappers):\n" .
                      "1. Title and Intro: Catchy H2 heading with 200+ words in Bengali.\n" .
                      "2. Detailed Design & Build: H3 heading.\n" .
                      "3. Display & Audio: H3 heading.\n" .
                      "4. Performance & Hardware: H3 heading.\n" .
                      "5. Full Specifications Table (HTML Table with class 'cyber-specs-table'): Processor, GPU, RAM, Storage, Display, Battery, OS, Weight, Price in BD.\n" .
                      "6. Rating Breakdown Block: `<div class=\"cyber-rating-grid\">` with `<div class=\"cyber-rating-card\"><h4>Category</h4><div class=\"score\">9.5/10</div></div>`.\n" .
                      "7. Pros & Cons: `<div class=\"cyber-pros-box\">` and `<div class=\"cyber-cons-box\">`.\n" .
                      "8. Buying Advice / Comparison: H3 heading.\n" .
                      "9. Verdict: H3 heading.\n\n" .
                      "Print clean HTML directly.";
        } else {
            $prompt = "You are a professional Hardware Smartphone Reviewer and Chief Technology Editor. Write an advanced, comprehensive, highly engaging, and SEO-optimized review for '{$selected_device}'.\n\n" .
                      "STRUCTURE REQUIRED (HTML format, no markdown block wrappers):\n" .
                      "1. Title and Intro: Catchy H2 heading with 200+ words in Bengali.\n" .
                      "2. Detailed Design & Build: H3 heading.\n" .
                      "3. Display & Multimedia: H3 heading.\n" .
                      "4. Performance & Gaming: H3 heading.\n" .
                      "5. Camera Review: H3 heading.\n" .
                      "6. Full Specifications Table (HTML Table with class 'cyber-specs-table'): Processor, RAM, ROM, Display, Battery, Front/Rear Camera, Price in BD.\n" .
                      "7. Rating Breakdown Block: `<div class=\"cyber-rating-grid\">` with `<div class=\"cyber-rating-card\"><h4>Category</h4><div class=\"score\">9.5/10</div></div>`.\n" .
                      "8. Pros & Cons: `<div class=\"cyber-pros-box\">` and `<div class=\"cyber-cons-box\">`.\n" .
                      "9. Buying Advice / Comparison: H3 heading.\n" .
                      "10. Verdict: H3 heading.\n\n" .
                      "Print clean HTML directly.";
        }

        $content = ily_call_gemini_api_direct($api_keys, $prompt, 6000, false, "You are a professional Chief Technology Editor writing human tech reviews in Bengali.", true, ['gemini-3.6-flash', 'gemini-3.5-flash', 'gemini-3.5-flash-lite', 'gemini-3.1-flash-lite', 'gemini-2.5-flash']);
        if (is_wp_error($content) || empty($content)) {
            $content = ilybd_get_phone_review_fallback($selected_device, $title);
        }

        $content_cleaned = preg_replace('/```[a-z]*\n/i', '', $content);
        $content_cleaned = str_replace('```', '', $content_cleaned);

        if (function_exists('ilybd_ai_seo_editor_review')) {
            $ai_editor_res = ilybd_ai_seo_editor_review($content_cleaned, 'Device Review', $title);
            if (!is_wp_error($ai_editor_res) && is_array($ai_editor_res) && !empty($ai_editor_res['content'])) {
                $content_cleaned = $ai_editor_res['content'];
                $seo_score = isset($ai_editor_res['score']) ? $ai_editor_res['score'] : 96;
            } else {
                $seo_score = 96;
            }
        } else {
            $seo_score = 96;
        }

        $author_id = function_exists('ilybd_get_rotated_author_id') ? ilybd_get_rotated_author_id() : 1;

        $post_id = wp_insert_post([
            'post_title'   => $title,
            'post_content' => $content_cleaned,
            'post_status'  => 'publish',
            'post_type'    => 'ilybd_phone_review',
            'post_author'  => $author_id
        ]);

        if (!is_wp_error($post_id) && $post_id > 0) {
            if ($brand_id > 0) {
                wp_set_post_terms($post_id, [$brand_id], 'phone_brand');
            }
            
            $tags_array = [
                $selected_device,
                "{$selected_device} Price in Bangladesh",
                "{$selected_device} Review",
                "{$selected_device} Price",
                "{$selected_device} Specs",
                "{$selected_device} রিভিউ",
                ($device_type === 'laptop' ? 'ল্যাপটপ রিভিউ' : 'স্মার্টফোন রিভিউ')
            ];
            
            wp_set_post_terms($post_id, $tags_array, 'phone_review_tag');

            update_post_meta($post_id, 'ilybd_seo_originality_score', $seo_score);
            update_post_meta($post_id, 'ilybd_seo_plagiarism_score', 100);
            update_post_meta($post_id, 'ilybd_seo_adsense_status', 'PASSED');
            update_post_meta($post_id, 'ilybd_device_type', $device_type);
            
            $thumb_keyword = "sleek modern " . ($device_type === 'laptop' ? 'laptop notebook' : 'smartphone mobile phone') . " studio product photography " . wp_strip_all_tags($selected_device) . " " . $brand_name;
            $rand_seed = rand(1001, 9999);
            $image_url = "https://image.pollinations.ai/prompt/" . urlencode($thumb_keyword) . "?width=1200&height=630&nologo=true&seed=" . $rand_seed . "&enhance=true&nofeed=true&model=flux";
            if (function_exists('ily_download_and_set_featured_image')) {
                ily_download_and_set_featured_image($post_id, $image_url);
            }
        }

        return $post_id;
    }
}

/**
 * 4. Device Review Section Homepage Markup
 */
if (!function_exists('ilybd_markup_phone_review_section')) {
    function ilybd_markup_phone_review_section() {
        $review_enabled = get_option('ilybd_enable_phone_review_section', 'yes');
        if ($review_enabled !== 'yes') return '';

        $display_count = intval(get_option('ilybd_phone_review_display_count', 5));
        $query = new WP_Query([
            'post_type'      => 'ilybd_phone_review',
            'posts_per_page' => $display_count,
            'post_status'    => 'publish'
        ]);

        if (!$query->have_posts()) return '';

        ob_start();
        ?>
        <section class="cyber-section phone-review-section" style="margin: 40px 0; background: #070b13; border: 1.5px solid rgba(63,185,80,0.2); border-radius: 16px; padding: 25px; box-shadow: 0 10px 30px rgba(0,0,0,0.5);">
            <div class="sec-header" style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid rgba(255,255,255,0.08); padding-bottom: 12px; margin-bottom: 20px;">
                <h2 style="color: #fff; font-size: 18px; margin: 0; font-weight: 800; display: flex; align-items: center; gap: 8px;">
                    <i class="fa-solid fa-mobile-screen-button" style="color: #3fb950;"></i>
                    স্মার্টফোন ও ডিভাইস রিভিউ (Device Reviews & Prices)
                </h2>
                <a href="<?php echo esc_url(get_post_type_archive_link('ilybd_phone_review') ?: home_url('/gadgets/')); ?>" style="color: #3fb950; font-size: 12px; font-weight: 700; text-decoration: none;">সবগুলো রিভিউ দেখুন →</a>
            </div>

            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 20px;">
                <?php while ($query->have_posts()) : $query->the_post(); 
                    $p_id = get_the_ID();
                    $thumb = get_the_post_thumbnail_url($p_id, 'medium') ?: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=600&q=80';
                    $brands = wp_get_post_terms($p_id, 'phone_brand');
                    $brand_name = !empty($brands) ? $brands[0]->name : 'Gadget';
                ?>
                    <article class="review-card" style="background: rgba(13,21,39,0.6); border: 1px solid rgba(255,255,255,0.06); border-radius: 12px; overflow: hidden; transition: 0.3s; display: flex; flex-direction: column;">
                        <a href="<?php the_permalink(); ?>" style="text-decoration: none; display: block; overflow: hidden; position: relative; height: 160px;">
                            <img src="<?php echo esc_url($thumb); ?>" alt="<?php the_title_attribute(); ?>" style="width: 100%; height: 100%; object-fit: cover; transition: 0.5s;" onmouseover="this.style.transform='scale(1.08)';" onmouseout="this.style.transform='scale(1)';">
                            <span style="position: absolute; top: 10px; left: 10px; background: #3fb950; color: #000; font-weight: 800; font-size: 10px; padding: 3px 8px; border-radius: 4px; text-transform: uppercase;">
                                <?php echo esc_html($brand_name); ?>
                            </span>
                        </a>
                        <div style="padding: 15px; flex: 1; display: flex; flex-direction: column; justify-content: space-between;">
                            <h3 style="margin: 0 0 10px 0; font-size: 14px; font-weight: 700; line-height: 1.4;">
                                <a href="<?php the_permalink(); ?>" style="color: #fff; text-decoration: none; transition: 0.2s;" onmouseover="this.style.color='#3fb950';" onmouseout="this.style.color='#fff';">
                                    <?php the_title(); ?>
                                </a>
                            </h3>
                            <a href="<?php the_permalink(); ?>" style="color: #3fb950; font-size: 12px; font-weight: 800; text-decoration: none; display: inline-flex; align-items: center; gap: 5px;">
                                বিস্তারিত ও সঠিক দাম <i class="fa-solid fa-arrow-right"></i>
                            </a>
                        </div>
                    </article>
                <?php endwhile; wp_reset_postdata(); ?>
            </div>
        </section>
        <?php
        return ob_get_clean();
    }
}

/**
 * 5. Device Review Fallback Generator
 */
if (!function_exists('ilybd_get_phone_review_fallback')) {
    function ilybd_get_phone_review_fallback($selected_device, $title) {
        return "<p><strong>{$selected_device}</strong> হলো বর্তমান প্রিমিয়াম টেক্স প্ল্যাটফর্মের অন্যতম আকর্ষণীয় ও শক্তিশালী ডিভাইস। অত্যন্ত উন্নত প্রসেসর এবং মেমরি আর্কিটেকচার দ্বারা তৈরি এই গ্যাজেটটি ব্যবহারকারীদের পারফরম্যান্সে দেবে এক নতুন মাত্রা।</p>" .
               "<h3>ডিজাইন ও বিল্ড কোয়ালিটি</h3><p>ডিভাইসটির প্রিমিয়াম ফিনিশিং এবং হাতের স্পর্শে আরামদায়ক গ্রিপ ব্যবহারকারীকে মুগ্ধ করবে। এর বডি গ্লাস ও প্রিমিয়াম ফ্রেমওয়ার্ক মেটেরিয়াল দিয়ে সুরক্ষিত।</p>" .
               "<h3>ডিসপ্লে ও পারফরম্যান্স</h3><p>উচ্চ রিফ্রেশ রেট এবং দারুণ রেজুলেশনের ডিসপ্লে দিয়ে যেকোনো হাই-এন্ড গেম ও ৪কে ভিডিও মসৃণভাবে উপভোগ করা যাবে।</p>" .
               "<table class=\"cyber-specs-table\"><tr><th>স্পেসিফিকেশন</th><th>বিস্তারিত</th></tr><tr><td>প্রসেসর</td><td>Advanced Octa-Core Chipset</td></tr><tr><td>মেমরি</td><td>8GB / 12GB RAM</td></tr><tr><td>আনুমানিক বাজারমূল্য</td><td>অফিসিয়াল তথ্য অনুযায়ী</td></tr></table>" .
               "<div class=\"cyber-pros-box\"><h4>সুবিধাসমূহ</h4><ul><li>চমৎকার ক্যামেরা ও নাইট মোড</li><li>দীর্ঘস্থায়ী ব্যাটারি ব্যাকআপ</li></ul></div>" .
               "<h3>চূড়ান্ত রায়</h3><p>আপনার বাজেট ও চাহিদার সাথে মিল থাকলে {$selected_device} হতে পারে এই বছরের অন্যতম সেরা নির্বাচন।</p>";
    }
}
