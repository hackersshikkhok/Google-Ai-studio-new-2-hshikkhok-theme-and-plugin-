<?php
if (!defined('ABSPATH')) {
    exit;
}

class ILYBD_Neon_Theme_Updater {
    public $theme_slug;
    public $version;
    public $api_url;
    public $cache_key;
    public $cache_allowed;

    public function __construct($theme_slug, $version, $api_url) {
        $this->theme_slug = $theme_slug;
        $this->version = $version;
        $this->api_url = $api_url;
        $this->cache_key = 'ilybd_theme_updater_cache';
        $this->cache_allowed = false;

        add_filter('site_transient_update_themes', array($this, 'check_update'));
        add_filter('transient_update_themes', array($this, 'check_update'));
        
        // Register settings
        add_action('admin_init', array($this, 'register_settings'));
    }

    public function register_settings() {
        register_setting('ilybd_theme_settings_group', 'ilybd_auto_update_enabled');
    }

    public function request() {
        $remote = get_transient($this->cache_key);

        if (false === $remote || !$this->cache_allowed) {
            $remote = wp_remote_get($this->api_url, array(
                'timeout' => 10,
                'headers' => array(
                    'Accept' => 'application/json'
                )
            ));

            if (is_wp_error($remote) || 200 !== wp_remote_retrieve_response_code($remote) || empty(wp_remote_retrieve_body($remote))) {
                return false;
            }

            set_transient($this->cache_key, $remote, HOUR_IN_SECONDS);
        }

        $remote = json_decode(wp_remote_retrieve_body($remote));
        return $remote;
    }

    function check_update($transient) {
        if (empty($transient->checked)) {
            return $transient;
        }

        $remote = $this->request();

        if ($remote && isset($remote->theme)) {
            $is_auto_update = get_option('ilybd_auto_update_enabled', 'manual');
            
            if (version_compare($this->version, $remote->theme->version, '<')) {
                $res = new stdClass();
                $res->theme = $this->theme_slug;
                $res->new_version = $remote->theme->version;
                $res->package = $remote->theme->url;
                $res->url = 'https://ais-pre-kj7sbotbfspb77im7cw3wt-262755331586.asia-southeast1.run.app';
                $transient->response[$this->theme_slug] = (array) $res;
                
                // If auto update is strictly selected as auto, we can hook it or let WP handle it.
                // WP 5.5+ handles auto updates natively if the user enables it in the UI.
                // We'll respect WP's native auto-update UI by providing the correct package structure.
            }
        }

        return $transient;
    }
}

function ilybd_neon_theme_updater_init() {
    $theme = wp_get_theme('ilybd-neon-v1-pro');
    $version = $theme->get('Version');
    if (!$version) $version = '1.0.0';
    $api_url = 'https://ais-pre-kj7sbotbfspb77im7cw3wt-262755331586.asia-southeast1.run.app/api/wordpress/version-info';
    new ILYBD_Neon_Theme_Updater('ilybd-neon-v1-pro', $version, $api_url);
}

add_action('init', 'ilybd_neon_theme_updater_init');

// Add settings to the custom admin page (hooked via ily-admin-settings.php usually)
add_action('admin_menu', 'ilybd_updater_settings_menu', 99);
function ilybd_updater_settings_menu() {
    add_submenu_page(
        'ily-settings',
        'System Updates',
        'System Updates',
        'manage_options',
        'ilybd-system-updates',
        'ilybd_updater_settings_page'
    );
}

function ilybd_updater_settings_page() {
    if (isset($_POST['ilybd_update_settings_nonce']) && wp_verify_nonce($_POST['ilybd_update_settings_nonce'], 'ilybd_save_update_settings')) {
        update_option('ilybd_auto_update_enabled', sanitize_text_field($_POST['ilybd_auto_update_enabled']));
        echo '<div class="updated"><p>Update settings saved.</p></div>';
    }
    
    $current_setting = get_option('ilybd_auto_update_enabled', 'manual');
    ?>
    <div class="wrap">
        <h2>IBD System Updates</h2>
        <form method="post" action="">
            <?php wp_nonce_field('ilybd_save_update_settings', 'ilybd_update_settings_nonce'); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Update Mode</th>
                    <td>
                        <select name="ilybd_auto_update_enabled">
                            <option value="manual" <?php selected($current_setting, 'manual'); ?>>Manual Update via Updates Page</option>
                            <option value="auto" <?php selected($current_setting, 'auto'); ?>>Force Auto-Update (Background)</option>
                        </select>
                        <p class="description">Select how you want to receive updates from AI Studio. Note: WordPress also has its own native auto-update toggles on the Themes and Plugins pages.</p>
                    </td>
                </tr>
            </table>
            <?php submit_button('Save Settings'); ?>
        </form>
    </div>
    <?php
}

// Hook to force auto updates if selected
add_filter('auto_update_theme', 'ilybd_force_auto_update_theme', 10, 2);
function ilybd_force_auto_update_theme($update, $item) {
    if (isset($item->theme) && $item->theme === 'ilybd-neon-v1-pro') {
        if (get_option('ilybd_auto_update_enabled') === 'auto') {
            return true;
        }
    }
    return $update;
}
