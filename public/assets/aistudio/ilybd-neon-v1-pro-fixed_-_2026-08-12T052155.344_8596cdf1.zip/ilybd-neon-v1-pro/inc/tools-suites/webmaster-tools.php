<?php
/**
 * Webmaster & Website Analysis Suite
 */


/* 1. Website Meta Tag Analyzer */
if (!function_exists('ilybd_render_tool_meta_tag_analyzer')) {
function ilybd_render_tool_meta_tag_analyzer() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">🌐 Website Meta Tag Analyzer / মেটা ট্যাগ এনালাইজার</h3>
    <p style="color:#94a3b8; font-size:13px; margin-bottom:12px;">Analyze HTML Title, Description length, Canonical URL, and Robots tags.</p>
    <textarea id="meta-input-html" rows="5" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; font-family:monospace; padding:10px; border-radius:6px;" placeholder="<title>Sample Title</title>\n<meta name=&quot;description&quot; content=&quot;Sample description text.&quot; />"></textarea>
    <button onclick="analyzeMetaTags()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🔍 Analyze Meta Code</button>
    <div id="meta-results-box" style="display:none; margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; border:1px solid #1e293b;"></div>
</div>
<script>
function analyzeMetaTags() {
    const raw = document.getElementById("meta-input-html").value.trim();
    const resBox = document.getElementById("meta-results-box");
    if(!raw) { alert("Paste HTML Meta Code!"); return; }
    const doc = new DOMParser().parseFromString(raw, "text/html");
    const title = doc.querySelector("title") ? doc.querySelector("title").textContent.trim() : "";
    const desc = doc.querySelector("meta[name='description']") ? doc.querySelector("meta[name='description']").getAttribute("content") : "";
    resBox.innerHTML = "<div style='color:#10b981; font-weight:bold;'>Title (" + title.length + " chars): " + (title || "Missing") + "</div><div style='color:#00f0ff; margin-top:5px;'>Description (" + desc.length + " chars): " + (desc || "Missing") + "</div>";
    resBox.style.display = "block";
}
</script>
<?php
}
}

/* 2. Open Graph Preview Generator */
if (!function_exists('ilybd_render_tool_open_graph_preview')) {
function ilybd_render_tool_open_graph_preview() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">🖼️ Open Graph Social Preview Generator</h3>
    <input type="text" id="og-title" value="Enterprise Cyber Tools 2040" placeholder="OG Title" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <input type="text" id="og-desc" value="Access 280+ high speed digital utility tools" placeholder="OG Description" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="renderOgCard()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Generate Social Card</button>
    <div id="og-card-box" style="margin-top:15px; background:#1877f2; padding:15px; border-radius:8px; color:#fff;">
        <div id="og-out-title" style="font-weight:bold; font-size:16px;">Enterprise Cyber Tools 2040</div>
        <div id="og-out-desc" style="font-size:13px; opacity:0.9;">Access 280+ high speed digital utility tools</div>
    </div>
</div>
<script>
function renderOgCard() {
    document.getElementById("og-out-title").innerText = document.getElementById("og-title").value;
    document.getElementById("og-out-desc").innerText = document.getElementById("og-desc").value;
}
</script>
<?php
}
}

/* 3. Twitter Card Preview */
if (!function_exists('ilybd_render_tool_twitter_card_preview')) {
function ilybd_render_tool_twitter_card_preview() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">🐦 Twitter / X Summary Card Preview</h3>
    <input type="text" id="tw-title" value="IBD Cyber Tools Platform" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="renderTw()" style="width:100%; background:#1d9bf0; color:#fff; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">⚡ Live X Preview</button>
    <div id="tw-box" style="margin-top:15px; background:#000; border:1px solid #333; padding:15px; border-radius:12px; color:#fff;">
        <div id="tw-out-t" style="font-weight:bold;">IBD Cyber Tools Platform</div>
    </div>
</div>
<script>
function renderTw() { document.getElementById("tw-out-t").innerText = document.getElementById("tw-title").value; }
</script>
<?php
}
}

/* 4. HTTP Status Code Checker */
if (!function_exists('ilybd_render_tool_http_status_checker')) {
function ilybd_render_tool_http_status_checker() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">🚦 HTTP Status Code Checker</h3>
    <input type="number" id="http-code" value="301" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; font-weight:bold; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="checkCode()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🔍 Check Meaning & SEO Impact</button>
    <div id="http-res" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">301 Moved Permanently - Passes PageRank Equity.</div>
</div>
<script>
function checkCode() {
    const c = document.getElementById("http-code").value;
    const m = { 200: "200 OK - Successful response.", 301: "301 Moved Permanently - Permanent redirect.", 404: "404 Not Found - Page missing.", 500: "500 Internal Error - Server issue." };
    document.getElementById("http-res").innerText = m[c] || (c + " HTTP Status Code");
}
</script>
<?php
}
}

/* 5. Redirect Chain Analyzer */
if (!function_exists('ilybd_render_tool_redirect_chain_analyzer')) {
function ilybd_render_tool_redirect_chain_analyzer() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">🔗 Redirect Chain Hop Counter</h3>
    <textarea id="redir-text" rows="3" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="http://a.com\nhttps://a.com\nhttps://www.a.com"></textarea>
    <button onclick="checkHops()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 Analyze Hops</button>
    <div id="redir-out" style="display:none; margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981;"></div>
</div>
<script>
function checkHops() {
    const lines = document.getElementById("redir-text").value.trim().split("\n").filter(Boolean);
    const out = document.getElementById("redir-out");
    out.innerHTML = "Redirect Hops: <strong>" + (lines.length - 1) + "</strong>";
    out.style.display = "block";
}
</script>
<?php
}
}

/* 6. Canonical Checker */
if (!function_exists('ilybd_render_tool_canonical_checker')) {
function ilybd_render_tool_canonical_checker() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">📌 Canonical URL Matcher</h3>
    <input type="text" id="c-p" value="https://example.com/item?id=1" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <input type="text" id="c-c" value="https://example.com/item" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="checkC()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Check Canonical Match</button>
    <div id="c-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Canonical strips query parameters correctly.</div>
</div>
<script>
function checkC() {
    const p = document.getElementById("c-p").value;
    const c = document.getElementById("c-c").value;
    document.getElementById("c-out").innerText = (p === c) ? "Self-referential Canonical URL." : "Parameter stripping Canonical URL.";
}
</script>
<?php
}
}

/* 7. Robots.txt Tester */
if (!function_exists('ilybd_render_tool_robots_txt_tester')) {
function ilybd_render_tool_robots_txt_tester() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">🤖 Robots.txt Rule Tester</h3>
    <textarea id="rob-rules" rows="3" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;">Disallow: /admin/</textarea>
    <input type="text" id="rob-path" value="/admin/dashboard" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin:10px 0;">
    <button onclick="testRob()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Test Allow/Disallow</button>
    <div id="rob-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#ef4444; font-weight:bold;">❌ DISALLOWED</div>
</div>
<script>
function testRob() {
    const r = document.getElementById("rob-rules").value;
    const p = document.getElementById("rob-path").value;
    const isD = r.includes("Disallow:") && p.startsWith(r.split("Disallow:")[1].trim());
    document.getElementById("rob-out").innerHTML = isD ? "<span style='color:#ef4444;'>❌ DISALLOWED</span>" : "<span style='color:#10b981;'>✅ ALLOWED</span>";
}
</script>
<?php
}
}

/* 8. XML Sitemap Validator */
if (!function_exists('ilybd_render_tool_sitemap_validator')) {
function ilybd_render_tool_sitemap_validator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">🗺️ XML Sitemap Linter</h3>
    <textarea id="sm-xml" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;"><urlset><url><loc>https://example.com</loc></url></urlset></textarea>
    <button onclick="lintSm()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🔍 Lint Sitemap XML</button>
    <div id="sm-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">✅ Valid XML Sitemap</div>
</div>
<script>
function lintSm() {
    const x = document.getElementById("sm-xml").value;
    const doc = new DOMParser().parseFromString(x, "text/xml");
    document.getElementById("sm-out").innerText = doc.querySelector("parsererror") ? "❌ Invalid XML" : "✅ Valid XML Sitemap";
}
</script>
<?php
}
}

/* 9. Response Header Viewer */
if (!function_exists('ilybd_render_tool_response_header_viewer')) {
function ilybd_render_tool_response_header_viewer() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">🛡️ HTTP Response Header Viewer</h3>
    <textarea id="head-text" rows="3" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;">strict-transport-security: max-age=31536000\nx-frame-options: SAMEORIGIN</textarea>
    <button onclick="parseH()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🔍 Parse Security Headers</button>
    <div id="head-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981;">HSTS & X-Frame-Options Present.</div>
</div>
<script>
function parseH() {
    const t = document.getElementById("head-text").value.toLowerCase();
    document.getElementById("head-out").innerText = (t.includes("hsts") || t.includes("strict")) ? "✅ Security headers active." : "⚠️ Security headers missing.";
}
</script>
<?php
}
}

/* 10. Content Size Analyzer */
if (!function_exists('ilybd_render_tool_content_size_analyzer')) {
function ilybd_render_tool_content_size_analyzer() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">📦 Content Size & Text Ratio Analyzer</h3>
    <textarea id="size-html" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="<p>Paste article HTML...</p>"></textarea>
    <button onclick="calcSize()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 Measure Bytes & Ratio</button>
    <div id="size-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#00f0ff;">Payload Size Measured.</div>
</div>
<script>
function calcSize() {
    const h = document.getElementById("size-html").value;
    const b = new Blob([h]).size;
    document.getElementById("size-out").innerHTML = "Payload Bytes: <strong>" + b + " bytes</strong> (" + (b/1024).toFixed(2) + " KB)";
}
</script>
<?php
}
}
