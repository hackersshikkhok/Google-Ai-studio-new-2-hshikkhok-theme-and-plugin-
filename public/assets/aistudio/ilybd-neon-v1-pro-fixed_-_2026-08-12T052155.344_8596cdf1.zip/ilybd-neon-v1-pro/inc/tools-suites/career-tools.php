<?php
/**
 * Freelancing & Career Suite
 */


/* 61. Freelance Quote Calculator */
if (!function_exists('ilybd_render_tool_freelance_quote_calculator')) {
function ilybd_render_tool_freelance_quote_calculator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">💼 Freelance Project Price Quote Calculator</h3>
    <input type="number" id="fq-hrs" value="20" placeholder="Estimated Hours" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <input type="number" id="fq-rate" value="35" placeholder="Hourly Rate ($)" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="calcFq()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Calculate Project Quote</button>
    <div id="fq-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Project Quote: $840.00 (Includes 20% revision buffer)</div>
</div>
<script>
function calcFq() {
    const h = parseFloat(document.getElementById("fq-hrs").value);
    const r = parseFloat(document.getElementById("fq-rate").value);
    const total = (h * r) * 1.2;
    document.getElementById("fq-out").innerText = "Recommended Project Quote: $" + total.toFixed(2) + " (Includes 20% revision buffer)";
}
</script>
<?php
}
}

/* 62. Freelance Income Target */
if (!function_exists('ilybd_render_tool_freelance_income_target')) {
function ilybd_render_tool_freelance_income_target() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">🎯 Freelance Monthly Income Target Calculator</h3>
    <input type="number" id="fi-goal" value="3000" placeholder="Target Monthly Net Income ($)" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="calcFi()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Calculate Minimum Hourly Rate</button>
    <div id="fi-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Required Hourly Rate: $37.50 / hour (100 billable hrs/mo)</div>
</div>
<script>
function calcFi() {
    const g = parseFloat(document.getElementById("fi-goal").value);
    document.getElementById("fi-out").innerText = "Required Hourly Rate: $" + ((g * 1.25) / 100).toFixed(2) + " / hour (~25 billable hrs/week)";
}
</script>
<?php
}
}

/* 63. Hourly Monthly Income */
if (!function_exists('ilybd_render_tool_hourly_monthly_income')) {
function ilybd_render_tool_hourly_monthly_income() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">💵 Hourly Pay to Salary & Monthly Income Converter</h3>
    <input type="number" id="hm-rate" value="25" placeholder="Hourly Wage ($)" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="calcHm()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Convert Wage</button>
    <div id="hm-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Monthly: $4,333.33 | Annual: $52,000.00</div>
</div>
<script>
function calcHm() {
    const r = parseFloat(document.getElementById("hm-rate").value);
    const yr = r * 40 * 52;
    document.getElementById("hm-out").innerText = "Monthly Gross: $" + (yr / 12).toFixed(2) + " | Annual Gross: $" + yr.toFixed(2);
}
</script>
<?php
}
}

/* 64. Job Application Tracker */
if (!function_exists('ilybd_render_tool_job_application_tracker')) {
function ilybd_render_tool_job_application_tracker() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">📌 Job Application Tracker</h3>
    <input type="text" id="ja-role" value="Senior Frontend Engineer" placeholder="Role Title" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <input type="text" id="ja-comp" value="TechCorp" placeholder="Company Name" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="saveJobApp()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Log Application</button>
    <div id="ja-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Logged: Senior Frontend Engineer at TechCorp (Status: Applied)</div>
</div>
<script>
function saveJobApp() {
    const r = document.getElementById("ja-role").value;
    const c = document.getElementById("ja-comp").value;
    document.getElementById("ja-out").innerText = "Logged: " + r + " at " + c + " (Status: Applied - Follow up in 7 days)";
}
</script>
<?php
}
}

/* 65. Interview Checklist */
if (!function_exists('ilybd_render_tool_interview_checklist')) {
function ilybd_render_tool_interview_checklist() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">📝 Interview Preparation Checklist</h3>
    <div style="color:#e2e8f0; font-size:13px; display:flex; flex-direction:column; gap:8px;">
        <label><input type="checkbox" checked> Research Company Products & Leadership</label>
        <label><input type="checkbox" checked> Prepare STAR stories for behavioral questions</label>
        <label><input type="checkbox"> Print 3 copies of updated Resume</label>
        <label><input type="checkbox"> Prepare 3 intelligent questions for interviewers</label>
    </div>
    <div style="margin-top:15px; background:#0b1120; padding:10px; border-radius:6px; color:#10b981; font-weight:bold;">Progress: 50% Prepared</div>
</div>
<?php
}
}

/* 66. Resume Keyword Checker */
if (!function_exists('ilybd_render_tool_resume_keyword_checker')) {
function ilybd_render_tool_resume_keyword_checker() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">📄 Resume ATS Keyword Match Checker</h3>
    <textarea id="rk-res" rows="3" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px; margin-bottom:10px;" placeholder="Paste Resume Text..."></textarea>
    <textarea id="rk-jd" rows="3" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px; margin-bottom:10px;" placeholder="Paste Job Description..."></textarea>
    <button onclick="checkRkMatch()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Scan ATS Keyword Match %</button>
    <div id="rk-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">ATS Keyword Match: 82%</div>
</div>
<script>
function checkRkMatch() {
    const r = document.getElementById("rk-res").value.toLowerCase();
    const j = document.getElementById("rk-jd").value.toLowerCase();
    const words = j.split(/\s+/).filter(w => w.length > 4);
    let matched = 0;
    words.forEach(w => { if(r.includes(w)) matched++; });
    const score = words.length ? ((matched / words.length) * 100).toFixed(0) : 80;
    document.getElementById("rk-out").innerText = "ATS Keyword Match Score: " + score + "%";
}
</script>
<?php
}
}

/* 67. Salary Comparison */
if (!function_exists('ilybd_render_tool_salary_comparison')) {
function ilybd_render_tool_salary_comparison() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⚖️ Job Offer Salary Comparison</h3>
    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(180px, 1fr)); gap:10px; margin-bottom:12px;">
        <input type="number" id="sc-o1" value="60000" placeholder="Offer 1 Base ($)" style="background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px;">
        <input type="number" id="sc-o2" value="70000" placeholder="Offer 2 Base ($)" style="background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px;">
    </div>
    <button onclick="calcSc()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Compare Offers</button>
    <div id="sc-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Offer 2 is $10,000/yr (16.67%) higher base salary.</div>
</div>
<script>
function calcSc() {
    const o1 = parseFloat(document.getElementById("sc-o1").value);
    const o2 = parseFloat(document.getElementById("sc-o2").value);
    const diff = o2 - o1;
    document.getElementById("sc-out").innerText = "Offer 2 is $" + diff.toFixed(2) + "/yr (" + ((diff/o1)*100).toFixed(2) + "%) higher base pay.";
}
</script>
<?php
}
}

/* 68. Notice Period Calculator */
if (!function_exists('ilybd_render_tool_notice_period_calculator')) {
function ilybd_render_tool_notice_period_calculator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">🗓️ Notice Period & Resignation Release Date</h3>
    <input type="date" id="np-start" value="2026-08-10" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; font-weight:bold; padding:10px; border-radius:6px; margin-bottom:10px;">
    <input type="number" id="np-days" value="30" placeholder="Notice Length (Days)" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="calcNp()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Calculate Last Working Day</button>
    <div id="np-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Last Working Day: Sep 9, 2026</div>
</div>
<script>
function calcNp() {
    const s = new Date(document.getElementById("np-start").value);
    const d = parseInt(document.getElementById("np-days").value);
    s.setDate(s.getDate() + d);
    document.getElementById("np-out").innerText = "Last Working Day: " + s.toDateString();
}
</script>
<?php
}
}

/* 69. Workday Calculator */
if (!function_exists('ilybd_render_tool_workday_calculator')) {
function ilybd_render_tool_workday_calculator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">📅 Business Workday Calculator</h3>
    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(180px, 1fr)); gap:10px; margin-bottom:12px;">
        <input type="date" id="wd-s" value="2026-08-01" style="background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px;">
        <input type="date" id="wd-e" value="2026-08-31" style="background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px;">
    </div>
    <button onclick="calcWd()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Calculate Business Days</button>
    <div id="wd-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Total Business Days: 22 Days</div>
</div>
<script>
function calcWd() {
    const d1 = new Date(document.getElementById("wd-s").value);
    const d2 = new Date(document.getElementById("wd-e").value);
    let count = 0;
    let cur = new Date(d1);
    while (cur <= d2) {
        const day = cur.getDay();
        if (day !== 0 && day !== 6) count++;
        cur.setDate(cur.getDate() + 1);
    }
    document.getElementById("wd-out").innerText = "Total Business Working Days: " + count + " Days";
}
</script>
<?php
}
}

/* 70. Freelance Workload Planner */
if (!function_exists('ilybd_render_tool_freelance_workload_planner')) {
function ilybd_render_tool_freelance_workload_planner() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">🔥 Freelance Workload & Burnout Risk Indicator</h3>
    <input type="number" id="wl-hrs" value="45" placeholder="Committed Hours This Week" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="calcWl()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Check Capacity & Burnout Risk</button>
    <div id="wl-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#f59e0b; font-weight:bold;">⚠️ High Workload (45 hrs/wk) - Moderate Burnout Risk. Take breaks!</div>
</div>
<script>
function calcWl() {
    const h = parseFloat(document.getElementById("wl-hrs").value);
    document.getElementById("wl-out").innerHTML = h > 50 
        ? "<span style='color:#ef4444;'>🚨 Critical Workload (" + h + " hrs/wk) - Severe Burnout Risk!</span>"
        : (h > 40 ? "<span style='color:#f59e0b;'>⚠️ High Workload (" + h + " hrs/wk) - Moderate Risk</span>" : "<span style='color:#10b981;'>✅ Healthy Balanced Workload (" + h + " hrs/wk)</span>");
}
</script>
<?php
}
}
