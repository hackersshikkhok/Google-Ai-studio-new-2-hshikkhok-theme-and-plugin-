<?php
/**
 * Business & E-Commerce Suite
 */


/* 51. Profit Margin Calculator */
if (!function_exists('ilybd_render_tool_profit_margin_calculator')) {
function ilybd_render_tool_profit_margin_calculator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">💼 Profit Margin & Gross Profit Calculator</h3>
    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(180px, 1fr)); gap:10px; margin-bottom:12px;">
        <input type="number" id="pm-cost" value="100" placeholder="Cost Price ($)" style="background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px;">
        <input type="number" id="pm-sale" value="150" placeholder="Selling Price ($)" style="background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px;">
    </div>
    <button onclick="calcPm()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Calculate Margin</button>
    <div id="pm-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Gross Profit: $50.00 (Margin: 33.33%)</div>
</div>
<script>
function calcPm() {
    const c = parseFloat(document.getElementById("pm-cost").value);
    const s = parseFloat(document.getElementById("pm-sale").value);
    const p = s - c;
    const m = (p / s) * 100;
    document.getElementById("pm-out").innerText = "Gross Profit: $" + p.toFixed(2) + " (Margin: " + m.toFixed(2) + "%)";
}
</script>
<?php
}
}

/* 52. Markup Calculator */
if (!function_exists('ilybd_render_tool_markup_calculator')) {
function ilybd_render_tool_markup_calculator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">🏷️ Business Markup Percentage Calculator</h3>
    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(180px, 1fr)); gap:10px; margin-bottom:12px;">
        <input type="number" id="mk-cost" value="100" placeholder="Cost ($)" style="background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px;">
        <input type="number" id="mk-sale" value="150" placeholder="Selling Price ($)" style="background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px;">
    </div>
    <button onclick="calcMk()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Calculate Markup %</button>
    <div id="mk-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Markup: 50.00%</div>
</div>
<script>
function calcMk() {
    const c = parseFloat(document.getElementById("mk-cost").value);
    const s = parseFloat(document.getElementById("mk-sale").value);
    const mk = ((s - c) / c) * 100;
    document.getElementById("mk-out").innerText = "Markup Percentage: " + mk.toFixed(2) + "%";
}
</script>
<?php
}
}

/* 53. Break-Even Calculator */
if (!function_exists('ilybd_render_tool_break_even_calculator')) {
function ilybd_render_tool_break_even_calculator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⚖️ Break-Even Point Sales Calculator</h3>
    <input type="number" id="be-fixed" value="5000" placeholder="Fixed Costs ($)" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <input type="number" id="be-price" value="50" placeholder="Price Per Unit ($)" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <input type="number" id="be-var" value="25" placeholder="Variable Cost Per Unit ($)" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="calcBe()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Calculate Break-Even Units</button>
    <div id="be-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Break-Even: 200 Units ($10,000 Revenue)</div>
</div>
<script>
function calcBe() {
    const f = parseFloat(document.getElementById("be-fixed").value);
    const p = parseFloat(document.getElementById("be-price").value);
    const v = parseFloat(document.getElementById("be-var").value);
    const u = f / (p - v);
    document.getElementById("be-out").innerText = "Break-Even Sales: " + Math.ceil(u) + " Units ($" + (Math.ceil(u)*p).toFixed(2) + " Revenue)";
}
</script>
<?php
}
}

/* 54. CAC Calculator */
if (!function_exists('ilybd_render_tool_cac_calculator')) {
function ilybd_render_tool_cac_calculator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">🎯 Customer Acquisition Cost (CAC) Calculator</h3>
    <input type="number" id="cac-mkt" value="2000" placeholder="Total Marketing Spend ($)" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <input type="number" id="cac-cust" value="100" placeholder="New Customers Acquired" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="calcCac()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Calculate CAC</button>
    <div id="cac-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">CAC: $20.00 / Customer</div>
</div>
<script>
function calcCac() {
    const m = parseFloat(document.getElementById("cac-mkt").value);
    const c = parseFloat(document.getElementById("cac-cust").value);
    document.getElementById("cac-out").innerText = "CAC: $" + (m / c).toFixed(2) + " / Customer";
}
</script>
<?php
}
}

/* 55. CLV Calculator */
if (!function_exists('ilybd_render_tool_clv_calculator')) {
function ilybd_render_tool_clv_calculator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">💎 Customer Lifetime Value (CLV/LTV) Calculator</h3>
    <input type="number" id="clv-aov" value="50" placeholder="Avg Order Value ($)" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <input type="number" id="clv-freq" value="4" placeholder="Purchases Per Year" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <input type="number" id="clv-years" value="3" placeholder="Lifespan (Years)" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="calcClv()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Calculate CLV</button>
    <div id="clv-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Lifetime Value: $600.00 / Customer</div>
</div>
<script>
function calcClv() {
    const a = parseFloat(document.getElementById("clv-aov").value);
    const f = parseFloat(document.getElementById("clv-freq").value);
    const y = parseFloat(document.getElementById("clv-years").value);
    document.getElementById("clv-out").innerText = "Lifetime Value (CLV): $" + (a * f * y).toFixed(2) + " / Customer";
}
</script>
<?php
}
}

/* 56. ROAS Calculator */
if (!function_exists('ilybd_render_tool_roas_calculator')) {
function ilybd_render_tool_roas_calculator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">📈 Return on Ad Spend (ROAS) Calculator</h3>
    <input type="number" id="roas-rev" value="4000" placeholder="Revenue Generated ($)" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <input type="number" id="roas-spend" value="1000" placeholder="Ad Spend ($)" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="calcRoas()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Calculate ROAS</button>
    <div id="roas-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">ROAS: 400% (4.00x Return)</div>
</div>
<script>
function calcRoas() {
    const r = parseFloat(document.getElementById("roas-rev").value);
    const s = parseFloat(document.getElementById("roas-spend").value);
    const roas = (r / s) * 100;
    document.getElementById("roas-out").innerText = "ROAS: " + roas.toFixed(0) + "% (" + (r/s).toFixed(2) + "x Revenue Return)";
}
</script>
<?php
}
}

/* 57. Conversion Rate Calculator */
if (!function_exists('ilybd_render_tool_conversion_rate_calculator')) {
function ilybd_render_tool_conversion_rate_calculator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">🛒 Website Conversion Rate Calculator</h3>
    <input type="number" id="cr-con" value="250" placeholder="Total Conversions / Orders" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <input type="number" id="cr-vis" value="10000" placeholder="Total Website Visitors" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="calcCr()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Calculate Conversion Rate</button>
    <div id="cr-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Conversion Rate: 2.50%</div>
</div>
<script>
function calcCr() {
    const c = parseFloat(document.getElementById("cr-con").value);
    const v = parseFloat(document.getElementById("cr-vis").value);
    document.getElementById("cr-out").innerText = "Conversion Rate: " + ((c / v) * 100).toFixed(2) + "%";
}
</script>
<?php
}
}

/* 58. Shipping Cost Calculator */
if (!function_exists('ilybd_render_tool_shipping_cost_calculator')) {
function ilybd_render_tool_shipping_cost_calculator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">📦 Dimensional Volumetric Weight Calculator</h3>
    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(100px, 1fr)); gap:10px; margin-bottom:12px;">
        <input type="number" id="dim-l" value="30" placeholder="L (cm)" style="background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px;">
        <input type="number" id="dim-w" value="20" placeholder="W (cm)" style="background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px;">
        <input type="number" id="dim-h" value="15" placeholder="H (cm)" style="background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px;">
    </div>
    <button onclick="calcDimWeight()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Calculate Volumetric Weight</button>
    <div id="dim-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Dimensional Weight: 2.40 kg</div>
</div>
<script>
function calcDimWeight() {
    const l = parseFloat(document.getElementById("dim-l").value);
    const w = parseFloat(document.getElementById("dim-w").value);
    const h = parseFloat(document.getElementById("dim-h").value);
    const kg = (l * w * h) / 5000;
    document.getElementById("dim-out").innerText = "Dimensional Volumetric Weight: " + kg.toFixed(2) + " kg";
}
</script>
<?php
}
}

/* 59. Wholesale & Retail Price */
if (!function_exists('ilybd_render_tool_wholesale_retail_price')) {
function ilybd_render_tool_wholesale_retail_price() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">🏬 Wholesale & Keystone Retail Price Calculator</h3>
    <input type="number" id="cost-prod" value="20" placeholder="Production Cost ($)" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="calcWsPrice()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Calculate Price Hierarchy</button>
    <div id="ws-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Wholesale Price: $40.00 | Keystone Retail: $80.00</div>
</div>
<script>
function calcWsPrice() {
    const c = parseFloat(document.getElementById("cost-prod").value);
    document.getElementById("ws-out").innerText = "Wholesale Price: $" + (c*2).toFixed(2) + " | Keystone Retail Price: $" + (c*4).toFixed(2);
}
</script>
<?php
}
}

/* 60. Inventory Turnover */
if (!function_exists('ilybd_render_tool_inventory_turnover')) {
function ilybd_render_tool_inventory_turnover() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">📊 Inventory Turnover Ratio Calculator</h3>
    <input type="number" id="inv-cogs" value="100000" placeholder="Cost of Goods Sold / COGS ($)" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <input type="number" id="inv-avg" value="20000" placeholder="Average Inventory Value ($)" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="calcInvTurn()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Calculate Turnover Ratio</button>
    <div id="inv-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Turnover Ratio: 5.00x (73 Days to sell inventory)</div>
</div>
<script>
function calcInvTurn() {
    const c = parseFloat(document.getElementById("inv-cogs").value);
    const a = parseFloat(document.getElementById("inv-avg").value);
    const r = c / a;
    document.getElementById("inv-out").innerText = "Turnover Ratio: " + r.toFixed(2) + "x (" + (365/r).toFixed(0) + " Days to sell stock)";
}
</script>
<?php
}
}
