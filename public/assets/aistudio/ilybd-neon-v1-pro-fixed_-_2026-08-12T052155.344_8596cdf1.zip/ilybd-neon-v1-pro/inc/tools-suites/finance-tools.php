<?php
if (!function_exists('ilybd_render_tool_emi_calculator')) {
function ilybd_render_tool_emi_calculator() {
    ?>
    <div style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif;">
        <label class="bento-label" style="color:#10b981;">💰 Enter Loan Details / লোনের তথ্য দিন</label>
        
        <div style="margin-bottom:15px;">
            <label style="color:#94a3b8; font-size:13px; display:block; margin-bottom:5px;">Loan Amount (Principal)</label>
            <input type="number" id="emi-amount" class="cyan-glow-input" placeholder="e.g. 500000" style="width:100%; padding:12px; background:#0b1120; border:1px solid #1e293b; color:#fff; border-radius:8px;">
        </div>
        
        <div style="display:flex; gap:15px; margin-bottom:20px;">
            <div style="flex:1;">
                <label style="color:#94a3b8; font-size:13px; display:block; margin-bottom:5px;">Interest Rate (% P.A.)</label>
                <input type="number" id="emi-rate" class="cyan-glow-input" placeholder="e.g. 9" style="width:100%; padding:12px; background:#0b1120; border:1px solid #1e293b; color:#fff; border-radius:8px;">
            </div>
            <div style="flex:1;">
                <label style="color:#94a3b8; font-size:13px; display:block; margin-bottom:5px;">Tenure (Months)</label>
                <input type="number" id="emi-months" class="cyan-glow-input" placeholder="e.g. 60" style="width:100%; padding:12px; background:#0b1120; border:1px solid #1e293b; color:#fff; border-radius:8px;">
            </div>
        </div>
        
        <button onclick="calculateEMI()" class="cyber-action-btn" style="width:100%; margin-bottom:20px; background:#10b981; color:#000;">⚡ CALCULATE EMI</button>
        
        <div id="emi-result" style="display:none; background:#0b1120; border:1px solid #10b981; padding:20px; border-radius:8px; color:#fff; text-align:center;">
            <!-- Result will be here -->
        </div>
    </div>
    <script>
        function calculateEMI() {
            var p = parseFloat(document.getElementById('emi-amount').value);
            var r = parseFloat(document.getElementById('emi-rate').value);
            var n = parseInt(document.getElementById('emi-months').value);
            
            if(!p || !r || !n || p <= 0 || r <= 0 || n <= 0) { alert('Please enter valid details.'); return; }
            
            var monthlyRate = r / 12 / 100;
            var emi = p * monthlyRate * Math.pow(1 + monthlyRate, n) / (Math.pow(1 + monthlyRate, n) - 1);
            var totalAmount = emi * n;
            var totalInterest = totalAmount - p;
            
            document.getElementById('emi-result').style.display = 'block';
            document.getElementById('emi-result').innerHTML = `
                <div style="font-size:32px; font-weight:bold; color:#10b981;">${emi.toFixed(2)}</div>
                <div style="font-size:16px; color:#cbd5e1; margin-top:5px;">Monthly EMI</div>
                <div style="display:flex; justify-content:space-between; margin-top:20px; padding-top:15px; border-top:1px solid rgba(16, 185, 129, 0.2); font-size:14px;">
                    <div><span style="color:#94a3b8;">Principal:</span> <br><strong>${p.toFixed(2)}</strong></div>
                    <div><span style="color:#94a3b8;">Total Interest:</span> <br><strong>${totalInterest.toFixed(2)}</strong></div>
                    <div><span style="color:#94a3b8;">Total Payable:</span> <br><strong>${totalAmount.toFixed(2)}</strong></div>
                </div>
            `;
        }
    </script>
    <?php
}
}

if (!function_exists('ilybd_render_tool_sip_calculator')) {
function ilybd_render_tool_sip_calculator() {
    ?>
    <div style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif;">
        <label class="bento-label" style="color:#10b981;">📈 SIP Details / বিনিয়োগের তথ্য দিন</label>
        
        <div style="margin-bottom:15px;">
            <label style="color:#94a3b8; font-size:13px; display:block; margin-bottom:5px;">Monthly Investment</label>
            <input type="number" id="sip-amount" class="cyan-glow-input" placeholder="e.g. 5000" style="width:100%; padding:12px; background:#0b1120; border:1px solid #1e293b; color:#fff; border-radius:8px;">
        </div>
        
        <div style="display:flex; gap:15px; margin-bottom:20px;">
            <div style="flex:1;">
                <label style="color:#94a3b8; font-size:13px; display:block; margin-bottom:5px;">Expected Return (% P.A.)</label>
                <input type="number" id="sip-rate" class="cyan-glow-input" placeholder="e.g. 12" style="width:100%; padding:12px; background:#0b1120; border:1px solid #1e293b; color:#fff; border-radius:8px;">
            </div>
            <div style="flex:1;">
                <label style="color:#94a3b8; font-size:13px; display:block; margin-bottom:5px;">Time Period (Years)</label>
                <input type="number" id="sip-years" class="cyan-glow-input" placeholder="e.g. 10" style="width:100%; padding:12px; background:#0b1120; border:1px solid #1e293b; color:#fff; border-radius:8px;">
            </div>
        </div>
        
        <button onclick="calculateSIP()" class="cyber-action-btn" style="width:100%; margin-bottom:20px; background:#10b981; color:#000;">⚡ CALCULATE RETURNS</button>
        
        <div id="sip-result" style="display:none; background:#0b1120; border:1px solid #10b981; padding:20px; border-radius:8px; color:#fff; text-align:center;">
            <!-- Result will be here -->
        </div>
    </div>
    <script>
        function calculateSIP() {
            var p = parseFloat(document.getElementById('sip-amount').value);
            var r = parseFloat(document.getElementById('sip-rate').value);
            var y = parseInt(document.getElementById('sip-years').value);
            
            if(!p || !r || !y || p <= 0 || r <= 0 || y <= 0) { alert('Please enter valid details.'); return; }
            
            var n = y * 12; // total months
            var i = r / 12 / 100; // monthly rate
            
            // Formula: M = P × ({[1 + i]^n - 1} / i) × (1 + i)
            var futureValue = p * ((Math.pow(1 + i, n) - 1) / i) * (1 + i);
            var totalInvestment = p * n;
            var estimatedReturns = futureValue - totalInvestment;
            
            document.getElementById('sip-result').style.display = 'block';
            document.getElementById('sip-result').innerHTML = `
                <div style="font-size:32px; font-weight:bold; color:#10b981;">${futureValue.toFixed(2)}</div>
                <div style="font-size:16px; color:#cbd5e1; margin-top:5px;">Total Value</div>
                <div style="display:flex; justify-content:space-between; margin-top:20px; padding-top:15px; border-top:1px solid rgba(16, 185, 129, 0.2); font-size:14px;">
                    <div><span style="color:#94a3b8;">Invested Amount:</span> <br><strong>${totalInvestment.toFixed(2)}</strong></div>
                    <div><span style="color:#94a3b8;">Est. Returns:</span> <br><strong>${estimatedReturns.toFixed(2)}</strong></div>
                </div>
            `;
        }
    </script>
    <?php
}
}

if (!function_exists('ilybd_render_tool_paypal_fee_calculator')) {
function ilybd_render_tool_paypal_fee_calculator() {
    ?>
    <div style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif;">
        <label class="bento-label" style="color:#10b981;">💳 PayPal Fee Details / পেপ্যাল ফি</label>
        
        <div style="margin-bottom:15px;">
            <label style="color:#94a3b8; font-size:13px; display:block; margin-bottom:5px;">Amount ($)</label>
            <input type="number" id="paypal-amount" class="cyan-glow-input" placeholder="e.g. 100" style="width:100%; padding:12px; background:#0b1120; border:1px solid #1e293b; color:#fff; border-radius:8px;">
        </div>
        
        <div style="display:flex; gap:15px; margin-bottom:20px;">
            <div style="flex:1;">
                <label style="color:#94a3b8; font-size:13px; display:block; margin-bottom:5px;">Percentage Fee (%)</label>
                <input type="number" id="paypal-pct" value="4.4" step="0.1" class="cyan-glow-input" style="width:100%; padding:12px; background:#0b1120; border:1px solid #1e293b; color:#fff; border-radius:8px;">
            </div>
            <div style="flex:1;">
                <label style="color:#94a3b8; font-size:13px; display:block; margin-bottom:5px;">Fixed Fee ($)</label>
                <input type="number" id="paypal-fixed" value="0.30" step="0.01" class="cyan-glow-input" style="width:100%; padding:12px; background:#0b1120; border:1px solid #1e293b; color:#fff; border-radius:8px;">
            </div>
        </div>
        
        <button onclick="calculatePayPal()" class="cyber-action-btn" style="width:100%; margin-bottom:20px; background:#10b981; color:#000;">⚡ CALCULATE FEES</button>
        
        <div id="paypal-result" style="display:none; background:#0b1120; border:1px solid #10b981; padding:20px; border-radius:8px; color:#fff; text-align:center;">
            <!-- Result will be here -->
        </div>
    </div>
    <script>
        function calculatePayPal() {
            var amount = parseFloat(document.getElementById('paypal-amount').value);
            var pct = parseFloat(document.getElementById('paypal-pct').value);
            var fixed = parseFloat(document.getElementById('paypal-fixed').value);
            
            if(!amount || amount <= 0) { alert('Please enter valid amount.'); return; }
            
            var fee = (amount * (pct / 100)) + fixed;
            var receive = amount - fee;
            var askFor = (amount + fixed) / (1 - (pct / 100)); // How much to ask to get exact amount
            
            document.getElementById('paypal-result').style.display = 'block';
            document.getElementById('paypal-result').innerHTML = `
                <div style="display:flex; justify-content:space-between; text-align:left; font-size:14px; margin-bottom:10px;">
                    <div style="color:#94a3b8;">You Receive:</div>
                    <div style="font-weight:bold; color:#10b981; font-size:18px;">$${receive.toFixed(2)}</div>
                </div>
                <div style="display:flex; justify-content:space-between; text-align:left; font-size:14px; margin-bottom:10px;">
                    <div style="color:#94a3b8;">Total PayPal Fees:</div>
                    <div style="font-weight:bold; color:#ef4444; font-size:18px;">$${fee.toFixed(2)}</div>
                </div>
                <div style="margin-top:15px; padding-top:15px; border-top:1px dashed rgba(16,185,129,0.3); text-align:left;">
                    <div style="color:#cbd5e1; font-size:13px; margin-bottom:5px;">To receive exactly <strong>$${amount}</strong>, ask for:</div>
                    <div style="font-size:24px; font-weight:bold; color:#38bdf8;">$${askFor.toFixed(2)}</div>
                </div>
            `;
        }
    </script>
    <?php
}
}

if (!function_exists('ilybd_render_tool_gst_calculator')) {
function ilybd_render_tool_gst_calculator() {
    ?>
    <div style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif;">
        <label class="bento-label" style="color:#10b981;">🧾 GST Details / জিএসটি ফি</label>
        
        <div style="margin-bottom:15px;">
            <label style="color:#94a3b8; font-size:13px; display:block; margin-bottom:5px;">Original Amount</label>
            <input type="number" id="gst-amount" class="cyan-glow-input" placeholder="e.g. 1000" style="width:100%; padding:12px; background:#0b1120; border:1px solid #1e293b; color:#fff; border-radius:8px;">
        </div>
        
        <div style="margin-bottom:20px;">
            <label style="color:#94a3b8; font-size:13px; display:block; margin-bottom:5px;">GST Rate (%)</label>
            <select id="gst-rate" class="cyan-glow-input" style="width:100%; padding:12px; background:#0b1120; border:1px solid #1e293b; color:#fff; border-radius:8px;">
                <option value="5">5%</option>
                <option value="12">12%</option>
                <option value="18" selected>18%</option>
                <option value="28">28%</option>
            </select>
        </div>
        
        <div style="display:flex; gap:10px; margin-bottom:20px;">
            <button onclick="calculateGST('add')" class="cyber-action-btn" style="flex:1; background:#10b981; color:#000;">➕ ADD GST</button>
            <button onclick="calculateGST('remove')" class="cyber-action-btn" style="flex:1; background:#ef4444; color:#fff;">➖ REMOVE GST</button>
        </div>
        
        <div id="gst-result" style="display:none; background:#0b1120; border:1px solid #10b981; padding:20px; border-radius:8px; color:#fff; text-align:center;">
            <!-- Result will be here -->
        </div>
    </div>
    <script>
        function calculateGST(action) {
            var amount = parseFloat(document.getElementById('gst-amount').value);
            var rate = parseFloat(document.getElementById('gst-rate').value);
            
            if(!amount || amount <= 0) { alert('Please enter valid amount.'); return; }
            
            var gstAmount = 0;
            var totalAmount = 0;
            
            if (action === 'add') {
                gstAmount = amount * (rate / 100);
                totalAmount = amount + gstAmount;
            } else {
                totalAmount = amount;
                var baseAmount = amount / (1 + (rate / 100));
                gstAmount = amount - baseAmount;
                amount = baseAmount;
            }
            
            document.getElementById('gst-result').style.display = 'block';
            document.getElementById('gst-result').innerHTML = `
                <div style="display:flex; justify-content:space-between; text-align:left; font-size:14px; margin-bottom:10px;">
                    <div style="color:#94a3b8;">Base Amount:</div>
                    <div style="font-weight:bold; color:#fff; font-size:16px;">${amount.toFixed(2)}</div>
                </div>
                <div style="display:flex; justify-content:space-between; text-align:left; font-size:14px; margin-bottom:10px;">
                    <div style="color:#94a3b8;">GST (${rate}%):</div>
                    <div style="font-weight:bold; color:#10b981; font-size:16px;">${gstAmount.toFixed(2)}</div>
                </div>
                <div style="display:flex; justify-content:space-between; text-align:left; font-size:14px; margin-top:15px; padding-top:15px; border-top:1px dashed rgba(16,185,129,0.3);">
                    <div style="color:#cbd5e1;">Total Amount:</div>
                    <div style="font-weight:bold; color:#38bdf8; font-size:20px;">${totalAmount.toFixed(2)}</div>
                </div>
            `;
        }
    </script>
    <?php
}
}


if (!function_exists('ilybd_render_tool_bd_salary_tax_calculator')) {
function ilybd_render_tool_bd_salary_tax_calculator() {
    ?>
    <div style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif;">
        <label class="bento-label" style="color:#10b981;">🇧🇩 Bangladesh Tax Calculator (2024-2025 Slabs)</label>
        
        <div style="margin-bottom:15px;">
            <label style="color:#94a3b8; font-size:13px; display:block; margin-bottom:5px;">করদাতার ধরন (Taxpayer Category)</label>
            <select id="bd-tax-cat" class="cyan-glow-input" style="width:100%; padding:12px; background:#0b1120; border:1px solid #1e293b; color:#fff; border-radius:8px;">
                <option value="male">সাধারণ পুরুষ (করমুক্ত সীমা: ৩,৫০,০০০ ৳)</option>
                <option value="female">নারী ও ৬৫+ বছর জ্যেষ্ঠ নাগরিক (করমুক্ত সীমা: ৪,০০,০০০ ৳)</option>
                <option value="disabled">প্রতিবন্ধী ব্যক্তি (করমুক্ত সীমা: ৪,৭৫,০০০ ৳)</option>
                <option value="freedom_fighter">গেজেটভুক্ত মুক্তিযোদ্ধা (করমুক্ত সীমা: ৫,০০,০০০ ৳)</option>
            </select>
        </div>

        <div style="margin-bottom:15px;">
            <label style="color:#94a3b8; font-size:13px; display:block; margin-bottom:5px;">বার্ষিক মোট বেতন বা আয় (Annual Gross Income - BDT)</label>
            <input type="number" id="bd-tax-income" class="cyan-glow-input" placeholder="যেমন: ৮০০০০০" style="width:100%; padding:12px; background:#0b1120; border:1px solid #1e293b; color:#fff; border-radius:8px;">
        </div>

        <div style="margin-bottom:20px;">
            <label style="color:#94a3b8; font-size:13px; display:block; margin-bottom:5px;">বার্ষিক অনুমোদিত বিনিয়োগ (Investment for Tax Rebate - BDT)</label>
            <input type="number" id="bd-tax-invest" class="cyan-glow-input" placeholder="যেমন: ১০০০০০ (ঐচ্ছিক)" style="width:100%; padding:12px; background:#0b1120; border:1px solid #1e293b; color:#fff; border-radius:8px;">
        </div>

        <button onclick="calculateBDTax()" class="cyber-action-btn" style="width:100%; margin-bottom:20px; background:#10b981; color:#000;">⚡ আয়কর হিসাব করুন</button>

        <div id="bd-tax-result" style="display:none; background:#0b1120; border:1px solid #10b981; padding:20px; border-radius:8px; color:#fff;">
            <!-- Result Output -->
        </div>
    </div>

    <script>
        function calculateBDTax() {
            var cat = document.getElementById("bd-tax-cat").value;
            var income = parseFloat(document.getElementById("bd-tax-income").value) || 0;
            var invest = parseFloat(document.getElementById("bd-tax-invest").value) || 0;

            if (income <= 0) { alert("অনুগ্রহ করে সঠিক আয়ের পরিমাণ লিখুন।"); return; }

            var exemptLimit = 350000;
            if (cat === "female") exemptLimit = 400000;
            else if (cat === "disabled") exemptLimit = 475000;
            else if (cat === "freedom_fighter") exemptLimit = 500000;

            var taxableIncome = Math.max(0, income - exemptLimit);
            var grossTax = 0;

            if (taxableIncome > 0) {
                var remaining = taxableIncome;

                // Slab 1: Next 100,000 @ 5%
                var slab1 = Math.min(remaining, 100000);
                grossTax += slab1 * 0.05;
                remaining -= slab1;

                // Slab 2: Next 300,000 @ 10%
                if (remaining > 0) {
                    var slab2 = Math.min(remaining, 300000);
                    grossTax += slab2 * 0.10;
                    remaining -= slab2;
                }

                // Slab 3: Next 400,000 @ 15%
                if (remaining > 0) {
                    var slab3 = Math.min(remaining, 400000);
                    grossTax += slab3 * 0.15;
                    remaining -= slab3;
                }

                // Slab 4: Next 500,000 @ 20%
                if (remaining > 0) {
                    var slab4 = Math.min(remaining, 500000);
                    grossTax += slab4 * 0.20;
                    remaining -= slab4;
                }

                // Slab 5: Remaining @ 25%
                if (remaining > 0) {
                    grossTax += remaining * 0.25;
                }
            }

            // Tax Rebate Calculation (15% of investment, max 3% of taxable income or 10 lac)
            var rebate = 0;
            if (invest > 0 && taxableIncome > 0) {
                var maxAllowedInvest = taxableIncome * 0.20;
                var eligibleInvest = Math.min(invest, maxAllowedInvest);
                rebate = eligibleInvest * 0.15;
            }

            var netTax = Math.max(0, grossTax - rebate);

            // Minimum tax in Bangladesh cities is 5000 / 4000 / 3000
            var minTax = 5000;
            if (income > exemptLimit && netTax < minTax) {
                netTax = minTax;
            }

            document.getElementById("bd-tax-result").style.display = "block";
            document.getElementById("bd-tax-result").innerHTML = `
                <div style="font-size:16px; font-weight:bold; color:#10b981; margin-bottom:15px; border-bottom:1px solid rgba(16,185,129,0.2); padding-bottom:10px;">
                    📊 আয়কর হিসাব ফলাফল (Tax Calculation Summary)
                </div>
                <div style="display:flex; justify-content:space-between; margin-bottom:8px; font-size:14px;">
                    <span style="color:#94a3b8;">করমুক্ত আয়ের সীমা:</span>
                    <strong>৳${exemptLimit.toLocaleString()}</strong>
                </div>
                <div style="display:flex; justify-content:space-between; margin-bottom:8px; font-size:14px;">
                    <span style="color:#94a3b8;">করযোগ্য আয় (Taxable Income):</span>
                    <strong>৳${taxableIncome.toLocaleString()}</strong>
                </div>
                <div style="display:flex; justify-content:space-between; margin-bottom:8px; font-size:14px;">
                    <span style="color:#94a3b8;">মোট গ্রস ট্যাক্স (Gross Tax):</span>
                    <strong style="color:#f59e0b;">৳${grossTax.toLocaleString()}</strong>
                </div>
                <div style="display:flex; justify-content:space-between; margin-bottom:8px; font-size:14px;">
                    <span style="color:#94a3b8;">বিনিয়োগ কর রেয়াত (Rebate):</span>
                    <strong style="color:#10b981;">- ৳${rebate.toLocaleString()}</strong>
                </div>
                <div style="display:flex; justify-content:space-between; font-size:18px; font-weight:bold; margin-top:15px; padding-top:12px; border-top:1px dashed rgba(16,185,129,0.4);">
                    <span style="color:#00f0ff;">প্রদেয় নিট কর (Net Tax Payable):</span>
                    <span style="color:#39ff14;">৳${netTax.toLocaleString()}</span>
                </div>
            `;
        }
    </script>
    <?php
}
}
