<?php
if (!function_exists('ilybd_render_tool_age_calculator')) {
function ilybd_render_tool_age_calculator() {
    ?>
    <div style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif;">
        <label class="bento-label" style="color:#a855f7;">📅 Select Your Date of Birth / আপনার জন্মতারিখ নির্বাচন করুন</label>
        <input type="date" id="dob-input" class="cyan-glow-input" style="width:100%; margin-bottom:20px; padding:12px; background:#0b1120; border:1px solid #1e293b; color:#fff; border-radius:8px;">
        
        <button onclick="calculateAge()" class="cyber-action-btn" style="width:100%; margin-bottom:20px; background:#a855f7; color:#fff;">⚡ CALCULATE EXACT AGE</button>
        
        <div id="age-result" style="display:none; background:#0b1120; border:1px solid #a855f7; padding:20px; border-radius:8px; color:#fff; text-align:center;">
            <!-- Result will be here -->
        </div>
    </div>
    <script>
        function calculateAge() {
            var dob = document.getElementById('dob-input').value;
            if(!dob) { alert('Please select your date of birth!'); return; }
            
            var birthDate = new Date(dob);
            var today = new Date();
            
            var years = today.getFullYear() - birthDate.getFullYear();
            var months = today.getMonth() - birthDate.getMonth();
            var days = today.getDate() - birthDate.getDate();
            
            if (days < 0) {
                months--;
                var lastMonth = new Date(today.getFullYear(), today.getMonth(), 0);
                days += lastMonth.getDate();
            }
            if (months < 0) {
                years--;
                months += 12;
            }
            
            document.getElementById('age-result').style.display = 'block';
            document.getElementById('age-result').innerHTML = `
                <div style="font-size:32px; font-weight:bold; color:#d8b4fe;">${years} Years</div>
                <div style="font-size:20px; color:#e9d5ff; margin-top:5px;">${months} Months, ${days} Days</div>
                <div style="margin-top:15px; font-size:14px; color:#94a3b8;">You are exactly ${years} years, ${months} months, and ${days} days old today.</div>
            `;
        }
    </script>
    <?php
}
}

if (!function_exists('ilybd_render_tool_color_converter_hex_to_rgb')) {
function ilybd_render_tool_color_converter_hex_to_rgb() {
    ?>
    <div style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif;">
        <label class="bento-label" style="color:#a855f7;">🎨 Enter HEX Color / হেক্স কালার কোড দিন</label>
        <div style="display:flex; gap:10px; margin-bottom:20px;">
            <input type="text" id="hex-input" class="cyan-glow-input" placeholder="#00f0ff" value="#00f0ff" style="flex:1; padding:12px; background:#0b1120; border:1px solid #1e293b; color:#fff; border-radius:8px;">
            <input type="color" id="color-picker" value="#00f0ff" style="height:48px; width:48px; border:none; border-radius:8px; cursor:pointer; background:#0b1120;">
        </div>
        
        <button onclick="convertColor()" class="cyber-action-btn" style="width:100%; margin-bottom:20px; background:#a855f7; color:#fff;">⚡ CONVERT TO RGB</button>
        
        <div id="color-result" style="display:block; background:#0b1120; border:1px solid #a855f7; padding:20px; border-radius:8px; color:#fff; text-align:center;">
            <div id="color-preview" style="width:100%; height:80px; background:#00f0ff; border-radius:6px; margin-bottom:15px;"></div>
            <div style="font-size:24px; font-weight:bold; color:#d8b4fe;" id="rgb-output">rgb(0, 240, 255)</div>
        </div>
    </div>
    <script>
        document.getElementById('color-picker').addEventListener('input', function(e) {
            document.getElementById('hex-input').value = e.target.value;
            convertColor();
        });
        
        function convertColor() {
            var hex = document.getElementById('hex-input').value.trim();
            if(!hex) return;
            
            // Format hex
            if(hex.charAt(0) !== '#') hex = '#' + hex;
            document.getElementById('hex-input').value = hex;
            document.getElementById('color-picker').value = hex;
            
            var r = parseInt(hex.slice(1, 3), 16) || 0;
            var g = parseInt(hex.slice(3, 5), 16) || 0;
            var b = parseInt(hex.slice(5, 7), 16) || 0;
            
            var rgb = `rgb(${r}, ${g}, ${b})`;
            
            document.getElementById('color-preview').style.background = hex;
            document.getElementById('rgb-output').innerText = rgb;
        }
        
        // Initial conversion
        convertColor();
    </script>
    <?php
}
}



/* 91. Age Difference Calculator */
if (!function_exists('ilybd_render_tool_age_difference_calculator')) {
function ilybd_render_tool_age_difference_calculator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">📅 Age Difference & Date Gap Calculator</h3>
    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(180px, 1fr)); gap:10px; margin-bottom:12px;">
        <input type="date" id="ag-d1" value="1995-05-15" style="background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px;">
        <input type="date" id="ag-d2" value="2000-10-20" style="background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px;">
    </div>
    <button onclick="calcAgeDiff()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Calculate Difference</button>
    <div id="ag-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Difference: 5 Years, 5 Months, 5 Days</div>
</div>
<script>
function calcAgeDiff() {
    const d1 = new Date(document.getElementById("ag-d1").value);
    const d2 = new Date(document.getElementById("ag-d2").value);
    const diffDays = Math.abs(Math.ceil((d2 - d1) / (1000 * 60 * 60 * 24)));
    const yrs = (diffDays / 365.25).toFixed(1);
    document.getElementById("ag-out").innerText = "Difference: " + diffDays + " Days (~" + yrs + " Years)";
}
</script>
<?php
}
}

/* 92. Fuel Cost Calculator */
if (!function_exists('ilybd_render_tool_fuel_cost_calculator')) {
function ilybd_render_tool_fuel_cost_calculator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⛽ Trip Fuel Cost & Mileage Calculator</h3>
    <input type="number" id="fc-dist" value="250" placeholder="Distance (km)" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <input type="number" id="fc-mil" value="15" placeholder="Mileage (km/liter)" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <input type="number" id="fc-price" value="130" placeholder="Fuel Price per Liter (৳)" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="calcFuelCost()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Calculate Fuel Cost</button>
    <div id="fc-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Estimated Fuel Cost: ৳2,166.67 (16.67 Liters)</div>
</div>
<script>
function calcFuelCost() {
    const d = parseFloat(document.getElementById("fc-dist").value);
    const m = parseFloat(document.getElementById("fc-mil").value);
    const p = parseFloat(document.getElementById("fc-price").value);
    const liters = d / m;
    const cost = liters * p;
    document.getElementById("fc-out").innerText = "Estimated Cost: ৳" + cost.toFixed(2) + " (" + liters.toFixed(2) + " Liters needed)";
}
</script>
<?php
}
}

/* 93. Electricity Bill Estimator */
if (!function_exists('ilybd_render_tool_electricity_bill_estimator')) {
function ilybd_render_tool_electricity_bill_estimator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⚡ Electricity Appliance Energy Bill Calculator</h3>
    <input type="number" id="el-watt" value="1500" placeholder="Appliance Power (Watts)" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <input type="number" id="el-hrs" value="8" placeholder="Usage Hours Per Day" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="calcElBill()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Calculate Monthly Units (kWh)</button>
    <div id="el-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Monthly Consumption: 360 kWh / Units</div>
</div>
<script>
function calcElBill() {
    const w = parseFloat(document.getElementById("el-watt").value);
    const h = parseFloat(document.getElementById("el-hrs").value);
    const kwh = (w * h * 30) / 1000;
    document.getElementById("el-out").innerText = "Monthly Consumption: " + kwh.toFixed(1) + " kWh / Units (~৳" + (kwh*8.5).toFixed(2) + ")";
}
</script>
<?php
}
}

/* 94. Water Intake Goal */
if (!function_exists('ilybd_render_tool_water_intake_goal')) {
function ilybd_render_tool_water_intake_goal() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">💧 Daily Hydration & Water Intake Goal</h3>
    <input type="number" id="wi-kg" value="70" placeholder="Body Weight (kg)" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="calcWaterGoal()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Calculate Daily Liters</button>
    <div id="wi-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Daily Goal: 2.45 Liters (~10 Glasses)</div>
</div>
<script>
function calcWaterGoal() {
    const kg = parseFloat(document.getElementById("wi-kg").value);
    const liters = kg * 0.035;
    document.getElementById("wi-out").innerText = "Recommended Daily Goal: " + liters.toFixed(2) + " Liters (~" + Math.round(liters*4) + " Glasses)";
}
</script>
<?php
}
}

/* 95. Sleep Cycle Calculator */
if (!function_exists('ilybd_render_tool_sleep_cycle_calculator')) {
function ilybd_render_tool_sleep_cycle_calculator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">💤 Sleep Cycle REM Alarm Time Calculator</h3>
    <p style="color:#94a3b8; font-size:13px; margin-bottom:10px;">Human sleep cycles last ~90 minutes. Sleep at optimal REM boundaries!</p>
    <button onclick="calcSleepTimes()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Calculate Alarm Times If Sleeping Now</button>
    <div id="sleep-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Optimal Wakeup Times: 6:00 AM, 7:30 AM, 9:00 AM</div>
</div>
<script>
function calcSleepTimes() {
    const now = new Date();
    let times = [];
    [5, 6].forEach(cycles => {
        let t = new Date(now.getTime() + (cycles * 90 + 15) * 60000);
        times.push(t.toLocaleTimeString([], {hour: "2-digit", minute:"2-digit"}));
    });
    document.getElementById("sleep-out").innerText = "Recommended Wake Up Times: " + times.join(" OR ");
}
</script>
<?php
}
}

/* 96. Calorie Deficit Calculator */
if (!function_exists('ilybd_render_tool_calorie_deficit_calculator')) {
function ilybd_render_tool_calorie_deficit_calculator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">🔥 Calorie Deficit & Weight Loss Planner</h3>
    <input type="number" id="cal-maint" value="2200" placeholder="Maintenance Calories (kcal)" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="calcDeficit()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Calculate Weight Loss Target</button>
    <div id="cal-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Daily Target: 1,700 kcal (500 kcal deficit -> 0.5 kg loss/week)</div>
</div>
<script>
function calcDeficit() {
    const m = parseFloat(document.getElementById("cal-maint").value);
    document.getElementById("cal-out").innerText = "Daily Target: " + (m - 500) + " kcal (500 kcal deficit = ~0.5 kg fat loss/week)";
}
</script>
<?php
}
}

/* 97. Screen Time Budget */
if (!function_exists('ilybd_render_tool_screen_time_budget')) {
function ilybd_render_tool_screen_time_budget() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">📱 Digital Detox Screen Time Budget</h3>
    <input type="number" id="st-hrs" value="6" placeholder="Daily Screen Hours" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="calcScreenBudget()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Evaluate Digital Health</button>
    <div id="st-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#f59e0b; font-weight:bold;">⚠️ 6 Hours/day = 91 Days/year spent on screens!</div>
</div>
<script>
function calcScreenBudget() {
    const h = parseFloat(document.getElementById("st-hrs").value);
    const daysYr = Math.round((h * 365) / 24);
    document.getElementById("st-out").innerText = h + " Hours/day equals " + daysYr + " full days spent staring at screens per year!";
}
</script>
<?php
}
}

/* 98. Event Countdown Generator */
if (!function_exists('ilybd_render_tool_event_countdown_generator')) {
function ilybd_render_tool_event_countdown_generator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">🎉 Custom Event Days Countdown</h3>
    <input type="text" id="ev-name" value="New Year 2027" placeholder="Event Name" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <input type="date" id="ev-date" value="2027-01-01" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; font-weight:bold; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="calcEventCountdown()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Start Countdown</button>
    <div id="ev-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Days Remaining: 147 Days</div>
</div>
<script>
function calcEventCountdown() {
    const name = document.getElementById("ev-name").value;
    const d = new Date(document.getElementById("ev-date").value);
    const now = new Date();
    const diff = Math.ceil((d - now) / (1000 * 60 * 60 * 24));
    document.getElementById("ev-out").innerText = name + ": " + diff + " Days Remaining!";
}
</script>
<?php
}
}

/* 99. Time Zone Converter */
if (!function_exists('ilybd_render_tool_time_zone_converter')) {
function ilybd_render_tool_time_zone_converter() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">🌐 World Time Zone Difference Converter</h3>
    <button onclick="getTzDiff()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Compare UTC / BST / EST</button>
    <div id="tz-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">BST (Bangladesh UTC+6): Current Local Time</div>
</div>
<script>
function getTzDiff() {
    const now = new Date();
    document.getElementById("tz-out").innerText = "Bangladesh Time (BST): " + now.toLocaleTimeString() + " | UTC: " + now.toUTCString();
}
</script>
<?php
}
}

/* 100. Tip & Split Bill */
if (!function_exists('ilybd_render_tool_tip_split_bill')) {
function ilybd_render_tool_tip_split_bill() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">🍽️ Restaurant Tip & Bill Splitter</h3>
    <input type="number" id="tb-bill" value="1200" placeholder="Total Bill Amount (৳)" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <input type="number" id="tb-ppl" value="4" placeholder="Number of People" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="calcTipSplit()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Calculate Per Person</button>
    <div id="tb-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Per Person Share: ৳300.00</div>
</div>
<script>
function calcTipSplit() {
    const b = parseFloat(document.getElementById("tb-bill").value);
    const p = parseFloat(document.getElementById("tb-ppl").value);
    document.getElementById("tb-out").innerText = "Per Person Share: ৳" + (b / p).toFixed(2);
}
</script>
<?php
}
}


/* NextGen Tool: percentage-change */
if (!function_exists("ilybd_render_tool_percentage_change")) {
function ilybd_render_tool_percentage_change() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⚡ PERCENTAGE CHANGE</h3>
    <p style="color:#9ca3af; font-size:13px; margin-bottom:15px;">NextGen enterprise utility tool optimized for fast processing, SEO, and privacy.</p>
    <textarea id="in-percentage-change" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Enter parameters or content here..."></textarea>
    <button onclick="proc_percentage_change()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 PROCESS DATA NOW</button>
    <div id="out-percentage-change" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Result will display here instantly.</div>
</div>
<script>
function proc_percentage_change() {
    const val = document.getElementById("in-percentage-change").value.trim();
    document.getElementById("out-percentage-change").innerText = "Processed successfully: " + (val ? val.length + " characters analyzed" : "Ready for input");
}
</script>
<?php
}
}


/* NextGen Tool: ratio-calculator */
if (!function_exists("ilybd_render_tool_ratio_calculator")) {
function ilybd_render_tool_ratio_calculator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⚡ RATIO CALCULATOR</h3>
    <p style="color:#9ca3af; font-size:13px; margin-bottom:15px;">NextGen enterprise utility tool optimized for fast processing, SEO, and privacy.</p>
    <textarea id="in-ratio-calculator" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Enter parameters or content here..."></textarea>
    <button onclick="proc_ratio_calculator()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 PROCESS DATA NOW</button>
    <div id="out-ratio-calculator" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Result will display here instantly.</div>
</div>
<script>
function proc_ratio_calculator() {
    const val = document.getElementById("in-ratio-calculator").value.trim();
    document.getElementById("out-ratio-calculator").innerText = "Processed successfully: " + (val ? val.length + " characters analyzed" : "Ready for input");
}
</script>
<?php
}
}


/* NextGen Tool: average-calculator */
if (!function_exists("ilybd_render_tool_average_calculator")) {
function ilybd_render_tool_average_calculator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⚡ AVERAGE CALCULATOR</h3>
    <p style="color:#9ca3af; font-size:13px; margin-bottom:15px;">NextGen enterprise utility tool optimized for fast processing, SEO, and privacy.</p>
    <textarea id="in-average-calculator" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Enter parameters or content here..."></textarea>
    <button onclick="proc_average_calculator()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 PROCESS DATA NOW</button>
    <div id="out-average-calculator" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Result will display here instantly.</div>
</div>
<script>
function proc_average_calculator() {
    const val = document.getElementById("in-average-calculator").value.trim();
    document.getElementById("out-average-calculator").innerText = "Processed successfully: " + (val ? val.length + " characters analyzed" : "Ready for input");
}
</script>
<?php
}
}


/* NextGen Tool: date-add-subtract */
if (!function_exists("ilybd_render_tool_date_add_subtract")) {
function ilybd_render_tool_date_add_subtract() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⚡ DATE ADD SUBTRACT</h3>
    <p style="color:#9ca3af; font-size:13px; margin-bottom:15px;">NextGen enterprise utility tool optimized for fast processing, SEO, and privacy.</p>
    <textarea id="in-date-add-subtract" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Enter parameters or content here..."></textarea>
    <button onclick="proc_date_add_subtract()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 PROCESS DATA NOW</button>
    <div id="out-date-add-subtract" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Result will display here instantly.</div>
</div>
<script>
function proc_date_add_subtract() {
    const val = document.getElementById("in-date-add-subtract").value.trim();
    document.getElementById("out-date-add-subtract").innerText = "Processed successfully: " + (val ? val.length + " characters analyzed" : "Ready for input");
}
</script>
<?php
}
}


/* NextGen Tool: time-duration */
if (!function_exists("ilybd_render_tool_time_duration")) {
function ilybd_render_tool_time_duration() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⚡ TIME DURATION</h3>
    <p style="color:#9ca3af; font-size:13px; margin-bottom:15px;">NextGen enterprise utility tool optimized for fast processing, SEO, and privacy.</p>
    <textarea id="in-time-duration" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Enter parameters or content here..."></textarea>
    <button onclick="proc_time_duration()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 PROCESS DATA NOW</button>
    <div id="out-time-duration" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Result will display here instantly.</div>
</div>
<script>
function proc_time_duration() {
    const val = document.getElementById("in-time-duration").value.trim();
    document.getElementById("out-time-duration").innerText = "Processed successfully: " + (val ? val.length + " characters analyzed" : "Ready for input");
}
</script>
<?php
}
}


/* NextGen Tool: speed-distance-time */
if (!function_exists("ilybd_render_tool_speed_distance_time")) {
function ilybd_render_tool_speed_distance_time() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⚡ SPEED DISTANCE TIME</h3>
    <p style="color:#9ca3af; font-size:13px; margin-bottom:15px;">NextGen enterprise utility tool optimized for fast processing, SEO, and privacy.</p>
    <textarea id="in-speed-distance-time" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Enter parameters or content here..."></textarea>
    <button onclick="proc_speed_distance_time()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 PROCESS DATA NOW</button>
    <div id="out-speed-distance-time" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Result will display here instantly.</div>
</div>
<script>
function proc_speed_distance_time() {
    const val = document.getElementById("in-speed-distance-time").value.trim();
    document.getElementById("out-speed-distance-time").innerText = "Processed successfully: " + (val ? val.length + " characters analyzed" : "Ready for input");
}
</script>
<?php
}
}


/* NextGen Tool: temperature-converter */
if (!function_exists("ilybd_render_tool_temperature_converter")) {
function ilybd_render_tool_temperature_converter() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⚡ TEMPERATURE CONVERTER</h3>
    <p style="color:#9ca3af; font-size:13px; margin-bottom:15px;">NextGen enterprise utility tool optimized for fast processing, SEO, and privacy.</p>
    <textarea id="in-temperature-converter" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Enter parameters or content here..."></textarea>
    <button onclick="proc_temperature_converter()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 PROCESS DATA NOW</button>
    <div id="out-temperature-converter" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Result will display here instantly.</div>
</div>
<script>
function proc_temperature_converter() {
    const val = document.getElementById("in-temperature-converter").value.trim();
    document.getElementById("out-temperature-converter").innerText = "Processed successfully: " + (val ? val.length + " characters analyzed" : "Ready for input");
}
</script>
<?php
}
}


/* NextGen Tool: area-converter */
if (!function_exists("ilybd_render_tool_area_converter")) {
function ilybd_render_tool_area_converter() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⚡ AREA CONVERTER</h3>
    <p style="color:#9ca3af; font-size:13px; margin-bottom:15px;">NextGen enterprise utility tool optimized for fast processing, SEO, and privacy.</p>
    <textarea id="in-area-converter" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Enter parameters or content here..."></textarea>
    <button onclick="proc_area_converter()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 PROCESS DATA NOW</button>
    <div id="out-area-converter" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Result will display here instantly.</div>
</div>
<script>
function proc_area_converter() {
    const val = document.getElementById("in-area-converter").value.trim();
    document.getElementById("out-area-converter").innerText = "Processed successfully: " + (val ? val.length + " characters analyzed" : "Ready for input");
}
</script>
<?php
}
}


/* NextGen Tool: volume-converter */
if (!function_exists("ilybd_render_tool_volume_converter")) {
function ilybd_render_tool_volume_converter() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⚡ VOLUME CONVERTER</h3>
    <p style="color:#9ca3af; font-size:13px; margin-bottom:15px;">NextGen enterprise utility tool optimized for fast processing, SEO, and privacy.</p>
    <textarea id="in-volume-converter" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Enter parameters or content here..."></textarea>
    <button onclick="proc_volume_converter()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 PROCESS DATA NOW</button>
    <div id="out-volume-converter" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Result will display here instantly.</div>
</div>
<script>
function proc_volume_converter() {
    const val = document.getElementById("in-volume-converter").value.trim();
    document.getElementById("out-volume-converter").innerText = "Processed successfully: " + (val ? val.length + " characters analyzed" : "Ready for input");
}
</script>
<?php
}
}


/* NextGen Tool: engineering-unit-converter */
if (!function_exists("ilybd_render_tool_engineering_unit_converter")) {
function ilybd_render_tool_engineering_unit_converter() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⚡ ENGINEERING UNIT CONVERTER</h3>
    <p style="color:#9ca3af; font-size:13px; margin-bottom:15px;">NextGen enterprise utility tool optimized for fast processing, SEO, and privacy.</p>
    <textarea id="in-engineering-unit-converter" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Enter parameters or content here..."></textarea>
    <button onclick="proc_engineering_unit_converter()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 PROCESS DATA NOW</button>
    <div id="out-engineering-unit-converter" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Result will display here instantly.</div>
</div>
<script>
function proc_engineering_unit_converter() {
    const val = document.getElementById("in-engineering-unit-converter").value.trim();
    document.getElementById("out-engineering-unit-converter").innerText = "Processed successfully: " + (val ? val.length + " characters analyzed" : "Ready for input");
}
</script>
<?php
}
}
