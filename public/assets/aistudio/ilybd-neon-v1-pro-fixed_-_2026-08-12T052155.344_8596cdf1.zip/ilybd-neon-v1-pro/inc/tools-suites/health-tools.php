<?php
if (!function_exists('ilybd_render_tool_bmi_calculator')) {
function ilybd_render_tool_bmi_calculator() {
    ?>
    <div style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif;">
        <label class="bento-label" style="color:#ef4444;">⚖️ Enter Details / আপনার তথ্য দিন</label>
        <div style="display:flex; gap:15px; margin-bottom:15px;">
            <div style="flex:1;">
                <label style="color:#94a3b8; font-size:13px; display:block; margin-bottom:5px;">Height (cm)</label>
                <input type="number" id="bmi-height" class="cyan-glow-input" placeholder="e.g. 170" style="width:100%; padding:12px; background:#0b1120; border:1px solid #1e293b; color:#fff; border-radius:8px;">
            </div>
            <div style="flex:1;">
                <label style="color:#94a3b8; font-size:13px; display:block; margin-bottom:5px;">Weight (kg)</label>
                <input type="number" id="bmi-weight" class="cyan-glow-input" placeholder="e.g. 70" style="width:100%; padding:12px; background:#0b1120; border:1px solid #1e293b; color:#fff; border-radius:8px;">
            </div>
        </div>
        
        <button onclick="calculateBMI()" class="cyber-action-btn" style="width:100%; margin-bottom:20px; background:#ef4444; color:#fff;">⚡ CALCULATE BMI</button>
        
        <div id="bmi-result" style="display:none; background:#0b1120; border:1px solid #ef4444; padding:20px; border-radius:8px; color:#fff; text-align:center;">
            <!-- Result will be here -->
        </div>
    </div>
    <script>
        function calculateBMI() {
            var h = parseFloat(document.getElementById('bmi-height').value);
            var w = parseFloat(document.getElementById('bmi-weight').value);
            
            if(!h || !w || h <= 0 || w <= 0) { alert('Please enter valid height and weight.'); return; }
            
            var hm = h / 100; // cm to m
            var bmi = w / (hm * hm);
            var category = '';
            var color = '';
            
            if (bmi < 18.5) { category = 'Underweight'; color = '#38bdf8'; }
            else if (bmi < 25) { category = 'Normal Weight'; color = '#10b981'; }
            else if (bmi < 30) { category = 'Overweight'; color = '#f59e0b'; }
            else { category = 'Obese'; color = '#ef4444'; }
            
            document.getElementById('bmi-result').style.display = 'block';
            document.getElementById('bmi-result').style.borderColor = color;
            document.getElementById('bmi-result').innerHTML = `
                <div style="font-size:36px; font-weight:bold; color:${color};">${bmi.toFixed(1)}</div>
                <div style="font-size:20px; color:#cbd5e1; margin-top:5px;">${category}</div>
                <div style="margin-top:15px; font-size:14px; color:#94a3b8;">Body Mass Index provides a basic indicator of your body weight status.</div>
            `;
        }
    </script>
    <?php
}
}

if (!function_exists('ilybd_render_tool_bmr_calculator')) {
function ilybd_render_tool_bmr_calculator() {
    ?>
    <div style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif;">
        <label class="bento-label" style="color:#ef4444;">🔥 Enter Details / আপনার তথ্য দিন</label>
        
        <div style="margin-bottom:15px;">
            <label style="color:#94a3b8; font-size:13px; display:block; margin-bottom:5px;">Gender</label>
            <select id="bmr-gender" class="cyan-glow-input" style="width:100%; padding:12px; background:#0b1120; border:1px solid #1e293b; color:#fff; border-radius:8px;">
                <option value="male">Male (পুরুষ)</option>
                <option value="female">Female (মহিলা)</option>
            </select>
        </div>
        
        <div style="display:flex; gap:15px; margin-bottom:15px;">
            <div style="flex:1;">
                <label style="color:#94a3b8; font-size:13px; display:block; margin-bottom:5px;">Age (Years)</label>
                <input type="number" id="bmr-age" class="cyan-glow-input" placeholder="e.g. 25" style="width:100%; padding:12px; background:#0b1120; border:1px solid #1e293b; color:#fff; border-radius:8px;">
            </div>
            <div style="flex:1;">
                <label style="color:#94a3b8; font-size:13px; display:block; margin-bottom:5px;">Height (cm)</label>
                <input type="number" id="bmr-height" class="cyan-glow-input" placeholder="e.g. 170" style="width:100%; padding:12px; background:#0b1120; border:1px solid #1e293b; color:#fff; border-radius:8px;">
            </div>
            <div style="flex:1;">
                <label style="color:#94a3b8; font-size:13px; display:block; margin-bottom:5px;">Weight (kg)</label>
                <input type="number" id="bmr-weight" class="cyan-glow-input" placeholder="e.g. 70" style="width:100%; padding:12px; background:#0b1120; border:1px solid #1e293b; color:#fff; border-radius:8px;">
            </div>
        </div>
        
        <button onclick="calculateBMR()" class="cyber-action-btn" style="width:100%; margin-bottom:20px; background:#ef4444; color:#fff;">⚡ CALCULATE BMR</button>
        
        <div id="bmr-result" style="display:none; background:#0b1120; border:1px solid #ef4444; padding:20px; border-radius:8px; color:#fff; text-align:center;">
            <!-- Result will be here -->
        </div>
    </div>
    <script>
        function calculateBMR() {
            var g = document.getElementById('bmr-gender').value;
            var a = parseInt(document.getElementById('bmr-age').value);
            var h = parseFloat(document.getElementById('bmr-height').value);
            var w = parseFloat(document.getElementById('bmr-weight').value);
            
            if(!a || !h || !w || a <= 0 || h <= 0 || w <= 0) { alert('Please enter valid data.'); return; }
            
            var bmr = 0;
            // Mifflin-St Jeor Equation
            if (g === 'male') {
                bmr = (10 * w) + (6.25 * h) - (5 * a) + 5;
            } else {
                bmr = (10 * w) + (6.25 * h) - (5 * a) - 161;
            }
            
            document.getElementById('bmr-result').style.display = 'block';
            document.getElementById('bmr-result').innerHTML = `
                <div style="font-size:36px; font-weight:bold; color:#ef4444;">${Math.round(bmr)} Calories/Day</div>
                <div style="font-size:18px; color:#cbd5e1; margin-top:5px;">Basal Metabolic Rate</div>
                <div style="margin-top:15px; font-size:14px; color:#94a3b8;">This is the number of calories your body burns at rest.</div>
            `;
        }
    </script>
    <?php
}
}
