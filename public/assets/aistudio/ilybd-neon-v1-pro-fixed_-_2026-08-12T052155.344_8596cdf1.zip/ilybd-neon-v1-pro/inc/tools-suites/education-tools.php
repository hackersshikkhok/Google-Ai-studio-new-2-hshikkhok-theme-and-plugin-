<?php
/**
 * Education & Student Tools Suite
 */


/* 41. GPA to Percentage Converter */
if (!function_exists('ilybd_render_tool_gpa_percentage_converter')) {
function ilybd_render_tool_gpa_percentage_converter() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">🎓 GPA to Percentage & Grade Converter</h3>
    <input type="number" step="0.01" id="gpa-val" value="3.75" placeholder="Enter GPA (e.g. 3.75)" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; font-weight:bold; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="calcGpaPerc()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Convert to Percentage</button>
    <div id="gpa-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Percentage: 88.75% (Grade A)</div>
</div>
<script>
function calcGpaPerc() {
    const g = parseFloat(document.getElementById("gpa-val").value);
    const p = (g / 4.0) * 95;
    document.getElementById("gpa-out").innerText = "Percentage: " + p.toFixed(2) + "% (Grade A / First Class)";
}
</script>
<?php
}
}

/* 42. CGPA to Percentage Converter */
if (!function_exists('ilybd_render_tool_cgpa_percentage_converter')) {
function ilybd_render_tool_cgpa_percentage_converter() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">🏛️ Varsity CGPA to Percentage Converter</h3>
    <input type="number" step="0.01" id="cgpa-val" value="3.50" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; font-weight:bold; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="calcCgpaPerc()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Convert CGPA</button>
    <div id="cgpa-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Equivalent Percentage: 82.5%</div>
</div>
<script>
function calcCgpaPerc() {
    const c = parseFloat(document.getElementById("cgpa-val").value);
    document.getElementById("cgpa-out").innerText = "Equivalent Percentage: " + (c * 23.5).toFixed(1) + "% (First Class Honors)";
}
</script>
<?php
}
}

/* 43. Study Time Planner */
if (!function_exists('ilybd_render_tool_study_time_planner')) {
function ilybd_render_tool_study_time_planner() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">📚 Study Time Planner & Credit Hour Allocator</h3>
    <input type="number" id="study-credits" value="15" placeholder="Total Course Credits" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="calcStudyHours()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Plan Weekly Study Hours</button>
    <div id="study-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Recommended: 30 hours/week (~4.2 hrs/day)</div>
</div>
<script>
function calcStudyHours() {
    const c = parseFloat(document.getElementById("study-credits").value);
    const hrs = c * 2;
    document.getElementById("study-out").innerText = "Recommended Study Time: " + hrs + " hours/week (~" + (hrs/7).toFixed(1) + " hrs/day)";
}
</script>
<?php
}
}

/* 44. Exam Countdown */
if (!function_exists('ilybd_render_tool_exam_countdown')) {
function ilybd_render_tool_exam_countdown() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⏳ Exam Countdown Timer & Progress</h3>
    <input type="date" id="exam-date" value="2026-11-15" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; font-weight:bold; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="calcExamCountdown()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Calculate Remaining Days</button>
    <div id="exam-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Days Remaining Until Exam</div>
</div>
<script>
function calcExamCountdown() {
    const d = new Date(document.getElementById("exam-date").value);
    const now = new Date();
    const diff = Math.ceil((d - now) / (1000 * 60 * 60 * 24));
    document.getElementById("exam-out").innerHTML = "Remaining: <strong style='font-size:20px;'>" + diff + " Days</strong> (~" + (diff/7).toFixed(1) + " Weeks left)";
}
</script>
<?php
}
}

/* 45. Grade Percentage Calculator */
if (!function_exists('ilybd_render_tool_grade_percentage_calculator')) {
function ilybd_render_tool_grade_percentage_calculator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">📊 Grade Percentage Calculator</h3>
    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(180px, 1fr)); gap:10px; margin-bottom:12px;">
        <input type="number" id="m-earned" value="85" placeholder="Earned Marks" style="background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px;">
        <input type="number" id="m-total" value="100" placeholder="Total Marks" style="background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px;">
    </div>
    <button onclick="calcGradePerc()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Calculate Score</button>
    <div id="m-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Grade: 85.0% (A)</div>
</div>
<script>
function calcGradePerc() {
    const e = parseFloat(document.getElementById("m-earned").value);
    const t = parseFloat(document.getElementById("m-total").value);
    const p = (e / t) * 100;
    document.getElementById("m-out").innerText = "Grade: " + p.toFixed(1) + "% (" + (p>=80?"A+":p>=70?"A":p>=60?"B":"C") + ")";
}
</script>
<?php
}
}

/* 46. Attendance Calculator */
if (!function_exists('ilybd_render_tool_attendance_calculator')) {
function ilybd_render_tool_attendance_calculator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">📝 Class Attendance Percentage Calculator</h3>
    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(180px, 1fr)); gap:10px; margin-bottom:12px;">
        <input type="number" id="att-attended" value="30" placeholder="Attended Classes" style="background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px;">
        <input type="number" id="att-total" value="40" placeholder="Total Conducted" style="background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px;">
    </div>
    <button onclick="calcAtt()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Check Attendance %</button>
    <div id="att-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Attendance: 75.0%</div>
</div>
<script>
function calcAtt() {
    const a = parseFloat(document.getElementById("att-attended").value);
    const t = parseFloat(document.getElementById("att-total").value);
    const p = (a / t) * 100;
    document.getElementById("att-out").innerHTML = "Attendance: <strong>" + p.toFixed(1) + "%</strong> " + (p>=75?"<span style='color:#10b981;'>✅ Eligible for exams!</span>":"<span style='color:#ef4444;'>⚠️ Below 75% requirement!</span>");
}
</script>
<?php
}
}

/* 47. Required Exam Score */
if (!function_exists('ilybd_render_tool_required_exam_score')) {
function ilybd_render_tool_required_exam_score() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">🎯 Required Final Exam Score Calculator</h3>
    <input type="number" id="req-cur" value="70" placeholder="Current Internal Score (%)" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <input type="number" id="req-target" value="80" placeholder="Target Overall Grade (%)" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="calcReqScore()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Calculate Target Score</button>
    <div id="req-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Required Final Score: 90%</div>
</div>
<script>
function calcReqScore() {
    const c = parseFloat(document.getElementById("req-cur").value);
    const t = parseFloat(document.getElementById("req-target").value);
    const req = (t - (c * 0.5)) / 0.5;
    document.getElementById("req-out").innerText = "Required Score in Final Exam: " + req.toFixed(1) + "%";
}
</script>
<?php
}
}

/* 48. Semester GPA Planner */
if (!function_exists('ilybd_render_tool_semester_gpa_planner')) {
function ilybd_render_tool_semester_gpa_planner() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">🗓️ Semester SGPA Target Planner</h3>
    <p style="color:#94a3b8; font-size:13px; margin-bottom:10px;">Calculate estimated SGPA for 3 sample courses.</p>
    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(180px, 1fr)); gap:10px; margin-bottom:12px;">
        <input type="number" id="c1-g" value="4.0" placeholder="Course 1 Grade (4.0)" style="background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px;">
        <input type="number" id="c2-g" value="3.5" placeholder="Course 2 Grade (3.5)" style="background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px;">
        <input type="number" id="c3-g" value="3.75" placeholder="Course 3 Grade (3.75)" style="background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px;">
    </div>
    <button onclick="calcSgpa()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Calculate Semester SGPA</button>
    <div id="sgpa-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Estimated SGPA: 3.75</div>
</div>
<script>
function calcSgpa() {
    const g1 = parseFloat(document.getElementById("c1-g").value);
    const g2 = parseFloat(document.getElementById("c2-g").value);
    const g3 = parseFloat(document.getElementById("c3-g").value);
    const avg = (g1 + g2 + g3) / 3;
    document.getElementById("sgpa-out").innerText = "Estimated Semester SGPA: " + avg.toFixed(2);
}
</script>
<?php
}
}

/* 49. Assignment Deadline Calculator */
if (!function_exists('ilybd_render_tool_assignment_deadline')) {
function ilybd_render_tool_assignment_deadline() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">✍️ Assignment Writing Pace Calculator</h3>
    <input type="number" id="as-words" value="3000" placeholder="Total Word Count Target" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <input type="number" id="as-days" value="5" placeholder="Remaining Days" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="calcPace()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Calculate Daily Target</button>
    <div id="pace-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Daily Writing Goal: 600 Words/day</div>
</div>
<script>
function calcPace() {
    const w = parseFloat(document.getElementById("as-words").value);
    const d = parseFloat(document.getElementById("as-days").value);
    document.getElementById("pace-out").innerText = "Daily Target: " + Math.ceil(w / d) + " Words/day";
}
</script>
<?php
}
}

/* 50. Citation Generator */
if (!function_exists('ilybd_render_tool_citation_generator')) {
function ilybd_render_tool_citation_generator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">📖 Academic Citation Generator (APA/MLA)</h3>
    <input type="text" id="cite-author" value="Smith, J." placeholder="Author Name" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <input type="text" id="cite-title" value="Artificial Intelligence Essentials 2040" placeholder="Book / Article Title" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="genCite()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Generate APA 7th Citation</button>
    <div id="cite-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#00f0ff; font-family:monospace;">Smith, J. (2026). Artificial Intelligence Essentials 2040. Academic Press.</div>
</div>
<script>
function genCite() {
    const a = document.getElementById("cite-author").value;
    const t = document.getElementById("cite-title").value;
    document.getElementById("cite-out").innerText = a + " (2026). " + t + ". Academic Press.";
}
</script>
<?php
}
}
