<?php
/**
 * Video & Creator Tools Suite
 */


/* 31. YouTube Thumbnail Size Calculator */
if (!function_exists('ilybd_render_tool_youtube_thumbnail_size')) {
function ilybd_render_tool_youtube_thumbnail_size() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">📸 YouTube Thumbnail Size & Aspect Ratio Checker</h3>
    <p style="color:#94a3b8; font-size:13px; margin-bottom:12px;">Standard YouTube thumbnail size is 1280x720 pixels (16:9 aspect ratio, max 2MB).</p>
    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(180px, 1fr)); gap:10px; margin-bottom:12px;">
        <div>
            <label style="color:#cbd5e1; font-size:12px;">Width (px):</label>
            <input type="number" id="yt-w" value="1280" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px;">
        </div>
        <div>
            <label style="color:#cbd5e1; font-size:12px;">Height (px):</label>
            <input type="number" id="yt-h" value="720" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px;">
        </div>
    </div>
    <button onclick="checkYtThumb()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🔍 Check Compliance</button>
    <div id="yt-thumb-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">✅ Perfect 16:9 HD Thumbnail Dimension!</div>
</div>
<script>
function checkYtThumb() {
    const w = parseInt(document.getElementById("yt-w").value);
    const h = parseInt(document.getElementById("yt-h").value);
    const r = (w / h).toFixed(2);
    const out = document.getElementById("yt-thumb-out");
    if(w >= 1280 && h >= 720 && r == "1.78") {
        out.innerHTML = "<span style='color:#10b981;'>✅ Complies with YouTube 1280x720 16:9 standard!</span>";
    } else {
        out.innerHTML = "<span style='color:#f59e0b;'>⚠️ Ratio: " + r + " (Recommended: 16:9 / 1280x720)</span>";
    }
}
</script>
<?php
}
}

/* 32. Video Aspect Ratio Calculator */
if (!function_exists('ilybd_render_tool_video_aspect_ratio')) {
function ilybd_render_tool_video_aspect_ratio() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">🎬 Video Aspect Ratio Calculator</h3>
    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(180px, 1fr)); gap:10px; margin-bottom:12px;">
        <div>
            <label style="color:#cbd5e1; font-size:12px;">Width (px):</label>
            <input type="number" id="v-w" value="1920" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px;">
        </div>
        <div>
            <label style="color:#cbd5e1; font-size:12px;">Height (px):</label>
            <input type="number" id="v-h" value="1080" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px;">
        </div>
    </div>
    <button onclick="calcVideoRatio()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Calculate Aspect Ratio</button>
    <div id="v-ratio-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#00f0ff; font-weight:bold;">Aspect Ratio: 16:9</div>
</div>
<script>
function gcd(a, b) { return b == 0 ? a : gcd(b, a % b); }
function calcVideoRatio() {
    const w = parseInt(document.getElementById("v-w").value);
    const h = parseInt(document.getElementById("v-h").value);
    const g = gcd(w, h);
    document.getElementById("v-ratio-out").innerText = "Aspect Ratio: " + (w/g) + ":" + (h/g);
}
</script>
<?php
}
}

/* 33. Video Bitrate Calculator */
if (!function_exists('ilybd_render_tool_video_bitrate_calculator')) {
function ilybd_render_tool_video_bitrate_calculator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⚙️ Video Bitrate & Quality Guide</h3>
    <select id="v-res" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px; margin-bottom:12px;">
        <option value="1080">1080p Full HD (30fps)</option>
        <option value="1080_60">1080p Full HD (60fps)</option>
        <option value="4k">4K Ultra HD (30fps)</option>
        <option value="4k_60">4K Ultra HD (60fps)</option>
    </select>
    <button onclick="getBitrate()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Get Recommended Bitrate</button>
    <div id="bitrate-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Recommended Video Bitrate: 8 Mbps</div>
</div>
<script>
function getBitrate() {
    const r = document.getElementById("v-res").value;
    const m = { "1080": "8 Mbps", "1080_60": "12 Mbps", "4k": "35-45 Mbps", "4k_60": "53-68 Mbps" };
    document.getElementById("bitrate-out").innerText = "Recommended Video Bitrate: " + m[r];
}
</script>
<?php
}
}

/* 34. Video Size Estimator */
if (!function_exists('ilybd_render_tool_video_size_estimator')) {
function ilybd_render_tool_video_size_estimator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">💾 Video File Size Estimator</h3>
    <input type="number" id="v-dur" value="10" placeholder="Duration (minutes)" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <input type="number" id="v-br" value="8" placeholder="Bitrate (Mbps)" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="calcVSize()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Estimate File Size</button>
    <div id="v-size-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#00f0ff; font-weight:bold;">Estimated Size: 600 MB</div>
</div>
<script>
function calcVSize() {
    const d = parseFloat(document.getElementById("v-dur").value);
    const b = parseFloat(document.getElementById("v-br").value);
    const mb = (d * 60 * b) / 8;
    document.getElementById("v-size-out").innerText = "Estimated File Size: " + mb.toFixed(1) + " MB (" + (mb/1024).toFixed(2) + " GB)";
}
</script>
<?php
}
}

/* 35. Watch Time Calculator */
if (!function_exists('ilybd_render_tool_watch_time_calculator')) {
function ilybd_render_tool_watch_time_calculator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⏳ YouTube Watch-Time Hours Calculator</h3>
    <input type="number" id="wt-views" value="10000" placeholder="Total Views" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <input type="number" id="wt-avg" value="3.5" placeholder="Avg Duration (minutes)" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="calcWatchTime()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Calculate Watch Hours</button>
    <div id="wt-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Total Watch Time: 583.3 Hours</div>
</div>
<script>
function calcWatchTime() {
    const v = parseFloat(document.getElementById("wt-views").value);
    const a = parseFloat(document.getElementById("wt-avg").value);
    const h = (v * a) / 60;
    document.getElementById("wt-out").innerHTML = "Total Watch Time: <strong>" + h.toFixed(1) + " Hours</strong> (" + ((h/4000)*100).toFixed(1) + "% of 4,000 hrs goal)";
}
</script>
<?php
}
}

/* 36. Video Upload Time */
if (!function_exists('ilybd_render_tool_video_upload_time')) {
function ilybd_render_tool_video_upload_time() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">📡 Video Upload Time Calculator</h3>
    <input type="number" id="up-mb" value="500" placeholder="File Size (MB)" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <input type="number" id="up-mbps" value="10" placeholder="Upload Speed (Mbps)" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="calcUpTime()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Calculate Duration</button>
    <div id="up-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#00f0ff; font-weight:bold;">Estimated Upload Time: 6 mins 40 secs</div>
</div>
<script>
function calcUpTime() {
    const mb = parseFloat(document.getElementById("up-mb").value);
    const mbps = parseFloat(document.getElementById("up-mbps").value);
    const secs = (mb * 8) / mbps;
    const mins = Math.floor(secs / 60);
    const rem = Math.round(secs % 60);
    document.getElementById("up-out").innerText = "Estimated Upload Time: " + mins + " mins " + rem + " secs";
}
</script>
<?php
}
}

/* 37. Subtitle Density Checker */
if (!function_exists('ilybd_render_tool_subtitle_density_checker')) {
function ilybd_render_tool_subtitle_density_checker() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">💬 Subtitle Density & Reading Speed (CPS/WPM)</h3>
    <textarea id="sub-text" rows="3" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;">Sample subtitle line for video captioning.</textarea>
    <button onclick="checkSub()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🔍 Measure CPS & WPM</button>
    <div id="sub-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981;">Comfortable Reading Pace.</div>
</div>
<script>
function checkSub() {
    const t = document.getElementById("sub-text").value.trim();
    document.getElementById("sub-out").innerText = "Character Count: " + t.length + " chars (~" + (t.length/15).toFixed(1) + " secs reading time)";
}
</script>
<?php
}
}

/* 38. YouTube Chapter Generator */
if (!function_exists('ilybd_render_tool_youtube_chapter_generator')) {
function ilybd_render_tool_youtube_chapter_generator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">📑 YouTube Video Chapter Generator</h3>
    <textarea id="chap-text" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;">00:00 Introduction&#10;01:30 Overview of Tools&#10;05:15 Final Conclusion</textarea>
    <button onclick="formatChap()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 Validate & Copy Chapters</button>
    <div id="chap-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">✅ First chapter begins at 00:00. Compliant for YouTube!</div>
</div>
<script>
function formatChap() {
    const t = document.getElementById("chap-text").value.trim();
    document.getElementById("chap-out").innerText = t.startsWith("00:00") ? "✅ Valid Chapters (Starts at 00:00)" : "⚠️ First line must start with 00:00 Intro";
}
</script>
<?php
}
}

/* 39. Video Description Generator */
if (!function_exists('ilybd_render_tool_video_description_generator')) {
function ilybd_render_tool_video_description_generator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">📝 Video Description Template Generator</h3>
    <input type="text" id="desc-topic" value="Top 10 Cyber Tools 2040" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="genDesc()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Generate Description Template</button>
    <textarea id="desc-out" rows="4" style="width:100%; margin-top:15px; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;"></textarea>
</div>
<script>
function genDesc() {
    const top = document.getElementById("desc-topic").value;
    document.getElementById("desc-out").value = "🔥 " + top + "\n\nIn this video, we explore " + top + " in depth!\n\n📌 TIMESTAMPS:\n00:00 Introduction\n\n🔗 LINKS:\nWebsite: https://iloveyoubd.com\n\n#CyberTools #Tech #2040";
}
</script>
<?php
}
}

/* 40. Creator Content Calendar */
if (!function_exists('ilybd_render_tool_creator_content_calendar')) {
function ilybd_render_tool_creator_content_calendar() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">📅 Creator Content Calendar Planner</h3>
    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(180px, 1fr)); gap:10px; margin-bottom:12px;">
        <input type="text" id="cal-title" placeholder="Video Title" value="NextGen AI Review" style="background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px;">
        <select id="cal-day" style="background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;">
            <option>Monday</option><option>Wednesday</option><option>Friday</option>
        </select>
    </div>
    <button onclick="addCal()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Schedule Video Post</button>
    <div id="cal-list" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981;">📅 Scheduled: NextGen AI Review on Monday</div>
</div>
<script>
function addCal() {
    const t = document.getElementById("cal-title").value;
    const d = document.getElementById("cal-day").value;
    document.getElementById("cal-list").innerText = "📅 Scheduled: " + t + " on " + d;
}
</script>
<?php
}
}
