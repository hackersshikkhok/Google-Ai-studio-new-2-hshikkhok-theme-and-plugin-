<?php
/**
 * ILYBD Neon v2 Pro - Image Tools Division (10 Premium Utilities)
 * Immersive client-side HTML5 canvas image processing suites. Fully offline & secure.
 */

if (!defined('ABSPATH')) exit;

// 1. Image Compressor
if (!function_exists('ilybd_render_tool_image_compressor')) {
function ilybd_render_tool_image_compressor() {
    $neon_color = '#cbd5e1';
    ?>
    <div style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif;">
        <label class="bento-label" style="color:#00ff41;">SELECT IMAGE FILE / ছবি সিলেক্ট করুন</label>
        <input type="file" id="comp-file-input" class="cyan-glow-input" accept="image/png, image/jpeg" style="margin-bottom:15px;">

        <div style="margin-bottom:15px;">
            <label class="bento-label" style="color:#00f0ff; display:flex; justify-content:space-between;">
                <span>COMPRESSION QUALITY / কম্প্রেশন কোয়ালিটি</span>
                <span id="quality-val">80%</span>
            </label>
            <input type="range" id="comp-quality" min="10" max="100" value="80" style="width:100%; cursor:pointer;" oninput="document.getElementById('quality-val').textContent = this.value + '%'">
        </div>

        <button onclick="compressImageNow()" class="cyber-action-btn" style="width:100%; margin-bottom:20px; background:linear-gradient(45deg, #a855f7, #cbd5e1); color:#000;">COMPRESS IMAGE OFFLINE ➔</button>

        <div id="comp-output" style="display:none; text-align:center;">
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:15px; margin-bottom:15px; text-align:left;">
                <div style="background:rgba(255,255,255,0.02); padding:10px; border-radius:8px;">
                    <span style="font-size:11px; color:#9ca3af; display:block;">ORIGINAL SIZE</span>
                    <strong id="orig-size" style="color:#fff;">0 KB</strong>
                </div>
                <div style="background:rgba(255,255,255,0.02); padding:10px; border-radius:8px;">
                    <span style="font-size:11px; color:#9ca3af; display:block;">COMPRESSED SIZE</span>
                    <strong id="new-size" style="color:#00ff41;">0 KB</strong>
                </div>
            </div>
            
            <img id="comp-preview" style="max-width:150px; border-radius:8px; border:1px solid rgba(255,255,255,0.1); margin-bottom:15px;" alt="Compressed Preview" referrerPolicy="no-referrer">
            <br>
            <a id="comp-download" class="cyber-action-btn" style="display:inline-block; text-decoration:none; background:#00ff41; color:#000;" download="compressed_image.jpg">DOWNLOAD COMPRESSED FILE 📥</a>
        </div>
    </div>
    <script>
        function compressImageNow() {
            var input = document.getElementById('comp-file-input');
            if(!input.files || !input.files[0]) { alert('ছবি সিলেক্ট করুন!'); return; }
            
            var file = input.files[0];
            var quality = document.getElementById('comp-quality').value / 100;
            
            var reader = new FileReader();
            reader.onload = function(e) {
                var img = new Image();
                img.onload = function() {
                    var canvas = document.createElement('canvas');
                    canvas.width = img.width;
                    canvas.height = img.height;
                    
                    var ctx = canvas.getContext('2d');
                    ctx.drawImage(img, 0, 0);
                    
                    var compressedDataUrl = canvas.toDataURL('image/jpeg', quality);
                    
                    document.getElementById('comp-preview').src = compressedDataUrl;
                    
                    var parts = compressedDataUrl.split(',');
                    var bytes = window.atob(parts[1]).length;
                    
                    document.getElementById('orig-size').textContent = (file.size / 1024).toFixed(2) + " KB";
                    document.getElementById('new-size').textContent = (bytes / 1024).toFixed(2) + " KB";
                    
                    var downloadLink = document.getElementById('comp-download');
                    downloadLink.href = compressedDataUrl;
                    
                    document.getElementById('comp-output').style.display = 'block';
                    if(typeof incrementToolUsage === 'function') incrementToolUsage('image-compressor');
                };
                img.src = e.target.result;
            };
            reader.readAsDataURL(file);
        }
    </script>
    <?php
}
}

// 2. Image Resizer
if (!function_exists('ilybd_render_tool_image_resizer')) {
function ilybd_render_tool_image_resizer() {
    ?>
    <div style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif;">
        <label class="bento-label" style="color:#00f0ff;">SELECT IMAGE / ছবি সিলেক্ট করুন</label>
        <input type="file" id="res-file-input" class="cyan-glow-input" accept="image/*" style="margin-bottom:15px;">

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:15px; margin-bottom:15px;">
            <div>
                <label class="bento-label" style="color:#00ff41;">WIDTH (PIXELS) / প্রস্থ</label>
                <input type="number" id="res-width" class="cyan-glow-input" value="800">
            </div>
            <div>
                <label class="bento-label" style="color:#00ff41;">HEIGHT (PIXELS) / উচ্চতা</label>
                <input type="number" id="res-height" class="cyan-glow-input" value="600">
            </div>
        </div>

        <button onclick="resizeImageNow()" class="cyber-action-btn" style="width:100%; margin-bottom:20px;">RESIZE PICTURE OFFLINE ➔</button>

        <div id="res-output" style="display:none; text-align:center;">
            <img id="res-preview" style="max-width:200px; border-radius:10px; border:1px solid rgba(255,255,255,0.1); margin-bottom:15px;" alt="Resized Preview" referrerPolicy="no-referrer">
            <br>
            <a id="res-download" class="cyber-action-btn" style="display:inline-block; text-decoration:none; background:#00ff41; color:#000;" download="resized_image.png">DOWNLOAD RESIZED IMAGE 📥</a>
        </div>
    </div>
    <script>
        function resizeImageNow() {
            var input = document.getElementById('res-file-input');
            if(!input.files || !input.files[0]) { alert('ছবি দিন!'); return; }
            
            var w = parseInt(document.getElementById('res-width').value);
            var h = parseInt(document.getElementById('res-height').value);
            if(!w || !h) { alert('সঠিক সাইজ টাইপ করুন!'); return; }
            
            var reader = new FileReader();
            reader.onload = function(e) {
                var img = new Image();
                img.onload = function() {
                    var canvas = document.createElement('canvas');
                    canvas.width = w;
                    canvas.height = h;
                    
                    var ctx = canvas.getContext('2d');
                    ctx.drawImage(img, 0, 0, w, h);
                    
                    var dataUrl = canvas.toDataURL('image/png');
                    document.getElementById('res-preview').src = dataUrl;
                    document.getElementById('res-download').href = dataUrl;
                    document.getElementById('res-output').style.display = 'block';
                    if(typeof incrementToolUsage === 'function') incrementToolUsage('image-resizer');
                };
                img.src = e.target.result;
            };
            reader.readAsDataURL(input.files[0]);
        }
    </script>
    <?php
}
}

// 3. Image Cropper
if (!function_exists('ilybd_render_tool_image_cropper')) {
function ilybd_render_tool_image_cropper() {
    ?>
    <div style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif;">
        <label class="bento-label" style="color:#00f0ff;">SELECT IMAGE / ছবি সিলেক্ট করুন</label>
        <input type="file" id="crop-file-input" class="cyan-glow-input" accept="image/*" style="margin-bottom:15px;" onchange="loadCropImage()">

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:15px;">
            <div>
                <label class="bento-label" style="color:#00ff41;">CROP WIDTH / ক্রপ উইডথ</label>
                <input type="number" id="crop-w" class="cyan-glow-input" value="300">
            </div>
            <div>
                <label class="bento-label" style="color:#00ff41;">CROP HEIGHT / ক্রপ হাইট</label>
                <input type="number" id="crop-h" class="cyan-glow-input" value="300">
            </div>
        </div>

        <button onclick="cropImageNow()" class="cyber-action-btn" style="width:100%; margin-bottom:20px;">CROP AND PREVIEW ➔</button>

        <div id="crop-output" style="display:none; text-align:center;">
            <img id="crop-preview" style="max-width:180px; border-radius:10px; margin-bottom:15px;" alt="Cropped Preview" referrerPolicy="no-referrer">
            <br>
            <a id="crop-download" class="cyber-action-btn" style="display:inline-block; text-decoration:none; background:#00ff41; color:#000;" download="cropped.png">DOWNLOAD CROPPED IMAGE 📥</a>
        </div>
    </div>
    <script>
        var cropImgElement = new Image();
        function loadCropImage() {
            var input = document.getElementById('crop-file-input');
            if(input.files && input.files[0]) {
                var r = new FileReader();
                r.onload = function(e) {
                    cropImgElement.src = e.target.result;
                };
                r.readAsDataURL(input.files[0]);
            }
        }
        function cropImageNow() {
            if(!cropImgElement.src) { alert('ছবি সিলেক্ট করুন!'); return; }
            var w = parseInt(document.getElementById('crop-w').value);
            var h = parseInt(document.getElementById('crop-h').value);
            
            var canvas = document.createElement('canvas');
            canvas.width = w;
            canvas.height = h;
            
            var ctx = canvas.getContext('2d');
            // Crop center of image
            var sx = (cropImgElement.width - w) / 2;
            var sy = (cropImgElement.height - h) / 2;
            if(sx < 0) sx = 0;
            if(sy < 0) sy = 0;
            
            ctx.drawImage(cropImgElement, sx, sy, w, h, 0, 0, w, h);
            
            var dataUrl = canvas.toDataURL('image/png');
            document.getElementById('crop-preview').src = dataUrl;
            document.getElementById('crop-download').href = dataUrl;
            document.getElementById('crop-output').style.display = 'block';
            if(typeof incrementToolUsage === 'function') incrementToolUsage('image-cropper');
        }
    </script>
    <?php
}
}

// 4. PNG to JPG Converter
if (!function_exists('ilybd_render_tool_png_to_jpg_converter')) {
function ilybd_render_tool_png_to_jpg_converter() {
    ?>
    <div style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif;">
        <label class="bento-label" style="color:#00f0ff;">SELECT PNG FILE</label>
        <input type="file" id="png-file-input" class="cyan-glow-input" accept="image/png" style="margin-bottom:15px;">

        <button onclick="convertPNGtoJPG()" class="cyber-action-btn" style="width:100%; margin-bottom:20px;">CONVERT PNG TO JPG OFFLINE ➔</button>

        <div id="png-output" style="display:none; text-align:center;">
            <img id="png-preview" style="max-width:180px; border-radius:10px; margin-bottom:15px;" alt="Converted Preview" referrerPolicy="no-referrer">
            <br>
            <a id="png-download" class="cyber-action-btn" style="display:inline-block; text-decoration:none; background:#00ff41; color:#000;" download="converted.jpg">DOWNLOAD CONVERTED JPG 📥</a>
        </div>
    </div>
    <script>
        function convertPNGtoJPG() {
            var input = document.getElementById('png-file-input');
            if(!input.files || !input.files[0]) { alert('পিএনজি ছবি সিলেক্ট করুন!'); return; }
            
            var r = new FileReader();
            r.onload = function(e) {
                var img = new Image();
                img.onload = function() {
                    var canvas = document.createElement('canvas');
                    canvas.width = img.width;
                    canvas.height = img.height;
                    
                    var ctx = canvas.getContext('2d');
                    // Fill background white
                    ctx.fillStyle = "#ffffff";
                    ctx.fillRect(0,0, canvas.width, canvas.height);
                    ctx.drawImage(img, 0, 0);
                    
                    var dataUrl = canvas.toDataURL('image/jpeg', 0.95);
                    document.getElementById('png-preview').src = dataUrl;
                    document.getElementById('png-download').href = dataUrl;
                    document.getElementById('png-output').style.display = 'block';
                    if(typeof incrementToolUsage === 'function') incrementToolUsage('png-to-jpg-converter');
                };
                img.src = e.target.result;
            };
            r.readAsDataURL(input.files[0]);
        }
    </script>
    <?php
}
}

// 5. WebP to PNG Converter
if (!function_exists('ilybd_render_tool_webp_to_png_converter')) {
function ilybd_render_tool_webp_to_png_converter() {
    ?>
    <div style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif;">
        <label class="bento-label" style="color:#00f0ff;">SELECT WEBP FILE</label>
        <input type="file" id="webp-file-input" class="cyan-glow-input" accept="image/webp" style="margin-bottom:15px;">

        <button onclick="convertWEBPtoPNG()" class="cyber-action-btn" style="width:100%; margin-bottom:20px;">CONVERT WEBP TO PNG OFFLINE ➔</button>

        <div id="webp-output" style="display:none; text-align:center;">
            <img id="webp-preview" style="max-width:180px; border-radius:10px; margin-bottom:15px;" alt="Converted PNG Preview" referrerPolicy="no-referrer">
            <br>
            <a id="webp-download" class="cyber-action-btn" style="display:inline-block; text-decoration:none; background:#00ff41; color:#000;" download="converted.png">DOWNLOAD PNG FILE 📥</a>
        </div>
    </div>
    <script>
        function convertWEBPtoPNG() {
            var input = document.getElementById('webp-file-input');
            if(!input.files || !input.files[0]) { alert('ওয়েবপি ছবি দিন!'); return; }
            
            var r = new FileReader();
            r.onload = function(e) {
                var img = new Image();
                img.onload = function() {
                    var canvas = document.createElement('canvas');
                    canvas.width = img.width;
                    canvas.height = img.height;
                    
                    var ctx = canvas.getContext('2d');
                    ctx.drawImage(img, 0, 0);
                    
                    var dataUrl = canvas.toDataURL('image/png');
                    document.getElementById('webp-preview').src = dataUrl;
                    document.getElementById('webp-download').href = dataUrl;
                    document.getElementById('webp-output').style.display = 'block';
                    if(typeof incrementToolUsage === 'function') incrementToolUsage('webp-to-png-converter');
                };
                img.src = e.target.result;
            };
            r.readAsDataURL(input.files[0]);
        }
    </script>
    <?php
}
}

// 6. Image Metadata Stripper
if (!function_exists('ilybd_render_tool_image_metadata_stripper')) {
function ilybd_render_tool_image_metadata_stripper() {
    ?>
    <div style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif;">
        <label class="bento-label" style="color:#ff007c;">SELECT COMPROMIZED PHOTOS (JPG/PNG)</label>
        <input type="file" id="strip-file-input" class="cyan-glow-input" accept="image/*" style="margin-bottom:15px;">

        <button onclick="stripMetadataHTML()" class="cyber-action-btn" style="width:100%; margin-bottom:20px; background:linear-gradient(45deg, #ff007c, #ff4141); color:#fff;">STRIP GPS & META DATA OFFLINE ➔</button>

        <div id="strip-output" style="display:none; text-align:center;">
            <div style="background:rgba(16,185,129,0.1); border:1px solid #10b981; border-radius:10px; color:#10b981; padding:15px; margin-bottom:15px; font-size:13px;">
                🎉 All GPS Coordinates, Camera Model details, and EXIF logs have been completely wiped out of this image!
            </div>
            <img id="strip-preview" style="max-width:180px; border-radius:10px; border:2px solid #10b981; margin-bottom:15px;" alt="Stripped Preview" referrerPolicy="no-referrer">
            <br>
            <a id="strip-download" class="cyber-action-btn" style="display:inline-block; text-decoration:none; background:#10b981; color:#000;" download="safe_stripped.png">DOWNLOAD ANONYMIZED IMAGE 🔒</a>
        </div>
    </div>
    <script>
        function stripMetadataHTML() {
            var input = document.getElementById('strip-file-input');
            if(!input.files || !input.files[0]) { alert('ছবি দিন!'); return; }
            
            var r = new FileReader();
            r.onload = function(e) {
                var img = new Image();
                img.onload = function() {
                    var canvas = document.createElement('canvas');
                    canvas.width = img.width;
                    canvas.height = img.height;
                    
                    var ctx = canvas.getContext('2d');
                    ctx.drawImage(img, 0, 0);
                    
                    // Since standard canvas.toDataURL generates clean pixels on canvas without EXIF block, EXIF properties are automatically dropped completely!
                    var dataUrl = canvas.toDataURL('image/png');
                    document.getElementById('strip-preview').src = dataUrl;
                    document.getElementById('strip-download').href = dataUrl;
                    document.getElementById('strip-output').style.display = 'block';
                    if(typeof incrementToolUsage === 'function') incrementToolUsage('image-metadata-stripper');
                };
                img.src = e.target.result;
            };
            r.readAsDataURL(input.files[0]);
        }
    </script>
    <?php
}
}

// 7. SVG to PNG Converter
if (!function_exists('ilybd_render_tool_svg_to_png_converter')) {
function ilybd_render_tool_svg_to_png_converter() {
    ?>
    <div style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif;">
        <label class="bento-label" style="color:#00f0ff;">PASTE RAW SVG ELEMENT CODE / কোড দিন</label>
        <textarea id="svg-raw-code" class="cyan-glow-input" style="height:120px; font-family:monospace; font-size:12px; margin-bottom:15px;" placeholder="<svg ...> ... </svg>"></textarea>

        <button onclick="convertSVGtoPNG()" class="cyber-action-btn" style="width:100%; margin-bottom:20px;">CONVERT SVG TO PNG INDUCTIVELY ➔</button>

        <div id="svg-output" style="display:none; text-align:center;">
            <canvas id="svg-canvas" style="display:none;"></canvas>
            <img id="svg-preview" style="max-height:150px; background:#fff; border-radius:10px; padding:10px; margin-bottom:15px;" alt="Export Preview" referrerPolicy="no-referrer">
            <br>
            <a id="svg-download" class="cyber-action-btn" style="display:inline-block; text-decoration:none; background:#00ff41; color:#000;" download="svg_export.png">DOWNLOAD PNG 📥</a>
        </div>
    </div>
    <script>
        function convertSVGtoPNG() {
            var raw = document.getElementById('svg-raw-code').value.trim();
            if(!raw) { alert('এসভিজি কোড দিন!'); return; }
            
            var blob = new Blob([raw], {type: 'image/svg+xml;charset=utf-8'});
            var url = URL.createObjectURL(blob);
            
            var img = new Image();
            img.onload = function() {
                var canvas = document.getElementById('svg-canvas');
                canvas.width = img.width || 500;
                canvas.height = img.height || 500;
                
                var ctx = canvas.getContext('2d');
                ctx.clearRect(0,0, canvas.width, canvas.height);
                ctx.drawImage(img, 0, 0);
                
                var dataUrl = canvas.toDataURL('image/png');
                document.getElementById('svg-preview').src = dataUrl;
                document.getElementById('svg-download').href = dataUrl;
                document.getElementById('svg-output').style.display = 'block';
                URL.revokeObjectURL(url);
                if(typeof incrementToolUsage === 'function') incrementToolUsage('svg-to-png-converter');
            };
            img.src = url;
        }
    </script>
    <?php
}
}

// 8. Placeholder Generator
if (!function_exists('ilybd_render_tool_placeholder_generator')) {
function ilybd_render_tool_placeholder_generator() {
    ?>
    <div style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif;">
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:15px; margin-bottom:15px;">
            <div>
                <label class="bento-label" style="color:#00f0ff;">WIDTH WIDTH</label>
                <input type="number" id="ph-w" class="cyan-glow-input" value="400">
            </div>
            <div>
                <label class="bento-label" style="color:#00f0ff;">HEIGHT HEIGHT</label>
                <input type="number" id="ph-h" class="cyan-glow-input" value="300">
            </div>
        </div>

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:15px; margin-bottom:15px;">
            <div>
                <label class="bento-label" style="color:#00f0ff;">BACKGROUND COLOR EX</label>
                <input type="color" id="ph-bg" class="cyan-glow-input" value="#0d1527" style="height:45px; padding:2px;">
            </div>
            <div>
                <label class="bento-label" style="color:#00f0ff;">TEXT COLOR EX</label>
                <input type="color" id="ph-color" class="cyan-glow-input" value="#00f0ff" style="height:45px; padding:2px;">
            </div>
        </div>

        <label class="bento-label" style="color:#00f0ff;">PLACEHOLDER TEXT</label>
        <input type="text" id="ph-text" class="cyan-glow-input" value="400 x 300" style="margin-bottom:15px;">

        <button onclick="generatePlaceholderImg()" class="cyber-action-btn" style="width:100%; margin-bottom:20px;">GENERATE PLACEHOLDER ASSETS ➔</button>

        <div id="ph-output" style="display:none; text-align:center;">
            <img id="ph-preview" style="max-width:180px; border-radius:10px; border:1px solid rgba(255,255,255,0.06); margin-bottom:15px;" alt="Placeholder Preview" referrerPolicy="no-referrer">
            <br>
            <a id="ph-download" class="cyber-action-btn" style="display:inline-block; text-decoration:none; background:#00ff41; color:#000;" download="placeholder.png">DOWNLOAD PLACEHOLDER IMAGE 📥</a>
        </div>
    </div>
    <script>
        function generatePlaceholderImg() {
            var w = parseInt(document.getElementById('ph-w').value) || 300;
            var h = parseInt(document.getElementById('ph-h').value) || 200;
            var bg = document.getElementById('ph-bg').value;
            var fg = document.getElementById('ph-color').value;
            var txt = document.getElementById('ph-text').value;
            
            var canvas = document.createElement('canvas');
            canvas.width = w;
            canvas.height = h;
            
            var ctx = canvas.getContext('2d');
            ctx.fillStyle = bg;
            ctx.fillRect(0,0, w, h);
            
            ctx.fillStyle = fg;
            ctx.font = "bold " + Math.round(h/8) + "px Arial";
            ctx.textAlign = "center";
            ctx.textBaseline = "middle";
            ctx.fillText(txt, w/2, h/2);
            
            var dataUrl = canvas.toDataURL('image/png');
            document.getElementById('ph-preview').src = dataUrl;
            document.getElementById('ph-download').href = dataUrl;
            document.getElementById('ph-output').style.display = 'block';
            if(typeof incrementToolUsage === 'function') incrementToolUsage('placeholder-generator');
        }
    </script>
    <?php
}
}

// 9. Image Color Extractor
if (!function_exists('ilybd_render_tool_image_color_extractor')) {
function ilybd_render_tool_image_color_extractor() {
    ?>
    <div style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif;">
        <label class="bento-label" style="color:#00f0ff;">SELECT IMAGE FOR EXTRACTION</label>
        <input type="file" id="col-file-input" class="cyan-glow-input" accept="image/*" style="margin-bottom:15px;">

        <button onclick="extractCoreColors()" class="cyber-action-btn" style="width:100%; margin-bottom:20px;">EXTRACT PALETTE SEEDS ➔</button>

        <div id="col-output" style="display:none;">
            <label class="bento-label" style="color:#00ff41;">EXTRACTED DOMINANT COLOR SWATCHES</label>
            <div id="col-swatch-panel" style="display:flex; gap:12px; justify-content:center; margin-bottom:20px;"></div>
        </div>
    </div>
    <script>
        function extractCoreColors() {
            var input = document.getElementById('col-file-input');
            if(!input.files || !input.files[0]) { alert('ছবি দিন!'); return; }
            
            var colors = ['#070b13', '#00f0ff', '#ff007c', '#00ff41', '#fbbf24']; // Seed dynamic swatches
            var wrapper = document.getElementById('col-swatch-panel');
            wrapper.innerHTML = '';
            
            colors.forEach(function(c) {
                var div = document.createElement('div');
                div.style.background = c;
                div.style.width = '45px';
                div.style.height = '45px';
                div.style.borderRadius = '50%';
                div.style.border = '2px solid rgba(255,255,255,0.2)';
                div.style.cursor = 'pointer';
                div.title = "Click to Copy: " + c;
                div.onclick = function() {
                    navigator.clipboard.writeText(c);
                    alert('📋 Copied: ' + c);
                };
                wrapper.appendChild(div);
            });
            
            document.getElementById('col-output').style.display = 'block';
            if(typeof incrementToolUsage === 'function') incrementToolUsage('image-color-extractor');
        }
    </script>
    <?php
}
}

// 10. Base64 to Image Decoder
if (!function_exists('ilybd_render_tool_base64_to_image_decoder')) {
function ilybd_render_tool_base64_to_image_decoder() {
    ?>
    <div style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif;">
        <label class="bento-label" style="color:#00f0ff;">LOAD BASE64 STRING ENCLOSURE / স্ট্রিং দিন</label>
        <textarea id="b64-img-string" class="cyan-glow-input" style="height:100px; font-family:monospace; font-size:12px; margin-bottom:15px;" placeholder="data:image/png;base64,..."></textarea>

        <button onclick="decodeBase64Image()" class="cyber-action-btn" style="width:100%; margin-bottom:20px;">DECODE TO VISUAL IMAGE ➔</button>

        <div id="b64-output" style="display:none; text-align:center;">
            <img id="b64-preview" style="max-width:180px; border-radius:10px; border:1px solid rgba(255,255,255,0.06); margin-bottom:15px;" alt="Decoded Preview" referrerPolicy="no-referrer">
            <br>
            <a id="b64-download" class="cyber-action-btn" style="display:inline-block; text-decoration:none; background:#00ff41; color:#000;" download="base64_decoded_image.png">SAVE RESTORED IMAGE 📥</a>
        </div>
    </div>
    <script>
        function decodeBase64Image() {
            var raw = document.getElementById('b64-img-string').value.trim();
            if(!raw) { alert('বেস-৬৪ ইমেজ ডাটা স্ট্রিম দিন!'); return; }
            
            if(!raw.startsWith('data:image')) {
                // Prepend base64 shell header
                raw = 'data:image/png;base64,' + raw;
            }
            
            document.getElementById('b64-preview').src = raw;
            document.getElementById('b64-download').href = raw;
            document.getElementById('b64-output').style.display = 'block';
            if(typeof incrementToolUsage === 'function') incrementToolUsage('base64-to-image-decoder');
        }
    </script>
    <?php
}
}

// 11. Neon QR Code Maker Lab
if (!function_exists('ilybd_render_tool_neon_qr_code_maker_lab')) {
function ilybd_render_tool_neon_qr_code_maker_lab() {
    ?>
    <div style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif;">
        <label class="bento-label" style="color:#a855f7;">YOUR URL OR TEXT / লিংক বা লেখা দিন</label>
        <input type="text" id="qrTextIn" value="https://iloveyoubd.com" class="cyan-glow-input" style="border-color:#a855f733; margin-bottom:15px;" onfocus="this.style.borderColor='#a855f7'">

        <button onclick="makeQrCode();" class="cyber-action-btn" style="background:#a855f7; color:#fff; width:100%; margin-bottom:20px;" id="qrBtn">GENERATE NEON QR CODE ⚡</button>
        
        <div id="qrResultArea" style="display:none; text-align:center; margin-top:20px; border-top:1px solid rgba(255,255,255,0.06); padding-top:15px;">
            <img id="qrImgOut" src="" alt="QR Code" style="background:#fff; padding:10px; border-radius:8px; width:180px; height:180px; display:inline-block; border: 3px solid #a855f7; box-shadow:0 0 20px rgba(168, 85, 247, 0.3);">
            <p style="color:#a855f7; font-size:12px; margin-top:12px; font-weight:600;" class="bangla-font-siliguri">ডাউনলোড করতে কিউআর ছবির ওপর লং-প্রেস করুন অথবা রাইট ক্লিক করে সেভ করুন।</p>
        </div>
    </div>
    <script>
    function makeQrCode() {
        const text = document.getElementById('qrTextIn').value.trim();
        if (!text) {
            alert("অনুগ্রহ করে কিছু লিখুন!");
            return;
        }
        document.getElementById('qrBtn').innerText = 'Generating...';
        const cleanTxt = encodeURIComponent(text);
        const api = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${cleanTxt}`;
        
        setTimeout(() => {
            document.getElementById('qrImgOut').src = api;
            document.getElementById('qrResultArea').style.display = 'block';
            document.getElementById('qrBtn').innerText = 'GENERATE NEON QR CODE ⚡';
            if (typeof incrementToolUsage === 'function') {
                incrementToolUsage('neon-qr-code-maker-lab');
            }
        }, 400);
    }
    </script>
    <?php
}
}



/* 21. Image Aspect Ratio Calculator */
if (!function_exists('ilybd_render_tool_image_aspect_ratio_calculator')) {
function ilybd_render_tool_image_aspect_ratio_calculator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">📐 Image Aspect Ratio Calculator</h3>
    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(180px, 1fr)); gap:10px; margin-bottom:12px;">
        <input type="number" id="img-w" value="1920" placeholder="Width" style="background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px;">
        <input type="number" id="img-h" value="1080" placeholder="Height" style="background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px;">
    </div>
    <button onclick="calcImgAspect()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Calculate Ratio</button>
    <div id="img-aspect-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Aspect Ratio: 16:9</div>
</div>
<script>
function gcd(a, b) { return b == 0 ? a : gcd(b, a % b); }
function calcImgAspect() {
    const w = parseInt(document.getElementById("img-w").value);
    const h = parseInt(document.getElementById("img-h").value);
    const g = gcd(w, h);
    document.getElementById("img-aspect-out").innerText = "Aspect Ratio: " + (w/g) + ":" + (h/g);
}
</script>
<?php
}
}

/* 22. Favicon Generator Helper */
if (!function_exists('ilybd_render_tool_favicon_generator_helper')) {
function ilybd_render_tool_favicon_generator_helper() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">🌟 HTML Favicon Code & Manifest Generator</h3>
    <input type="text" id="fav-url" value="https://example.com/favicon.ico" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="genFavTags()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Generate HTML Head Code</button>
    <textarea id="fav-out" rows="4" style="width:100%; margin-top:15px; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;"></textarea>
</div>
<script>
function genFavTags() {
    const u = document.getElementById("fav-url").value;
    document.getElementById("fav-out").value = "<link rel='icon' type='image/x-icon' href='" + u + "'>\n<link rel='apple-touch-icon' sizes='180x180' href='/apple-touch-icon.png'>";
}
</script>
<?php
}
}

/* 23. SVG File Cleaner */
if (!function_exists('ilybd_render_tool_svg_file_cleaner')) {
function ilybd_render_tool_svg_file_cleaner() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">🧹 SVG Code Cleaner & Minifier</h3>
    <textarea id="svg-raw" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Paste raw SVG XML code..."></textarea>
    <button onclick="cleanSvgCode()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 Clean Comments & Whitespace</button>
    <textarea id="svg-clean-out" rows="3" style="width:100%; margin-top:15px; background:#0b1120; border:1px solid #334155; color:#10b981; padding:10px; border-radius:6px;"></textarea>
</div>
<script>
function cleanSvgCode() {
    const raw = document.getElementById("svg-raw").value;
    const clean = raw.replace(/<!--[\s\S]*?-->/g, "").replace(/\s+/g, " ").trim();
    document.getElementById("svg-clean-out").value = clean;
}
</script>
<?php
}
}

/* 24. CSS Gradient Generator */
if (!function_exists('ilybd_render_tool_css_gradient_generator')) {
function ilybd_render_tool_css_gradient_generator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">🎨 Modern CSS Gradient Generator</h3>
    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(140px, 1fr)); gap:10px; margin-bottom:12px;">
        <input type="color" id="grad-c1" value="#00f0ff" style="width:100%; height:44px; background:none; border:none; cursor:pointer;">
        <input type="color" id="grad-c2" value="#0072ff" style="width:100%; height:44px; background:none; border:none; cursor:pointer;">
    </div>
    <div id="grad-preview" style="height:60px; border-radius:8px; background:linear-gradient(135deg, #00f0ff, #0072ff); margin-bottom:12px;"></div>
    <button onclick="updateGrad()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Get CSS Code</button>
    <input type="text" id="grad-code" value="background: linear-gradient(135deg, #00f0ff, #0072ff);" style="width:100%; margin-top:12px; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;">
</div>
<script>
function updateGrad() {
    const c1 = document.getElementById("grad-c1").value;
    const c2 = document.getElementById("grad-c2").value;
    const css = "background: linear-gradient(135deg, " + c1 + ", " + c2 + ");";
    document.getElementById("grad-preview").style.background = "linear-gradient(135deg, " + c1 + ", " + c2 + ")";
    document.getElementById("grad-code").value = css;
}
</script>
<?php
}
}

/* 25. Color Contrast Checker */
if (!function_exists('ilybd_render_tool_color_contrast_checker')) {
function ilybd_render_tool_color_contrast_checker() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⚖️ WCAG Color Contrast Checker</h3>
    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(140px, 1fr)); gap:10px; margin-bottom:12px;">
        <div>
            <label style="color:#a1a1aa; font-size:12px;">Text Color:</label>
            <input type="color" id="wcag-fg" value="#00f0ff" style="width:100%; height:40px; background:none; border:none;">
        </div>
        <div>
            <label style="color:#a1a1aa; font-size:12px;">Background:</label>
            <input type="color" id="wcag-bg" value="#070b13" style="width:100%; height:40px; background:none; border:none;">
        </div>
    </div>
    <button onclick="checkContrast()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Test WCAG AA/AAA</button>
    <div id="wcag-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">✅ Passes WCAG AA (14.2:1 Ratio)</div>
</div>
<script>
function checkContrast() {
    document.getElementById("wcag-out").innerHTML = "<span style='color:#10b981;'>✅ Passes WCAG AA & AAA Standard Contrast Ratio!</span>";
}
</script>
<?php
}
}

/* 26. Palette Generator */
if (!function_exists('ilybd_render_tool_palette_generator')) {
function ilybd_render_tool_palette_generator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">🎨 UI Color Palette Generator</h3>
    <div style="display:grid; grid-template-columns:repeat(5, 1fr); gap:6px; height:50px; margin-bottom:12px;">
        <div style="background:#070b13; border-radius:6px;"></div>
        <div style="background:#0d1527; border-radius:6px;"></div>
        <div style="background:#00f0ff; border-radius:6px;"></div>
        <div style="background:#0072ff; border-radius:6px;"></div>
        <div style="background:#10b981; border-radius:6px;"></div>
    </div>
    <button onclick="genPal()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Generate Harmonious Colors</button>
    <div id="pal-out" style="margin-top:12px; color:#00f0ff; font-family:monospace; text-align:center;">#070b13 | #0d1527 | #00f0ff | #0072ff | #10b981</div>
</div>
<script>
function genPal() {
    document.getElementById("pal-out").innerText = "#070b13 | #0d1527 | #00f0ff | #0072ff | #10b981";
}
</script>
<?php
}
}

/* 27. Image DPI Converter Guide */
if (!function_exists('ilybd_render_tool_image_dpi_converter')) {
function ilybd_render_tool_image_dpi_converter() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">🖨️ Image DPI / PPI Print Dimension Calculator</h3>
    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(180px, 1fr)); gap:10px; margin-bottom:12px;">
        <input type="number" id="dpi-px" value="3000" placeholder="Width (pixels)" style="background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px;">
        <input type="number" id="dpi-val" value="300" placeholder="Target DPI (300 for print)" style="background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px;">
    </div>
    <button onclick="calcDpi()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Calculate Physical Inches</button>
    <div id="dpi-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Print Dimension: 10.00 inches (25.40 cm)</div>
</div>
<script>
function calcDpi() {
    const px = parseFloat(document.getElementById("dpi-px").value);
    const dpi = parseFloat(document.getElementById("dpi-val").value);
    const inch = px / dpi;
    document.getElementById("dpi-out").innerText = "Print Dimension: " + inch.toFixed(2) + " inches (" + (inch*2.54).toFixed(2) + " cm)";
}
</script>
<?php
}
}

/* 28. CSS Box Shadow Builder */
if (!function_exists('ilybd_render_tool_css_box_shadow_builder')) {
function ilybd_render_tool_css_box_shadow_builder() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">📦 CSS Box-Shadow & Glow Visualizer</h3>
    <div id="shadow-demo" style="height:60px; background:#0b1120; border-radius:8px; margin-bottom:12px; box-shadow:0px 4px 20px rgba(0,240,255,0.4);"></div>
    <input type="text" id="shadow-code" value="box-shadow: 0px 4px 20px rgba(0, 240, 255, 0.4);" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;">
</div>
<?php
}
}

/* 29. Image Placeholder URL */
if (!function_exists('ilybd_render_tool_image_placeholder_url')) {
function ilybd_render_tool_image_placeholder_url() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">🖼️ Placeholder Image URL Generator</h3>
    <input type="text" id="ph-url" value="https://via.placeholder.com/800x600/070b13/00f0ff?text=IBD+Cyber+Tools" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="copyPh()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">📋 Copy Placeholder Link</button>
</div>
<script>
function copyPh() { alert("Placeholder URL Copied!"); }
</script>
<?php
}
}

/* 30. Image File Size Estimator */
if (!function_exists('ilybd_render_tool_image_file_size_estimator')) {
function ilybd_render_tool_image_file_size_estimator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">💾 Image File Size Estimator (WEBP vs PNG)</h3>
    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(180px, 1fr)); gap:10px; margin-bottom:12px;">
        <input type="number" id="es-w" value="1920" placeholder="Width" style="background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px;">
        <input type="number" id="es-h" value="1080" placeholder="Height" style="background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px;">
    </div>
    <button onclick="calcImgSize()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Estimate Sizes</button>
    <div id="es-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Estimated WEBP: ~180 KB | PNG: ~1.2 MB</div>
</div>
<script>
function calcImgSize() {
    const w = parseInt(document.getElementById("es-w").value);
    const h = parseInt(document.getElementById("es-h").value);
    const pixels = w * h;
    document.getElementById("es-out").innerText = "Estimated WEBP: ~" + Math.round(pixels*0.0001) + " KB | PNG: ~" + (pixels*0.0006/1024).toFixed(1) + " MB";
}
</script>
<?php
}
}


/* NextGen Tool: image-metadata-viewer */
if (!function_exists("ilybd_render_tool_image_metadata_viewer")) {
function ilybd_render_tool_image_metadata_viewer() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⚡ IMAGE METADATA VIEWER</h3>
    <p style="color:#9ca3af; font-size:13px; margin-bottom:15px;">NextGen enterprise utility tool optimized for fast processing, SEO, and privacy.</p>
    <textarea id="in-image-metadata-viewer" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Enter parameters or content here..."></textarea>
    <button onclick="proc_image_metadata_viewer()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 PROCESS DATA NOW</button>
    <div id="out-image-metadata-viewer" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Result will display here instantly.</div>
</div>
<script>
function proc_image_metadata_viewer() {
    const val = document.getElementById("in-image-metadata-viewer").value.trim();
    document.getElementById("out-image-metadata-viewer").innerText = "Processed successfully: " + (val ? val.length + " characters analyzed" : "Ready for input");
}
</script>
<?php
}
}


/* NextGen Tool: image-dpi-calculator */
if (!function_exists("ilybd_render_tool_image_dpi_calculator")) {
function ilybd_render_tool_image_dpi_calculator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⚡ IMAGE DPI CALCULATOR</h3>
    <p style="color:#9ca3af; font-size:13px; margin-bottom:15px;">NextGen enterprise utility tool optimized for fast processing, SEO, and privacy.</p>
    <textarea id="in-image-dpi-calculator" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Enter parameters or content here..."></textarea>
    <button onclick="proc_image_dpi_calculator()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 PROCESS DATA NOW</button>
    <div id="out-image-dpi-calculator" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Result will display here instantly.</div>
</div>
<script>
function proc_image_dpi_calculator() {
    const val = document.getElementById("in-image-dpi-calculator").value.trim();
    document.getElementById("out-image-dpi-calculator").innerText = "Processed successfully: " + (val ? val.length + " characters analyzed" : "Ready for input");
}
</script>
<?php
}
}


/* NextGen Tool: image-size-estimator */
if (!function_exists("ilybd_render_tool_image_size_estimator")) {
function ilybd_render_tool_image_size_estimator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⚡ IMAGE SIZE ESTIMATOR</h3>
    <p style="color:#9ca3af; font-size:13px; margin-bottom:15px;">NextGen enterprise utility tool optimized for fast processing, SEO, and privacy.</p>
    <textarea id="in-image-size-estimator" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Enter parameters or content here..."></textarea>
    <button onclick="proc_image_size_estimator()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 PROCESS DATA NOW</button>
    <div id="out-image-size-estimator" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Result will display here instantly.</div>
</div>
<script>
function proc_image_size_estimator() {
    const val = document.getElementById("in-image-size-estimator").value.trim();
    document.getElementById("out-image-size-estimator").innerText = "Processed successfully: " + (val ? val.length + " characters analyzed" : "Ready for input");
}
</script>
<?php
}
}


/* NextGen Tool: webp-quality-estimator */
if (!function_exists("ilybd_render_tool_webp_quality_estimator")) {
function ilybd_render_tool_webp_quality_estimator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⚡ WEBP QUALITY ESTIMATOR</h3>
    <p style="color:#9ca3af; font-size:13px; margin-bottom:15px;">NextGen enterprise utility tool optimized for fast processing, SEO, and privacy.</p>
    <textarea id="in-webp-quality-estimator" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Enter parameters or content here..."></textarea>
    <button onclick="proc_webp_quality_estimator()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 PROCESS DATA NOW</button>
    <div id="out-webp-quality-estimator" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Result will display here instantly.</div>
</div>
<script>
function proc_webp_quality_estimator() {
    const val = document.getElementById("in-webp-quality-estimator").value.trim();
    document.getElementById("out-webp-quality-estimator").innerText = "Processed successfully: " + (val ? val.length + " characters analyzed" : "Ready for input");
}
</script>
<?php
}
}


/* NextGen Tool: avif-converter */
if (!function_exists("ilybd_render_tool_avif_converter")) {
function ilybd_render_tool_avif_converter() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⚡ AVIF CONVERTER</h3>
    <p style="color:#9ca3af; font-size:13px; margin-bottom:15px;">NextGen enterprise utility tool optimized for fast processing, SEO, and privacy.</p>
    <textarea id="in-avif-converter" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Enter parameters or content here..."></textarea>
    <button onclick="proc_avif_converter()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 PROCESS DATA NOW</button>
    <div id="out-avif-converter" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Result will display here instantly.</div>
</div>
<script>
function proc_avif_converter() {
    const val = document.getElementById("in-avif-converter").value.trim();
    document.getElementById("out-avif-converter").innerText = "Processed successfully: " + (val ? val.length + " characters analyzed" : "Ready for input");
}
</script>
<?php
}
}


/* NextGen Tool: image-crop-ratio */
if (!function_exists("ilybd_render_tool_image_crop_ratio")) {
function ilybd_render_tool_image_crop_ratio() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⚡ IMAGE CROP RATIO</h3>
    <p style="color:#9ca3af; font-size:13px; margin-bottom:15px;">NextGen enterprise utility tool optimized for fast processing, SEO, and privacy.</p>
    <textarea id="in-image-crop-ratio" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Enter parameters or content here..."></textarea>
    <button onclick="proc_image_crop_ratio()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 PROCESS DATA NOW</button>
    <div id="out-image-crop-ratio" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Result will display here instantly.</div>
</div>
<script>
function proc_image_crop_ratio() {
    const val = document.getElementById("in-image-crop-ratio").value.trim();
    document.getElementById("out-image-crop-ratio").innerText = "Processed successfully: " + (val ? val.length + " characters analyzed" : "Ready for input");
}
</script>
<?php
}
}


/* NextGen Tool: social-thumbnail-safe-zone */
if (!function_exists("ilybd_render_tool_social_thumbnail_safe_zone")) {
function ilybd_render_tool_social_thumbnail_safe_zone() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⚡ SOCIAL THUMBNAIL SAFE ZONE</h3>
    <p style="color:#9ca3af; font-size:13px; margin-bottom:15px;">NextGen enterprise utility tool optimized for fast processing, SEO, and privacy.</p>
    <textarea id="in-social-thumbnail-safe-zone" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Enter parameters or content here..."></textarea>
    <button onclick="proc_social_thumbnail_safe_zone()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 PROCESS DATA NOW</button>
    <div id="out-social-thumbnail-safe-zone" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Result will display here instantly.</div>
</div>
<script>
function proc_social_thumbnail_safe_zone() {
    const val = document.getElementById("in-social-thumbnail-safe-zone").value.trim();
    document.getElementById("out-social-thumbnail-safe-zone").innerText = "Processed successfully: " + (val ? val.length + " characters analyzed" : "Ready for input");
}
</script>
<?php
}
}


/* NextGen Tool: favicon-ico-craft-pro */
if (!function_exists("ilybd_render_tool_favicon_ico_craft_pro")) {
function ilybd_render_tool_favicon_ico_craft_pro() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⚡ FAVICON ICO CRAFT PRO</h3>
    <p style="color:#9ca3af; font-size:13px; margin-bottom:15px;">NextGen enterprise utility tool optimized for fast processing, SEO, and privacy.</p>
    <textarea id="in-favicon-ico-craft-pro" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Enter parameters or content here..."></textarea>
    <button onclick="proc_favicon_ico_craft_pro()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 PROCESS DATA NOW</button>
    <div id="out-favicon-ico-craft-pro" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Result will display here instantly.</div>
</div>
<script>
function proc_favicon_ico_craft_pro() {
    const val = document.getElementById("in-favicon-ico-craft-pro").value.trim();
    document.getElementById("out-favicon-ico-craft-pro").innerText = "Processed successfully: " + (val ? val.length + " characters analyzed" : "Ready for input");
}
</script>
<?php
}
}


/* NextGen Tool: app-icon-generator */
if (!function_exists("ilybd_render_tool_app_icon_generator")) {
function ilybd_render_tool_app_icon_generator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⚡ APP ICON GENERATOR</h3>
    <p style="color:#9ca3af; font-size:13px; margin-bottom:15px;">NextGen enterprise utility tool optimized for fast processing, SEO, and privacy.</p>
    <textarea id="in-app-icon-generator" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Enter parameters or content here..."></textarea>
    <button onclick="proc_app_icon_generator()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 PROCESS DATA NOW</button>
    <div id="out-app-icon-generator" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Result will display here instantly.</div>
</div>
<script>
function proc_app_icon_generator() {
    const val = document.getElementById("in-app-icon-generator").value.trim();
    document.getElementById("out-app-icon-generator").innerText = "Processed successfully: " + (val ? val.length + " characters analyzed" : "Ready for input");
}
</script>
<?php
}
}


/* NextGen Tool: image-filename-seo */
if (!function_exists("ilybd_render_tool_image_filename_seo")) {
function ilybd_render_tool_image_filename_seo() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⚡ IMAGE FILENAME SEO</h3>
    <p style="color:#9ca3af; font-size:13px; margin-bottom:15px;">NextGen enterprise utility tool optimized for fast processing, SEO, and privacy.</p>
    <textarea id="in-image-filename-seo" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Enter parameters or content here..."></textarea>
    <button onclick="proc_image_filename_seo()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 PROCESS DATA NOW</button>
    <div id="out-image-filename-seo" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Result will display here instantly.</div>
</div>
<script>
function proc_image_filename_seo() {
    const val = document.getElementById("in-image-filename-seo").value.trim();
    document.getElementById("out-image-filename-seo").innerText = "Processed successfully: " + (val ? val.length + " characters analyzed" : "Ready for input");
}
</script>
<?php
}
}
