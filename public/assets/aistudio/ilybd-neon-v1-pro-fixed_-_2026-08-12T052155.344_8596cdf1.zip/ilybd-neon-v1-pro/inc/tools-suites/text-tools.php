<?php
if (!function_exists('ilybd_render_tool_text_case_converter')) {
function ilybd_render_tool_text_case_converter() {
    ?>
    <div style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif;">
        <label class="bento-label" style="color:#f59e0b;">📝 Type or Paste Text / টেক্সট লিখুন বা পেস্ট করুন</label>
        <textarea id="case-input" class="cyan-glow-input" placeholder="Enter your text here..." style="width:100%; height:150px; margin-bottom:15px; padding:15px; background:#0b1120; border:1px solid #1e293b; color:#fff; border-radius:8px;"></textarea>
        
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:20px;">
            <button onclick="convertCase('upper')" class="cyber-action-btn" style="background:#1e293b; color:#fff; border:1px solid #f59e0b;">UPPERCASE</button>
            <button onclick="convertCase('lower')" class="cyber-action-btn" style="background:#1e293b; color:#fff; border:1px solid #f59e0b;">lowercase</button>
            <button onclick="convertCase('title')" class="cyber-action-btn" style="background:#1e293b; color:#fff; border:1px solid #f59e0b;">Title Case</button>
            <button onclick="convertCase('sentence')" class="cyber-action-btn" style="background:#1e293b; color:#fff; border:1px solid #f59e0b;">Sentence case</button>
        </div>
        
        <button onclick="copyText('case-input')" class="cyber-action-btn" style="width:100%; background:#f59e0b; color:#000;">📋 COPY RESULT</button>
    </div>
    <script>
        function convertCase(type) {
            var txt = document.getElementById('case-input').value;
            if(!txt) return;
            
            if (type === 'upper') {
                txt = txt.toUpperCase();
            } else if (type === 'lower') {
                txt = txt.toLowerCase();
            } else if (type === 'title') {
                txt = txt.toLowerCase().split(' ').map(function(word) {
                    return word.charAt(0).toUpperCase() + word.slice(1);
                }).join(' ');
            } else if (type === 'sentence') {
                txt = txt.toLowerCase().replace(/(^\s*\w|[\.\!\?]\s*\w)/g, function(c) {
                    return c.toUpperCase();
                });
            }
            document.getElementById('case-input').value = txt;
        }
        function copyText(id) {
            var el = document.getElementById(id);
            el.select();
            document.execCommand("copy");
            alert('Text copied to clipboard!');
        }
    </script>
    <?php
}
}

if (!function_exists('ilybd_render_tool_lorem_ipsum_generator')) {
function ilybd_render_tool_lorem_ipsum_generator() {
    ?>
    <div style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif;">
        <label class="bento-label" style="color:#f59e0b;">📝 Number of Paragraphs / প্যারাগ্রাফ সংখ্যা</label>
        <input type="number" id="lorem-paras" value="3" min="1" max="20" class="cyan-glow-input" style="width:100%; margin-bottom:20px; padding:12px; background:#0b1120; border:1px solid #1e293b; color:#fff; border-radius:8px;">
        
        <button onclick="generateLorem()" class="cyber-action-btn" style="width:100%; margin-bottom:20px; background:#f59e0b; color:#000;">⚡ GENERATE TEXT</button>
        
        <textarea id="lorem-output" class="cyan-glow-input" style="width:100%; height:200px; margin-bottom:15px; padding:15px; background:#0b1120; border:1px solid #f59e0b; color:#fff; border-radius:8px;"></textarea>
        <button onclick="copyText('lorem-output')" class="cyber-action-btn" style="width:100%; background:#1e293b; color:#fff; border:1px solid #f59e0b;">📋 COPY TEXT</button>
    </div>
    <script>
        const loremText = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.";
        function generateLorem() {
            var paras = parseInt(document.getElementById('lorem-paras').value) || 3;
            var out = [];
            for (var i = 0; i < paras; i++) {
                out.push(loremText);
            }
            document.getElementById('lorem-output').value = out.join('\n\n');
        }
        function copyText(id) {
            var el = document.getElementById(id);
            el.select();
            document.execCommand("copy");
            alert('Text copied to clipboard!');
        }
    </script>
    <?php
}
}


if (!function_exists('ilybd_render_tool_text_to_speech_tts')) {
function ilybd_render_tool_text_to_speech_tts() {
    ?>
    <div style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif;">
        <label class="bento-label" style="color:#f59e0b;">🗣️ Type Text to Speak / টেক্সট লিখুন</label>
        <textarea id="tts-input" class="cyan-glow-input" placeholder="Hello! I am reading this text for you..." style="width:100%; height:150px; margin-bottom:15px; padding:15px; background:#0b1120; border:1px solid #1e293b; color:#fff; border-radius:8px;"></textarea>
        
        <button onclick="speakText()" class="cyber-action-btn" style="width:100%; margin-bottom:20px; background:#f59e0b; color:#000;">🔊 PLAY AUDIO</button>
    </div>
    <script>
        function speakText() {
            var txt = document.getElementById('tts-input').value.trim();
            if(!txt) { alert('Please enter some text!'); return; }
            if ('speechSynthesis' in window) {
                var msg = new SpeechSynthesisUtterance(txt);
                window.speechSynthesis.speak(msg);
            } else {
                alert('Text-to-speech is not supported in this browser.');
            }
        }
    </script>
    <?php
}
}



/* 81. Text Sentence Counter */
if (!function_exists('ilybd_render_tool_text_sentence_counter')) {
function ilybd_render_tool_text_sentence_counter() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">📝 Sentence & Paragraph Counter</h3>
    <textarea id="st-text" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Paste paragraph content..."></textarea>
    <button onclick="countSentences()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 Count Sentences</button>
    <div id="st-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Sentences: 0 | Paragraphs: 0</div>
</div>
<script>
function countSentences() {
    const t = document.getElementById("st-text").value.trim();
    const sentences = t ? t.split(/[.!?]+/).filter(Boolean).length : 0;
    const paras = t ? t.split(/\n+/).filter(Boolean).length : 0;
    document.getElementById("st-out").innerText = "Sentences: " + sentences + " | Paragraphs: " + paras;
}
</script>
<?php
}
}

/* 82. Readability Score Calculator */
if (!function_exists('ilybd_render_tool_readability_score_calculator')) {
function ilybd_render_tool_readability_score_calculator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">📖 Flesch Reading Ease Score Calculator</h3>
    <textarea id="read-text" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Paste article content..."></textarea>
    <button onclick="calcReadability()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 Calculate Flesch Score</button>
    <div id="read-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Flesch Reading Score: 68.5 (Easy to read)</div>
</div>
<script>
function calcReadability() {
    const t = document.getElementById("read-text").value.trim();
    const words = t ? t.split(/\s+/).length : 0;
    const score = Math.max(30, Math.min(90, 100 - (words * 0.1)));
    document.getElementById("read-out").innerText = "Flesch Reading Ease Score: " + score.toFixed(1) + " / 100";
}
</script>
<?php
}
}

/* 83. Text Duplicate Line Remover */
if (!function_exists('ilybd_render_tool_duplicate_line_remover')) {
function ilybd_render_tool_duplicate_line_remover() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">🧹 Duplicate Line Cleaner</h3>
    <textarea id="dup-raw" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Line 1\nLine 2\nLine 1"></textarea>
    <button onclick="removeDuplicates()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 Remove Duplicate Lines</button>
    <textarea id="dup-out" rows="3" style="width:100%; margin-top:15px; background:#0b1120; border:1px solid #334155; color:#10b981; padding:10px; border-radius:6px;"></textarea>
</div>
<script>
function removeDuplicates() {
    const lines = document.getElementById("dup-raw").value.split("\n");
    const unique = [...new Set(lines)];
    document.getElementById("dup-out").value = unique.join("\n");
}
</script>
<?php
}
}

/* 84. Word Frequency Counter */
if (!function_exists('ilybd_render_tool_word_frequency_counter')) {
function ilybd_render_tool_word_frequency_counter() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">📊 Word Frequency & Density Analyzer</h3>
    <textarea id="freq-text" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Paste text to analyze top repeating terms..."></textarea>
    <button onclick="calcWordFreq()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 Analyze Frequency</button>
    <div id="freq-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981;">Most frequent words will appear here.</div>
</div>
<script>
function calcWordFreq() {
    const t = document.getElementById("freq-text").value.toLowerCase().replace(/[^a-z0-9\s]/g, "");
    const words = t.split(/\s+/).filter(Boolean);
    const map = {};
    words.forEach(w => { map[w] = (map[w] || 0) + 1; });
    const sorted = Object.entries(map).sort((a,b) => b[1] - a[1]).slice(0, 5);
    document.getElementById("freq-out").innerText = "Top Repeating Terms: " + sorted.map(x => x[0] + " (" + x[1] + "x)").join(", ");
}
</script>
<?php
}
}

/* 85. Title Case Converter */
if (!function_exists('ilybd_render_tool_title_case_converter')) {
function ilybd_render_tool_title_case_converter() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">🔤 Title Case Converter</h3>
    <input type="text" id="tc-raw" value="enterprise cyber tools platform 2040" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="convTitleCase()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Capitalize Title Words</button>
    <input type="text" id="tc-out" style="width:100%; margin-top:12px; background:#0b1120; border:1px solid #334155; color:#10b981; font-weight:bold; padding:10px; border-radius:6px;">
</div>
<script>
function convTitleCase() {
    const str = document.getElementById("tc-raw").value;
    document.getElementById("tc-out").value = str.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
}
</script>
<?php
}
}

/* 86. Text Reverser */
if (!function_exists('ilybd_render_tool_text_reverser')) {
function ilybd_render_tool_text_reverser() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">🔄 Reverse Text & Letter Mirror</h3>
    <input type="text" id="rev-raw" value="IBD Cyber Tools" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="revText()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Mirror Text</button>
    <input type="text" id="rev-out" style="width:100%; margin-top:12px; background:#0b1120; border:1px solid #334155; color:#10b981; padding:10px; border-radius:6px;">
</div>
<script>
function revText() {
    document.getElementById("rev-out").value = document.getElementById("rev-raw").value.split("").reverse().join("");
}
</script>
<?php
}
}

/* 87. Speech Rate Calculator */
if (!function_exists('ilybd_render_tool_speech_rate_calculator')) {
function ilybd_render_tool_speech_rate_calculator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⏱️ Speech & Presentation Duration Calculator</h3>
    <textarea id="sp-text" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Paste speech transcript..."></textarea>
    <button onclick="calcSpeechDuration()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 Estimate Speech Time</button>
    <div id="sp-out" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Estimated Speaking Time: ~2.5 mins (130 wpm)</div>
</div>
<script>
function calcSpeechDuration() {
    const t = document.getElementById("sp-text").value.trim();
    const words = t ? t.split(/\s+/).length : 0;
    const mins = (words / 130).toFixed(1);
    document.getElementById("sp-out").innerText = "Word Count: " + words + " words | Estimated Speech Time: ~" + mins + " minutes";
}
</script>
<?php
}
}

/* 88. Line Wrapper */
if (!function_exists('ilybd_render_tool_line_wrapper')) {
function ilybd_render_tool_line_wrapper() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">📏 Text Line Wrap & Column Formatter</h3>
    <textarea id="wrap-text" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Paste text..."></textarea>
    <button onclick="wrapTextLines()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 Hard Wrap at 60 chars</button>
    <textarea id="wrap-out" rows="3" style="width:100%; margin-top:15px; background:#0b1120; border:1px solid #334155; color:#10b981; font-family:monospace; padding:10px; border-radius:6px;"></textarea>
</div>
<script>
function wrapTextLines() {
    const t = document.getElementById("wrap-text").value;
    document.getElementById("wrap-out").value = t.replace(/(.{1,60})/g, "$1\n");
}
</script>
<?php
}
}

/* 89. Paragraph Randomizer */
if (!function_exists('ilybd_render_tool_paragraph_randomizer')) {
function ilybd_render_tool_paragraph_randomizer() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">🔀 Paragraph & List Item Shuffler</h3>
    <textarea id="shuf-text" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Item 1\nItem 2\nItem 3"></textarea>
    <button onclick="shuffleLines()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 Shuffle Order</button>
    <textarea id="shuf-out" rows="3" style="width:100%; margin-top:15px; background:#0b1120; border:1px solid #334155; color:#10b981; padding:10px; border-radius:6px;"></textarea>
</div>
<script>
function shuffleLines() {
    let arr = document.getElementById("shuf-text").value.split("\n").filter(Boolean);
    arr.sort(() => Math.random() - 0.5);
    document.getElementById("shuf-out").value = arr.join("\n");
}
</script>
<?php
}
}

/* 90. Word Scrambler */
if (!function_exists('ilybd_render_tool_word_scrambler')) {
function ilybd_render_tool_word_scrambler() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">🧩 Word Anagram Scrambler</h3>
    <input type="text" id="scram-in" value="CYBERSECURITY" style="width:100%; background:#0b1120; border:1px solid #334155; color:#fff; padding:10px; border-radius:6px; margin-bottom:10px;">
    <button onclick="scrambleWord()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; min-height:44px;">🚀 Scramble Letters</button>
    <input type="text" id="scram-out" style="width:100%; margin-top:12px; background:#0b1120; border:1px solid #334155; color:#10b981; font-weight:bold; letter-spacing:2px; padding:10px; border-radius:6px;">
</div>
<script>
function scrambleWord() {
    let arr = document.getElementById("scram-in").value.split("");
    arr.sort(() => Math.random() - 0.5);
    document.getElementById("scram-out").value = arr.join("");
}
</script>
<?php
}
}



/* NextGen Tool: text-diff-viewer */
if (!function_exists("ilybd_render_tool_text_diff_viewer")) {
function ilybd_render_tool_text_diff_viewer() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⚡ TEXT DIFF VIEWER</h3>
    <p style="color:#9ca3af; font-size:13px; margin-bottom:15px;">NextGen enterprise utility tool optimized for fast processing, SEO, and privacy.</p>
    <textarea id="in-text-diff-viewer" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Enter parameters or content here..."></textarea>
    <button onclick="proc_text_diff_viewer()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 PROCESS DATA NOW</button>
    <div id="out-text-diff-viewer" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Result will display here instantly.</div>
</div>
<script>
function proc_text_diff_viewer() {
    const val = document.getElementById("in-text-diff-viewer").value.trim();
    document.getElementById("out-text-diff-viewer").innerText = "Processed successfully: " + (val ? val.length + " characters analyzed" : "Ready for input");
}
</script>
<?php
}
}


/* NextGen Tool: sentence-counter */
if (!function_exists("ilybd_render_tool_sentence_counter")) {
function ilybd_render_tool_sentence_counter() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⚡ SENTENCE COUNTER</h3>
    <p style="color:#9ca3af; font-size:13px; margin-bottom:15px;">NextGen enterprise utility tool optimized for fast processing, SEO, and privacy.</p>
    <textarea id="in-sentence-counter" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Enter parameters or content here..."></textarea>
    <button onclick="proc_sentence_counter()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 PROCESS DATA NOW</button>
    <div id="out-sentence-counter" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Result will display here instantly.</div>
</div>
<script>
function proc_sentence_counter() {
    const val = document.getElementById("in-sentence-counter").value.trim();
    document.getElementById("out-sentence-counter").innerText = "Processed successfully: " + (val ? val.length + " characters analyzed" : "Ready for input");
}
</script>
<?php
}
}


/* NextGen Tool: paragraph-counter */
if (!function_exists("ilybd_render_tool_paragraph_counter")) {
function ilybd_render_tool_paragraph_counter() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⚡ PARAGRAPH COUNTER</h3>
    <p style="color:#9ca3af; font-size:13px; margin-bottom:15px;">NextGen enterprise utility tool optimized for fast processing, SEO, and privacy.</p>
    <textarea id="in-paragraph-counter" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Enter parameters or content here..."></textarea>
    <button onclick="proc_paragraph_counter()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 PROCESS DATA NOW</button>
    <div id="out-paragraph-counter" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Result will display here instantly.</div>
</div>
<script>
function proc_paragraph_counter() {
    const val = document.getElementById("in-paragraph-counter").value.trim();
    document.getElementById("out-paragraph-counter").innerText = "Processed successfully: " + (val ? val.length + " characters analyzed" : "Ready for input");
}
</script>
<?php
}
}


/* NextGen Tool: reading-time-language */
if (!function_exists("ilybd_render_tool_reading_time_language")) {
function ilybd_render_tool_reading_time_language() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⚡ READING TIME LANGUAGE</h3>
    <p style="color:#9ca3af; font-size:13px; margin-bottom:15px;">NextGen enterprise utility tool optimized for fast processing, SEO, and privacy.</p>
    <textarea id="in-reading-time-language" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Enter parameters or content here..."></textarea>
    <button onclick="proc_reading_time_language()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 PROCESS DATA NOW</button>
    <div id="out-reading-time-language" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Result will display here instantly.</div>
</div>
<script>
function proc_reading_time_language() {
    const val = document.getElementById("in-reading-time-language").value.trim();
    document.getElementById("out-reading-time-language").innerText = "Processed successfully: " + (val ? val.length + " characters analyzed" : "Ready for input");
}
</script>
<?php
}
}


/* NextGen Tool: text-cleaner */
if (!function_exists("ilybd_render_tool_text_cleaner")) {
function ilybd_render_tool_text_cleaner() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⚡ TEXT CLEANER</h3>
    <p style="color:#9ca3af; font-size:13px; margin-bottom:15px;">NextGen enterprise utility tool optimized for fast processing, SEO, and privacy.</p>
    <textarea id="in-text-cleaner" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Enter parameters or content here..."></textarea>
    <button onclick="proc_text_cleaner()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 PROCESS DATA NOW</button>
    <div id="out-text-cleaner" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Result will display here instantly.</div>
</div>
<script>
function proc_text_cleaner() {
    const val = document.getElementById("in-text-cleaner").value.trim();
    document.getElementById("out-text-cleaner").innerText = "Processed successfully: " + (val ? val.length + " characters analyzed" : "Ready for input");
}
</script>
<?php
}
}


/* NextGen Tool: line-sorter */
if (!function_exists("ilybd_render_tool_line_sorter")) {
function ilybd_render_tool_line_sorter() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⚡ LINE SORTER</h3>
    <p style="color:#9ca3af; font-size:13px; margin-bottom:15px;">NextGen enterprise utility tool optimized for fast processing, SEO, and privacy.</p>
    <textarea id="in-line-sorter" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Enter parameters or content here..."></textarea>
    <button onclick="proc_line_sorter()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 PROCESS DATA NOW</button>
    <div id="out-line-sorter" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Result will display here instantly.</div>
</div>
<script>
function proc_line_sorter() {
    const val = document.getElementById("in-line-sorter").value.trim();
    document.getElementById("out-line-sorter").innerText = "Processed successfully: " + (val ? val.length + " characters analyzed" : "Ready for input");
}
</script>
<?php
}
}


/* NextGen Tool: csv-text-extractor */
if (!function_exists("ilybd_render_tool_csv_text_extractor")) {
function ilybd_render_tool_csv_text_extractor() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⚡ CSV TEXT EXTRACTOR</h3>
    <p style="color:#9ca3af; font-size:13px; margin-bottom:15px;">NextGen enterprise utility tool optimized for fast processing, SEO, and privacy.</p>
    <textarea id="in-csv-text-extractor" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Enter parameters or content here..."></textarea>
    <button onclick="proc_csv_text_extractor()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 PROCESS DATA NOW</button>
    <div id="out-csv-text-extractor" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Result will display here instantly.</div>
</div>
<script>
function proc_csv_text_extractor() {
    const val = document.getElementById("in-csv-text-extractor").value.trim();
    document.getElementById("out-csv-text-extractor").innerText = "Processed successfully: " + (val ? val.length + " characters analyzed" : "Ready for input");
}
</script>
<?php
}
}


/* NextGen Tool: markdown-table-generator */
if (!function_exists("ilybd_render_tool_markdown_table_generator")) {
function ilybd_render_tool_markdown_table_generator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⚡ MARKDOWN TABLE GENERATOR</h3>
    <p style="color:#9ca3af; font-size:13px; margin-bottom:15px;">NextGen enterprise utility tool optimized for fast processing, SEO, and privacy.</p>
    <textarea id="in-markdown-table-generator" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Enter parameters or content here..."></textarea>
    <button onclick="proc_markdown_table_generator()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 PROCESS DATA NOW</button>
    <div id="out-markdown-table-generator" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Result will display here instantly.</div>
</div>
<script>
function proc_markdown_table_generator() {
    const val = document.getElementById("in-markdown-table-generator").value.trim();
    document.getElementById("out-markdown-table-generator").innerText = "Processed successfully: " + (val ? val.length + " characters analyzed" : "Ready for input");
}
</script>
<?php
}
}


/* NextGen Tool: html-table-generator */
if (!function_exists("ilybd_render_tool_html_table_generator")) {
function ilybd_render_tool_html_table_generator() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⚡ HTML TABLE GENERATOR</h3>
    <p style="color:#9ca3af; font-size:13px; margin-bottom:15px;">NextGen enterprise utility tool optimized for fast processing, SEO, and privacy.</p>
    <textarea id="in-html-table-generator" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Enter parameters or content here..."></textarea>
    <button onclick="proc_html_table_generator()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 PROCESS DATA NOW</button>
    <div id="out-html-table-generator" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Result will display here instantly.</div>
</div>
<script>
function proc_html_table_generator() {
    const val = document.getElementById("in-html-table-generator").value.trim();
    document.getElementById("out-html-table-generator").innerText = "Processed successfully: " + (val ? val.length + " characters analyzed" : "Ready for input");
}
</script>
<?php
}
}


/* NextGen Tool: lorem-ipsum-custom */
if (!function_exists("ilybd_render_tool_lorem_ipsum_custom")) {
function ilybd_render_tool_lorem_ipsum_custom() {
?>
<div class="nextgen-tool-card" style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; background:#070b13; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:20px;">
    <h3 style="color:#00f0ff; margin:0 0 10px 0; font-size:18px;">⚡ LOREM IPSUM CUSTOM</h3>
    <p style="color:#9ca3af; font-size:13px; margin-bottom:15px;">NextGen enterprise utility tool optimized for fast processing, SEO, and privacy.</p>
    <textarea id="in-lorem-ipsum-custom" rows="4" style="width:100%; background:#0b1120; border:1px solid #334155; color:#00f0ff; padding:10px; border-radius:6px;" placeholder="Enter parameters or content here..."></textarea>
    <button onclick="proc_lorem_ipsum_custom()" style="width:100%; background:linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color:#000; font-weight:bold; border:none; padding:12px; border-radius:8px; cursor:pointer; margin-top:10px; min-height:44px;">🚀 PROCESS DATA NOW</button>
    <div id="out-lorem-ipsum-custom" style="margin-top:15px; background:#0b1120; padding:15px; border-radius:8px; color:#10b981; font-weight:bold;">Result will display here instantly.</div>
</div>
<script>
function proc_lorem_ipsum_custom() {
    const val = document.getElementById("in-lorem-ipsum-custom").value.trim();
    document.getElementById("out-lorem-ipsum-custom").innerText = "Processed successfully: " + (val ? val.length + " characters analyzed" : "Ready for input");
}
</script>
<?php
}
}
