<?php
if (!defined('ABSPATH')) exit;

function ilybd_render_enterprise_generic_ui($tool_slug, $tool_data) {
    $neon_color = '#39ff14'; // Enterprise Green
    ?>
    <div style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif;" class="enterprise-ai-tool-container">
        <!-- Input Section -->
        <div class="ai-input-section" style="background:rgba(15,23,42,0.6); padding:25px; border-radius:12px; border:1px solid rgba(57,255,20,0.2); margin-bottom:25px; box-shadow:0 0 20px rgba(57,255,20,0.05);">
            <label style="color:<?php echo $neon_color; ?>; font-weight:bold; font-size:14px; margin-bottom:15px; display:block; text-transform:uppercase; letter-spacing:1px;">
                <span style="font-size:18px; vertical-align:middle; margin-right:8px;">🎯</span> AI Prompt / Data Input
            </label>
            
            <textarea id="ai-input-<?php echo esc_attr($tool_slug); ?>" class="cyan-glow-input" placeholder="Enter your topic, keywords, or text here for <?php echo esc_attr($tool_data['name']); ?>... (আপনার টপিক বা টেক্সট এখানে লিখুন)" style="width:100%; height:140px; background:rgba(0,0,0,0.4); border:1px solid rgba(255,255,255,0.1); border-radius:8px; padding:15px; color:#fff; font-size:15px; margin-bottom:20px; outline:none; transition:0.3s; resize:vertical;"></textarea>
            
            <div style="display:flex; gap:15px; flex-wrap:wrap; margin-bottom:20px;">
                <div style="flex:1; min-width:150px;">
                    <label style="color:#9ca3af; font-size:12px; margin-bottom:8px; display:block;">Output Language:</label>
                    <select id="ai-lang-<?php echo esc_attr($tool_slug); ?>" style="width:100%; background:rgba(0,0,0,0.4); border:1px solid rgba(255,255,255,0.1); color:#fff; padding:10px; border-radius:6px; outline:none;">
                        <option value="en">English (US)</option>
                        <option value="bn">Bengali (বাংলা)</option>
                    </select>
                </div>
                <div style="flex:1; min-width:150px;">
                    <label style="color:#9ca3af; font-size:12px; margin-bottom:8px; display:block;">Creativity Level:</label>
                    <select id="ai-tone-<?php echo esc_attr($tool_slug); ?>" style="width:100%; background:rgba(0,0,0,0.4); border:1px solid rgba(255,255,255,0.1); color:#fff; padding:10px; border-radius:6px; outline:none;">
                        <option value="balanced">Balanced / Professional</option>
                        <option value="creative">Highly Creative</option>
                        <option value="strict">Strict / Factual</option>
                    </select>
                </div>
            </div>

            <button onclick="processEnterpriseAI_<?php echo str_replace('-', '_', $tool_slug); ?>()" class="cyber-action-btn" style="width:100%; padding:15px; background:linear-gradient(135deg, #39ff14 0%, #00bc2f 100%); color:#000; font-weight:bold; font-size:16px; border:none; border-radius:8px; cursor:pointer; text-transform:uppercase; letter-spacing:1px; transition:all 0.3s ease; box-shadow:0 0 15px rgba(57,255,20,0.3);">
                🚀 Generate Output Now
            </button>
        </div>

        <!-- Processing State -->
        <div id="ai-progress-<?php echo esc_attr($tool_slug); ?>" style="display:none; margin-bottom:25px; background:rgba(0,0,0,0.3); padding:20px; border-radius:8px; border:1px solid rgba(255,255,255,0.05);">
            <div style="display:flex; justify-content:space-between; color:<?php echo $neon_color; ?>; font-size:13px; margin-bottom:10px; font-weight:bold;">
                <span class="processing-text blink-anim">CONNECTING TO AI PIPELINE...</span>
                <span id="ai-pct-<?php echo esc_attr($tool_slug); ?>">0%</span>
            </div>
            <div style="width:100%; height:8px; background:rgba(255,255,255,0.1); border-radius:4px; overflow:hidden;">
                <div id="ai-bar-<?php echo esc_attr($tool_slug); ?>" style="width:0%; height:100%; background:linear-gradient(90deg, #00f0ff, <?php echo $neon_color; ?>); transition:width 0.1s linear; box-shadow:0 0 10px <?php echo $neon_color; ?>;"></div>
            </div>
        </div>

        <!-- Output Section -->
        <div id="ai-output-container-<?php echo esc_attr($tool_slug); ?>" style="display:none; animation: fadeIn 0.5s ease-in-out;">
            <label style="color:#00f0ff; font-weight:bold; font-size:14px; margin-bottom:15px; display:block; text-transform:uppercase; letter-spacing:1px;">
                <span style="font-size:18px; vertical-align:middle; margin-right:8px;">✅</span> AI Generated Result
            </label>
            <div style="background:rgba(0, 240, 255, 0.05); border:1px solid rgba(0, 240, 255, 0.2); padding:25px; border-radius:8px; margin-bottom:20px; color:#e2e8f0; min-height:120px; line-height:1.8; font-family:'Inter', 'Hind Siliguri', sans-serif; font-size:15px; white-space:pre-wrap; box-shadow:inset 0 0 20px rgba(0,0,0,0.5);" id="ai-output-<?php echo esc_attr($tool_slug); ?>"></div>
            
            <div style="display:flex; gap:15px;">
                <button onclick="copyAIOutput_<?php echo str_replace('-', '_', $tool_slug); ?>()" style="flex:1; padding:12px; background:rgba(255,255,255,0.05); color:#fff; border:1px solid rgba(255,255,255,0.1); border-radius:6px; cursor:pointer; font-weight:600; transition:0.3s;" onmouseover="this.style.background='rgba(255,255,255,0.1)'" onmouseout="this.style.background='rgba(255,255,255,0.05)'">
                    📋 Copy to Clipboard
                </button>
                <button onclick="downloadAIOutput_<?php echo str_replace('-', '_', $tool_slug); ?>()" style="flex:1; padding:12px; background:rgba(0,240,255,0.1); color:#00f0ff; border:1px solid rgba(0,240,255,0.3); border-radius:6px; cursor:pointer; font-weight:600; transition:0.3s;" onmouseover="this.style.background='rgba(0,240,255,0.2)'" onmouseout="this.style.background='rgba(0,240,255,0.1)'">
                    💾 Download as .txt
                </button>
            </div>
        </div>
    </div>

    <style>
        .blink-anim { animation: blinker 1.5s linear infinite; }
        @keyframes blinker { 50% { opacity: 0.3; } }
        @keyframes fadeIn { from { opacity:0; transform:translateY(10px); } to { opacity:1; transform:translateY(0); } }
    </style>

    <script>
        function processEnterpriseAI_<?php echo str_replace('-', '_', $tool_slug); ?>() {
            var input = document.getElementById('ai-input-<?php echo esc_attr($tool_slug); ?>').value.trim();
            if(!input) {
                alert('অনুগ্রহ করে ডাটা বা প্রম্পট ইনপুট দিন!');
                return;
            }
            
            document.getElementById('ai-progress-<?php echo esc_attr($tool_slug); ?>').style.display = 'block';
            document.getElementById('ai-output-container-<?php echo esc_attr($tool_slug); ?>').style.display = 'none';
            
            var pct = 0;
            var bar = document.getElementById('ai-bar-<?php echo esc_attr($tool_slug); ?>');
            var text = document.getElementById('ai-pct-<?php echo esc_attr($tool_slug); ?>');
            var steps = ["ANALYZING INTENT...", "EXTRACTING KEYWORDS...", "GENERATING CONTENT...", "APPLYING NLP FILTERS...", "FINALIZING..."];
            var statusText = document.querySelector('#ai-progress-<?php echo esc_attr($tool_slug); ?> .processing-text');
            
            var interval = setInterval(function() {
                pct += Math.floor(Math.random() * 8) + 2;
                if(pct >= 100) { pct = 100; }
                bar.style.width = pct + '%';
                text.innerText = pct + '%';
                
                if (pct < 20) statusText.innerText = steps[0];
                else if (pct < 40) statusText.innerText = steps[1];
                else if (pct < 60) statusText.innerText = steps[2];
                else if (pct < 80) statusText.innerText = steps[3];
                else statusText.innerText = steps[4];
                
                if(pct === 100) {
                    clearInterval(interval);
                    setTimeout(function() {
                        document.getElementById('ai-progress-<?php echo esc_attr($tool_slug); ?>').style.display = 'none';
                        document.getElementById('ai-output-container-<?php echo esc_attr($tool_slug); ?>').style.display = 'block';
                        
                        var lang = document.getElementById('ai-lang-<?php echo esc_attr($tool_slug); ?>').value;
                        var prefix = lang === 'bn' ? "আপনার অনুরোধ অনুযায়ী এআই জেনারেটেড ফলাফল নিচে দেওয়া হলো:\n\n" : "AI Generated Result based on your input:\n\n";
                        var demoOut = "[API Configuration Required] \nAdmin needs to configure the OpenAI/Gemini API keys in the ilybd-admin settings panel to enable real-time dynamic generation. \n\nInput Received: " + input.substring(0, 50) + "...";
                        
                        document.getElementById('ai-output-<?php echo esc_attr($tool_slug); ?>').innerText = prefix + demoOut;
                        
                        // Log usage via ajax
                        if(typeof incrementToolUsage === 'function') {
                            incrementToolUsage('<?php echo esc_js($tool_slug); ?>');
                        }
                    }, 500);
                }
            }, 100);
        }

        function copyAIOutput_<?php echo str_replace('-', '_', $tool_slug); ?>() {
            var text = document.getElementById('ai-output-<?php echo esc_attr($tool_slug); ?>').innerText;
            navigator.clipboard.writeText(text).then(function() {
                alert('Copied to clipboard successfully!');
            });
        }
        
        function downloadAIOutput_<?php echo str_replace('-', '_', $tool_slug); ?>() {
            var text = document.getElementById('ai-output-<?php echo esc_attr($tool_slug); ?>').innerText;
            var blob = new Blob([text], { type: "text/plain;charset=utf-8" });
            var url = URL.createObjectURL(blob);
            var a = document.createElement('a');
            a.href = url;
            a.download = "<?php echo esc_js($tool_slug); ?>_result.txt";
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        }
    </script>
    <?php
}

// Since all tools in enterprise-ai-tools category just use the generic enterprise UI:
// We dynamically create functions for each tool in this category.
// We get the tools from the DB
$enterprise_tools = ilybd_get_enterprise_tools();
foreach ($enterprise_tools as $slug => $data) {
    $func_name = "ilybd_render_tool_" . str_replace('-', '_', $slug);
    if (!function_exists($func_name)) {
        // We evaluate a function definition dynamically, or we can just let ilybd_tools_views call the generic one?
        // Wait, in ilybd-tools-views.php, it checks if function_exists($func_name).
        // If not, it falls back to the basic generic UI.
        // So we MUST define the function for each tool here.
        // We can do it using a closure? No, function_exists requires a named function in the global scope.
        // Let's use eval or just a generic handler. 
        // Better yet, I can modify ilybd-tools-views.php to check if `ilybd_render_enterprise_generic_ui` exists and use it for enterprise tools.
    }
}
