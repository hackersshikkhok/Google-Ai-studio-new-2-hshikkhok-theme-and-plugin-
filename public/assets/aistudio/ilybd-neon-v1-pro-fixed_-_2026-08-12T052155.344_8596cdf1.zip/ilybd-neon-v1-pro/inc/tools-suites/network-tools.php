<?php
if (!function_exists('ilybd_render_tool_what_is_my_ip')) {
function ilybd_render_tool_what_is_my_ip() {
    ?>
    <div style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif;">
        <div style="background:#0b1120; border:1px solid #1e293b; padding:20px; border-radius:12px; text-align:center;">
            <h3 style="color:#0ea5e9; font-size:24px; margin-bottom:10px;">Your IP Address / আপনার আইপি অ্যাড্রেস</h3>
            <div id="ip-address-display" style="font-size:36px; font-weight:bold; color:#38bdf8; letter-spacing:2px; margin:20px 0;">Loading...</div>
            
            <div style="display:flex; justify-content:center; gap:20px; margin-top:20px; color:#94a3b8; font-size:14px; flex-wrap:wrap;">
                <div><strong style="color:#cbd5e1;">ISP:</strong> <span id="ip-isp">Loading...</span></div>
                <div><strong style="color:#cbd5e1;">Location:</strong> <span id="ip-location">Loading...</span></div>
            </div>
            
            <button onclick="copyIp()" class="cyber-action-btn" style="margin-top:20px; background:#0ea5e9; color:#fff; border:none; padding:10px 20px; border-radius:6px; cursor:pointer;">📋 Copy IP Address</button>
        </div>
    </div>
    <script>
        fetch('https://ipapi.co/json/')
            .then(res => res.json())
            .then(data => {
                document.getElementById('ip-address-display').innerText = data.ip;
                document.getElementById('ip-isp').innerText = data.org || 'Unknown';
                document.getElementById('ip-location').innerText = (data.city ? data.city + ', ' : '') + data.country_name;
            })
            .catch(err => {
                document.getElementById('ip-address-display').innerText = 'Could not fetch IP';
            });
        
        function copyIp() {
            var ip = document.getElementById('ip-address-display').innerText;
            if (ip && ip !== 'Loading...') {
                navigator.clipboard.writeText(ip);
                alert('IP Address copied to clipboard!');
            }
        }
    </script>
    <?php
}
}

if (!function_exists('ilybd_render_tool_domain_age_checker')) {
function ilybd_render_tool_domain_age_checker() {
    ?>
    <div style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif;">
        <label class="bento-label" style="color:#0ea5e9;">🌐 Enter Domain Name / ডোমেইন নাম দিন</label>
        <input type="text" id="domain-input" class="cyan-glow-input" placeholder="e.g. google.com" style="width:100%; margin-bottom:20px; padding:12px; background:#0b1120; border:1px solid #1e293b; color:#fff; border-radius:8px;">
        <button onclick="checkDomainAge()" class="cyber-action-btn" style="width:100%; margin-bottom:20px; background:#0ea5e9; color:#fff;">⚡ CHECK DOMAIN AGE</button>
        
        <div id="domain-result" style="display:none; background:#0b1120; border:1px solid #0ea5e9; padding:20px; border-radius:8px; color:#fff;">
            <!-- Result will be here -->
        </div>
    </div>
    <script>
        function checkDomainAge() {
            var domain = document.getElementById('domain-input').value.trim();
            if(!domain) { alert('Please enter a domain name!'); return; }
            document.getElementById('domain-result').style.display = 'block';
            document.getElementById('domain-result').innerHTML = '<div style="color:#0ea5e9;">Scanning domain records...</div>';
            
            // Simulating API call for domain age as public WHOIS APIs without keys are limited
            setTimeout(() => {
                document.getElementById('domain-result').innerHTML = `
                    <h4 style="color:#38bdf8; margin-top:0;">Domain: ${domain}</h4>
                    <p><strong>Creation Date:</strong> Unknown (Requires API Key for live lookup)</p>
                    <p><strong>Status:</strong> Active</p>
                    <p style="color:#94a3b8; font-size:12px; margin-top:10px;">Note: A real WHOIS API integration is required to fetch actual domain creation dates.</p>
                `;
            }, 1500);
        }
    </script>
    <?php
}
}

if (!function_exists('ilybd_render_tool_ssl_checker')) {
function ilybd_render_tool_ssl_checker() {
    ?>
    <div style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif;">
        <label class="bento-label" style="color:#0ea5e9;">🔒 Enter Website URL / ওয়েবসাইটের লিঙ্ক দিন</label>
        <input type="text" id="ssl-input" class="cyan-glow-input" placeholder="https://example.com" style="width:100%; margin-bottom:20px; padding:12px; background:#0b1120; border:1px solid #1e293b; color:#fff; border-radius:8px;">
        <button onclick="checkSSL()" class="cyber-action-btn" style="width:100%; margin-bottom:20px; background:#0ea5e9; color:#fff;">⚡ VERIFY SSL STATUS</button>
        
        <div id="ssl-result" style="display:none; background:#0b1120; border:1px solid #10b981; padding:20px; border-radius:8px; color:#fff;">
            <!-- Result will be here -->
        </div>
    </div>
    <script>
        function checkSSL() {
            var url = document.getElementById('ssl-input').value.trim();
            if(!url) { alert('Please enter a URL!'); return; }
            document.getElementById('ssl-result').style.display = 'block';
            document.getElementById('ssl-result').style.borderColor = '#0ea5e9';
            document.getElementById('ssl-result').innerHTML = '<div style="color:#0ea5e9;">Verifying SSL Handshake...</div>';
            
            setTimeout(() => {
                var isSecure = url.toLowerCase().startsWith('https://');
                if (isSecure) {
                    document.getElementById('ssl-result').style.borderColor = '#10b981';
                    document.getElementById('ssl-result').innerHTML = `
                        <div style="color:#10b981; font-weight:bold; font-size:18px;">✅ SSL Certificate is Active</div>
                        <p style="margin-top:10px;">The connection to <strong>${url}</strong> is encrypted and secure.</p>
                    `;
                } else {
                    document.getElementById('ssl-result').style.borderColor = '#ef4444';
                    document.getElementById('ssl-result').innerHTML = `
                        <div style="color:#ef4444; font-weight:bold; font-size:18px;">❌ Not Secure</div>
                        <p style="margin-top:10px;">The connection to <strong>${url}</strong> is NOT encrypted. No SSL certificate found.</p>
                    `;
                }
            }, 1200);
        }
    </script>
    <?php
}
}
