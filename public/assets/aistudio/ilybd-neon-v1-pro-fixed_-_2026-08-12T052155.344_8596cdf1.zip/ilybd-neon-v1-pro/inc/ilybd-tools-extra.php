<?php
/**
 * 2040 Next-Level Extra Tools Engine Module
 * Adds 25+ highly viral, high-CPC AdSense-friendly, SEO-magnet tools.
 * Brings total tool count to over 100.
 */

function ilybd_get_extra_tools() {
    return [
        /* -----------------------------------------
         * FINANCIAL CALCULATORS (Very High AdSense RPM)
         * ----------------------------------------- */
        'emi-calculator' => [
            'name' => 'EMI Calculator Pro',
            'name_bn' => 'ইএমআই (EMI) ক্যালকুলেটর',
            'category' => 'finance-tools',
            'desc_en' => 'Calculate your Equated Monthly Installment (EMI) for home, car, or personal loans instantly.',
            'desc_bn' => 'আপনার হোম লোন, কার লোন বা পার্সোনাল লোনের মাসিক কিস্তি (EMI) কত আসবে তা নির্ভুলভাবে হিসাব করুন।',
            'features' => ['১০০% নির্ভুল ক্যালকুলেশন', 'আসল এবং সুদের বিস্তারিত ব্রেকডাউন', 'ডায়নামিক চার্ট সাপোর্ট'],
            'benefits' => ['সহজেই লোনের পরিকল্পনা করতে পারবেন', 'ভুল হিসাবের ঝুঁকি এড়াতে পারবেন'],
            'faqs' => [
                ['Q' => 'EMI কিভাবে কাজ করে?', 'A' => 'EMI হলো আপনার লোনের আসল টাকা এবং সুদের একটি নির্দিষ্ট মাসিক কিস্তি, যা নির্দিষ্ট সময়ের মধ্যে লোন পরিশোধ করতে সাহায্য করে।'],
                ['Q' => 'এই ক্যালকুলেটর কি ফ্রী?', 'A' => 'হ্যাঁ, এটি সম্পূর্ণ বিনামূল্যে এবং ১০০% নিরাপদ। আপনার কোনো তথ্য সংরক্ষণ করা হয় না।']
            ]
        ],
        'sip-calculator' => [
            'name' => 'SIP Investment Calculator',
            'name_bn' => 'এসআইপি (SIP) ইনভেস্টমেন্ট ক্যালকুলেটর',
            'category' => 'finance-tools',
            'desc_en' => 'Calculate the future value of your Systematic Investment Plan (SIP) and achieve your financial goals.',
            'desc_bn' => 'ভবিষ্যতে আপনার এসআইপি (SIP) বিনিয়োগ কত রিটার্ন দেবে, তা দ্রুত হিসাব করুন এবং ফিনান্সিয়াল গোল সেট করুন।',
            'features' => ['দীর্ঘমেয়াদী রিটার্ন এনালাইসিস', 'ইন্টারেস্ট রেট কাস্টমাইজেশন', 'ইনফ্লেশন বা মুদ্রাস্ফীতি এডজাস্টমেন্ট অপশন'],
            'benefits' => ['স্মার্ট বিনিয়োগে সাহায্য করে', 'ভবিষ্যতের ফিনান্সিয়াল নিরাপত্তা প্ল্যানিং সহজ হয়'],
            'faqs' => [
                ['Q' => 'SIP কি?', 'A' => 'SIP (Systematic Investment Plan) হলো মিউচুয়াল ফান্ডে নিয়মিত ছোট অংকের টাকা বিনিয়োগ করার একটি নিরাপদ পদ্ধতি।']
            ]
        ],
        'paypal-fee-calculator' => [
            'name' => 'PayPal Fee Calculator',
            'name_bn' => 'পেপ্যাল ফি ক্যালকুলেটর',
            'category' => 'finance-tools',
            'desc_en' => 'Calculate PayPal fees for sending or receiving money across different regions.',
            'desc_bn' => 'ফ্রিল্যান্সিং বা ব্যবসার পেমেন্ট রিসিভ করার সময় পেপ্যাল ঠিক কত টাকা ফি কাটবে, তা আগে থেকেই জেনে নিন।',
            'features' => ['আন্তর্জাতিক ও লোকাল ফি রেট সাপোর্ট', 'সেন্ড এবং রিসিভ মোড', 'সঠিক ইনভয়েস এমাউন্ট নির্ণয়'],
            'benefits' => ['সঠিকভাবে পেমেন্ট ইনভয়েস তৈরি করতে পারবেন', 'লুকানো চার্জ থেকে বাঁচতে পারবেন'],
            'faqs' => [
                ['Q' => 'এই ফি রেট কি আপডেটেড?', 'A' => 'হ্যাঁ, আমরা পেপ্যালের স্ট্যান্ডার্ড গ্লোবাল ফি রেট অনুযায়ী এই হিসাব তৈরি করেছি।']
            ]
        ],
        'gst-calculator' => [
            'name' => 'GST Calculator',
            'name_bn' => 'জিএসটি (GST) ক্যালকুলেটর',
            'category' => 'finance-tools',
            'desc_en' => 'Calculate GST amount included or exclusive of the product price.',
            'desc_bn' => 'যেকোনো পণ্যের মূল্যের উপর জিএসটি (GST) যোগ বা বিয়োগ করে সঠিক দাম বের করুন খুব সহজেই।',
            'features' => ['Add/Remove GST অপশন', 'কাস্টমাইজড পার্সেন্টেজ স্লাইডার', 'বিস্তারিত ট্যাক্স ব্রেকডাউন'],
            'benefits' => ['ব্যবসায়িক ইনভয়েস তৈরিতে সময় বাঁচে', 'ট্যাক্স হিসাব নির্ভুল হয়'],
            'faqs' => []
        ],

        /* -----------------------------------------
         * HEALTH & FITNESS (High search volume)
         * ----------------------------------------- */
        'bmi-calculator' => [
            'name' => 'BMI Calculator',
            'name_bn' => 'বিএমআই (BMI) ক্যালকুলেটর',
            'category' => 'health-tools',
            'desc_en' => 'Check your Body Mass Index (BMI) to see if you are at a healthy weight.',
            'desc_bn' => 'উচ্চতা ও ওজনের সঠিক অনুপাত (BMI) মেপে জেনে নিন আপনার স্বাস্থ্য কেমন আছে এবং ফিট থাকতে কি করা উচিত।',
            'features' => ['মেট্রিক এবং ইম্পেরিয়াল সিস্টেম সাপোর্ট', 'বয়স ও লিঙ্গ অনুযায়ী সঠিক ফলাফল', 'স্বাস্থ্যকর ওজনের রেঞ্জ পরামর্শ'],
            'benefits' => ['শারীরিক সুস্থতা সম্পর্কে সতর্ক হওয়া যায়', 'ডায়েট প্ল্যান করতে সুবিধা হয়'],
            'faqs' => []
        ],
        'bmr-calculator' => [
            'name' => 'BMR Calculator',
            'name_bn' => 'বিএমআর (BMR) ক্যালকুলেটর',
            'category' => 'health-tools',
            'desc_en' => 'Calculate your Basal Metabolic Rate to know how many calories your body needs.',
            'desc_bn' => 'প্রতিদিন আপনার শরীরের কত ক্যালরি প্রয়োজন, তা বৈজ্ঞানিক উপায়ে (BMR) হিসাব করে বের করুন।',
            'features' => ['Mifflin-St Jeor ইকুয়েশন ব্যবহার', 'অ্যাক্টিভিটি লেভেল সিলেকশন', 'সঠিক ক্যালরি গাইড'],
            'benefits' => ['ওজন কমানো বা বাড়ানোর সঠিক ডায়েট প্ল্যান করা যায়'],
            'faqs' => []
        ],

        /* -----------------------------------------
         * TEXT & CONTENT UTILITIES (High utility & engagement)
         * ----------------------------------------- */
        'text-case-converter' => [
            'name' => 'Text Case Converter',
            'name_bn' => 'টেক্সট কেস কনভার্টার',
            'category' => 'text-tools',
            'desc_en' => 'Easily convert your text between UPPERCASE, lowercase, Title Case, and Sentence case.',
            'desc_bn' => 'আপনার ইংরেজি লেখাকে মুহূর্তের মধ্যে UPPERCASE, lowercase, বা Title Case এ পরিবর্তন করে ফেলুন।',
            'features' => ['সিঙ্গেল ক্লিক কনভার্সন', 'রিয়েল-টাইম আউটপুট', 'ক্লিপবোর্ড কপি সুবিধা'],
            'benefits' => ['লেখার ফরম্যাটিং দ্রুত ঠিক করা যায়', 'সময় বাঁচে'],
            'faqs' => []
        ],
        'lorem-ipsum-generator' => [
            'name' => 'Lorem Ipsum Generator',
            'name_bn' => 'লরেম ইপসাম (Lorem Ipsum) জেনারেটর',
            'category' => 'text-tools',
            'desc_en' => 'Generate custom Lorem Ipsum placeholder text for your design and web projects.',
            'desc_bn' => 'ডিজাইন বা ওয়েবসাইট ডেভেলপমেন্টের জন্য ডামি টেক্সট (Lorem Ipsum) জেনারেট করুন আপনার প্রয়োজন মতো।',
            'features' => ['প্যারাগ্রাফ বা শব্দ সংখ্যা সিলেক্ট করা যায়', 'এইচটিএমএল (HTML) ট্যাগ সাপোর্ট', 'দ্রুত কপি করার সুবিধা'],
            'benefits' => ['ওয়েব ডিজাইনারদের জন্য অত্যন্ত দরকারী', 'প্রজেক্টের লেআউট টেস্ট করতে সুবিধা হয়'],
            'faqs' => []
        ],
        'duplicate-line-remover' => [
            'name' => 'Duplicate Line Remover',
            'name_bn' => 'ডুপ্লিকেট লাইন রিমুভার',
            'category' => 'text-tools',
            'desc_en' => 'Clean up your text by instantly removing duplicate lines and empty spaces.',
            'desc_bn' => 'আপনার টেক্সট বা লিস্ট থেকে ডুপ্লিকেট (একাধিকবার থাকা) লাইনগুলো এক ক্লিকে মুছে ফেলুন এবং ফাইল ক্লিন করুন।',
            'features' => ['অ্যালফাবেটিক্যালি সর্ট করার অপশন', 'ফাঁকা লাইন ডিলিট করার সুবিধা', 'বড় ডাটা হ্যান্ডলিং সক্ষমতা'],
            'benefits' => ['এসও (SEO) কিওয়ার্ড ক্লিনিং এর জন্য সেরা', 'প্রোগ্রামার ও ডাটা এন্ট্রি কাজের জন্য কার্যকরী'],
            'faqs' => []
        ],
        'text-to-speech' => [
            'name' => 'Text to Speech (TTS)',
            'name_bn' => 'টেক্সট টু স্পিচ (TTS)',
            'category' => 'text-tools',
            'desc_en' => 'Convert your written text into human-like voice using advanced AI Web Speech API.',
            'desc_bn' => 'আপনার লেখা টেক্সটকে মানুষের মতো স্বাভাবিক কণ্ঠে রূপান্তর করে শুনুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['একাধিক ভাষার সাপোর্ট', 'ভয়েস স্পিড ও পিচ কন্ট্রোল', 'ব্রাউজার বেসড নিরাপদ ইঞ্জিন'],
            'benefits' => ['বই বা আর্টিকেল শোনার জন্য দারুণ', 'উচ্চারণ শিখতে সাহায্য করে'],
            'faqs' => []
        ],

        /* -----------------------------------------
         * UTILITY CONVERTERS
         * ----------------------------------------- */
        'age-calculator' => [
            'name' => 'Age Calculator',
            'name_bn' => 'বয়স ক্যালকুলেটর',
            'category' => 'utility-tools',
            'desc_en' => 'Calculate your exact age in years, months, days, and even seconds.',
            'desc_bn' => 'আপনার সঠিক বয়স বছর, মাস, দিন এবং এমনকি সেকেন্ডে কত তা একদম নির্ভুলভাবে হিসাব করুন।',
            'features' => ['নির্ভুল দিনক্ষণ হিসাব', 'পরবর্তী জন্মদিনের কাউন্টডাউন', 'সুন্দর ড্যাশবোর্ড ভিউ'],
            'benefits' => ['চাকরির আবেদনে সঠিক বয়স লিখতে সাহায্য করে', 'জন্মদিন মনে রাখতে সুবিধা হয়'],
            'faqs' => []
        ],
        'color-converter' => [
            'name' => 'Color Converter (HEX to RGB)',
            'name_bn' => 'কালার কনভার্টার (HEX/RGB)',
            'category' => 'utility-tools',
            'desc_en' => 'Convert color codes between HEX, RGB, HSL, and CMYK formats for web design.',
            'desc_bn' => 'ওয়েব ডিজাইন ও গ্রাফিক্সের জন্য বিভিন্ন কালার কোড (যেমন: HEX থেকে RGB) খুব সহজেই পরিবর্তন করুন।',
            'features' => ['রিয়েল-টাইম কালার প্রিভিউ', 'CSS ফরম্যাটে কপি করার সুবিধা', 'ডায়নামিক কালার পিকার'],
            'benefits' => ['ডিজাইনারদের সময় বাঁচায়', 'সঠিক কালার ম্যাচিং করতে সাহায্য করে'],
            'faqs' => []
        ],

        /* -----------------------------------------
         * NETWORK & WEB MASTER TOOLS
         * ----------------------------------------- */
        'what-is-my-ip' => [
            'name' => 'What Is My IP Address',
            'name_bn' => 'আমার আইপি অ্যাড্রেস কত?',
            'category' => 'network-tools',
            'desc_en' => 'Find out your public IPv4/IPv6 address, location, and ISP details instantly.',
            'desc_bn' => 'আপনার বর্তমান ইন্টারনেট কানেকশনের আইপি (IP) অ্যাড্রেস, লোকাল এরিয়া এবং আইএসপি (ISP) এর বিস্তারিত তথ্য জানুন।',
            'features' => ['পাবলিক আইপি ডিটেকশন', 'লোকেশন (শহর/দেশ) ট্র্যাকিং', 'ব্রাউজার ইউজার এজেন্ট ডিটেইলস'],
            'benefits' => ['ভিপিএন (VPN) কাজ করছে কিনা চেক করা যায়', 'নেটওয়ার্ক সিকিউরিটি সম্পর্কে নিশ্চিত হওয়া যায়'],
            'faqs' => []
        ],
        'domain-age-checker' => [
            'name' => 'Domain Age Checker',
            'name_bn' => 'ডোমেইন এজ চেকার',
            'category' => 'network-tools',
            'desc_en' => 'Check the exact age, creation date, and expiration of any website domain.',
            'desc_bn' => 'যেকোনো ওয়েবসাইটের ডোমেইন কত পুরোনো এবং কবে তৈরি হয়েছে তার বিস্তারিত ইতিহাস চেক করুন।',
            'features' => ['WHOIS ডাটাবেইজ ইনটিগ্রেশন', 'এক্সপায়ারেশন ডেট এলার্ট', 'সহজ ইউজার ইন্টারফেস'],
            'benefits' => ['পুরোনো ডোমেইন কেনার আগে চেক করতে কাজে লাগে', 'কম্পিটিটরদের ওয়েবসাইটের বয়স জানা যায়'],
            'faqs' => []
        ],
        'ssl-checker' => [
            'name' => 'SSL Certificate Checker',
            'name_bn' => 'এসএসএল (SSL) চেকার',
            'category' => 'network-tools',
            'desc_en' => 'Verify the SSL certificate installation, validity, and issuer details of a domain.',
            'desc_bn' => 'যেকোনো ওয়েবসাইটের এসএসএল (SSL) সার্টিফিকেট ঠিক আছে কিনা এবং কবে মেয়াদ শেষ হবে তা যাচাই করুন।',
            'features' => ['সার্টিফিকেট চেইন এনালাইসিস', 'এক্সপায়ারি ডেট ট্র্যাকিং', 'ইস্যুয়ার ডিটেইলস'],
            'benefits' => ['ওয়েবসাইটের সিকিউরিটি নিশ্চিত করা যায়', 'অনলাইন লেনদেনের আগে ওয়েবসাইটের বিশ্বস্ততা বোঝা যায়'],
            'faqs' => []
        ],
    
        /* -----------------------------------------
         * NEW 2026 HIGH-DEMAND ENTERPRISE & FINANCE TOOLS
         * ----------------------------------------- */
        "bd-salary-tax-calculator" => [
            "name" => "BD Income Tax Calculator 2024-2025",
            "name_bn" => "বাংলাদেশ আয়কর হিসাবক (২০২৪-২০২৫)",
            "category" => "finance-tools",
            "desc_en" => "Calculate your personal income tax according to the latest National Board of Revenue (NBR) tax slabs in Bangladesh.",
            "desc_bn" => "জাতীয় রাজস্ব বোর্ড (NBR) এর সর্বশেষ ট্যাক্স স্ল্যাব অনুসারে আপনার বার্ষিক আয়কর ও কর ছাড়ের নিখুঁত হিসাব করুন।",
            "features" => ["সর্বশেষ এনবিআর ট্যাক্স স্ল্যাব ২০২৪-২৫", "পুরুষ, নারী ও জ্যেষ্ঠ নাগরিকদের জন্য আলাদা ছাড়", "রেয়াত ও বিনিয়োগের হিসাব"],
            "benefits" => ["আয়কর রিটার্ন জমার আগে সঠিক ট্যাক্স নির্ধারণ করা যায়", "আইনসম্মত কর ছাড়ের হিসাব পাওয়া যায়"],
            "faqs" => [
                ["Q" => "বাংলাদেশে ন্যূনতম করমুক্ত আয়ের সীমা কত?", "A" => "সাধারণ পুরুষ করদাতাদের জন্য ৩,৫০,০০০ টাকা এবং নারী ও ৬৫ বছর বা তদূর্ধ্ব করদাতাদের জন্য ৪,০০,০০০ টাকা পর্যন্ত করমুক্ত।"]
            ]
        ],
        "dps-interest-calculator" => [
            "name" => "DPS Interest & Maturity Calculator",
            "name_bn" => "ডিপিএস মুনাফা ও জমা হিসাবক",
            "category" => "finance-tools",
            "desc_en" => "Calculate the exact maturity value and profit on monthly Deposit Premium Schemes (DPS) across Bangladesh banks.",
            "desc_bn" => "ডিপিএস (DPS) স্কিমে প্রতি মাসে নির্দিষ্ট পরিমাণ টাকা জমা দিলে মেয়াদ শেষে মুনাফাসহ কত টাকা পাবেন তা হিসাব করুন।",
            "features" => ["মাসিক জমার পরিমাণ ও মেয়াদ নির্বাচন", "চক্রবৃদ্ধি মুনাফা হিসাব", "কর পরবর্তী নিট প্রাপ্তি প্রদর্শন"],
            "benefits" => ["সঞ্চয় পরিকল্পনার ক্ষেত্রে সঠিক সিদ্ধান্ত নিতে সাহায্য করে", "বিভিন্ন ব্যাংকের সুদের হার তুলনা করা সহজ হয়"],
            "faqs" => [
                ["Q" => "ডিপিএসের ওপর কত শতাংশ ব্যাংক ট্যাক্স কাটে?", "A" => "টিন (TIN) সার্টিফিকেট থাকলে ১০% এবং টিন সার্টিফিকেট না থাকলে ১৫% সোর্স ট্যাক্স (AIT) কর্তন করা হয়।"]
            ]
        ],
        "fdr-profit-calculator" => [
            "name" => "FDR Profit & Return Calculator",
            "name_bn" => "এফডিআর লাভ ও রিটার্ন হিসাবক",
            "category" => "finance-tools",
            "desc_en" => "Calculate quarterly or annual interest returns on Fixed Deposit Receipts (FDR) in Bangladeshi banks.",
            "desc_bn" => "ব্যাংক বা ফিন্যান্সিয়াল প্রতিষ্ঠানে এফডিআর (FDR) এককালীন জমা রাখলে প্রতি মাসে বা বছর শেষে কত লাভ পাবেন তা হিসাব করুন।",
            "features" => ["এককালীন মূলধন ও মেয়াদের হিসাব", "উৎস কর (AIT) বাদ দিয়ে নিট লাভ", "মাসিক ও বার্ষিক মুনাফা অপশন"],
            "benefits" => ["নিরাপদ বিনিয়োগ নিশ্চিত করতে সাহায্য করে", "এক পলকে নিট মুনাফা দেখা যায়"],
            "faqs" => [
                ["Q" => "এফডিআর কি মেয়াদপূর্তির আগে ভাঙা যায়?", "A" => "হ্যাঁ, তবে মেয়াদপূর্তির আগে ভাঙলে সাধারণ সেভিংস একাউন্টের হারে কম সুদ প্রদান করা হয়।"]
            ]
        ],
        "crypto-profit-loss-calculator" => [
            "name" => "Crypto Profit & Loss Calculator",
            "name_bn" => "ক্রিপ্টো ট্রেডিং প্রফিট ও লস ক্যালকুলেটর",
            "category" => "finance-tools",
            "desc_en" => "Calculate trade profit, loss percentage, and net return on cryptocurrency trades with exchange fees.",
            "desc_bn" => "বাইন্যান্স বা যেকোনো ক্রিপ্টো এক্সচেঞ্জে ট্রেডিংয়ের কেনাবেচার দাম ও ফি বাদ দিয়ে নিট লাভ বা ক্ষতি হিসাব করুন।",
            "features" => ["বাই ও সেল প্রাইস ইনপুট", "ট্রেডিং ফি পার্সেন্টেজ হিসাব", "পার্সেন্টেজ রিটার্ন অন ইনভেস্টমেন্ট (ROI)"],
            "benefits" => ["ট্রেডিংয়ের নিখুঁত লাভ-ক্ষতি জানা যায়", "ঝুঁকি নিয়ন্ত্রণে রাখতে সাহায্য করে"],
            "faqs" => []
        ],
        "simple-compound-interest" => [
            "name" => "Simple & Compound Interest Calculator",
            "name_bn" => "সরল ও চক্রবৃদ্ধি সুদ ক্যালকুলেটর",
            "category" => "finance-tools",
            "desc_en" => "Compare simple vs compound interest growth on loans or investments over customized time periods.",
            "desc_bn" => "যেকোনো মূলধনের ওপর নির্দিষ্ট মেয়াদে সরল ও চক্রবৃদ্ধি সুদের হিসাবের পার্থক্য ও মোট বৃদ্ধি সহজেই নির্ণয় করুন।",
            "features" => ["দৈনিক, মাসিক, বার্ষিক চক্রবৃদ্ধি মেথড", "সুন্দর গ্রাফ ও চার্ট ভিউ", "সুদ ও আসলের ব্রেকডাউন"],
            "benefits" => ["অর্থনৈতিক বিনিয়োগ বোঝা সহজ হয়", "লোন বা জমার সুদের পার্থক্য স্পষ্ট হয়"],
            "faqs" => []
        ],
        "discount-sale-calculator" => [
            "name" => "Shopping Discount & Savings Calculator",
            "name_bn" => "কেনাকাটা ডিসকাউন্ট ও সেভিংস ক্যালকুলেটর",
            "category" => "finance-tools",
            "desc_en" => "Instantly compute the final price after discount and total saved amount for retail shopping.",
            "desc_bn" => "কেনাকাটার সময় যেকোনো পণে্ শতকড়়া ছাটের পর প্রকৃত দাম এবং মোট কত টাকা বাঁচলো তা সহজেই বের করুন।",
            "features" => ["মাল্টিপল ডিসকাউন্ট সাপোর্ট", "ভ্যাট/ট্যাক্স যোগ করার অপশন", "ইনস্ট্যান্ট নিট প্রাইস আউটপুট"],
            "benefits" => ["শপিং করার সময় দ্রুত দাম নিশ্চিত হওয়া যায়", "প্রকৃত ছাটের পরিমাণ জানা যায়"],
            "faqs" => []
        ],
        "loan-emi-calculator-pro" => [
            "name" => "Bank Loan EMI Calculator Pro",
            "name_bn" => "ব্যাংক লোন ইএমআই ক্যালকুলেটর প্রো",
            "category" => "finance-tools",
            "desc_en" => "Calculate equated monthly installments (EMI) for home, personal, or car loans with detailed repayment schedules.",
            "desc_bn" => "হোম লোন, পার্সোনাল লোন বা কার লোনের জন্য প্রতি মাসে কত টাকা ইএমআই (EMI) কিস্তি দিতে হবে তা হিসাব করুন।",
            "features" => ["ইএমআই প্রিন্সিপাল ও ইন্টারেস্ট চার্ট", "মাসিক কিস্তির ব্রেকডাউন", "মোট সুদের পরিমাণ নির্ণয়"],
            "benefits" => ["লোন নেওয়ার আগে মাসিক খরচের বাজেট তৈরি করা যায়", "ব্যাংক সুদের হারের সঠিক প্রভাব বোঝা যায়"],
            "faqs" => []
        ],
        /* -----------------------------------------
         * HEALTH & FITNESS TOOLS
         * ----------------------------------------- */
        "bmi-bmr-calculator" => [
            "name" => "BMI & BMR Fitness Calculator",
            "name_bn" => "বিএমআই ও বিএমআর স্বাস্থ্য ক্যালকুলেটর",
            "category" => "health-tools",
            "desc_en" => "Check your Body Mass Index (BMI) and Basal Metabolic Rate (BMR) to manage healthy weight and calories.",
            "desc_bn" => "আপনার উচ্চতা ও ওজন অনুযায়ী শরীরের বিএমআই (BMI) এবং দৈনিক মৌলিক ক্যালোরি চাহিদা (BMR) দ্রুত বের করুন।",
            "features" => ["মেট্রিক ও ইম্পেরিয়াল ইউনিট সুবিধা", "ক্যালোরি খরচের চার্ট", "স্বাস্থ্য ঝুঁকি নির্দেশক মিটার"],
            "benefits" => ["ওজন নিয়ন্ত্রণ ও ফিটনেস বজায় রাখতে সাহায্য করে", "দৈনিক খাবারের ক্যালোরি পরিকল্পনা করা সহজ হয়"],
            "faqs" => [
                ["Q" => "স্বাভাবিক বিএমআই কত হওয়া উচিত?", "A" => "প্রাপ্তবয়স্কদের জন্য ১৮.৫ থেকে ২৪.৯ বিএমআই কে আদর্শ ও স্বাভাবিক ওজন হিসেবে ধরা হয়।"]
            ]
        ],
        "water-intake-calculator" => [
            "name" => "Daily Water Intake Calculator",
            "name_bn" => "দৈনিক পানি পানের পরিমাণ হিসাবক",
            "category" => "health-tools",
            "desc_en" => "Calculate how much water you should drink daily based on body weight, activity level, and climate.",
            "desc_bn" => "আপনার শারীরিক ওজন ও দৈনন্দিন পরিশ্রমের ওপর ভিত্তি করে প্রতিদিন কত গ্লাস বা লিটার পানি পান করা প্রয়োজন তা জানুন।",
            "features" => ["ওজন ও অ্যাক্টিভিটি লেভেল ইনপুট", "গ্লাস ও লিটার গণনা", "ডিহাইড্রেশন সতর্কবার্তা"],
            "benefits" => ["শরীর হাইড্রেটেড রাখতে সাহায্য করে", "ত্বক ও কিডনির স্বাস্থ্য ভালো রাখে"],
            "faqs" => []
        ],
        "ideal-body-weight-calculator" => [
            "name" => "Ideal Body Weight (IBW) Calculator",
            "name_bn" => "আদর্শ শারীরিক ওজন ক্যালকুলেটর",
            "category" => "health-tools",
            "desc_en" => "Find your ideal body weight based on Devine and Robinson medical formulas.",
            "desc_bn" => "মেডিকেল সূত্রানুযায়ী আপনার উচ্চতা ও লিঙ্গ অনুসারে সুস্থ থাকার জন্য আদর্শ ওজন কত হওয়া উচিত তা নির্ণয় করুন।",
            "features" => ["ডিভাইন ও রবিনসন ফর্মুলা", "পুরুষ ও নারীদের জন্য আলাদা হিসাব", "রেঞ্জ ভিউ"],
            "benefits" => ["ফিটনেস টার্গেট সেট করতে সাহায্য করে", "অতিরিক্ত ওজন নিয়ন্ত্রণ করা সহজ হয়"],
            "faqs" => []
        ],
        /* -----------------------------------------
         * DEVELOPER & UI DESIGNER TOOLS
         * ----------------------------------------- */
        "css-flexbox-generator" => [
            "name" => "CSS Flexbox Layout Generator",
            "name_bn" => "সিএসএস ফ্লেক্সবক্স জেনারেটর",
            "category" => "developer-tools",
            "desc_en" => "Visually build flexible CSS flexbox containers and generate ready-to-use clean CSS code.",
            "desc_bn" => "ইন্টারেক্টিভভাবে সিএসএস ফ্লেক্সবক্স লেআউট ডিজাইন করুন এবং সাথে সাথেই কপিযোগ্য রেডিমেড সিএসএস কোড পান।",
            "features" => ["Flex-direction, Justify-content, Align-items পিকার", "লাইভ প্রিভিউ উইন্ডো", "ওয়ান ক্লিক সিএসএস কপি"],
            "benefits" => ["ওয়েব ডিজাইনারদের দ্রুত লেআউট তৈরি করতে সাহায্য করে", "লেআউট বাগ দূর করে"],
            "faqs" => []
        ],
        "css-grid-generator" => [
            "name" => "CSS Grid Studio & Generator",
            "name_bn" => "সিএসএস গ্রিড লেআউট জেনারেটর",
            "category" => "developer-tools",
            "desc_en" => "Design complex responsive multi-column CSS grid layouts visually with gap and template controls.",
            "desc_bn" => "পিক্সেল-পারফেক্ট মাল্টি-কলাম সিএসএস গ্রিড লেআউট তৈরি করুন এবং আপনার ওয়েবসাইটের জন্য সিএসএস গ্রিড কোড জেনারেট করুন।",
            "features" => ["রো ও কলাম সংখ্যা টিউন", "গ্যাপ ও ফ্র্যাকশন (fr) কন্ট্রোল", "রেসপনসিভ প্রিভিউ"],
            "benefits" => ["জটিল কলাম ডিজাইন খুব সহজে তৈরি করা যায়", "কোডিং করার সময় বাঁচায়"],
            "faqs" => []
        ],
        "border-radius-generator" => [
            "name" => "CSS Border Radius Visualizer",
            "name_bn" => "সিএসএস বর্ডার রেডিয়াস জেনারেটর",
            "category" => "developer-tools",
            "desc_en" => "Create custom smooth organic curves, pills, or rounded shapes with individual corner radius controls.",
            "desc_bn" => "ওয়েব এলিমেন্টের চার কোণার রেডিয়াস পছন্দমতো অ্যাডজাস্ট করে নান্দনিক ডিজাইন ও বর্ডার রেডিয়াস সিএসএস তৈরি করুন।",
            "features" => ["৪টি ভিন্ন কোণ স্বাধীনভাবে কাস্টমাইজ", "অর্গানিক শেপ অপশন", "লাইভ সিএসএস কোড"],
            "benefits" => ["ইউআই (UI) বাটনের লুক প্রফেশনাল করতে সাহায্য করে", "ডিজাইন ট্রাই করার সময় বাঁচায়"],
            "faqs" => []
        ],
        "box-shadow-generator" => [
            "name" => "CSS Box Shadow Designer",
            "name_bn" => "সিএসএস বক্স শ্যাডো ডিজাইন মেকার",
            "category" => "developer-tools",
            "desc_en" => "Design modern soft elevation box-shadows, inset shadows, and glowing border effects visually.",
            "desc_bn" => "কার্ড বা বাটনের ওপর আধুনিক গ্লোয়িং বা সফট ড্রপ-শ্যাডো এফেক্ট তৈরি করে সিএসএস শ্যাডো কোড কপি করুন।",
            "features" => ["X, Y অফসেট, ব্লার ও স্প্রেড স্লাইডার", "ইনসেট ও আউটসেট শ্যাডো", "কালার ও অপাসিটি টিউন"],
            "benefits" => ["মডার্ন গ্লাস ও কার্ড ডিজাইন তৈরি করা সহজ হয়", "শেড কোড দ্রুত পাওয়া যায়"],
            "faqs" => []
        ],
        "px-to-rem-converter" => [
            "name" => "Pixel to REM / EM Converter",
            "name_bn" => "পিক্সেল থেকে রেম (PX to REM) কনভার্টার",
            "category" => "developer-tools",
            "desc_en" => "Convert PX values to REM/EM units based on configurable root font size (default 16px).",
            "desc_bn" => "ওয়েবসাইটের ফন্ট সাইজ পিক্সেল (PX) থেকে এক্সেসিবল রেম (REM) ও ইএম (EM) ইউনিটে দ্রুত রূপান্তর করুন।",
            "features" => ["কাস্টমাইজেবল রুট ফন্ট সাইজ (16px)", "টু-ওয়ে রিয়েলটাইম কনভার্সন", "সিএসএস টেবিল ভিউ"],
            "benefits" => ["রেসপনসিভ ও এক্সেসিবল ওয়েবসাইট তৈরিতে অত্যন্ত দরকারি", "টাইপোগ্রাফি স্কেলিং সহজ হয়"],
            "faqs" => []
        ],
        "aspect-ratio-calculator" => [
            "name" => "Image & Video Aspect Ratio Calculator",
            "name_bn" => "অ্যাসপেক্ট রেশিও হিসাবক (16:9, 4:3)",
            "category" => "developer-tools",
            "desc_en" => "Calculate proportional width and height dimensions for videos, banners, and responsive images.",
            "desc_bn" => "ভিডিও, ব্যানার বা ইউটিউব থাম্বনেইলের ১৬:৯, ৪:৩ বা ১:১ অনুপাত বজায় রেখে নিখুঁত দৈর্ঘ্য-প্রস্থ বের করুন।",
            "features" => ["প্রিসেট রেশিও (16:9, 4:3, 1:1, 9:16)", "কাস্টম রেশিও লকিং", "রিয়েলটাইম পিক্সেল স্কেলিং"],
            "benefits" => ["ভিডিও এডিটিং ও ফটো রিসাইজিংয়ে সাহায্য করে", "ইমেজ বিকৃত হওয়া রোধ করে"],
            "faqs" => []
        ],
        /* -----------------------------------------
         * TEXT & SEO CONTENT UTILITIES
         * ----------------------------------------- */
        "word-char-counter-pro" => [
            "name" => "Advanced Word & Character Counter Pro",
            "name_bn" => "শব্দ ও অক্ষর গণনাকারী প্রো",
            "category" => "text-tools",
            "desc_en" => "Count words, characters with/without spaces, sentences, paragraphs, and reading time instantly.",
            "desc_bn" => "আপনার লেখার মোট শব্দ, অক্ষর, বাক্য, প্যারাগ্রাফ এবং আনুমানিক পড়ার সময় নির্ভুলভাবে গণনা করুন।",
            "features" => ["পড়ার আনুমানিক সময় (Reading Time)", "স্পেসসহ ও স্পেসছাড়া ক্যারেক্টার কাউন্ট", "কিওয়ার্ড ফ্রিকোয়েন্সি এনালাইসিস"],
            "benefits" => ["আর্টিকেল বা সোশ্যাল মিডিয়া পোস্টের লেন্থ ঠিক রাখা যায়", "রাইটিং স্পিড ও স্পেস অপ্টিমাইজেশন সহজ হয়"],
            "faqs" => []
        ],
        "case-converter-tool" => [
            "name" => "Uppercase, Lowercase & Title Case Converter",
            "name_bn" => "টেক্সট কেস রূপান্তরকারী",
            "category" => "text-tools",
            "desc_en" => "Convert any block of text to UPPERCASE, lowercase, Title Case, Sentence case, or Capitalized case.",
            "desc_bn" => "যেকোনো লেখাকে এক ক্লিকে বড় হাতের অক্ষর (UPPERCASE), ছোট হাতের অক্ষর (lowercase) বা টাইটেল কেসে রূপান্তর করুন।",
            "features" => ["Sentence case, Title case, UPPERCASE, lowercase", "ক্লিন বোর্ড ও ওয়ান ক্লিক কপি", "বানান ও ফরম্যাটিং অক্ষুণ্ণ রাখা"],
            "benefits" => ["আর্টিকেলের হেডিং ঠিক করতে সময় বাঁচায়", "ডাটা এন্ট্রির কাজ সহজ করে"],
            "faqs" => []
        ],
        "slug-generator-tool" => [
            "name" => "SEO Friendly URL Slug Generator",
            "name_bn" => "এসইও ফ্রেন্ডলি ইউআরএল স্লগ মেকার",
            "category" => "text-tools",
            "desc_en" => "Transform article titles into clean, lowercase, hyphenated SEO-friendly URL slugs.",
            "desc_bn" => "যেকোনো ব্লগ টাইটেল বা বাক্যকে গুগলের পছন্দসই ক্লিন, হাইফেন যুক্ত এসইও ফ্রেন্ডলি ইউআরএল (URL Slug) এ রূপান্তর করুন।",
            "features" => ["স্পেশাল ক্যারেক্টার ও সিম্বল রিমুভাল", "স্পেসকে হাইফেনে (-) রূপান্তর", "লোয়ারকেস ইউআরএল আউটপুট"],
            "benefits" => ["সার্চ ইঞ্জিনে ভালো পারফরম্যান্স দেয়", "ক্লিন ডিরেক্টরি পারমালিংক তৈরি হয়"],
            "faqs" => []
        ],
        /* -----------------------------------------
         * GENERAL UTILITY & MATH TOOLS
         * ----------------------------------------- */
        "time-zone-converter" => [
            "name" => "Global World Time Zone Converter",
            "name_bn" => "গ্লোবাল টাইম জোন কনভার্টার (BD / UTC / EST)",
            "category" => "utility-tools",
            "desc_en" => "Convert current time between Bangladesh Time (BST), UTC, EST, PST, GMT, and global time zones.",
            "desc_bn" => "বাংলাদেশ সময় (BST) এর সাথে ইউএসএ (EST/PST), ইউকে (GMT), বা ইউরোপের সময়ের তাৎক্ষণিক রূপান্তর করুন।",
            "features" => ["রিয়েল-টাইম ক্লক সিঙ্ক", "গ্লোবাল প্রধান সিটি প্রিসেট", "১২ ও ২৪ ঘণ্টার ঘড়ি ফরম্যাট"],
            "benefits" => ["ফ্রিল্যান্সারদের ক্লায়েন্ট মিটিং শিডিউল করতে সাহায্য করে", "আন্তর্জাতিক সময় সহজেই বোঝা যায়"],
            "faqs" => []
        ],
        "unit-converter-pro" => [
            "name" => "All-in-One Multi Unit Measurement Converter",
            "name_bn" => "অল-ইন-ওয়ান মাল্টি ইউনিট কনভার্টার",
            "category" => "utility-tools",
            "desc_en" => "Convert measurements across length, weight, temperature, area, volume, and speed units.",
            "desc_bn" => "দৈর্ঘ্য (মিটার/ফুট), ওজন (কেজি/পাউন্ড), তাপমাত্রা (সেলসিয়াস/ফারেনহাইট) ও আয়তন খুব সহজে রূপান্তর করুন।",
            "features" => ["দৈর্ঘ্য, ওজন, তাপমাত্রা ও এরিয়া ক্যাটালগ", "ইনস্ট্যান্ট টু-ওয়ে রেজাল্ট", "নির্ভুল দশমিক মান"],
            "benefits" => ["দৈনন্দিন হিসাব ও বিজ্ঞানের কাজে দরকারী", "সহজে একক পরিবর্তন করা যায়"],
            "faqs" => []
        ],
        "scientific-calculator-online" => [
            "name" => "Online Scientific Calculator",
            "name_bn" => "অনলাইন সায়েন্টিফিক ক্যালকুলেটর",
            "category" => "utility-tools",
            "desc_en" => "Perform advanced mathematical, trigonometric (sin, cos, tan), logarithmic, and algebraic calculations online.",
            "desc_bn" => "ত্রিকোণমিতি, লগারিদম, সূচক ও জটিল গাণিতিক হিসাব-নিকাশ ব্রাউজারেই সরাসরি সম্পন্ন করুন।",
            "features" => ["Sin, Cos, Tan, Log, Square Root, Pi", "মেমোরি সেভ (MS, MR, MC) ফানশন", "কীবোর্ড ইনপুট রেসপন্স"],
            "benefits" => ["শিক্ষার্থী ও গবেষকদের জন্য অত্যন্ত দরকারী", "ফিজিক্যাল ক্যালকুলেটরের অভাব পূরণ করে"],
            "faqs" => []
        ],
        "gpa-grading-calculator" => [
            "name" => "GPA & CGPA Grading Calculator",
            "name_bn" => "জিপিএ ও সিজিপিএ গ্রেডিং ক্যালকুলেটর",
            "category" => "utility-tools",
            "desc_en" => "Calculate your GPA / CGPA based on subject credit hours and grade points for schools and universities.",
            "desc_bn" => "এসএসসি, এইচএসসি বা বিশ্ববিদ্যালয় পরীক্ষার সাবজেক্ট ক্রেডিট ও গ্রেড পয়েন্ট দিয়ে নিখুঁত জিপিএ (GPA) হিসাব করুন।",
            "features" => ["মাল্টিপল সাবজেক্ট অ্যাড করার সুবিধা", "ক্রেডিট আওয়ার ওয়েটেড এভারেজ", "লেটার গ্রেড প্রদর্শন (A+, A, B)"],
            "benefits" => ["পরীক্ষার ফলাফল বিশ্লেষণ করা সহজ হয়", "ভবিষ্যত সিজিপিএ লক্ষ্য নির্ধারণে সাহায্য করে"],
            "faqs" => []
        ],
        "random-number-generator-pro" => [
            "name" => "Random Number Generator & Winner Picker",
            "name_bn" => "র‍্যান্ডম নম্বর জেনারেটর ও ড্র পিকার",
            "category" => "utility-tools",
            "desc_en" => "Generate cryptographic random numbers within custom ranges for raffles, games, and draws.",
            "desc_bn" => "নির্দিষ্ট রেঞ্জের (যেমন: ১ থেকে ১০০) মধ্যে সম্পূর্ণ র‍্যান্ডম নম্বর জেনারেট করুন লটারি, র্যাফেল ড্র বা বিজয়ী নির্বাচনের জন্য।",
            "features" => ["মিনিমাম ও ম্যাক্সিমাম লিমিট সেট", "ডুপ্লিকেট অ্যালাউ বা ব্লক অপশন", "ক্রিপ্টোগ্রাফিক ট্রু-র্যান্ডম স্কিম"],
            "benefits" => ["স্বচ্ছতার সাথে র্যাফেল ড্র সম্পন্ন করা যায়", "গেম ও কুইজ আয়োজনে কাজে লাগে"],
            "faqs" => []
        ],

        'word-counter' => [
            'name' => 'Word & Character Counter Pro',
            'name_bn' => 'শব্দ ও অক্ষর গণনাকারী',
            'category' => 'text-tools',
            'desc_en' => 'Instant real-time word counter, character count, sentence counter, paragraph counter, and estimated reading time calculator.',
            'desc_bn' => 'রিয়েল-টাইমে বাংলা ও ইংরেজি লেখার শব্দ সংখ্যা, অক্ষর, বাক্য এবং আনুমানিক পড়ার সময় নিখুঁতভাবে গণনা করুন।',
            'features' => ['শব্দ ও অক্ষর গণনা', 'পড়ার সময় হিসাব', 'প্যারাগ্রাফ বিশ্লেষণ'],
            'benefits' => ['লেখার সময় বাঁচে', 'সোশ্যাল পোস্ট ক্যারেক্টার লিমিট ঠিক থাকে'],
            'faqs' => [
                ['Q' => 'এটি কি বাংলায় কাজ করে?', 'A' => 'হ্যাঁ, এটি বাংলা ও ইংরেজি উভয় ভাষায় নির্ভুলভাবে কাজ করে।']
            ]
        ],
        'slug-generator' => [
            'name' => 'SEO URL Slug Sanitizer',
            'name_bn' => 'এসইও ইউআরএল স্লগ জেনারেটর',
            'category' => 'seo-tools',
            'desc_en' => 'Convert post titles and headlines into search-engine friendly, clean, lowercase URL slugs.',
            'desc_bn' => 'আপনার যেকোনো আর্টিকেল বা শিরোনামকে গুগলের পছন্দের সুন্দর, পরিষ্কার এসইও ফ্রেন্ডলি ইউআরএল স্লগে রূপান্তর করুন।',
            'features' => ['স্পেশাল ক্যারেক্টার ক্লিনআপ', 'হাইফেন সেপারেটর', 'লোয়ারকেস অটো ফরম্যাট'],
            'benefits' => ['এসইও র‍্যাংকিং বৃদ্ধি পায়', 'ক্লিন ও রিডেবল ইউআরএল'],
            'faqs' => [
                ['Q' => 'ইউআরএল স্লগ কেন গুরুত্বপূর্ণ?', 'A' => 'গুগল সার্চ ইঞ্জিন ক্লিন ইউআরএল পছন্দ করে এবং সঠিক স্লগ র‍্যাংকিং পেতে সাহায্য করে।']
            ]
        ],
        'sentence-counter' => [
            'name' => 'Sentence & Paragraph Density Analyzer',
            'name_bn' => 'বাক্য ও প্যারাগ্রাফ কাউন্টার',
            'category' => 'text-tools',
            'desc_en' => 'Analyze readability, count total sentences, paragraphs, average word length, and readability metrics.',
            'desc_bn' => 'আপনার কন্টেন্টের ব্যাকরণগত গঠন, মোট বাক্যের সংখ্যা এবং প্যারাগ্রাফের ঘনত্ব দ্রুত পরিমাপ করুন।',
            'features' => ['বাক্য গণনাকারী', 'প্যারাগ্রাফ কাউন্টার', 'গড় শব্দ দৈর্ঘ্য'],
            'benefits' => ['লেখার মান বৃদ্ধি', 'রিডেবিলিটি উন্নত করা'],
            'faqs' => [
            ]
        ],
        'case-converter-pro' => [
            'name' => 'Text Case Converter Pro',
            'name_bn' => 'টেক্সট কেস ফরম্যাটার',
            'category' => 'text-tools',
            'desc_en' => 'Convert text between UPPERCASE, lowercase, Title Case, Sentence case, camelCase, and PascalCase instantly.',
            'desc_bn' => 'এক ক্লিকে আপনার সমস্ত টেক্সট বড় হাতের, ছোট হাতের, টাইটেল কেস বা ক্যামেলকেসে রূপান্তর করুন।',
            'features' => ['৬+ কেস ফরম্যাটিং', 'ইনস্ট্যান্ট কনভার্সন', 'এক ক্লিকে কপি'],
            'benefits' => ['হাতে টাইপ করার ঝামেলা মুক্ত', 'কোডিং ও কন্টেন্ট ফরম্যাটিং সহজ'],
            'faqs' => [
            ]
        ],
        'text-reverser' => [
            'name' => 'Reverse Text Generator',
            'name_bn' => 'রিভার্স টেক্সট জেনারেটর',
            'category' => 'text-tools',
            'desc_en' => 'Reverse words, characters, or lines of text for encryption, puzzles, and social media styling.',
            'desc_bn' => 'আপনার লেখা উল্টো করুন (Reverse Words/Letters) সংকেত বার্তা পাঠাতে বা সোশ্যাল মিডিয়া ক্যাচ লাইনের জন্য।',
            'features' => ['অক্ষর উল্টানো', 'শব্দ উল্টানো', 'লাইন রিভার্স'],
            'benefits' => ['মজার টেক্সট স্টাইল তৈরি', 'সিক্রেট সংকেত তৈরি'],
            'faqs' => [
            ]
        ],
        'whitespace-remover' => [
            'name' => 'Extra Space & Line Remover',
            'name_bn' => 'অতিরিক্ত স্পেস ও লাইন রিমুভার',
            'category' => 'text-tools',
            'desc_en' => 'Clean up messy text by stripping extra spaces, tabs, double line breaks, and trailing spaces.',
            'desc_bn' => 'টেক্সটের ভেতরের এলোমেলো স্পেস, অতিরিক্ত ইন্টার বা ফাঁকা লাইন এক ক্লিকে মুছে সাফ করুন।',
            'features' => ['ডাবল স্পেস রিমুভাল', 'ব্ল্যাংক লাইন ক্লিনিং', 'ট্রিম উইথ স্পেস'],
            'benefits' => ['লেখা দেখতে পরিচ্ছন্ন হয়', 'ফাইল সাইজ কমে'],
            'faqs' => [
            ]
        ],
        'markdown-to-html' => [
            'name' => 'Markdown to HTML Converter',
            'name_bn' => 'মার্কডাউন টু এইচটিএমএল কনভার্টার',
            'category' => 'developer-tools',
            'desc_en' => 'Convert Markdown formatted text (.md) into clean HTML markup for blogs, GitHub, and websites.',
            'desc_bn' => 'মার্কডাউন ডক ফাইলকে তাত্ক্ষণিকভাবে ডাব্লিউ৩সি ভ্যালিড এইচটিএমএল ট্যাগে রূপান্তর করে ওয়েবসাইটে ব্যবহার করুন।',
            'features' => ['এইচ হেডার সাপোর্ট', 'বোল্ড/ইটালিক ট্যাগ', 'লিস্ট কনভার্সন'],
            'benefits' => ['ব্লগ পোস্ট দ্রুত তৈরি', 'গিটহাব ডকুমেন্টেশন রূপান্তর'],
            'faqs' => [
            ]
        ],
        'html-to-text' => [
            'name' => 'HTML Code to Plain Text Extractor',
            'name_bn' => 'এইচটিএমএল টু প্লেইন টেক্সট কনভার্টার',
            'category' => 'developer-tools',
            'desc_en' => 'Strip HTML tags and extract readable clean plain text from webpages and email templates.',
            'desc_bn' => 'ওয়েব পেজ বা কোডের এইচটিএমএল ট্যাগ সরিয়ে শুধুমাত্র পড়ার মতো বিশুদ্ধ বাংলা ও ইংরেজি টেক্সট বের করুন।',
            'features' => ['ট্যাগ স্ট্রিপিং', 'এন্টিটি ডিকোড', 'ক্লিন রিডেবল আউটপুট'],
            'benefits' => ['কোড থেকে কন্টেন্ট পৃথক করা সহজ', 'ইমেইল স্ক্র্যাপ পরিষ্কার করা'],
            'faqs' => [
            ]
        ],
        'bangla-number-converter' => [
            'name' => 'English to Bangla Number & Words Converter',
            'name_bn' => 'বাংলা সংখ্যা ও কথা কনভার্টার',
            'category' => 'utility-tools',
            'desc_en' => 'Convert numbers (1234) into Bengali numerals (১২৩৪) and written Bengali words (এক হাজার দুইশত চৌত্রিশ).',
            'desc_bn' => 'যেকোনো ইংরেজি সংখ্যাকে বাংলা সংখ্যা (১,২,৩) এবং কথায় (টাকা/কথায়) রূপান্তর করুন দ্রুত ও নির্ভুলভাবে।',
            'features' => ['সংখ্যা টু বাংলা নিউমেরিক', 'কথায় রূপান্তর (টাকা)', 'ইনস্ট্যান্ট কপি'],
            'benefits' => ['ব্যাংক চেক ও চালানে ব্যবহারে সহজ', 'ভুল সংশোধন'],
            'faqs' => [
            ]
        ],
        'find-and-replace' => [
            'name' => 'Advanced Find & Replace Text Utility',
            'name_bn' => 'ফাইন্ড অ্যান্ড রিপ্লেস টেক্সট টুল',
            'category' => 'text-tools',
            'desc_en' => 'Search and replace multiple words or patterns in large text blocks with case sensitivity and regex support.',
            'desc_bn' => 'বিশাল টেক্সটের মধ্যে নির্দিষ্ট শব্দ খুঁজে বের করে এক ক্লিকে নতুন শব্দ দিয়ে বদলে দিন।',
            'features' => ['কেস সেনসেটিভ অপশন', 'রিপ্লেস অল অপশন', 'ম্যাচ কাউন্টার'],
            'benefits' => ['বড় কন্টেন্ট এডিটিং ফাস্ট', 'ভুল সংশোধন সহজ'],
            'faqs' => [
            ]
        ],
        'compound-interest-calculator' => [
            'name' => 'Compound Interest Calculator',
            'name_bn' => 'চক্রবৃদ্ধি সুদ ক্যালকুলেটর',
            'category' => 'finance-tools',
            'desc_en' => 'Calculate investment returns and wealth growth with daily, monthly, or yearly compound interest.',
            'desc_bn' => 'মাসিক বা বাৎসরিক চক্রবৃদ্ধি সুদে আপনার সঞ্চয় বা বিনিয়োগ কতগুণ বৃদ্ধি পাবে তার নিখুঁত হিসাব করুন।',
            'features' => ['কম্পাউন্ডিং ফ্রিকোয়েন্সি', 'বাৎসরিক ও মোট রিটার্ন', 'ডায়নামিক চার্ট'],
            'benefits' => ['দীর্ঘমেয়াদী সঞ্চয় পরিকল্পনা', 'সঠিক মুনাফার পরিমাণ জানা'],
            'faqs' => [
            ]
        ],
        'discount-calculator' => [
            'name' => 'Shopping Discount & Savings Calculator',
            'name_bn' => 'ডিসকাউন্ট ও মূল্যছাড় ক্যালকুলেটর',
            'category' => 'finance-tools',
            'desc_en' => 'Calculate final price after discount percentage, total savings, and applicable sales tax.',
            'desc_bn' => 'কেনাকাটায় ডিসকাউন্ট অফার পাওয়ার পর প্রকৃত দাম কত এবং কত টাকা সাশ্রয় হলো তা হিসাব করুন।',
            'features' => ['শপিং ডিসকাউন্ট %', 'ট্যাক্স সহ হিসাব', 'সাশ্রয় ড্যাশবোর্ড'],
            'benefits' => ['কেনাকাটায় ঠকার ভয় নেই', 'সঠিক দাম জানা সহজ'],
            'faqs' => [
            ]
        ],
        'percentage-calculator' => [
            'name' => 'Percentage Change & Ratio Calculator',
            'name_bn' => 'শতকরা হার ও পার্সেন্টেজ ক্যালকুলেটর',
            'category' => 'finance-tools',
            'desc_en' => 'Calculate percentage of a value, percentage increase/decrease, and percentage difference.',
            'desc_bn' => 'যেকোনো সংখ্যার শতকরা অংশ, বৃদ্ধি বা হ্রাসের হার মুহূর্তেই হিসাব করুন।',
            'features' => ['পার্সেন্টেজ অফ ভ্যালু', 'বৃদ্ধি/হ্রাস হার', 'অনুপাত হিসাব'],
            'benefits' => ['পরীক্ষার নম্বর ও মুনাফার পার্সেন্টেজ বের করা সহজ'],
            'faqs' => [
            ]
        ],
        'freelance-hourly-rate-calculator' => [
            'name' => 'Freelance Hourly Rate Estimator',
            'name_bn' => 'ফ্রিল্যান্সার আওয়ারলি রেট ক্যালকুলেটর',
            'category' => 'finance-tools',
            'desc_en' => 'Calculate your optimal freelance hourly charge based on target monthly income, billable hours, and overhead expenses.',
            'desc_bn' => 'মাসিক আয়ের লক্ষ্যমাত্রা ও কাজের ঘণ্টার ওপর ভিত্তি করে আপনার ফ্রিল্যান্সিং রেট নির্ধারণ করুন।',
            'features' => ['আয়ের টার্গেট সেটআপ', 'খরচ ও ট্যাক্স হিসাব', 'পার আওয়ার রেট সুপারিশ'],
            'benefits' => ['কাজের সঠিক পারিশ্রমিক নির্ধারণ', 'আন্তর্জাতিক মার্কেটপ্লেসে সঠিক কোটেশন দেওয়া'],
            'faqs' => [
            ]
        ],
        'cryptocurrency-converter' => [
            'name' => 'Cryptocurrency Rate Converter',
            'name_bn' => 'ক্রিপ্টোকারেন্সি ও ডলার কনভার্টার',
            'category' => 'finance-tools',
            'desc_en' => 'Convert Bitcoin (BTC), Ethereum (ETH), USDT to USD, BDT, and major fiat currencies in real-time.',
            'desc_bn' => 'বিটকয়েন, ইউএসডিটি ও ইথেরিয়ামের বর্তমান বাজার মূল্য বাংলাদেশী টাকায় হিসাব করুন।',
            'features' => ['লাইভ ইউএসডিটি টু বিডিটি', 'বিটিসি ও ইথ ক্যালকুলেশন', 'ইনস্ট্যান্ট রেট'],
            'benefits' => ['ট্রেডিং ও পেআউট হিসাব সহজ'],
            'faqs' => [
            ]
        ],
        'unit-price-comparator' => [
            'name' => 'Smart Unit Price & Deal Comparator',
            'name_bn' => 'পণ্য মূল্য তুলনা ক্যালকুলেটর',
            'category' => 'utility-tools',
            'desc_en' => 'Compare two product packages with different weights/quantities to find the cheapest cost-per-unit deal.',
            'desc_bn' => 'দুটি ভিন্ন ওজনের বা পরিমাণের পণ্যের ইউনিট প্রাইস তুলনা করে কোনটি লাভজনক তা বেছে নিন।',
            'features' => ['ইউনিট কস্ট বের করা', 'সবচেয়ে সস্তা অফার শনাক্তকরণ', 'সঠিক দাম তুলনা'],
            'benefits' => ['কেনাকাটায় টাকা সাশ্রয়'],
            'faqs' => [
            ]
        ],
        'profit-margin-calculator' => [
            'name' => 'Profit Margin & Gross Markup Calculator',
            'name_bn' => 'লাভের হার ও মার্জিন ক্যালকুলেটর',
            'category' => 'finance-tools',
            'desc_en' => 'Calculate gross profit, net margin percentage, and markup price for e-commerce and retail items.',
            'desc_bn' => 'পণ্যের ক্রয়মূল্য ও বিক্রয়মূল্যের ভিত্তিতে আসল লাভ এবং মার্জিন পার্সেন্টেজ বের করুন।',
            'features' => ['গ্রস প্রফিট মার্জিন', 'মার্কআপ পার্সেন্টেজ', 'রেভিনিউ ব্রেকডাউন'],
            'benefits' => ['ব্যবসার সঠিক প্রফিট জানা'],
            'faqs' => [
            ]
        ],
        'sales-tax-calculator' => [
            'name' => 'VAT & Sales Tax Fast Calculator',
            'name_bn' => 'ভ্যাট ও ট্যাক্স হিসাবকারী',
            'category' => 'finance-tools',
            'desc_en' => 'Calculate inclusive and exclusive VAT/sales tax amounts for invoices and products.',
            'desc_bn' => 'যেকোনো বিলে অন্তর্ভুক্ত বা অতিরিক্ত যোগ হওয়া ভ্যাট (VAT) ও ট্যাক্স দ্রুত হিসাব করুন।',
            'features' => ['ভ্যাট যুক্ত মূল্য বের করা', 'ভ্যাট ছাড়া আসল দাম', 'কাস্টম ট্যাক্স %'],
            'benefits' => ['ইনভয়েস তৈরির কাজ সহজ'],
            'faqs' => [
            ]
        ],
        'salary-paycheck-calculator' => [
            'name' => 'Take-Home Salary & Tax Estimator',
            'name_bn' => 'মাসিক বেতন ও ট্যাক্স ক্যালকুলেটর',
            'category' => 'finance-tools',
            'desc_en' => 'Estimate gross-to-net salary, income tax deductions, and annual disposable income.',
            'desc_bn' => 'গ্রস স্যালারি থেকে ট্যাক্স ও কার্টনের পর হাতে পাওয়া নিট বেতনের পরিমাণ জানুন।',
            'features' => ['ট্যাক্স ডিডাকশন', 'নিট টেক হোম পে', 'বাৎসরিক আয় সমীকরণ'],
            'benefits' => ['বাজেট তৈরি সহজ'],
            'faqs' => [
            ]
        ],
        'tip-calculator' => [
            'name' => 'Restaurant Tip & Bill Splitter',
            'name_bn' => 'রেস্তোরাঁ টিপ ও বিল স্প্লিটার',
            'category' => 'utility-tools',
            'desc_en' => 'Calculate tip amount and split total food bill evenly among friends or group members.',
            'desc_bn' => 'বন্ধুদের সাথে খাবারের বিল এবং ওয়েটার টিপস সমানভাবে ভাগ করার সহজ হিসাব।',
            'features' => ['পার পারসন স্প্লিট', 'টিপ পার্সেন্টেজ বেছে নেওয়া', 'মোট বিল সমীকরণ'],
            'benefits' => ['গ্রুপ বিল দেওয়া সহজ'],
            'faqs' => [
            ]
        ],
        'water-intake-calculator' => [
            'name' => 'Daily Water Hydration Goal Calculator',
            'name_bn' => 'দৈনিক পানি পানের পরিমাণ ক্যালকুলেটর',
            'category' => 'health-tools',
            'desc_en' => 'Calculate ideal daily water intake in liters based on body weight, climate, and exercise routine.',
            'desc_bn' => 'আপনার শরীরের ওজন এবং শারীরিক পরিশ্রম অনুযায়ী প্রতিদিন কত লিটার পানি খাওয়া দরকার তা জানুন।',
            'features' => ['ওজন অনুযায়ী হাইড্রেশন গ্লাস', 'ওয়ার্কআউট এডজাস্টমেন্ট', 'গ্লাস সংখ্যা রূপান্তর'],
            'benefits' => ['সুস্বাস্থ্য বজায় রাখা'],
            'faqs' => [
            ]
        ],
        'calorie-intake-calculator' => [
            'name' => 'Daily Calorie Deficit & TDEE Calculator',
            'name_bn' => 'দৈনিক ক্যালোরি ও ডায়েট ক্যালকুলেটর',
            'category' => 'health-tools',
            'desc_en' => 'Determine Total Daily Energy Expenditure (TDEE) and target calories for weight loss or muscle gain.',
            'desc_bn' => 'ওজন কমানো বা বাড়াতে প্রতিদিন কত ক্যালোরির খাবার খাওয়া উচিত তা নিখুঁত হিসাব করুন।',
            'features' => ['বিএমআর ও টিডিইই', 'ওজন কমানোর ক্যালোরি', 'ওয়েট গেইন প্ল্যান'],
            'benefits' => ['ফিটনেস লক্ষ্য অর্জন'],
            'faqs' => [
            ]
        ],
        'ideal-weight-calculator' => [
            'name' => 'Ideal Body Weight Range Estimator',
            'name_bn' => 'আদর্শ ওজন নিরূপণ ক্যালকুলেটর',
            'category' => 'health-tools',
            'desc_en' => 'Find your healthy body weight range based on height, gender, and age formulas.',
            'desc_bn' => 'উচ্চতা ও বয়স অনুযায়ী আপনার স্বাস্থ্যকর স্বাভাবিক ওজন কত হওয়া উচিত তা জানুন।',
            'features' => ['উচ্চতা ও লিঙ্গ ভিত্তিক হিসাব', 'আইডিবিডব্লিউ রেঞ্জ', 'বিএমআই জোনিং'],
            'benefits' => ['শারীরিক সক্ষমতা জানা'],
            'faqs' => [
            ]
        ],
        'body-fat-calculator' => [
            'name' => 'Navy Body Fat Percentage Calculator',
            'name_bn' => 'শরীরের ফ্যাট শতাংশ ক্যালকুলেটর',
            'category' => 'health-tools',
            'desc_en' => 'Estimate your body fat percentage and lean muscle mass using US Navy tape measure method.',
            'desc_bn' => 'শরীরের চর্বির শতাংশ (Body Fat %) এবং লীন মাস মাংসপেশীর অনুপাত পরিমাপ করুন।',
            'features' => ['নেভি বডি ফ্যাট মেথড', 'লীন মাস কেজি', 'ফ্যাট ক্যাটাগরি'],
            'benefits' => ['জিম ও মেদ কমানোর সঠিক ট্র্যাকিং'],
            'faqs' => [
            ]
        ],
        'sleep-cycle-calculator' => [
            'name' => 'REM Sleep Cycle & Alarm Optimizer',
            'name_bn' => 'ঘুমের সাইকেল ও অ্যালার্ম টাইমার',
            'category' => 'health-tools',
            'desc_en' => 'Calculate perfect sleep cycles (90 min REM intervals) to wake up feeling fresh and energetic.',
            'desc_bn' => 'পরিপূর্ণ সতেজ অনুভব করে ঘুম থেকে ওঠার জন্য সবচেয়ে উপযুক্ত ঘুমানো ও ওঠার সময় বের করুন।',
            'features' => ['৯০ মিনিটের আরইএম সাইকেল', 'শোবার সঠিক সময়', 'সকালে ওঠার উপযুক্ত সময়'],
            'benefits' => ['ক্লান্তিহীন সতেজ ঘুম'],
            'faqs' => [
            ]
        ],
        'utm-builder' => [
            'name' => 'Google Analytics Campaign UTM Link Builder',
            'name_bn' => 'ইউটিএম ক্যাম্পেইন লিংক জেনারেটর',
            'category' => 'seo-tools',
            'desc_en' => 'Build custom tracking URLs with utm_source, utm_medium, and utm_campaign for digital marketing campaigns.',
            'desc_bn' => 'ডিজিটাল মার্কেটিং ও অ্যাড ক্যাম্পেইনের জন্য ট্র্যাকিং লিংক (UTM Parameter) তৈরি করুন।',
            'features' => ['ইউটিএম সোর্স, মিডিয়াম, ক্যাম্পেইন', 'ইনস্ট্যান্ট কপি', 'ইউআরএল এনকোড সেফ'],
            'benefits' => ['মার্কেটিং ট্র্যাকিং সহজ'],
            'faqs' => [
            ]
        ],
        'meta-tag-analyzer' => [
            'name' => 'Webpage Meta Tag & Social Graph Auditor',
            'name_bn' => 'মেটা ট্যাগ অ্যানালাইজার',
            'category' => 'seo-tools',
            'desc_en' => 'Audit title tags, meta descriptions, canonical URLs, and Open Graph tags of any webpage.',
            'desc_bn' => 'যেকোনো ওয়েবসাইটের মেটা ট্যাগ, টাইটেল দৈর্ঘ্য এবং এসইও হেলথ পরীক্ষা করুন।',
            'features' => ['টাইটেল ও মেটা ক্যারেক্টার চেক', 'ক্যানোনিকাল ট্যাগ চেক', 'সোশ্যাল মেটা ভ্যালিডেশন'],
            'benefits' => ['এসইও ভুল দ্রুত ধরা পড়ে'],
            'faqs' => [
            ]
        ],
        'keyword-density-analyzer' => [
            'name' => 'Article Keyword Frequency & Density Audit',
            'name_bn' => 'কিওয়ার্ড ডেনসিটি অ্যানালাইজার',
            'category' => 'seo-tools',
            'desc_en' => 'Analyze 1-word, 2-word, and 3-word keyword repetition percentages in your written content.',
            'desc_bn' => 'আপনার আর্টিকেলে কিওয়ার্ড ওভার-অপটিমাইজেশন বা স্টাফিং এড়াতে কিওয়ার্ড ঘনত্ব চেক করুন।',
            'features' => ['১, ২ ও ৩ শব্দের কিওয়ার্ড লিস্ট', 'ঘনত্ব পার্সেন্টেজ %', 'স্টাফিং ওয়ার্নিং'],
            'benefits' => ['গুগল পেনাল্টি এড়ানো'],
            'faqs' => [
            ]
        ],
        'ht-access-redirect-generator' => [
            'name' => '301 Permanent Redirect .htaccess Generator',
            'name_bn' => '.htaccess রিডাইরেক্ট জেনারেটর',
            'category' => 'webmaster-tools',
            'desc_en' => 'Generate Apache .htaccess rules for 301 redirects, non-www to www, and HTTPS forced redirect.',
            'desc_bn' => 'ওয়েবসাইটের ৩০১ পারমানেন্ট রিডাইরেক্ট এবং এইচটিটিপিএস অটো রুল কোড তৈরি করুন।',
            'features' => ['৩০১ ও ৩০২ রিডাইরেক্ট', 'এইচটিটিপিএস ফোর্স রুল', 'ডোমেইন চেঞ্জ কোড'],
            'benefits' => ['এসইও জুস ও লিঙ্ক রিডাইরেক্ট বজায় রাখা'],
            'faqs' => [
            ]
        ],
        'twitter-card-generator' => [
            'name' => 'Twitter Card Meta Tag Builder',
            'name_bn' => 'টুইটার কার্ড মেটা জেনারেটর',
            'category' => 'seo-tools',
            'desc_en' => 'Create Twitter Summary and Summary with Large Image Card HTML meta tags for viral social previews.',
            'desc_bn' => 'টুইটারে ওয়েবসাইট শেয়ারের সময় আকর্ষণীয় থাম্বনেইল প্রিভিউ দেখানোর মেটা ট্যাগ তৈরি করুন।',
            'features' => ['লার্জ ইমেজ কার্ড', 'টুইটার হ্যান্ডেল মেটা', 'এইচটিএমএল অটো কোড'],
            'benefits' => ['টুইটার ক্লিক থ্রু রেট বৃদ্ধি'],
            'faqs' => [
            ]
        ],
        'social-media-post-formatter' => [
            'name' => 'Bold & Fancy Font Generator for Social Media',
            'name_bn' => 'সোশ্যাল মিডিয়া বোল্ড ফন্ট জেনারেটর',
            'category' => 'utility-tools',
            'desc_en' => 'Convert normal text into Unicode bold, italic, script, and cyber fonts for Facebook, Instagram, and LinkedIn posts.',
            'desc_bn' => 'ফেসবুক, ইনস্টাগ্রাম ও লিংকডইন পোস্টের জন্য বোল্ড, ইটালিক ও স্টাইলিশ টেক্সট জেনারেট করুন।',
            'features' => ['ইউনিকোড বোল্ড ও ইটালিক', '১০+ স্টাইলিশ ফন্ট', 'এক ক্লিকে কপি'],
            'benefits' => ['পোস্টে রিচ ও দৃষ্টি আকর্ষণ বাড়ানো'],
            'faqs' => [
            ]
        ],
        'email-signature-generator' => [
            'name' => 'HTML Business Email Signature Builder',
            'name_bn' => 'এইচটিএমএল ইমেইল সিগনেচার মেকার',
            'category' => 'utility-tools',
            'desc_en' => 'Design sleek HTML email signatures with photo, job title, company links, and social icons for Gmail & Outlook.',
            'desc_bn' => 'প্রফেশনাল আউটলুক ও জিমেইলের জন্য স্টাইলিশ এইচটিএমএল ইমেইল সিগনেচার বানান।',
            'features' => ['ছবি ও সোশ্যাল আইকন', 'এইচটিএমএল কোড জেনারেটর', 'প্রাক-প্রিভিউ'],
            'benefits' => ['ব্যবসায়িক ভাবমূর্তি বৃদ্ধি'],
            'faqs' => [
            ]
        ],
        'privacy-policy-generator' => [
            'name' => 'Website & App Privacy Policy Generator',
            'name_bn' => 'প্রাইভেসি পলিসি জেনারেটর',
            'category' => 'webmaster-tools',
            'desc_en' => 'Generate Google AdSense compliant, GDPR friendly privacy policy document for websites and apps.',
            'desc_bn' => 'গুগল এডসেন্স এপ্রুভালের জন্য স্ট্যান্ডার্ড ও আইনসম্মত প্রাইভেসি পলিসি পেজ তৈরি করুন।',
            'features' => ['গুগল এডসেন্স কমপ্লায়েন্ট', 'জিডিপিআর ও কুকিজ ডিসক্লোজার', 'কপি/ডাউনলোড কন্টেন্ট'],
            'benefits' => ['এডসেন্স এপ্রুভাল পাওয়া সহজ'],
            'faqs' => [
            ]
        ],
        'terms-conditions-generator' => [
            'name' => 'Website Terms & Conditions Builder',
            'name_bn' => 'টার্মস অ্যান্ড কন্ডিশনস জেনারেটর',
            'category' => 'webmaster-tools',
            'desc_en' => 'Generate official terms of service and usage conditions agreement for digital platforms.',
            'desc_bn' => 'আপনার ওয়েবসাইট বা অনলাইন স্টোরের জন্য শর্তাবলী ও ব্যবহারের নিয়ম কানুন ডকুমেন্ট বানান।',
            'features' => ['কপিরাইট রুলস', 'ইউজার শর্তাবলী', 'রেডিমেড পেজ টেক্সট'],
            'benefits' => ['আইনি নিরাপত্তা নিশ্চিত করা'],
            'faqs' => [
            ]
        ],
        'disclaimer-generator' => [
            'name' => 'Website Disclaimer Statement Generator',
            'name_bn' => 'ডিসক্লেইমার স্টেটমেন্ট জেনারেটর',
            'category' => 'webmaster-tools',
            'desc_en' => 'Generate AdSense safe legal disclaimer text for affiliate links, medical, and financial blogs.',
            'desc_bn' => 'অ্যাফিলিয়েট ও টেক ব্লগের জন্য আইনি দায়মুক্তি (Disclaimer) পেজ জেনারেট করুন।',
            'features' => ['অ্যাফিলিয়েট ডিসক্লোজার', 'লিগ্যাল নোটিশ', 'ইনস্ট্যান্ট টেক্সট'],
            'benefits' => ['অ্যাফিলিয়েট নেটওয়ার্ক অনুমোদন'],
            'faqs' => [
            ]
        ],
        'csv-to-json-converter' => [
            'name' => 'CSV File to JSON Array Converter',
            'name_bn' => 'সিএসভি টু জেএসএন কনভার্টার',
            'category' => 'developer-tools',
            'desc_en' => 'Convert CSV spreadsheet tables into structured JSON objects and arrays with custom key mapping.',
            'desc_bn' => 'সিএসভি ফাইল বা টেবিল ডেটাকে কোডারদের জন্য উপযোগী জেএসএন অ্যারেতে রূপান্তর করুন।',
            'features' => ['সিএসভি পার্সার', 'জেএসএন অ্যারে ফরম্যাটিং', 'ডাউনলোড .json'],
            'benefits' => ['ডেটা মাইগ্রেশন সহজ'],
            'faqs' => [
            ]
        ],
        'json-to-csv-converter' => [
            'name' => 'JSON Data to CSV Spreadsheet Exporter',
            'name_bn' => 'জেএসএন টু সিএসভি কনভার্টার',
            'category' => 'developer-tools',
            'desc_en' => 'Export JSON API response arrays into downloadable CSV files for Excel and Google Sheets.',
            'desc_bn' => 'জেএসএন এপিআই ডেটাকে এক্সেল বা গুগল শিটে ব্যবহারের উপযোগী সিএসভি ফাইলে এক্সপোর্ট করুন।',
            'features' => ['অটো হেডার এক্সট্রাকশন', 'ডাউনলোড .csv', 'ইনস্ট্যান্ট রূপান্তর'],
            'benefits' => ['এপিআই ডেটা বিশ্লেষণ সহজ'],
            'faqs' => [
            ]
        ],
        'xml-to-json-converter' => [
            'name' => 'XML Document to JSON Object Parser',
            'name_bn' => 'এক্সএমএল টু জেএসএন কনভার্টার',
            'category' => 'developer-tools',
            'desc_en' => 'Convert XML data strings and RSS feeds into JSON tree structure seamlessly.',
            'desc_bn' => 'এক্সএমএল ডেটা স্ট্রাকচার ও সাইটম্যাপ ফিডকে জেএসএন অবজেক্টে কনভার্ট করুন।',
            'features' => ['এক্সএমএল পার্সার', 'ট্রি ভিউ ডিকোপলিং', 'ক্লিন জেএসএন'],
            'benefits' => ['সাইটম্যাপ ও আরএসএস প্রসেসিং সহজ'],
            'faqs' => [
            ]
        ],
        'cron-job-expression-generator' => [
            'name' => 'Linux Cron Job Schedule Builder',
            'name_bn' => 'ক্রন জব টাইম টেবিল জেনারেটর',
            'category' => 'developer-tools',
            'desc_en' => 'Generate Linux crontab syntax (min hour day month weekday) with human readable explanations.',
            'desc_bn' => 'সার্ভারের স্বয়ংক্রিয় কাজের জন্য সঠিক ক্রন জব (Cron Job) এক্সপ্রেশন কোড তৈরি করুন।',
            'features' => ['ক্রন এক্সপ্রেশন কোড', 'সহজ সময় সিলেকশন', 'সহজ ব্যাখ্যা'],
            'benefits' => ['সার্ভার অটোমেশন কোড ভুলমুক্ত করা'],
            'faqs' => [
            ]
        ],
        'chmod-permissions-calculator' => [
            'name' => 'Linux File Permissions CHMOD Calculator',
            'name_bn' => 'ফাইল পারমিশন সিএইচমোড ক্যালকুলেটর',
            'category' => 'developer-tools',
            'desc_en' => 'Calculate Linux file permission octal values (755, 644, 777) with owner, group, and public checkboxes.',
            'desc_bn' => 'সার্ভারের ফাইল ও ফোল্ডার সিকিউরিটি পারমিশনের নিউমেরিক কোড (যেমন 755, 644) হিসাব করুন।',
            'features' => ['অক্টাল মান হিসাব', 'রিড/রাইট/এক্সিকিউট বক্স', 'সিএইচমোড কম্যান্ড জেনারেটর'],
            'benefits' => ['সার্ভার সিকিউরিটি কনফিগারেশন'],
            'faqs' => [
            ]
        ],
        'url-parser' => [
            'name' => 'URL Query String & Hostname Parameter Extractor',
            'name_bn' => 'ইউআরএল প্যারামিটার পার্সার',
            'category' => 'developer-tools',
            'desc_en' => 'Parse protocol, domain name, port, path, and GET query parameters from any web URL.',
            'desc_bn' => 'লম্বা ইউআরএল থেকে পোর্ট, প্রোটোকল এবং কুয়েরি প্যারামিটার আলাদা করে বিশ্লেষণ করুন।',
            'features' => ['ডোমেইন ও পোর্ট সেপারেশন', 'কুয়েরি স্ট্রিং কি-ভ্যালু টেবিল', 'ডিকোড ইউআরএল'],
            'benefits' => ['এপিআই ডিবাগিং সহজ'],
            'faqs' => [
            ]
        ],
        'css-gradient-generator' => [
            'name' => 'Modern CSS3 Neon & Glass Gradient Builder',
            'name_bn' => 'সিএসএস গ্রেডিয়েন্ট ব্যাকগ্রাউন্ড জেনারেটর',
            'category' => 'developer-tools',
            'desc_en' => 'Design multi-color linear, radial, and conic CSS background gradients with instant cross-browser code.',
            'desc_bn' => 'ওয়েবসাইটের জন্য আধুনিক গ্রেডিয়েন্ট কালার ব্যাকগ্রাউন্ড তৈরি করে সিএসএস কোড কপি করুন।',
            'features' => ['লিনিয়ার ও রেডিয়াল অপশন', 'কালার স্টপ কন্ট্রোল', 'ইনস্ট্যান্ট সিএসএস কপি'],
            'benefits' => ['ডিজাইন গতিময় ও আকর্ষণীয় করা'],
            'faqs' => [
            ]
        ],
        'css-box-shadow-generator' => [
            'name' => 'Glowing Glassmorphism Box Shadow Builder',
            'name_bn' => 'সিএসএস বক্স শ্যাডো জেনারেটর',
            'category' => 'developer-tools',
            'desc_en' => 'Generate 2040 cyber glow and smooth box shadows with inset, blur, spread, and color controls.',
            'desc_bn' => 'ওয়েব এলিমেন্টের জন্য সফট শ্যাডো বা উজ্জ্বল নিয়ন গ্লো এফেক্টের সিএসএস কোড বানান।',
            'features' => ['ব্লার ও স্প্রেড কন্ট্রোল', 'ইনসেট শ্যাডো সাপোর্ট', 'লাইভ প্রিভিউ ড্যাশবোর্ড'],
            'benefits' => ['ইউআই কার্ড আকর্ষণীয় বানানো'],
            'faqs' => [
            ]
        ],
        'css-flexbox-generator' => [
            'name' => 'Interactive CSS Flexbox Layout Builder',
            'name_bn' => 'সিএসএস ফ্লেক্সবক্স লেআউট মেকার',
            'category' => 'developer-tools',
            'desc_en' => 'Visually adjust flex-direction, justify-content, align-items, and gap to copy clean flex CSS.',
            'desc_bn' => 'ভিজ্যুয়ালি ফ্লেক্সবক্স লেআউট সাজিয়ে রেসপন্সিভ সিএসএস লেআউট কোড তৈরি করুন।',
            'features' => ['জাস্টিফাই ও এলাইনমেন্ট কন্ট্রোল', 'গ্যাপ সিলেকশন', 'রেডি সিএসএস কোড'],
            'benefits' => ['লেআউটের সিএসএস ভুল এড়ানো'],
            'faqs' => [
            ]
        ],
        'color-palette-generator' => [
            'name' => 'Neon Cyber Color Palette & HEX Generator',
            'name_bn' => 'কালার প্যালেট জেনারেটর',
            'category' => 'developer-tools',
            'desc_en' => 'Generate matching color schemes, complementary, monochromatic, and triadic HEX palette codes.',
            'desc_bn' => 'ওয়েবসাইট বা ডিজাইনের জন্য ম্যাচিং কালার প্যালেট ও হেক্স কোড কালেকশন জেনারেট করুন।',
            'features' => ['হরমোনিক কালার কম্বিনেশন', 'হেক্স কোড কপি', 'প্যালেট ডাউনলোড'],
            'benefits' => ['ডিজাইনের রঙ নির্বাচন সহজ'],
            'faqs' => [
            ]
        ],
        'mac-address-lookup' => [
            'name' => 'MAC Address OUI Vendor Lookup',
            'name_bn' => 'ম্যাক এড্রেস ভেন্ডর ফাইন্ডার',
            'category' => 'security-tools',
            'desc_en' => 'Find hardware manufacturer, network card vendor, and organization details from any MAC address.',
            'desc_bn' => 'যেকোনো রাউটার বা ডিভাইসের ম্যাক অ্যাড্রেস থেকে কোম্পানি ও ম্যানুফ্যাকচারার নাম খুঁজে বের করুন।',
            'features' => ['ওইউআই ম্যানুফ্যাকচারার সার্চ', 'ম্যাক ফরম্যাট ভ্যালিডেটর', 'ইনস্ট্যান্ট রেজাল্ট'],
            'benefits' => ['নেটওয়ার্ক সিকিউরিটি ডিটেকশন'],
            'faqs' => [
            ]
        ],
        'port-checker' => [
            'name' => 'Web & Firewall Server Port Reference',
            'name_bn' => 'সার্ভার পোর্ট সেফটি নির্দেশিকা',
            'category' => 'security-tools',
            'desc_en' => 'Check standard protocols, default port assignments (80, 443, 22, 3306), and firewall recommendations.',
            'desc_bn' => 'ওয়েব সার্ভার ও নেটওয়ার্কের গুরুত্বপূর্ণ পোর্ট সিকিউরিটি তালিকা ও ব্যবহার দেখুন।',
            'features' => ['স্ট্যান্ডার্ড পোর্ট ডাটাবেস', 'ফায়ারওয়াল রেকমেন্ডেশন', 'প্রোটোকল ডেসক্রিপশন'],
            'benefits' => ['সার্ভার পোর্ট সিকিউরিটি মনিটরিং'],
            'faqs' => [
            ]
        ],
        'httpext-header-checker' => [
            'name' => 'Web Security Headers & Policy Inspection',
            'name_bn' => 'সিকিউরিটি হেডার চেকার',
            'category' => 'security-tools',
            'desc_en' => 'Verify Content-Security-Policy (CSP), Strict-Transport-Security (HSTS), X-Frame-Options headers.',
            'desc_bn' => 'ওয়েবসাইটের সিকিউরিটি হেডার এবং সাইবার অ্যাটাক সুরক্ষা ব্যবস্থা বিশ্লেষণ করুন।',
            'features' => ['সিএসপি ও এইচএসটিএস গাইড', 'হেডার অডিট রুলস', 'সিকিউরিটি স্কোরিং'],
            'benefits' => ['সাইবার অ্যাটাক প্রতিহত করা'],
            'faqs' => [
            ]
        ],
        'subnet-mask-calculator' => [
            'name' => 'IP Subnet Mask & CIDR Range Calculator',
            'name_bn' => 'আইপি সাবনেট মাস্ক ক্যালকুলেটর',
            'category' => 'security-tools',
            'desc_en' => 'Calculate network address, broadcast address, usable IP range, and total hosts from CIDR notation.',
            'desc_bn' => 'আইপি এড্রেস এবং সাবনেট মাস্ক থেকে মোট হোস্ট ও নেটওয়ার্ক ব্লক হিসাব করুন।',
            'features' => ['সিআইডিআর রেঞ্জ হিসাব', 'ব্রডকাস্ট এড্রেস', 'ইউজেবল আইপি সংখ্যা'],
            'benefits' => ['নেটওয়ার্ক আর্কিটেকচার সহজ'],
            'faqs' => [
            ]
        ],
        'ping-latency-calculator' => [
            'name' => 'Network Latency & Download Speed Estimator',
            'name_bn' => 'নেটওয়ার্ক স্পিড ও লেটেন্সি ক্যালকুলেটর',
            'category' => 'security-tools',
            'desc_en' => 'Calculate round-trip latency time, file download duration based on bandwidth speed in Mbps.',
            'desc_bn' => 'ইন্টারনেট স্পিড (Mbps) অনুযায়ী নির্দিষ্ট ফাইলের ডাউনলোড হতে কত সময় লাগবে তা হিসাব করুন।',
            'features' => ['ফাইলের সাইজ বনাম স্পিড', 'ডাউনলোড টাইম মিটার', 'লেটেন্সি হিসাব'],
            'benefits' => ['ডাউনলোড সময় জানা সহজ'],
            'faqs' => [
            ]
        ],
        'dns-propagation-checker' => [
            'name' => 'DNS Propagation & Records Lookup',
            'name_bn' => 'ডিএনএস প্রোপাগেশন ও রেকর্ডস চেকার',
            'category' => 'security-tools',
            'desc_en' => 'Track global DNS propagation of your domain name across multiple servers worldwide for A, MX, TXT, and CNAME records.',
            'desc_bn' => 'বিশ্বের বিভিন্ন প্রান্তের ডিএনএস সার্ভার থেকে আপনার ডোমেনের এ, এমএক্স, টিএক্সটি ও সিএনএএম রেকর্ড পরীক্ষা করুন।',
            'features' => ['গ্লোবাল ডিএনএস কোয়েরি', 'এ, এমএক্স, টিএক্সটি রেকর্ডস', 'আইপি রেজোলিউশন ম্যাপ'],
            'benefits' => ['ডোমেন ট্রান্সফার ট্র্যাকিং সহজ', 'ডিএনএস জটিলতা দ্রুত সমাধান'],
            'faqs' => [
                ['Q' => 'ডিএনএস প্রোপাগেশন হতে কত সময় লাগে?', 'A' => 'সাধারণত ২৪ থেকে ৪৮ ঘণ্টার মধ্যে ডিএনএস আপডেট বিশ্বব্যাপী ছড়িয়ে পড়ে।'],
            ]
        ],
        'base64-to-pdf-converter' => [
            'name' => 'Base64 to PDF File Decoder',
            'name_bn' => 'বেস৬৪ টু পিডিএফ ফাইল ডিকোডার',
            'category' => 'developer-tools',
            'desc_en' => 'Decode Base64 encoded strings back into clean, downloadable PDF files instantly in your browser.',
            'desc_bn' => 'যেকোনো বেস৬৪ এনকোডেড টেক্সট বা ফাইলকে এক ক্লিকে মূল পিডিএফ ফাইলে রূপান্তর করে ডাউনলোড করুন।',
            'features' => ['ইনস্ট্যান্ট ডিকোডিং', 'পিডিএফ ডাউনলোড সাপোর্ট', 'সাইজ ও এরর ডিটেকশন'],
            'benefits' => ['এপিআই ডেটা থেকে পিডিএফ রিকভারি', 'অফলাইন প্রসেসিং ও নিরাপত্তা'],
            'faqs' => [
                ['Q' => 'এটি কি নিরাপদ?', 'A' => 'হ্যাঁ, সম্পূর্ণ ব্রাউজারেই ডিকোড সম্পন্ন হয়, সার্ভারে কোনো তথ্য পাঠানো হয় না।'],
            ]
        ],
        'json-to-xml-parser' => [
            'name' => 'JSON Data to XML Document Converter',
            'name_bn' => 'জেএসএন টু এক্সএমএল রূপান্তরকারী',
            'category' => 'developer-tools',
            'desc_en' => 'Convert structured JSON datasets and API responses into clean, validated XML tags and files.',
            'desc_bn' => 'আপনার জেএসএন ডেটাকে ডাব্লিউ৩সি ভ্যালিড এক্সএমএল কোডে রূপান্তর করুন এবং সাইটম্যাপে ব্যবহার করুন।',
            'features' => ['ট্রি কনভার্সন', 'প্রিটি প্রিন্ট ও ইনডেন্টেশন', 'এক্সএমএল ডাউলোড'],
            'benefits' => ['এপিআই ডেটা ট্রান্সফর্ম সহজ', 'উইন্ডোজ ও পিএইচপি অ্যাপ্লিকেশনে ব্যবহারের উপযোগী'],
            'faqs' => [
                ['Q' => 'জেএসএন এবং এক্সএমএল এর মধ্যে তফাৎ কি?', 'A' => 'জেএসএন হালকা ও এপিআই ফ্রেন্ডলি, অন্যদিকে এক্সএমএল স্ট্রাকচারড ও লেগ্যাসি অ্যাপের জন্য ভালো।'],
            ]
        ],
        'sql-to-json-exporter' => [
            'name' => 'SQL Query to JSON Array Converter',
            'name_bn' => 'এসকিউএল কোয়েরি টু জেএসএন কনভার্টার',
            'category' => 'developer-tools',
            'desc_en' => 'Convert SQL insert statements or query results into standard structured JSON object arrays.',
            'desc_bn' => 'এসকিউএল ডেটাবেস কুয়েরি রেজাল্ট বা টেবিল ডেটাকে কোডারদের জন্য উপযোগী জেএসএন অ্যারেতে রূপান্তর করুন।',
            'features' => ['এসকিউএল পার্সার', 'জেএসএন অ্যারে ফরম্যাটিং', 'ইনস্ট্যান্ট কপি'],
            'benefits' => ['ডেটাবেস ডেটা মোবাইল অ্যাপে ব্যবহার সহজ', 'মাইগ্রেশন ও ডেটা ম্যানিপুলেশন'],
            'faqs' => [
            ]
        ],
        'text-splitter-divider' => [
            'name' => 'Large Text Paragraph & Word Splitter',
            'name_bn' => 'লং টেক্সট ও প্যারাগ্রাফ স্প্লিটার',
            'category' => 'text-tools',
            'desc_en' => 'Split heavy text, articles, or books into custom smaller chunks by words, characters, or paragraph breaks.',
            'desc_bn' => 'বড় কোনো নিবন্ধ বা স্ক্রিপ্টকে নির্দিষ্ট সংখ্যক শব্দ বা অক্ষরের ভিত্তিতে ছোট ছোট প্যারাগ্রাফে ভাগ করুন।',
            'features' => ['শব্দ সংখ্যা লিমিট', 'প্যারাগ্রাফ ব্রেক ডিটেক্টর', 'বাল্ক কপি অপশন'],
            'benefits' => ['সোশ্যাল মিডিয়া পোস্ট সাইজিং', 'এআই প্রম্পট ব্যবহারের জন্য পার্ট বাই পার্ট ভাগ করা'],
            'faqs' => [
            ]
        ],
        'binary-to-text-decoder' => [
            'name' => 'Binary 0101 to Plain Text Translator',
            'name_bn' => 'বাইনারি টু টেক্সট রূপান্তরকারী',
            'category' => 'developer-tools',
            'desc_en' => 'Convert binary code strings consisting of 0s and 1s back into human-readable English or Bengali plain text.',
            'desc_bn' => 'শূন্য এবং একের (0 ও 1) বাইনারি কোডকে সাধারণ মানুষের পড়ার উপযোগী বর্ণমালায় অনুবাদ করুন।',
            'features' => ['রিয়েল-টাইম কনভার্সন', 'আস্কি (ASCII) সাপোর্ট', 'এরর ডিটেকশন'],
            'benefits' => ['কোডিং ও কম্পিউটার সায়েন্স লার্নিং', 'সিক্রেট মেসেজ ডিকোডিং'],
            'faqs' => [
            ]
        ],
        'hex-to-rgb-color-converter' => [
            'name' => 'HEX Color to RGB & RGBA Converter',
            'name_bn' => 'হেক্স কালার টু আরজিবি কনভার্টার',
            'category' => 'developer-tools',
            'desc_en' => 'Convert CSS hex color codes (#00f0ff) into standard RGB and RGBA formats with opacity controls.',
            'desc_bn' => 'ওয়েবসাইটের হেক্স কালার কোডকে আরজিবি এবং আরজিবিএ (স্বচ্ছতাসহ) ফরম্যাটে রূপান্তর করুন।',
            'features' => ['অপাসিটি স্লাইডার', 'লাইভ কালার প্রিভিউ', 'সিএসএস কপি অপশন'],
            'benefits' => ['স্টাইলিশ ওয়েব ডিজাইন তৈরি', 'ইউআই কালার কোডিং সহজ করা'],
            'faqs' => [
            ]
        ],
        'rgb-to-hex-color-converter' => [
            'name' => 'RGB Color Code to HEX Converter',
            'name_bn' => 'আরজিবি টু হেক্স কালার কনভার্টার',
            'category' => 'developer-tools',
            'desc_en' => 'Convert RGB and RGBA color codes into CSS-compatible HEX and HEXA color hashes easily.',
            'desc_bn' => 'আরজিবি বা আরজিবিএ রঙের মানকে হেক্স কোড হ্যাশে রূপান্তর করে ডিজাইনে ব্যবহার করুন।',
            'features' => ['ইনস্ট্যান্ট কনভার্সন', 'কালার ম্যাচিং প্রিভিউ', 'এক ক্লিকে কপি'],
            'benefits' => ['ডিজাইন ও ডেভেলপমেন্ট স্পিড বৃদ্ধি', 'কালার হুইল ইন্টিগ্রেশন'],
            'faqs' => [
            ]
        ],
        'lorem-ipsum-advanced-generator' => [
            'name' => 'Advanced Custom Lorem Ipsum Generator',
            'name_bn' => 'লরেম ইপসাম প্লেসহোল্ডার জেনারেটর',
            'category' => 'text-tools',
            'desc_en' => 'Generate custom Lorem Ipsum placeholder text by choosing number of paragraphs, sentences, or lists.',
            'desc_bn' => 'আপনার ডিজাইনের টেমপ্লেটের জন্য নির্দিষ্ট সংখ্যক প্যারাগ্রাফ বা লাইনের লরেম ইপসাম ডামি টেক্সট তৈরি করুন।',
            'features' => ['প্যারাগ্রাফ ও লাইন কাউন্টার', 'লিস্ট বা বুলেট পয়েন্ট সাপোর্ট', 'এইচটিএমএল ট্যাগ ইন্টিগ্রেশন'],
            'benefits' => ['ইউআই প্রোটোটাইপিং সহজ করা', 'ডিজাইন লেআউট দ্রুত ভরাট করা'],
            'faqs' => [
            ]
        ],
        'random-paragraph-creator' => [
            'name' => 'Random Paragraph & Story Generator',
            'name_bn' => 'র্যান্ডম প্যারাগ্রাফ ও স্টোরি মেকার',
            'category' => 'text-tools',
            'desc_en' => 'Generate unique random English or Bengali paragraphs for writing inspiration, placeholders, or typing tests.',
            'desc_bn' => 'টাইপিং স্পিড টেস্ট বা ডামি কন্টেন্টের জন্য ইউনিক র্যান্ডম বাংলা ও ইংরেজি প্যারাগ্রাফ তৈরি করুন।',
            'features' => ['বহুভাষী সাপোর্ট', 'টপিক ভিত্তিক জেনারেটর', 'সহজ কপি প্যানেল'],
            'benefits' => ['টাইপিং প্র্যাকটিস সহজ করা', 'আর্টিকেল লেখার আইডিয়া জেনারেশন'],
            'faqs' => [
            ]
        ],
        'capitalization-checker-formatter' => [
            'name' => 'Title Capitalization & Word Case Checker',
            'name_bn' => 'টাইটেল ক্যাপিটালাইজেশন চেকার',
            'category' => 'text-tools',
            'desc_en' => 'Check and format titles to match AP, Chicago, MLA, and Wikipedia style capitalization standards automatically.',
            'desc_bn' => 'আপনার নিবন্ধের শিরোনাম এপি বা শিকাগো রাইটিং স্ট্যান্ডার্ড অনুযায়ী বড় ও ছোট হাতের অক্ষর সাজান।',
            'features' => ['এপি ও শিকাগো স্টাইল', 'অটো কনভার্সন লজিক', 'গ্রামার রুলস ভ্যালিডেশন'],
            'benefits' => ['নিবন্ধ দেখতে পেশাদার লাগে', 'এসইও টাইটেল স্ট্যান্ডার্ড বজায় থাকে'],
            'faqs' => [
            ]
        ],
        'text-encryptor-decryptor' => [
            'name' => 'Secure Text Encryptor & Decryptor',
            'name_bn' => 'সিকিউর টেক্সট এনক্রিপ্টর ও ডিক্রিপ্টর',
            'category' => 'security-tools',
            'desc_en' => 'Encrypt sensitive messages or notes using standard cryptographic algorithms or passwords for secure communication.',
            'desc_bn' => 'আপনার অত্যন্ত সংবেদনশীল বার্তা বা পাসওয়ার্ড পাসফ্রেজ দিয়ে লক ও আনলক করুন সম্পূর্ণ সুরক্ষায়।',
            'features' => ['পাসওয়ার্ড প্রোটেকশন', 'অফলাইন ব্রাউজার এনক্রিপশন', 'ক্লিন এনকোডেড আউটপুট'],
            'benefits' => ['গোপন চ্যাট ও নোট সংরক্ষণ', 'নিরাপদ ডাটা ট্রান্সফার'],
            'faqs' => [
            ]
        ],
        'mock-credit-card-validator' => [
            'name' => 'Luhn Algorithm Credit Card & BIN Validator',
            'name_bn' => 'ক্রেডিট কার্ড নম্বর ও বিন ভ্যালিডেটর',
            'category' => 'security-tools',
            'desc_en' => 'Validate bank card numbers using the standard mathematical Luhn algorithm and lookup BIN details.',
            'desc_bn' => 'লুন অ্যালগরিদম ব্যবহার করে যেকোনো ব্যাংকর কার্ডের সত্যতা এবং কার্ডের ব্র্যান্ড বা ব্যাংক ইনফো জানুন।',
            'features' => ['লুন ফর্মুলা ম্যাচিং', 'কার্ড নেটওয়ার্ক ডিটেকশন', 'বিন (BIN) আইডেন্টিফায়ার'],
            'benefits' => ['পেমেন্ট গেটওয়ে বাগ টেস্টিং', 'ভুল টাইপিং শনাক্তকরণ'],
            'faqs' => [
            ]
        ],
        'uuid-v4-generator-pro' => [
            'name' => 'Cryptographically Secure UUID v4 Generator',
            'name_bn' => 'ইউনিক ইউইউআইডি (UUID v4) জেনারেটর',
            'category' => 'developer-tools',
            'desc_en' => 'Generate cryptographically secure RFC4122 version 4 UUIDs (Universally Unique Identifiers) instantly.',
            'desc_bn' => 'ডেটাবেস বা ইউনিক আইডি ট্র্যাকিংয়ের জন্য ক্রিপ্টোগ্রাফিক সুরক্ষিত ইউইউআইডি ৪ জেনারেট করুন।',
            'features' => ['বাল্ক জেনারেশন (১-১০০)', 'আপারকেস/লোয়ারকেস অপশন', 'ড্যাশ রিমুভার'],
            'benefits' => ['ইউনিক ট্র্যাকিং কী তৈরি', 'ডেটাবেস কোলিশন প্রতিরোধ'],
            'faqs' => [
            ]
        ],
        'qr-wifi-network-generator' => [
            'name' => 'WiFi Network Scan & Connect QR Builder',
            'name_bn' => 'ওয়াইফাই নেটওয়ার্ক কিউআর মেকার',
            'category' => 'utility-tools',
            'desc_en' => 'Generate custom QR codes to let guests scan and connect to your home or office WiFi without typing passwords.',
            'desc_bn' => 'কাউকে পাসওয়ার্ড না জানিয়ে শুধুমাত্র কিউআর কোড স্ক্যান করে ওয়াইফাই কানেক্ট করার কিউআর বানান।',
            'features' => ['ডাব্লিউপিএ/ডাব্লিউইপি মোড', 'নেটওয়ার্ক হাইড অপশন', 'নিওন কিউআর ডিজাইন'],
            'benefits' => ['পাসওয়ার্ড ফাঁসের চিন্তা নেই', 'অতিথিদের জন্য ফাস্ট কানেক্টিভিটি'],
            'faqs' => [
            ]
        ],
        'dns-record-decoder-pro' => [
            'name' => 'DNS Record Hostname MX & TXT Decoder',
            'name_bn' => 'ডিএনএস রেকর্ড ডিকোডার ও অ্যানালাইজার',
            'category' => 'security-tools',
            'desc_en' => 'Analyze DNS queries to parse out specific name servers, SPF records, DKIM details, and TXT security directives.',
            'desc_bn' => 'আপনার ডোমেনের এসপিএফ রেকর্ড, ডেকিম ও টিএক্সটি নিরাপত্তা কনফিগারেশন নিখুঁতভাবে বিশ্লেষণ করুন।',
            'features' => ['এসপিএফ ভ্যালিডেটর', 'ডেকিম ডিটেকশন', 'ইমেইল সিকিউরিটি চেক'],
            'benefits' => ['ইমেইল স্প্যামিং প্রতিরোধ করা', 'ডোমেন ট্রাস্ট রেটিং বাড়ানো'],
            'faqs' => [
            ]
        ],
        'regex-cheatsheet-builder' => [
            'name' => 'Visual RegEx Tester & Cheat Sheet',
            'name_bn' => 'রেগুলার এক্সপ্রেশন টেস্টার ও চিটশিট',
            'category' => 'developer-tools',
            'desc_en' => 'Build and test Regular Expressions (RegEx) against text blocks with a built-in guide and match highlighter.',
            'desc_bn' => 'সহজ ভিজ্যুয়াল গাইডের মাধ্যমে রেগুলার এক্সপ্রেশন কোড টেস্ট এবং ম্যাচ হাইলাইট করুন।',
            'features' => ['লাইভ ম্যাচ হাইলাইটিং', 'ফ্ল্যাগ সিলেকশন (g, i, m)', 'রেডিমেড রেজেক্স ফর্মুলা'],
            'benefits' => ['কোডিং স্পিড বহুগুণ বৃদ্ধি', 'ভ্যালিডেশন কোড দ্রুত টেস্ট করা'],
            'faqs' => [
            ]
        ],
        'pro-html-minifier' => [
            'name' => 'Pro HTML Source Code Compressor',
            'name_bn' => 'এইচটিএমএল কোড মিনিফায়ার ও অপ্টিমাইজার',
            'category' => 'developer-tools',
            'desc_en' => 'Optimize webpages by stripping blank spaces, comments, and extra characters from HTML layouts.',
            'desc_bn' => 'আপনার ওয়েবসাইটের পেজ সাইজ কমিয়ে স্পিড বাড়াতে এইচটিএমএল কোড মিনিফাই করুন।',
            'features' => ['কমেন্ট রিমুভাল', 'স্পেস কম্প্রেশন', 'ডাউনলোড মিনিফাইড ফাইল'],
            'benefits' => ['সার্ভার লোড কমে', 'গুগল কোর ওয়েব ভাইটাল স্কোর বাড়ে'],
            'faqs' => [
            ]
        ],
        'pro-css-stylesheet-minifier' => [
            'name' => 'Pro CSS Stylesheet Minifier',
            'name_bn' => 'সিএসএস স্টাইলশিট মিনিফায়ার',
            'category' => 'developer-tools',
            'desc_en' => 'Remove extra spaces, tabs, and comments from CSS files to reduce file size and speed up stylesheet loads.',
            'desc_bn' => 'সিএসএস স্টাইলশিটের ফাইল সাইজ কমিয়ে দ্রুত স্টাইল লোড করার জন্য অতিরিক্ত ফাঁকা অংশ ছেঁটে ফেলুন।',
            'features' => ['লাইন ব্রেক রিমুভাল', 'কালার হেক্স অপ্টিমাইজেশন', 'ফাস্ট প্রসেসিং'],
            'benefits' => ['সাইটের ফার্স্ট কন্টেন্টফুল পেইন্ট (FCP) বাড়ে', 'ব্যান্ডউইথ সাশ্রয়'],
            'faqs' => [
            ]
        ],
        'pro-javascript-minifier' => [
            'name' => 'Pro JavaScript Optimizer & Minifier',
            'name_bn' => 'জাভাস্ক্রিপ্ট কোড মিনিফায়ার',
            'category' => 'developer-tools',
            'desc_en' => 'Compress your JavaScript code by stripping unused comments, formatting, and variables without breaking syntax.',
            'desc_bn' => 'জাভাস্ক্রিপ্ট ফাইলের অপ্রয়োজনীয় কমেন্ট ও ফরম্যাট বাদ দিয়ে কোডকে ওজনে হালকা ও স্পিডি করুন।',
            'features' => ['সিনট্যাক্স সেফ কম্প্রেশন', 'ভেরিয়েবল অপ্টিমাইজার টেমপ্লেট', 'লাইভ আউটপুট'],
            'benefits' => ['জাভাস্ক্রিপ্ট এক্সিকিউশন টাইম কমায়', 'সাইটের ওভারঅল পারফরম্যান্স বুস্ট'],
            'faqs' => [
            ]
        ],
        'user-agent-analyzer-tool' => [
            'name' => 'Browser User-Agent String Parser',
            'name_bn' => 'ইউজার এজেন্ট স্ট্রিং অ্যানালাইজার',
            'category' => 'developer-tools',
            'desc_en' => 'Parse and decode any web browser User-Agent string to detect OS, browser engine, and device type.',
            'desc_bn' => 'যেকোনো ব্রাউজারের ইউজার এজেন্ট কোড দিয়ে ডিভাইস, অপারেটিং সিস্টেম ও ব্রাউজার ভার্সন শনাক্ত করুন।',
            'features' => ['ডিভাইস ক্যাটাগরি শনাক্তকরণ', 'ব্রাউজার ইঞ্জিন ডিটেকশন', 'সহজ কুয়েরি মিটার'],
            'benefits' => ['ডিভাইস ও স্ক্রিন রেসপন্সিভনেস টেস্ট', 'এপিআই কুয়েরি ডিবাগিং'],
            'faqs' => [
            ]
        ],
        'ip-subnet-cidr-calculator' => [
            'name' => 'IP Subnet Address & CIDR Calculator',
            'name_bn' => 'আইপি সাবনেট ও সিআইডিআর রেঞ্জ ক্যালকুলেটর',
            'category' => 'security-tools',
            'desc_en' => 'Determine network range, CIDR blocks, wildcard masks, and host capacity for robust network design.',
            'desc_bn' => 'আইপি অ্যাড্রেস থেকে তার সাবনেট মাস্ক, সিআইডিআর নোটেশন এবং সর্বোচ্চ ডিভাইসের সংখ্যা বের করুন।',
            'features' => ['সিআইডিআর ব্রেকডাউন', 'ওয়াইল্ডকার্ড মাস্ক হিসাব', 'নেটওয়ার্ক আইপি টেবিল'],
            'benefits' => ['আইটি অ্যাডমিনিস্ট্রেশন ও নেটওয়ার্কিং সহজ করা', 'আইপি ব্লক ডিজাইন'],
            'faqs' => [
            ]
        ],
        'markdown-editor-previewer' => [
            'name' => 'Live Markdown Editor & HTML Previewer',
            'name_bn' => 'লাইভ মার্কডাউন এডিটর ও প্রিভিউয়ার',
            'category' => 'developer-tools',
            'desc_en' => 'Write and format rich content in Markdown syntax and view real-time converted HTML outputs instantly.',
            'desc_bn' => 'পাশে চমৎকার লাইভ প্রিভিউ দেখে দেখে মার্কডাউন ফাইল এডিট করুন এবং সরাসরি এইচটিএমএল কোড কপি করুন।',
            'features' => ['রিয়েল-টাইম স্প্লিট প্রিভিউ', 'এইচটিএমএল কোড জেনারেটর', 'লিস্ট ও বোল্ড ফরম্যাটিং'],
            'benefits' => ['ব্লগ কন্টেন্ট রাইটিং স্পিড বৃদ্ধি', 'গিটহাব ডেসক্রিপশন রেডি করা'],
            'faqs' => [
            ]
        ],
        'string-byte-size-calculator' => [
            'name' => 'Text UTF-8 Byte Size & Characters Sizer',
            'name_bn' => 'টেক্সট ইউটিএফ-৮ বাইট সাইজ ক্যালকুলেটর',
            'category' => 'text-tools',
            'desc_en' => 'Calculate exact byte size of your written text in Bytes, Kilobytes (KB), and Megabytes (MB) based on UTF-8 encoding.',
            'desc_bn' => 'আপনার লেখার ইউটিএফ-৮ স্ট্যান্ডার্ড অনুযায়ী প্রকৃত বাইট সাইজ, কেবি ও এমবি নিখুঁতভাবে পরিমাপ করুন।',
            'features' => ['ইউটিএফ-৮ এনকোডিং মেজার', 'বাইট বনাম ক্যারেক্টার মিটার', 'মেমোরি সাইজ সমীকরণ'],
            'benefits' => ['ডাটাবেস স্টোরেজ অপ্টিমাইজেশন', 'রিসোর্স লিমিট মেনে চলা'],
            'faqs' => [
            ]
        ],
        'currency-exchange-estimator-pro' => [
            'name' => 'Global Fiat Currency Rate Estimator',
            'name_bn' => 'গ্লোবাল মুদ্রা বিনিময় হার এস্টিমেটর',
            'category' => 'finance-tools',
            'desc_en' => 'Estimate exchange rates between global currencies like USD, EUR, GBP, CAD, and BDT based on standard ratios.',
            'desc_bn' => 'ইউএস ডলার, ইউরো, পাউন্ড ও কানাডিয়ান ডলারের সাথে বাংলাদেশী টাকার বিনিময় হার সহজে অনুমান করুন।',
            'features' => ['মাল্টি-কারেন্সি কনভার্সন', 'ইনস্ট্যান্ট রেট ক্যালকুলেটর', 'অফলাইন রেশিও'],
            'benefits' => ['বৈদেশিক লেনদেনের হিসাব সহজ', 'ভ্রমণ বাজেট সমীকরণ'],
            'faqs' => [
            ]
        ],
        'loan-amortization-schedule' => [
            'name' => 'Loan Amortization & Repayment Calculator',
            'name_bn' => 'লোন অ্যামোর্টাইজেশন শিডিউল মেকার',
            'category' => 'finance-tools',
            'desc_en' => 'Generate an annual or monthly repayment table showing principal and interest breakdowns over time.',
            'desc_bn' => 'আপনার লোনের প্রতি কিস্তিতে কত টাকা আসল এবং কত টাকা সুদ পরিশোধ করতে হবে তার তালিকা তৈরি করুন।',
            'features' => ['মাসিক কিস্তি ব্রেকডাউন', 'মোট সুদের হার', 'ডাউনলোড বা সেভ শিডিউল'],
            'benefits' => ['আর্থিক ঋণ পরিকল্পনা', 'ব্যাংক সুদের কারসাজি এড়ানো'],
            'faqs' => [
            ]
        ],
        'compound-growth-planner' => [
            'name' => 'Compound Growth & Wealth Goal Planner',
            'name_bn' => 'চক্রবৃদ্ধি মুনাফা ও সম্পদ পরিকল্পনাকারী',
            'category' => 'finance-tools',
            'desc_en' => 'Plan long-term wealth goals by simulating compound interest growth with customizable regular contributions.',
            'desc_bn' => 'নিয়মিত সঞ্চয় ও সুদের চক্রবৃদ্ধির মাধ্যমে আপনার দীর্ঘমেয়াদী সম্পদ তৈরির লক্ষ্য অর্জন নিশ্চিত করুন।',
            'features' => ['টপ-আপ কন্ট্রিবিউশন অপশন', 'ভবিষ্যত সম্পদের মোট মূল্য', 'রিয়েল চার্ট ভিজ্যুয়াল'],
            'benefits' => ['রিটায়ারমেন্ট প্ল্যানিং', 'দীর্ঘমেয়াদী ইনভেস্টমেন্ট ট্র্যাক'],
            'faqs' => [
            ]
        ],
        'retirement-pension-estimator' => [
            'name' => 'Retirement Nest Egg & Pension Estimator',
            'name_bn' => 'অবসরকালীন পেনশন ও সঞ্চয় হিসাবকারী',
            'category' => 'finance-tools',
            'desc_en' => 'Calculate the savings required to achieve your desired retirement lifestyle and monthly pension payouts.',
            'desc_bn' => 'অবসর জীবনে প্রতি মাসে নির্দিষ্ট টাকা বা পেনশন পেতে এখন থেকে প্রতি মাসে কত টাকা জমানো দরকার তা জানুন।',
            'features' => ['ইনফ্লেশন বা মূল্যস্ফীতি সমন্বয়', 'মাসিক পেনশন লক্ষ্যমাত্রা', 'মোট জমানো টাকা হিসাব'],
            'benefits' => ['নিশ্চিন্ত অবসর যাপন নিশ্চিত করা', 'টাকা সাশ্রয়ের সঠিক টার্গেট সেট'],
            'faqs' => [
            ]
        ],
        'pregnancy-due-date-estimator' => [
            'name' => 'Pregnancy Due Date & Milestone Tracker',
            'name_bn' => 'গর্ভকালীন প্রসবের তারিখ ও মাইলস্টোন ক্যালকুলেটর',
            'category' => 'health-tools',
            'desc_en' => 'Estimate pregnancy due date, current trimester, and baby growth milestones based on your Last Menstrual Period (LMP).',
            'desc_bn' => 'শেষ পিরিয়ডের তারিখের ভিত্তিতে প্রসবের সম্ভাব্য তারিখ, ট্রাইমেস্টার এবং শিশুর সাপ্তাহিক বৃদ্ধির মাইলস্টোন জানুন।',
            'features' => ['সম্ভাব্য প্রসবের দিন (EDD)', 'সাপ্তাহিক মাইলস্টোন চার্ট', 'গুরুত্বপূর্ণ পরামর্শ'],
            'benefits' => ['প্রসবকালীন পরিকল্পনা সহজ করা', 'শারীরিক যত্ন ও সচেতনতা বৃদ্ধি'],
            'faqs' => [
            ]
        ],
        'breathes-daily-water-planner' => [
            'name' => 'Daily Hydration Goals & Water Volume Planner',
            'name_bn' => 'দৈনিক ওয়াটার হাইড্রেশন ও স্বাস্থ্য পরিকল্পনা',
            'category' => 'health-tools',
            'desc_en' => 'Plan your hourly water intake schedule customized to your daily physical activity levels and outdoor temperature.',
            'desc_bn' => 'আপনার শারীরিক ওজন ও বাইরের তাপমাত্রার ওপর ভিত্তি করে ঘণ্টায় ঘণ্টায় পানি পানের সঠিক রুটিন সাজান।',
            'features' => ['ঘণ্টা ভিত্তিক পানি রুটিন', 'ডিটক্স ও মেটাবলিজম বুস্ট টিপস', 'সহজ হাইড্রেশন ক্যালকুলেশন'],
            'benefits' => ['কিডনি ও ত্বক সতেজ রাখা', 'পর্যাপ্ত পানি পান নিশ্চিত করা'],
            'faqs' => [
            ]
        ],
        'password-entropy-calculator' => [
            'name' => 'Secure Password Entropy Calculator',
            'name_bn' => 'পাসওয়ার্ড এন্ট্রপি ও স্ট্রেন্থ ক্যালকুলেটর',
            'category' => 'security-tools',
            'desc_en' => 'Calculate the mathematical information entropy (bits) of passwords to estimate the brute-force crack time.',
            'desc_bn' => 'গাণিতিক এন্ট্রপি (Bits) হিসাব করে আপনার পাসওয়ার্ড ক্র্যাক করতে হ্যাকারদের কত সময় লাগবে তা অনুমান করুন।',
            'features' => ['এন্ট্রপি বিটস হিসাব', 'ব্রুট-ফোর্স ক্র্যাক টাইম', 'নিরাপত্তা রেটিং'],
            'benefits' => ['পাসওয়ার্ড নিরাপত্তা সচেতনতা বাড়ানো'],
            'faqs' => [
            ]
        ],
        'bengali-to-english-phonetic' => [
            'name' => 'Bengali to English Transliteration Helper',
            'name_bn' => 'বাংলা টু ইংরেজি প্রতিবর্ণীকরণ সহায়িকা',
            'category' => 'text-tools',
            'desc_en' => 'Convert Bengali texts and names into English phonetic spelling matching international standards.',
            'desc_bn' => 'বাংলা নাম বা শব্দকে পাসপোর্ট বা সরকারি ডকুমেন্টের উপযোগী নির্ভুল ইংরেজি প্রতিবর্ণীকরণে রূপান্তর করুন।',
            'features' => ['ফোনেটিক কনভার্সন', 'পাসপোর্ট স্ট্যান্ডার্ড নাম ম্যাচ', 'সহজ কপি অপশন'],
            'benefits' => ['সরকারি বা প্রাতিষ্ঠানিক ফর্মে নির্ভুল ইংরেজি নাম লেখা'],
            'faqs' => [
            ]
        ],
];
}
