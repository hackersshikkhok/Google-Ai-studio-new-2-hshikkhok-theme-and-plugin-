<?php
/**
 * Standalone SMS & Status Autopilot Engine
 * Path: inc/sms-status-autopilot.php
 * Handles AI-driven SMS/Status collection creation, card parsing, fallbacks, display markups, and admin panel.
 */

if (!defined('ABSPATH')) exit;

/**
 * 1. Admin Menu & Submenu Handler
 */
if (!function_exists('ilybd_register_sms_autopilot_menu')) {
    function ilybd_register_sms_autopilot_menu() {
        $parent_slugs = array('ilybd-settings', 'ily-settings', 'ily-seo-dashboard');
        foreach ($parent_slugs as $parent) {
            add_submenu_page(
                $parent,
                'SMS & Status Autopilot Console',
                '💬 SMS Autopilot',
                'manage_options',
                'ilybd-sms-autopilot',
                'ilybd_render_sms_autopilot_page'
            );
        }
    }
}
add_action('admin_menu', 'ilybd_register_sms_autopilot_menu', 20);

/**
 * 2. Render Admin Page for SMS & Status Autopilot
 */
if (!function_exists('ilybd_render_sms_autopilot_page')) {
    function ilybd_render_sms_autopilot_page() {
        $message = function_exists('ilybd_handle_autopilot_manual_trigger') ? ilybd_handle_autopilot_manual_trigger() : '';
        $sms_enabled = get_option('ilybd_enable_sms_section', 'yes');
        $sms_pilot = get_option('ilybd_sms_autopilot_enabled', 'yes');
        $sms_count = intval(get_option('ilybd_sms_daily_count', 1));
        $sms_frequency = get_option('ilybd_sms_frequency', 'daily');
        $sms_display_count = intval(get_option('ilybd_sms_display_count', 5));
        ?>
        <div class="wrap" style="background:#070b13; color:#c9d1d9; padding:25px; border-radius:14px; border:1px solid #00f0ff; font-family:system-ui; max-width:900px; margin-top:20px; box-shadow:0 0 25px rgba(0,240,255,0.15);">
            <h1 style="color:#00f0ff; text-align:center; font-weight:800; text-transform:uppercase; letter-spacing:1px; margin-bottom:5px;">💬 SMS & Status Autopilot Control</h1>
            <p style="text-align:center; color:#8b949e; margin-bottom:25px;">Standalone Autopilot Module for Categorized Tap-to-Copy SMS & Status Posts</p>

            <?php if (!empty($message)) : ?>
                <div style="background:rgba(0, 240, 255, 0.1); border:1.5px solid #00f0ff; color:#00f0ff; padding:15px; border-radius:8px; margin-bottom:20px; font-weight:bold; font-size:14px;">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <form method="post" action="options.php">
                <?php settings_fields('ilybd_nextgen_group'); ?>
                <div style="background:#0d1527; border: 1px solid rgba(0,240,255,0.25); border-radius:12px; padding:25px; margin-bottom:20px;">
                    <div style="margin-bottom:20px;">
                        <label style="display:block; font-size:13px; font-weight:bold; color:#fff; margin-bottom:8px;">Section Visibility (Show/Hide in Site):</label>
                        <select name="ilybd_enable_sms_section" style="width:100%; background:#070b13; color:#00ff41; border:1px solid rgba(0,255,65,0.3); padding:12px; border-radius:6px; font-weight:bold;">
                            <option value="yes" <?php selected($sms_enabled, 'yes'); ?>>Visible (SHOW)</option>
                            <option value="no" <?php selected($sms_enabled, 'no'); ?>>Hidden (HIDE)</option>
                        </select>
                    </div>

                    <div style="margin-bottom:20px;">
                        <label style="display:block; font-size:13px; font-weight:bold; color:#fff; margin-bottom:8px;">Autopilot AI Writer Status:</label>
                        <select name="ilybd_sms_autopilot_enabled" style="width:100%; background:#070b13; color:#00f0ff; border:1px solid rgba(0,240,255,0.3); padding:12px; border-radius:6px; font-weight:bold;">
                            <option value="yes" <?php selected($sms_pilot, 'yes'); ?>>Enabled / ON (Auto Posts Active)</option>
                            <option value="no" <?php selected($sms_pilot, 'no'); ?>>Disabled / OFF (No Auto Posts)</option>
                        </select>
                    </div>

                    <div style="margin-bottom:20px;">
                        <label style="display:block; font-size:13px; font-weight:bold; color:#fff; margin-bottom:8px;">Autopilot Frequency (কতক্ষণ পর পর পোস্ট হবে):</label>
                        <select name="ilybd_sms_frequency" style="width:100%; background:#070b13; color:#fff; border:1px solid rgba(255,255,255,0.2); padding:12px; border-radius:6px; font-weight:bold;">
                            <option value="daily" <?php selected($sms_frequency, 'daily'); ?>>Every 24 Hours (প্রতিদিন ১ বার)</option>
                            <option value="custom_12_hours" <?php selected($sms_frequency, 'custom_12_hours'); ?>>Every 12 Hours (প্রতি ১২ ঘণ্টায় ১ বার)</option>
                            <option value="custom_6_hours" <?php selected($sms_frequency, 'custom_6_hours'); ?>>Every 6 Hours (প্রতি ৬ ঘণ্টায় ১ বার)</option>
                            <option value="custom_4_hours" <?php selected($sms_frequency, 'custom_4_hours'); ?>>Every 4 Hours (প্রতি ৪ ঘণ্টায় ১ বার)</option>
                            <option value="custom_3_hours" <?php selected($sms_frequency, 'custom_3_hours'); ?>>Every 3 Hours (প্রতি ৩ ঘণ্টায় ১ বার)</option>
                            <option value="custom_2_hours" <?php selected($sms_frequency, 'custom_2_hours'); ?>>Every 2 Hours (প্রতি ২ ঘণ্টায় ১ বার)</option>
                            <option value="hourly" <?php selected($sms_frequency, 'hourly'); ?>>Every 1 Hour (প্রতি ১ ঘণ্টায় ১ বার)</option>
                        </select>
                    </div>

                    <div style="margin-bottom:20px;">
                        <label style="display:block; font-size:13px; font-weight:bold; color:#fff; margin-bottom:8px;">Posts Count per Cycle (প্রতি চক্রে কয়টি জেনারেট হবে):</label>
                        <select name="ilybd_sms_daily_count" style="width:100%; background:#070b13; color:#fff; border:1px solid rgba(255,255,255,0.2); padding:12px; border-radius:6px; font-weight:bold;">
                            <?php for($n=1; $n<=10; $n++): ?>
                                <option value="<?php echo $n; ?>" <?php selected($sms_count, $n); ?>><?php echo $n; ?> Posts / Cycle</option>
                            <?php endfor; ?>
                        </select>
                    </div>

                    <div style="margin-bottom:20px;">
                        <label style="display:block; font-size:13px; font-weight:bold; color:#fff; margin-bottom:8px;">Homepage Display Limit (হোমপেজে ডিসপ্লে সংখ্যা):</label>
                        <select name="ilybd_sms_display_count" style="width:100%; background:#070b13; color:#00f0ff; border:1px solid rgba(0,240,255,0.3); padding:12px; border-radius:6px; font-weight:bold;">
                            <?php for($n=1; $n<=20; $n++): ?>
                                <option value="<?php echo $n; ?>" <?php selected($sms_display_count, $n); ?>><?php echo $n; ?> Posts (Default 5)</option>
                            <?php endfor; ?>
                        </select>
                    </div>

                    <div style="display:flex; gap:15px; margin-top:25px;">
                        <button type="submit" class="button button-primary" style="flex:1; background:linear-gradient(90deg, #00f0ff 0%, #0072ff 100%); color:#000; border:none; padding:12px; border-radius:6px; font-weight:800; font-size:13px; cursor:pointer;">💾 SAVE SMS SETTINGS</button>
                        <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=ilybd-sms-autopilot&trigger_pilot=sms'), 'ilybd_trigger_pilot_action'); ?>" class="button button-secondary" style="flex:1; text-align:center; background:#102231; color:#00f0ff; border:1px solid #00f0ff; padding:12px; border-radius:6px; font-weight:800; font-size:13px; text-decoration:none;">⚡ TRIGGER SMS GENERATOR NOW</a>
                    </div>
                </div>
            </form>
        </div>
        <?php
    }
}

/**
 * 3. SMS & Status Autopilot Generator Trigger
 */
if (!function_exists('ilybd_trigger_sms_autopilot')) {
    function ilybd_trigger_sms_autopilot() {
        $api_keys = function_exists('ily_get_all_rotated_api_keys') ? ily_get_all_rotated_api_keys() : [];
        if (empty($api_keys)) {
            return new WP_Error('no_keys', 'কোনো সচল Gemini API Key পাওয়া যায়নি।');
        }

        $viral_sms_ideas = [
            'ভালোবাসা ও প্রেম (Romantic Love)', 'দুঃখ ও বিরহের যন্ত্রণা (Sadness & Pain)', 
            'খাঁটি বন্ধুত্ব ও আড্ডা (Best Friendship)', 'গার্লফ্রেন্ডের মন জয় (Girlfriend Special)', 
            'বয়ফ্রেন্ডকে সারপ্রাইজ (Boyfriend Special)', 'স্ত্রীর প্রতি ভালোবাসা (Wife Special)', 
            'স্বামীর মিষ্টি প্রেম (Husband Special)', 'মা-বাবার দোয়া ও ভালোবাসা (Parents Love)', 
            'ভাই-বোনের মিষ্টি বন্ধন (Siblings Bond)', 'অভিমান ও অনুযোগ (Ego & Complaints)', 
            'স্নিগ্ধ শুভ সকাল (Good Morning Wishes)', 'শান্ত শুভ রাত্রি (Good Night Wishes)', 
            'শুভ জন্মদিন অভিনন্দন (Birthday Wishes)', 'ইসলামিক হেদায়েত ও উক্তি (Islamic Status)', 
            'জীবন যুদ্ধের মোটিভেশন (Life Motivation)', 'কষ্টের গভীর স্ট্যাটাস (Deep Sad Status)', 
            'বুকভাঙা বিরহ ও ব্যাকুলতা (Breakup Pain)', 'হাসির জোকস ও ট্রোল (Funny Jokes & Fun)', 
            'শুভ নববর্ষ বৈশাখী শুভেচ্ছা (New Year Celebration)', 'ঈদ মোবারক শুভেচ্ছা বার্তা (Eid Mubarak Special)', 
            'একাকিত্ব ও নিঝুম রাত (Loneliness & Night)', 'প্রবাসীদের জীবন সংগ্রাম (Expatriate Hardship)',
            'রাজকীয় এটিটিউড ও অ্যাটিটিউড (Royal Attitude)', 'সাইবার কোডিং ও টেকপ্রেমী (Tech & Coding Quotes)',
            'প্রেমের প্রস্তাব ও প্রপোজ (Proposal Quotes)', 'উপদেশ ও জীবনদর্শন (Life Advice & Lessons)',
            'মেয়ের মন জয় করার এসএমএস (Girls Heart Winning)', 'ক্যাম্পাস লাইফ ও ক্রাশ (Campus Nostalgia)',
            'অনুপ্রেরণা ও আত্মবিশ্বাস (Self Confidence & Success)', 'উৎসব ও পার্বণের শুভেচ্ছা (Festival Greetings)'
        ];
        
        $use_new_category = (rand(1, 10) <= 7);
        $selected_cat_id = 0;
        
        if ($use_new_category) {
            $selected_cat_name = $viral_sms_ideas[array_rand($viral_sms_ideas)];
            $selected_cat_slug = sanitize_title(str_replace(['(', ')', '&'], '', $selected_cat_name));
        } else {
            $terms = get_terms(['taxonomy' => 'sms_category', 'hide_empty' => false]);
            if (!is_wp_error($terms) && !empty($terms)) {
                $selected_term = $terms[array_rand($terms)];
                $selected_cat_name = $selected_term->name;
                $selected_cat_slug = $selected_term->slug;
                $selected_cat_id = $selected_term->term_id;
            } else {
                $selected_cat_name = 'ভালোবাসা ও প্রেম (Romantic Love)';
                $selected_cat_slug = 'romantic-love';
            }
        }

        if ($selected_cat_id == 0) {
            $term = term_exists($selected_cat_slug, 'sms_category');
            if ($term) {
                $selected_cat_id = is_array($term) ? $term['term_id'] : $term;
            } else {
                $inserted = wp_insert_term($selected_cat_name, 'sms_category', ['slug' => $selected_cat_slug]);
                if (!is_wp_error($inserted)) {
                    $selected_cat_id = $inserted['term_id'];
                }
            }
        }

        $recent_sms_posts = get_posts([
            'post_type'      => 'ilybd_sms',
            'post_status'    => 'publish',
            'posts_per_page' => 100,
            'fields'         => 'ids'
        ]);
        $exclude_sms_str = "";
        if (!empty($recent_sms_posts)) {
            $ex_titles = [];
            foreach ($recent_sms_posts as $sms_id) {
                $ex_titles[] = get_the_title($sms_id);
            }
            $exclude_sms_str = "AVOID these recent titles completely: " . implode(" | ", array_slice($ex_titles, 0, 30)) . ". ";
        }

        $possible_counts = [100, 120, 150, 180, 200, 250];
        $count = $possible_counts[array_rand($possible_counts)];

        $title_prompt = "Generate a highly viral, clickable, and SEO-optimized title for a collection of {$count}+ SMS/Status updates under category '{$selected_cat_name}'. " . $exclude_sms_str . " Must contain English and Bengali words with year " . date('Y') . ". Return ONLY exact title string.";
        $title_res = ily_call_gemini_api_direct($api_keys, $title_prompt, 150);
        
        $default_sms_titles = [
            "{$count}+ Best {$selected_cat_name} SMS & Status (বাংলা ও English " . date('Y') . ")",
            "{$count}+ Viral {$selected_cat_name} Captions (নতুন অনন্য সংকলন " . date('Y') . ")"
        ];
        $title = (!is_wp_error($title_res) && !empty($title_res)) ? trim($title_res, "\"'#\n\r ") : $default_sms_titles[array_rand($default_sms_titles)];
        $title = preg_replace('/^Title:\s*/i', '', $title);
        if (function_exists('ily_clean_ai_title_for_seo')) {
            $title = ily_clean_ai_title_for_seo($title);
        }

        $existing_sms = get_page_by_title($title, OBJECT, 'ilybd_sms');
        if ($existing_sms) {
            $title .= " (" . date('Y') . " Special Edition)";
        }

        $prompt = "You are an elite Bengali human writer. Write a batch of exactly {$count} Status and SMS messages under category: '{$selected_cat_name}'.\n\n" .
                  "1. Write 150-200 words intro paragraph in Bengali.\n" .
                  "2. Provide EXACTLY {$count} SMS cards in format:\n" .
                  "---\n[CARD_NUMBER]\nBN: [Bengali status]\nEN: [English caption]\n---\n";

        $content = ily_call_gemini_api_direct($api_keys, $prompt, 8192, false, "You are an elite bilingual copywriter creating Bengali SMS and status updates.");
        if (is_wp_error($content) || empty($content)) {
            $content = ilybd_get_sms_fallback($selected_cat_name, $count);
        }

        $content_cleaned = preg_replace('/```[a-z]*\n/i', '', $content);
        $content_cleaned = str_replace('```', '', $content_cleaned);

        $ai_editor_res = function_exists('ilybd_ai_seo_editor_review') ? ilybd_ai_seo_editor_review($content_cleaned, 'SMS & Status', $title) : ['content' => $content_cleaned, 'score' => 98];
        $content_cleaned = $ai_editor_res['content'];
        $seo_score = $ai_editor_res['score'];

        $author_id = function_exists('ilybd_get_rotated_author_id') ? ilybd_get_rotated_author_id() : 1;

        $post_id = wp_insert_post([
            'post_title'   => $title,
            'post_content' => $content_cleaned,
            'post_status'  => 'publish',
            'post_type'    => 'ilybd_sms',
            'post_author'  => $author_id
        ]);

        if (!is_wp_error($post_id) && $post_id > 0) {
            if ($selected_cat_id > 0) {
                wp_set_post_terms($post_id, [$selected_cat_id], 'sms_category');
            }
            
            $tags_array = ['বাংলা এসএমএস', 'স্ট্যাটাস ২০২৬', 'মোবাইল এসএমএস', 'Viral Status', 'Romantic SMS'];
            wp_set_post_terms($post_id, $tags_array, 'sms_tag');
            
            update_post_meta($post_id, 'ilybd_seo_originality_score', $seo_score);
            update_post_meta($post_id, 'ilybd_seo_plagiarism_score', 100);
            update_post_meta($post_id, 'ilybd_seo_adsense_status', 'PASSED');
            update_post_meta($post_id, 'ilybd_sms_dynamic_count', $count);
            
            $thumb_keyword = "mobile phone text messages glowing typography " . str_replace('-', ' ', $selected_cat_slug);
            $rand_seed = rand(1001, 9999);
            $image_url = "https://image.pollinations.ai/prompt/" . urlencode($thumb_keyword) . "?width=1200&height=630&nologo=true&seed=" . $rand_seed . "&enhance=true&nofeed=true&model=flux";
            if (function_exists('ily_download_and_set_featured_image')) {
                ily_download_and_set_featured_image($post_id, $image_url);
            }
            
            flush_rewrite_rules(false);
        }

        return $post_id;
    }
}

/**
 * 4. SMS & Status Parser & Renderer
 */
if (!function_exists('ilybd_parse_and_render_sms_content')) {
    function ilybd_parse_and_render_sms_content($content) {
        if (empty($content)) return '';

        if (strpos($content, 'cyber-sms-card') !== false) {
            return wpautop($content);
        }

        $parts = explode('---', $content);
        if (count($parts) <= 1) {
            $fallback_parts = preg_split('/(?=\d+\.\s*BN:|১\.\s*BN:)/iu', $content);
            if (is_array($fallback_parts)) {
                $parts = $fallback_parts;
            }
        }
        
        $intro = '';
        if (is_array($parts) && count($parts) > 0) {
            $intro = trim((string)array_shift($parts));
        }
        $rendered_content = '<div class="sms-intro-paragraph" style="font-size: 17px; line-height: 1.85; color: #cbd5e0; margin-bottom: 25px;">' . wpautop($intro) . '</div>';

        $sms_index = 1;
        foreach ($parts as $part) {
            $part = trim($part);
            if (empty($part)) continue;

            $bn_text = '';
            $en_text = '';

            if (preg_match('/(?:BN:|বাংলা:)\s*(.*?)(?=\s*(?:EN:|ইংরেজি:|$))/ius', $part, $bn_match)) {
                $bn_text = trim($bn_match[1]);
            }
            if (preg_match('/(?:EN:|ইংরেজি:)\s*(.*?)$/ius', $part, $en_match)) {
                $en_text = trim($en_match[1]);
            }

            if (empty($bn_text)) {
                $lines = array_filter(array_map('trim', explode("\n", $part)));
                $lines = array_values(array_filter($lines, function($line) {
                    return !preg_match('/^\d+\.?$/u', $line) && !preg_match('/^[১-৯]+\.?$/u', $line);
                }));
                if (count($lines) >= 2) {
                    $bn_text = $lines[0];
                    $en_text = $lines[1];
                } elseif (count($lines) == 1) {
                    $bn_text = $lines[0];
                }
            }

            if (empty($bn_text)) continue;

            $bn_text = preg_replace('/^\s*(?:\d+|[১-৯]+)\.?\s*/iu', '', $bn_text);
            $en_text = preg_replace('/^\s*(?:\d+|[১-৯]+)\.?\s*/iu', '', $en_text);

            $post_id = get_the_ID();
            $card_img_url = get_template_directory_uri() . '/inc/dynamic-image-generator-card.php?post_id=' . $post_id . '&sms_index=' . $sms_index;
            $img_alt = esc_attr(get_the_title($post_id)) . ' - SMS #' . $sms_index;

            $rendered_content .= '
            <div class="cyber-sms-card" id="sms-card-' . $sms_index . '" style="background: rgba(13, 21, 39, 0.55); border: 1px solid rgba(0, 240, 255, 0.15); border-radius: 12px; padding: 22px; margin-bottom: 20px; position: relative; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.2);">
                <div class="sms-card-image-wrapper" style="margin-bottom: 20px; border-radius: 8px; overflow: hidden; border: 1.5px solid rgba(0, 240, 255, 0.2); aspect-ratio: 16/9; width: 100%; background: #070b13;">
                    <img src="' . esc_url($card_img_url) . '" alt="' . $img_alt . '" style="width: 100%; height: 100%; object-fit: cover; display: block;" loading="lazy" />
                </div>
                <div class="sms-body-bn" style="font-size: 17.5px; line-height: 1.75; color: #ffffff; font-weight: 500; text-align: left; margin-bottom: 12px;">' . esc_html($bn_text) . '</div>';
            
            if (!empty($en_text)) {
                $rendered_content .= '
                <div class="sms-body-en" style="font-size: 15px; line-height: 1.65; color: #8b949e; text-align: left; margin-bottom: 18px; border-top: 1px solid rgba(255,255,255,0.03); padding-top: 10px;">' . esc_html($en_text) . '</div>';
            }

            $rendered_content .= '
                <div class="sms-actions" style="display: flex; gap: 8px; flex-wrap: wrap;">
                    <button class="copy-sms-btn-bn" onclick="copySmsCardBn(this)" style="background: rgba(0, 240, 255, 0.05); color: #00f0ff; border: 1px solid rgba(0, 240, 255, 0.2); padding: 6px 12px; border-radius: 6px; font-weight: bold; font-size: 11.5px; cursor: pointer;"><i class="fa-regular fa-copy"></i> বাংলা কপি</button>';
            
            if (!empty($en_text)) {
                $rendered_content .= '
                    <button class="copy-sms-btn-en" onclick="copySmsCardEn(this)" style="background: rgba(157, 78, 221, 0.05); color: #c77dff; border: 1px solid rgba(157, 78, 221, 0.2); padding: 6px 12px; border-radius: 6px; font-weight: bold; font-size: 11.5px; cursor: pointer;"><i class="fa-regular fa-copy"></i> ইংরেজি কপি</button>';
            }

            $rendered_content .= '
                    <button class="share-whatsapp-btn" onclick="shareSmsOnWhatsapp(this)" style="background: rgba(37, 211, 102, 0.05); color: #25d366; border: 1px solid rgba(37, 211, 102, 0.2); padding: 6px 12px; border-radius: 6px; font-weight: bold; font-size: 11.5px; cursor: pointer;"><i class="fa-brands fa-whatsapp"></i> শেয়ার</button>
                </div>
            </div>';

            $sms_index++;
        }

        return $rendered_content;
    }
}

/**
 * 5. SMS & Status Homepage Section Markup
 */
if (!function_exists('ilybd_markup_sms_section')) {
    function ilybd_markup_sms_section() {
        $sms_enabled = get_option('ilybd_enable_sms_section', 'yes');
        if ($sms_enabled !== 'yes') return '';

        $display_count = intval(get_option('ilybd_sms_display_count', 5));
        $query = new WP_Query([
            'post_type'      => 'ilybd_sms',
            'posts_per_page' => $display_count,
            'post_status'    => 'publish'
        ]);

        if (!$query->have_posts()) return '';

        ob_start();
        ?>
        <section class="cyber-section sms-section" style="margin: 40px 0; background: #070b13; border: 1.5px solid rgba(0, 240, 255, 0.2); border-radius: 16px; padding: 25px; box-shadow: 0 10px 30px rgba(0,0,0,0.5);">
            <div class="sec-header" style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid rgba(255,255,255,0.08); padding-bottom: 12px; margin-bottom: 20px;">
                <h2 style="color: #fff; font-size: 18px; margin: 0; font-weight: 800; display: flex; align-items: center; gap: 8px;">
                    <i class="fa-solid fa-comments" style="color: #00f0ff;"></i>
                    সেরা বাংলা এসএমএস ও ক্যাপশন (SMS & Status Hub)
                </h2>
                <a href="<?php echo esc_url(get_post_type_archive_link('ilybd_sms') ?: home_url('/sms/')); ?>" style="color: #00f0ff; font-size: 12px; font-weight: 700; text-decoration: none;">সবগুলো সংকলন দেখুন →</a>
            </div>

            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 20px;">
                <?php while ($query->have_posts()) : $query->the_post(); 
                    $p_id = get_the_ID();
                    $thumb = get_the_post_thumbnail_url($p_id, 'medium') ?: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=600&q=80';
                    $cats = wp_get_post_terms($p_id, 'sms_category');
                    $cat_name = !empty($cats) ? $cats[0]->name : 'Status';
                ?>
                    <article class="sms-card" style="background: rgba(13,21,39,0.6); border: 1px solid rgba(255,255,255,0.06); border-radius: 12px; overflow: hidden; display: flex; flex-direction: column;">
                        <a href="<?php the_permalink(); ?>" style="text-decoration: none; display: block; overflow: hidden; position: relative; height: 160px;">
                            <img src="<?php echo esc_url($thumb); ?>" alt="<?php the_title_attribute(); ?>" style="width: 100%; height: 100%; object-fit: cover;" />
                            <span style="position: absolute; top: 10px; left: 10px; background: rgba(0,240,255,0.9); color: #000; font-size: 10px; font-weight: 900; padding: 3px 8px; border-radius: 4px;">
                                <?php echo esc_html($cat_name); ?>
                            </span>
                        </a>
                        <div style="padding: 15px; flex: 1; display: flex; flex-direction: column; justify-content: space-between;">
                            <h3 style="margin: 0 0 10px 0; font-size: 14px; font-weight: 700; line-height: 1.4;">
                                <a href="<?php the_permalink(); ?>" style="color: #fff; text-decoration: none;">
                                    <?php the_title(); ?>
                                </a>
                            </h3>
                            <a href="<?php the_permalink(); ?>" style="color: #00f0ff; font-size: 12px; font-weight: 800; text-decoration: none; display: inline-flex; align-items: center; gap: 5px;">
                                কপি করুন ও পড়ুন <i class="fa-solid fa-arrow-right"></i>
                            </a>
                        </div>
                    </article>
                <?php endwhile; wp_reset_postdata(); ?>
            </div>
        </section>
        <?php
        return ob_get_clean();
    }
}

/**
 * 6. SMS Fallback Generator
 */
if (!function_exists('ilybd_get_sms_fallback')) {
    function ilybd_get_sms_fallback($selected_cat_name, $count) {
        $fallback = "প্রিয় পাঠক, আপনাদের জন্য পছন্দসই '{$selected_cat_name}' ক্যাটাগরির সেরা এসএমএস ও স্ট্যাটাস সংকলন তৈরি করা হয়েছে।\n\n";
        for ($i = 1; $i <= min($count, 20); $i++) {
            $fallback .= "---\n[{$i}]\nBN: জীবন এক সুন্দর অনুভূতি, ভালোবাসায় ভরে উঠুক আপনার প্রতিটি মুহূর্ত।\nEN: Life is a beautiful journey, may love fill your every moment.\n---\n";
        }
        return $fallback;
    }
}
