<?php
/**
 * ILYBD Neon v2 Pro - Dynamic SEO Content Engine
 * Generates 100% Unique, SEO-friendly 500-1000 word content for each tool.
 * BILINGUAL (English + Bengali) for maximum search indexation and user intent fulfillment.
 */
if (!defined('ABSPATH')) exit;

require_once get_template_directory() . '/inc/ilybd-tools-manual-seo.php';

function ilybd_generate_unique_seo_article($tool_slug, $tool, $cat_det) {
    // 1. Check if admin has manually written a custom SEO article via WP Admin
    $custom_article = get_option("ilybd_tool_seo_article_{$tool_slug}", "");
    if (!empty($custom_article)) {
        return '<div class="custom-seo-article bangla-font-siliguri">' . wp_kses_post($custom_article) . '</div>';
    }

    // 2. Check if we have manually written hardcoded AI content
    if (function_exists('ilybd_get_manual_seo_content')) {
        $manual_content = ilybd_get_manual_seo_content($tool_slug);
        if (!empty($manual_content)) {
            return '<div class="ai-generated-seo bangla-font-siliguri">' . $manual_content . '</div>';
        }
    }

    $name = esc_html($tool['name_bn'] ?? $tool['name']);
    $name_en = esc_html($tool['name']);
    $desc = esc_html($tool['desc_bn'] ?? '');
    $desc_en = esc_html($tool['desc_en'] ?? $name_en . ' is a professional online utility tool designed for efficiency and speed.');
    $cat = $tool['category'] ?? '';
    $features = $tool['features'] ?? [];
    $benefits = $tool['benefits'] ?? [];
    $faqs = $tool['faqs'] ?? [];

    // Ensure we have at least 5 FAQs
    $base_faqs = [
        ['Q' => "Is {$name_en} completely free to use?", 'A' => "Yes, our {$name_en} tool is 100% free with no hidden charges or subscription fees. We believe in providing premium utility tools accessible to everyone without cost. (হ্যাঁ, আমাদের এই টুলটি ব্যবহার করতে কোনো টাকা লাগে না, এটি সম্পূর্ণ ফ্রি। আমরা চাই সবাই বিনামূল্যে এই প্রিমিয়াম সুবিধা উপভোগ করুক।)"],
        ['Q' => "Do I need to install any software or app to use {$name_en}?", 'A' => "No installation is required. It is a modern cloud-based web application that works directly in your browser on both mobile smartphones and desktop computers. (না, কোনো সফটওয়্যার বা অ্যাপ ইন্সটল করার প্রয়োজন নেই। এটি একটি ক্লাউড-ভিত্তিক ওয়েব টুল যা সরাসরি আপনার ব্রাউজারে কাজ করে।)"],
        ['Q' => "Is my data safe and private when using {$name_en}?", 'A' => "Absolutely. We prioritize your privacy above all. All processing is done securely within your browser session, and we do not store or track your personal input data on our servers. (অবশ্যই, আপনার ডেটার নিরাপত্তা আমাদের কাছে সবচেয়ে গুরুত্বপূর্ণ। আপনার দেয়া ইনপুট সম্পূর্ণ সুরক্ষিত এবং আমরা সার্ভারে কোনো তথ্য সংরক্ষণ করি না।)"],
        ['Q' => "Can I use {$name_en} on my mobile phone?", 'A' => "Yes, the entire ILYBD tool suite is fully responsive and optimized for mobile devices. It works smoothly on Android, iOS, tablets, and PCs. (হ্যাঁ, আমাদের প্ল্যাটফর্মটি মোবাইল-ফ্রেন্ডলি। এটি অ্যান্ড্রয়েড, আইওএস, ট্যাবলেট এবং ডেস্কটপে খুব দ্রুত ও সুন্দরভাবে কাজ করে।)"],
        ['Q' => "How accurate is the result provided by {$name_en}?", 'A' => "Our algorithms are highly optimized and tested rigorously to ensure 100% accurate, error-free, and instant results every single time you use the tool. (আমাদের অ্যালগরিদমগুলো অত্যন্ত উন্নত, যা আপনাকে প্রতিবার ১০০% নির্ভুল এবং তাৎক্ষণিক ফলাফল দিতে সক্ষম।)"]
    ];

    $merged_faqs = array_merge($faqs, $base_faqs);
    // Unique the FAQs based on questions
    $final_faqs = [];
    $faq_keys = [];
    foreach ($merged_faqs as $fq) {
        $q_hash = md5($fq['Q']);
        if (!in_array($q_hash, $faq_keys)) {
            $final_faqs[] = $fq;
            $faq_keys[] = $q_hash;
        }
        if (count($final_faqs) >= 6) break; // Limit to 6
    }

    // Dynamic Seed based on tool slug so random selections are always consistent per tool
    srand(crc32($tool_slug));

    // Dynamic Paragraphs for Intro
    $intro_paras_bn = [
        "বর্তমান ডিজিটাল যুগে প্রতিটি কাজ দ্রুত এবং নিখুঁতভাবে সম্পন্ন করা অত্যন্ত জরুরি। <strong>{$name}</strong> বা <strong>{$name_en}</strong> হলো এমন একটি অত্যাধুনিক এবং নির্ভরযোগ্য অনলাইন টুল, যা আপনার দৈনন্দিন জীবনের জটিল কাজগুলোকে সেকেন্ডের মধ্যে সমাধান করে দিতে পারে। বিশেষ করে যারা প্রফেশনাল, ছাত্র-ছাত্রী বা ফ্রিল্যান্সার, তাদের জন্য এই টুলটি একটি অপরিহার্য ডিজিটাল সঙ্গী। ম্যানুয়াল কাজের ঝামেলা এড়িয়ে প্রযুক্তির সহায়তায় নিজের প্রোডাক্টিভিটি বাড়াতে এর জুড়ি মেলা ভার। {$desc} এটি একটি ফাস্ট এবং সুরক্ষিত ইউটিলিটি।",
        "প্রযুক্তির অবিশ্বাস্য উন্নতির সাথে সাথে আমাদের কাজের ধরনও বদলে যাচ্ছে। এখন আর ঘণ্টার পর ঘণ্টা ম্যানুয়াল হিসাব বা কাজ করার প্রয়োজন নেই। <strong>{$name_en}</strong> ({$name}) নিয়ে এসেছে একটি স্মার্ট সমাধান। এটি এমনভাবে ডেভেলপ করা হয়েছে যাতে আপনি কোনো পূর্ব-অভিজ্ঞতা ছাড়াই খুব সহজে ব্যবহার করতে পারেন। এই প্রিমিয়াম মানের টুলটি ব্যবহার করে আপনি আপনার মূল্যবান সময় বাঁচাতে পারবেন এবং কাজের গুণগত মান শতভাগ বজায় রাখতে পারবেন। {$desc} আমাদের প্ল্যাটফর্মটি মোবাইল এবং ডেস্কটপ উভয়ের জন্যই চমৎকারভাবে অপ্টিমাইজড।",
        "ইন্টারনেটের এই যুগে সঠিক সময়ে সঠিক সিদ্ধান্ত নেওয়া এবং কাজ দ্রুত করা সফলতার অন্যতম চাবিকাঠি। আপনার কাজকে আরো সহজ, গতিশীল এবং শতভাগ নির্ভুল করার জন্যই তৈরি করা হয়েছে <strong>{$name}</strong>। এটি একটি ইউজার-ফ্রেন্ডলি, ক্লাউড-বেজড সলিউশন, যা যেকোনো স্মার্টফোন বা কম্পিউটার থেকে মুহূর্তেই অ্যাক্সেস করা সম্ভব। {$desc} এটি আপনার কাজের চাপ কমিয়ে আপনাকে দেবে এক নির্ভার অভিজ্ঞতা। সবচেয়ে বড় কথা, এটি ব্যবহার করার জন্য আপনাকে কোনো টাকা খরচ করতে হবে না।"
    ];

    $intro_paras_en = [
        "In today's fast-paced digital ecosystem, completing tasks with speed and absolute precision is highly essential. The <strong>{$name_en}</strong> is an advanced, highly reliable online utility designed to solve your complex daily workflows in a matter of seconds. Whether you are a professional, a student, or a freelancer, this tool acts as an indispensable digital companion. By eliminating the hassle of manual labor, it significantly boosts your overall productivity. {$desc_en} It is a fast, safe, and robust utility.",
        "As technology continues to evolve at an unprecedented rate, the way we manage our tasks is rapidly transforming. There is no longer a need to spend hours on manual calculations or repetitive processes. <strong>{$name_en}</strong> brings a smart, automated solution to your fingertips. Developed with user experience in mind, anyone can utilize this tool without prior technical expertise. Leverage this premium-grade utility to save your valuable time while maintaining 100% output quality. {$desc_en} Our platform is brilliantly optimized for both mobile and desktop devices.",
        "In the modern era of the internet, making swift decisions and executing tasks rapidly is the key to success. To make your workflow easier, dynamic, and error-free, we have introduced the <strong>{$name_en}</strong>. It is a highly user-friendly, cloud-based solution that can be accessed instantly from any smartphone or computer. {$desc_en} This tool is engineered to reduce your workload and provide a seamless, stress-free digital experience. Best of all, it is entirely free to use."
    ];

    // Dynamic Paragraphs for Why Use
    $why_use_paras_bn = [
        "এই টুলটি ব্যবহার করার সবচেয়ে বড় কারণ হলো এর অতুলনীয় কার্যকারিতা এবং নির্ভরযোগ্যতা। আপনি যখন ম্যানুয়ালি কোনো কাজ করতে যান, তখন মানুষের স্বাভাবিক ভুলের (Human error) সম্ভাবনা থেকেই যায়। কিন্তু <strong>{$name}</strong> ব্যবহার করলে সেই ভুলের মাত্রা শূন্যে নেমে আসে। এর পাশাপাশি, এটি সম্পূর্ণ ফ্রি এবং কোনো ধরনের অ্যাকাউন্ট রেজিস্ট্রেশন বা লগইন ছাড়াই আনলিমিটেড ব্যবহার করা যায়। আপনার ডেটার গোপনীয়তা রক্ষায় আমরা বদ্ধপরিকর। এটি আপনার দৈনন্দিন জীবনের সময় সাশ্রয়ে একটি বড় অবদান রাখে।",
        "স্মার্ট যুগে ম্যানুয়াল কাজ পরিহার করে স্মার্ট ও ডিজিটাল টুল ব্যবহার করার কোনো বিকল্প নেই। এটি আপনার কাজের স্পিড কয়েক গুণ বাড়াতে দারুন ভূমিকা রাখে। বিশেষ করে যারা কর্পোরেট প্রফেশনাল, ডেভেলপার বা ক্রিয়েটিভ সেক্টরে কাজ করেন, তাদের জন্য এই টুলটি একটি মাস্ট-হ্যাভ (Must-have)। এটি সম্পূর্ণ সুরক্ষিত, নির্ভরযোগ্য এবং যেকোনো ব্রাউজারে সাপোর্ট করে। এর সাহায্যে আপনি আপনার কাজগুলোকে খুব দ্রুত এবং কোনো রকম ভুল ছাড়াই সম্পন্ন করতে পারবেন।"
    ];

    $why_use_paras_en = [
        "The primary reason to use this tool lies in its outstanding efficiency and unwavering reliability. Manual operations are always prone to human error, but by utilizing the <strong>{$name_en}</strong>, the margin of error drops to absolute zero. Furthermore, it is completely free to use and requires no annoying registrations, sign-ups, or subscriptions. We are deeply committed to protecting your data privacy and ensuring a secure environment. It makes a significant contribution to saving time in your daily life.",
        "In this smart digital age, skipping manual labor in favor of intelligent online tools is highly recommended. It plays a fantastic role in accelerating your working speed exponentially. Especially for corporate professionals, developers, and creative individuals, this utility is an absolute must-have. It is completely secure, highly reliable, and universally supported across all modern web browsers. With its assistance, you can achieve your objectives incredibly fast and complete complex tasks without a single hitch."
    ];

    // Ensure we have some default features and benefits if none provided
    if (empty($features)) {
        $features = [
            "Lightning Fast Processing Speed (সুপার ফাস্ট প্রসেসিং স্পিড)",
            "Clean & Intuitive User Interface (সহজ ইউজার ইন্টারফেস)",
            "100% Accurate & Reliable Results (নির্ভুল ও নির্ভরযোগ্য ফলাফল)",
            "High-end Security and Privacy (নিরাপদ ও সুরক্ষিত)",
            "Cross-Platform Compatibility (যেকোনো ডিভাইসে সাপোর্ট করে)"
        ];
    }

    $feature_elaborations_bn = [
        "এটি টুলটির সবচেয়ে আকর্ষণীয় দিক, যা ব্যবহারকারীদের কাজের অভিজ্ঞতাকে আরও মসৃণ ও আনন্দদায়ক করে তোলে। আপনি খুব সহজেই আপনার কাঙ্ক্ষিত ফলাফল পেতে পারেন।",
        "এই ফিচারের মাধ্যমে আপনার কাজের মান যেমন বাড়বে, তেমনি সময়ও বাঁচবে উল্লেখযোগ্য হারে। প্রফেশনালদের জন্য এটি একটি সত্যিকারের গেম-চেঞ্জার।",
        "যারা নিখুঁত এবং নির্ভুল কাজ করতে চান, তাদের জন্য এই বৈশিষ্ট্যটি অত্যন্ত সহায়ক ভূমিকা পালন করে। এটি আমাদের সিস্টেমের একটি কোর বা মূল অংশ।",
        "ডিজিটাল নিরাপত্তার কথা মাথায় রেখে এই ফিচারটি যুক্ত করা হয়েছে, যা আপনার ব্রাউজিং অভিজ্ঞতাকে করে তুলবে সম্পূর্ণ ঝুঁকিহীন ও সুরক্ষিত।"
    ];
    $feature_elaborations_en = [
        "This is the most attractive aspect of the tool, ensuring the user experience remains extremely smooth and enjoyable. You can obtain your desired results effortlessly.",
        "Through this feature, not only will the quality of your work improve, but you will also save a significant amount of time. It acts as a true game-changer for professionals.",
        "For those who demand perfection and accuracy, this specific feature plays a highly supportive role. It is considered a core component of our robust system.",
        "Keeping digital security in mind, this feature has been meticulously integrated, ensuring your entire browsing experience remains completely risk-free and protected."
    ];

    // Select random elements
    $selected_intro_bn = $intro_paras_bn[array_rand($intro_paras_bn)];
    $selected_intro_en = $intro_paras_en[array_rand($intro_paras_en)];
    
    $selected_why_bn = $why_use_paras_bn[array_rand($why_use_paras_bn)];
    $selected_why_en = $why_use_paras_en[array_rand($why_use_paras_en)];

    // Generate output HTML string
    $out = '<article class="ilybd-dynamic-seo-content p-4 md:p-8 mt-10 rounded-2xl bg-[#0a0f1a]/80 border border-white/5 shadow-2xl space-y-10">';

    // 1. H1 Title and Introduction
    $out .= '
        <section class="seo-section">
            <h1 class="text-3xl md:text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500 mb-6 pb-4 border-b border-white/10 bangla-font-siliguri tracking-tight">
                ' . $name . ' (' . $name_en . ') - Ultimate Guide & Tool
            </h1>
            <div class="prose prose-invert max-w-none text-gray-300 text-base md:text-lg leading-relaxed space-y-6">
                <p class="bangla-font-siliguri text-justify">' . $selected_intro_bn . '</p>
                <p class="font-sans text-justify text-gray-400">' . $selected_intro_en . '</p>
            </div>
        </section>
    ';

    // 2. H2: Why use the tool?
    $out .= '
        <section class="seo-section">
            <h2 class="text-2xl font-bold text-pink-500 mb-6 flex items-center gap-3 bangla-font-siliguri">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>
                কেন ' . $name . ' ব্যবহার করবেন? (Why use ' . $name_en . '?)
            </h2>
            <div class="prose prose-invert max-w-none text-gray-300 text-base md:text-lg leading-relaxed space-y-6">
                <p class="bangla-font-siliguri text-justify">' . $selected_why_bn . '</p>
                <p class="font-sans text-justify text-gray-400">' . $selected_why_en . '</p>
            </div>
        </section>
    ';

    // 3. H3: Steps (Step-by-Step)
    $out .= '
        <section class="seo-section bg-white/5 p-6 rounded-xl border border-white/10">
            <h3 class="text-xl font-bold text-emerald-400 mb-6 bangla-font-siliguri">
                ব্যবহারের নিয়ম (Step-by-Step Guide for ' . $name_en . ')
            </h3>
            <div class="space-y-6">
                <p class="text-gray-300 bangla-font-siliguri text-justify leading-relaxed">
                    এই টুলটি ডিজাইন করা হয়েছে সাধারণ ব্যবহারকারীদের কথা মাথায় রেখে। কোনো প্রযুক্তিগত জ্ঞান ছাড়াই মাত্র কয়েকটি ক্লিকের মাধ্যমে আপনি আপনার কাজ সম্পন্ন করতে পারবেন। (This tool is designed with everyday users in mind. Without any technical knowledge, you can accomplish your task in just a few clicks.)
                </p>
                <ul class="space-y-4">
                    <li class="flex gap-4">
                        <span class="flex-shrink-0 w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">1</span>
                        <div>
                            <p class="text-gray-200 bangla-font-siliguri font-medium text-lg">প্রয়োজনীয় ডেটা ইনপুট দিন (Enter your required data)</p>
                            <p class="text-gray-400 text-sm mt-1 bangla-font-siliguri">প্রদত্ত টেক্সট বক্স বা ফর্ম ফিল্ডে আপনার প্রয়োজনীয় তথ্য সাবধানে ইনপুট করুন। (Carefully input your required information into the provided text box or form field.)</p>
                        </div>
                    </li>
                    <li class="flex gap-4">
                        <span class="flex-shrink-0 w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">2</span>
                        <div>
                            <p class="text-gray-200 bangla-font-siliguri font-medium text-lg">অ্যাকশন বাটনে ক্লিক করুন (Click the Action Button)</p>
                            <p class="text-gray-400 text-sm mt-1 bangla-font-siliguri">প্যারামিটার সেট করার পর নিচে থাকা প্রধান বাটনে ক্লিক করুন। (After setting the parameters, click on the main primary action button below.)</p>
                        </div>
                    </li>
                    <li class="flex gap-4">
                        <span class="flex-shrink-0 w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">3</span>
                        <div>
                            <p class="text-gray-200 bangla-font-siliguri font-medium text-lg">ফলাফল কপি বা সংরক্ষণ করুন (Copy or Save the Result)</p>
                            <p class="text-gray-400 text-sm mt-1 bangla-font-siliguri">মাত্র কয়েক মিলি-সেকেন্ডের মধ্যে জেনারেট হওয়া নির্ভুল ফলাফলটি কপি করে আপনার কাজে ব্যবহার করুন। (Instantly copy the generated accurate result within milliseconds and use it in your workflow.)</p>
                        </div>
                    </li>
                </ul>
            </div>
        </section>
    ';

    // 4. H2: Core Features
    $out .= '
        <section class="seo-section">
            <h2 class="text-2xl font-bold text-blue-400 mb-6 flex items-center gap-3 bangla-font-siliguri">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                মূল ফিচারসমূহ (Core Features & Advantages)
            </h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">';
    
    foreach ($features as $idx => $feat) {
        $elab_bn = $feature_elaborations_bn[$idx % count($feature_elaborations_bn)];
        $elab_en = $feature_elaborations_en[$idx % count($feature_elaborations_en)];
        $out .= '
                <div class="bg-gradient-to-br from-white/5 to-transparent p-5 rounded-xl border border-white/5 hover:border-blue-500/30 transition-colors">
                    <h3 class="text-lg font-bold text-gray-100 mb-2 bangla-font-siliguri">✦ ' . esc_html($feat) . '</h3>
                    <p class="text-gray-400 text-sm leading-relaxed bangla-font-siliguri mb-3">' . $elab_bn . '</p>
                    <p class="text-gray-500 text-xs leading-relaxed font-sans italic">" ' . $elab_en . ' "</p>
                </div>';
    }

    $out .= '
            </div>
        </section>
    ';

    // 5. H2: FAQ
    $out .= '
        <section class="seo-section border-t border-white/10 pt-8 mt-8">
            <h2 class="text-2xl font-bold text-white mb-8 flex items-center gap-3 bangla-font-siliguri">
                <svg class="w-6 h-6 text-yellow-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                সচরাচর জিজ্ঞাসিত প্রশ্নাবলী (Frequently Asked Questions)
            </h2>
            <div class="space-y-4">';
    
    foreach ($final_faqs as $fq) {
        $out .= '
                <details class="group bg-white/5 rounded-xl border border-white/10 [&_summary::-webkit-details-marker]:hidden">
                    <summary class="flex items-center justify-between p-5 cursor-pointer">
                        <h3 class="font-bold text-gray-200 bangla-font-siliguri text-lg pr-4">' . esc_html($fq['Q']) . '</h3>
                        <span class="transition duration-300 group-open:-rotate-180 text-cyan-400">
                            <svg fill="none" height="24" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" width="24"><polyline points="6 9 12 15 18 9"></polyline></svg>
                        </span>
                    </summary>
                    <div class="p-5 pt-0 text-gray-400 leading-relaxed bangla-font-siliguri text-base border-t border-white/5 mt-2">
                        ' . esc_html($fq['A']) . '
                    </div>
                </details>';
    }

    $out .= '
            </div>
        </section>
    ';

    // Inject Google Search Console Compatible FAQPage Schema (JSON-LD)
    if (!empty($final_faqs)) {
        $faq_schema = [
            '@context' => 'https://schema.org',
            '@type' => 'FAQPage',
            'mainEntity' => []
        ];
        foreach ($final_faqs as $fq) {
            $faq_schema['mainEntity'][] = [
                '@type' => 'Question',
                'name' => $fq['Q'],
                'acceptedAnswer' => [
                    '@type' => 'Answer',
                    'text' => $fq['A']
                ]
            ];
        }
        $out .= "\n<script type=\"application/ld+json\">\n" . json_encode($faq_schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) . "\n</script>\n";
    }

    $out .= '</article>';

    return $out;
}

/**
 * Get unique custom topic-matched high-resolution banner image for each tool
 */
if (!function_exists('ilybd_get_tool_featured_image')) {
function ilybd_get_tool_featured_image($tool_slug, $tool = null) {
    if (!$tool && function_exists('ilybd_get_all_tools')) {
        $all_tools = ilybd_get_all_tools();
        $tool = $all_tools[$tool_slug] ?? null;
    }
    
    $name_en = $tool['name'] ?? str_replace('-', ' ', $tool_slug);
    
    // Custom topic-matched prompts for Pollinations AI
    $prompts = [
        'ai-blog-title-generator' => 'futuristic cyberpunk dashboard interface for ai blog title generator, glowing neon cyan and blue holographic text lines, ultra detailed, 8k resolution, web application banner',
        'ai-blog-outline-generator' => 'glowing holographic article outline flowchart diagram, cyber neon green and slate workspace, 8k resolution web application banner',
        'ai-meta-description-generator' => 'google search engine results page SERP meta tag generator interface, glowing neon cyan and dark slate, 8k resolution web header',
        'ai-faq-generator' => 'glowing holographic FAQ question mark nodes with neon purple and cyan connectors, cyber digital workspace UI, 8k resolution',
        'ai-keyword-idea-generator' => 'glowing matrix nodes of keyword search intent cloud network, neon orange and gold cyber dashboard, 8k resolution',
        'ai-youtube-title-generator' => 'futuristic youtube creator studio neon red and dark slate dashboard with glowing viral title metrics, 8k resolution',
        'ai-youtube-description-generator' => 'futuristic video editing and description generator workstation with glowing timestamps, neon magenta and violet, 8k resolution',
        'ai-hashtag-generator' => 'glowing 3d viral hashtags network in deep dark cyber space with neon pink and electric blue accents, 8k resolution',
        'ai-email-writer' => 'futuristic AI email drafting application interface with glowing holographic envelope and text lines, 8k resolution',
        'ai-prompt-generator' => 'glowing neural prompt engineering terminal interface with glowing code lines and holographic ai matrix, 8k resolution',
        'keyword-density-checker' => 'glowing analytics frequency gauge graph for keyword density checking, neon green and cyber slate, 8k resolution',
        'meta-tag-generator' => 'glowing html meta tags code editor terminal with neon brackets and cyan accents, dark cyber theme, 8k resolution',
        'robots-txt-generator' => 'glowing cyber security robot shield guarding search crawler indexing paths, neon green matrix, 8k resolution',
        'xml-sitemap-generator' => 'glowing holographic sitemap node tree diagram with cyber blue connections, 8k resolution',
        'schema-generator' => 'glowing structured json-ld schema markup flowchart with neon yellow and cyan nodes, 8k resolution',
        'canonical-tag-generator' => 'glowing canonical link redirect shield with neon teal and blue cyber lines, 8k resolution',
        'open-graph-generator' => 'glowing social media open graph preview cards in dark cyber space, neon pink and blue, 8k resolution',
        'serp-preview-tool' => 'glowing google search engine desktop and mobile serp live preview interface, 8k resolution',
        'internal-link-suggestion-tool' => 'glowing hyper-connected internal web page link network graph, neon purple and green, 8k resolution',
        'keyword-clustering-tool' => 'glowing 3d keyword cluster constellation map with neon intent categories, 8k resolution',
        'image-compressor' => 'glowing digital file compression gauge with file size percentage saving meter, neon cyan and magenta, 8k resolution',
        'image-resizer' => 'glowing canvas dimension controls with pixel width and height indicators, neon blue and orange, 8k resolution',
        'image-cropper' => 'glowing cropping boundary grid with neon handles over futuristic graphics, 8k resolution',
        'jpg-to-png-converter' => 'glowing format conversion arrow between JPG and PNG image file icons, neon violet and blue, 8k resolution',
        'png-to-jpg-converter' => 'glowing transparent PNG to flat JPG image conversion interface, neon emerald, 8k resolution',
        'image-to-webp-converter' => 'glowing Google WebP next-gen image format lightning fast conversion banner, neon green, 8k resolution',
        'dns-lookup-tool' => 'glowing global cloudflare dns server lookup records matrix with neon blue nodes, 8k resolution',
        'ai-maya-cloud-assistant' => 'futuristic glowing holographic ai assistant maya with cyan neon aura and dark cyber slate background, 8k resolution',
        'neon-qr-code-maker' => 'glowing 3d neon qr code cube floating in dark cyber space, neon magenta and blue, 8k resolution',
        'seo-metadata-css-glow-factory' => 'glowing neon css glow generator interface with vibrant neon blue green pink glows, 8k resolution',
        'neon-music-synthesizer' => 'futuristic 2040 retro music synthesizer audio waveform interface with glowing neon keys, 8k resolution',
        'cyber-talking-pet-cat' => 'cybernetic futuristic robotic cat with glowing neon eyes and 3d audio visualizer waves, 8k resolution',
        'qa-forum-cash-gateway' => 'futuristic digital community q and a forum dashboard with glowing reward cash points, 8k resolution',
        'background-remover' => 'glowing ai background removal threshold interface showing transparent checkerboard grid, 8k resolution',
        'qr-code-generator' => 'glowing vector qr code generator with neon cyan border and dark slate background, 8k resolution',
        'barcode-generator' => 'glowing barcode scanner line over barcode graphics, neon green and dark slate, 8k resolution',
        'favicon-generator' => 'glowing multi resolution browser tab favicon icons in dark cyber space, 8k resolution',
        'json-formatter' => 'glowing json code beautifier editor with color coded syntax highlighting and indent lines, 8k resolution',
        'json-validator' => 'glowing json syntax validator terminal with green checkmarks and red error highlights, 8k resolution',
        'html-minifier' => 'glowing html source code minification compression engine with glowing line counters, 8k resolution',
        'css-minifier' => 'glowing css stylesheet minifier compression dashboard with neon violet accents, 8k resolution',
        'base64-encoder-decoder' => 'glowing binary base64 encoding encryption matrix terminal with cyan text, 8k resolution'
    ];

    $prompt = $prompts[$tool_slug] ?? ("futuristic cyber UI dashboard header for " . $name_en . ", glowing neon accents, 8k resolution, web application banner");
    $seed = abs(crc32($tool_slug));
    
    return 'https://image.pollinations.ai/prompt/' . rawurlencode($prompt) . '?width=1200&height=630&seed=' . $seed . '&nologo=true';
}
}
?>
