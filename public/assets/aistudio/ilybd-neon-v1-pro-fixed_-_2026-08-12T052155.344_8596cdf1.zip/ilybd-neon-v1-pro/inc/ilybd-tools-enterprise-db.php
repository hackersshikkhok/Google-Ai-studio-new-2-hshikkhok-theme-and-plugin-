<?php
if (!defined('ABSPATH')) exit;

function ilybd_get_enterprise_tools() {
    return [
        'ai-article-writer-pro' => [
            'name' => 'AI Article Writer Pro',
            'name_bn' => 'এআই আর্টিকেল রাইটার প্রো',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Generate SEO-optimized, 2000+ words articles with human-like tone, NLP keywords, and subheadings automatically.',
            'desc_bn' => 'এসইও অপ্টিমাইজড এবং হিউম্যান-লাইক ২০০০+ শব্দের বাংলা/ইংরেজি আর্টিকেল লিখুন এক ক্লিকে।',
            'features' => ['NLP কিওয়ার্ড ইন্টিগ্রেশন', 'হিউম্যান টোন অপশন', 'লং-ফর্ম কন্টেন্ট জেনারেশন'],
            'benefits' => ['গুগলে দ্রুত র‍্যাংকিং', 'রাইটিং খরচ ১০০% সাশ্রয়', 'কপিরাইট ফ্রি কন্টেন্ট'],
            'faqs' => [['Q' => 'কন্টেন্ট কি ইউনিক হবে?', 'A' => 'হ্যাঁ, ১০০% প্লাগারিজম ফ্রি এবং ইউনিক।']]
        ],
        'ai-youtube-script-writer' => [
            'name' => 'AI YouTube Script Writer',
            'name_bn' => 'ইউটিউব স্ক্রিপ্ট রাইটার',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Create engaging, highly-retentive YouTube video scripts with hook, intro, body, and CTA.',
            'desc_bn' => 'ইউটিউব ভিডিওর জন্য আকর্ষণীয় হুক, বডি এবং কল-টু-অ্যাকশন সহ ভাইরাল স্ক্রিপ্ট তৈরি করুন।',
            'features' => ['ভাইরাল হুক জেনারেটর', 'টাইমস্ট্যাম্প মেকার', 'কল টু অ্যাকশন (CTA)'],
            'benefits' => ['অডিয়েন্স রিটেনশন বৃদ্ধি', 'ওয়াচটাইম বাড়ানো', 'দ্রুত মনিটাইজেশন'],
            'faqs' => [['Q' => 'বাংলা স্ক্রিপ্ট লেখা যাবে?', 'A' => 'হ্যাঁ, সম্পূর্ণ বাংলায় স্ক্রিপ্ট জেনারেট করা সম্ভব।']]
        ],
        'ai-meta-tag-generator' => [
            'name' => 'AI Meta Tag Generator',
            'name_bn' => 'এআই মেটা ট্যাগ জেনারেটর',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Generate high-CTR SEO title and meta descriptions based on current Google algorithms.',
            'desc_bn' => 'গুগল সার্চে বেশি ক্লিক (CTR) পাওয়ার জন্য অপ্টিমাইজড মেটা টাইটেল ও ডেসক্রিপশন তৈরি করুন।',
            'features' => ['CTR অপ্টিমাইজড', 'গুগল পিক্সেল লিমিট চেক', 'লোকাল এসইও ফোকাস'],
            'benefits' => ['সার্চ ইঞ্জিন ভিজিবিলিটি বৃদ্ধি', 'অর্গানিক ট্রাফিক লাভ'],
            'faqs' => []
        ],
        'ai-code-reviewer' => [
            'name' => 'AI Code Reviewer',
            'name_bn' => 'এআই কোড রিভিউয়ার',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Analyze your PHP, JS, or Python code for bugs, security vulnerabilities, and performance issues.',
            'desc_bn' => 'আপনার কোডের ভুল, বাগ এবং সিকিউরিটি সমস্যাগুলো এআই দিয়ে অটোমেটিক ফিক্স করুন।',
            'features' => ['বাগ ডিটেকশন', 'সিকিউরিটি অডিট', 'পারফরম্যান্স অপ্টিমাইজেশন'],
            'benefits' => ['ক্লিন কোড', 'ডেভেলপমেন্ট সময় সাশ্রয়'],
            'faqs' => []
        ],
        'ai-schema-generator' => [
            'name' => 'AI Schema Markup Generator',
            'name_bn' => 'স্কিমা মার্কআপ মেকার',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Generate JSON-LD schema markup (FAQ, Article, Recipe) for rich snippets in Google.',
            'desc_bn' => 'গুগলে রিচ স্নিপেট পাওয়ার জন্য নিখুঁত JSON-LD স্কিমা মার্কআপ কোড তৈরি করুন।',
            'features' => ['FAQ স্কিমা', 'আর্টিকেল স্কিমা', 'অটো ভ্যালিডেশন'],
            'benefits' => ['গুগল রিচ রেজাল্ট', 'সার্চে বেশি জায়গা দখল'],
            'faqs' => []
        ],
        'ai-social-media-post' => [
            'name' => 'AI Social Media Post Generator',
            'name_bn' => 'সোশ্যাল মিডিয়া পোস্ট মেকার',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Generate viral posts for Facebook, Instagram, LinkedIn, and Twitter with perfect hashtags.',
            'desc_bn' => 'ফেসবুক, টুইটার, লিংকডইন এর জন্য ভাইরাল ক্যাপশন ও পারফেক্ট হ্যাশট্যাগ তৈরি করুন।',
            'features' => ['প্লাটফর্ম স্পেসিফিক টোন', 'হ্যাশট্যাগ রিকমেন্ডেশন', 'ইমোজি অপ্টিমাইজেশন'],
            'benefits' => ['সোশ্যাল এনগেজমেন্ট বৃদ্ধি', 'ব্র্যান্ডিং ডেভেলপমেন্ট'],
            'faqs' => []
        ],
        'ai-image-prompt-generator' => [
            'name' => 'AI Image Prompt Generator',
            'name_bn' => 'এআই ইমেজ প্রম্পট মেকার',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Create ultra-detailed prompts for Midjourney, DALL-E, and Stable Diffusion.',
            'desc_bn' => 'মিডজার্নি বা ডাল-ই এর জন্য নিখুঁত এআই ইমেজ জেনারেট করার প্রম্পট তৈরি করুন।',
            'features' => ['হাই-রেজল্যুশন কীওয়ার্ডস', 'আর্ট স্টাইল সিলেকশন', 'ক্যামেরা অ্যাঙ্গেল ডিটেইলস'],
            'benefits' => ['পেশাদার ইমেজ জেনারেশন', 'এআই আর্ট শেখার সুবিধা'],
            'faqs' => []
        ],
        'ai-business-name-generator' => [
            'name' => 'AI Business Name Generator',
            'name_bn' => 'বিজনেস নেম জেনারেটর',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Discover catchy, brandable business names and check domain availability instantly.',
            'desc_bn' => 'নতুন ব্যবসার জন্য আকর্ষণীয় নাম এবং এভেইলেবল ডোমেইন আইডিয়া খুঁজে বের করুন।',
            'features' => ['ইউনিক ব্র্যান্ড নেম', 'ডোমেইন সার্চ', 'ইন্ডাস্ট্রি স্পেসিফিক নেমিং'],
            'benefits' => ['ব্র্যান্ড আইডেন্টিটি তৈরি', 'সহজে মনে রাখার মত নাম নির্বাচন'],
            'faqs' => []
        ],
        'ai-plagiarism-rewriter' => [
            'name' => 'AI Plagiarism Rewriter',
            'name_bn' => 'প্লাগারিজম রিমুভার ও রিরাইটার',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Rewrite any article to pass AI detection and plagiarism checks with 100% uniqueness.',
            'desc_bn' => 'যেকোনো কপি করা লেখাকে এআই দিয়ে নতুন করে লিখুন এবং প্লাগারিজম বা কপিরাইট এড়ান।',
            'features' => ['হিউম্যান-লাইক রিরাইটিং', 'গ্রামার চেকার', 'এআই ডিটেকশন বাইপাস'],
            'benefits' => ['গুগল পেনাল্টি থেকে রক্ষা', 'ইউনিক কন্টেন্ট জেনারেশন'],
            'faqs' => []
        ],
        'ai-product-description' => [
            'name' => 'AI Product Description Writer',
            'name_bn' => 'প্রোডাক্ট ডেসক্রিপশন রাইটার',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Create compelling eCommerce product descriptions that drive sales and boost conversions.',
            'desc_bn' => 'ই-কমার্স ওয়েবসাইটের প্রোডাক্ট বিক্রয় বাড়ানোর জন্য আকর্ষণীয় বর্ণনা তৈরি করুন।',
            'features' => ['কনভার্শন ফোকাসড', 'এসইও ফ্রেন্ডলি', 'ফিচার ও বেনিফিট হাইলাইট'],
            'benefits' => ['বিক্রয় বৃদ্ধি', 'কাস্টমার ট্রাস্ট অর্জন'],
            'faqs' => []
        ]
        ,
'ai-grammar-checker' => [
            'name' => 'AI Grammar & Spell Checker',
            'name_bn' => 'এআই গ্রামার চেকার',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Check grammar and spelling instantly.',
            'desc_bn' => 'এআই গ্রামার চেকার টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-text-summarizer' => [
            'name' => 'AI Text Summarizer',
            'name_bn' => 'টেক্সট সামারাইজার',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Summarize long articles into short points.',
            'desc_bn' => 'টেক্সট সামারাইজার টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-paragraph-writer' => [
            'name' => 'AI Paragraph Writer',
            'name_bn' => 'প্যারাগ্রাফ রাইটার',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Write unique paragraphs on any topic.',
            'desc_bn' => 'প্যারাগ্রাফ রাইটার টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-essay-writer' => [
            'name' => 'AI Essay Writer',
            'name_bn' => 'এসে রাইটার (প্রবন্ধ)',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Generate well-structured essays.',
            'desc_bn' => 'এসে রাইটার (প্রবন্ধ) টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-youtube-tags' => [
            'name' => 'YouTube Tag Generator',
            'name_bn' => 'ইউটিউব ট্যাগ মেকার',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Get trending tags for YouTube videos.',
            'desc_bn' => 'ইউটিউব ট্যাগ মেকার টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-youtube-title' => [
            'name' => 'YouTube Title Generator',
            'name_bn' => 'ইউটিউব টাইটেল মেকার',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Generate catchy YouTube video titles.',
            'desc_bn' => 'ইউটিউব টাইটেল মেকার টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-youtube-desc' => [
            'name' => 'YouTube Description Writer',
            'name_bn' => 'ইউটিউব ডেসক্রিপশন',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Write SEO optimized YouTube descriptions.',
            'desc_bn' => 'ইউটিউব ডেসক্রিপশন টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-instagram-caption' => [
            'name' => 'Instagram Caption Generator',
            'name_bn' => 'ইন্সটাগ্রাম ক্যাপশন',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Generate engaging Instagram captions.',
            'desc_bn' => 'ইন্সটাগ্রাম ক্যাপশন টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-tiktok-script' => [
            'name' => 'TikTok Script Writer',
            'name_bn' => 'টিকটক স্ক্রিপ্ট',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Create viral TikTok video scripts.',
            'desc_bn' => 'টিকটক স্ক্রিপ্ট টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-email-writer' => [
            'name' => 'AI Email Writer',
            'name_bn' => 'এআই ইমেইল রাইটার',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Write professional emails in seconds.',
            'desc_bn' => 'এআই ইমেইল রাইটার টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-cover-letter' => [
            'name' => 'AI Cover Letter Maker',
            'name_bn' => 'কভার লেটার মেকার',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Generate job-winning cover letters.',
            'desc_bn' => 'কভার লেটার মেকার টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-resume-builder' => [
            'name' => 'AI Resume Summary',
            'name_bn' => 'রেজুমে সামারি রাইটার',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Create a strong summary for your resume.',
            'desc_bn' => 'রেজুমে সামারি রাইটার টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-blog-ideas' => [
            'name' => 'AI Blog Idea Generator',
            'name_bn' => 'ব্লগ আইডিয়া জেনারেটর',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Get creative ideas for your next blog post.',
            'desc_bn' => 'ব্লগ আইডিয়া জেনারেটর টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-blog-outline' => [
            'name' => 'AI Blog Outline Generator',
            'name_bn' => 'ব্লগ আউটলাইন',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Structure your blog post perfectly.',
            'desc_bn' => 'ব্লগ আউটলাইন টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-domain-name' => [
            'name' => 'AI Domain Name Finder',
            'name_bn' => 'ডোমেইন নেম ফাইন্ডার',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Find available domain names for your startup.',
            'desc_bn' => 'ডোমেইন নেম ফাইন্ডার টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-slogan-maker' => [
            'name' => 'AI Slogan Generator',
            'name_bn' => 'স্লোগান মেকার',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Create catchy slogans for your brand.',
            'desc_bn' => 'স্লোগান মেকার টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-seo-keywords' => [
            'name' => 'AI SEO Keyword Planner',
            'name_bn' => 'এসইও কি-ওয়ার্ড প্ল্যানার',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Find high volume, low competition keywords.',
            'desc_bn' => 'এসইও কি-ওয়ার্ড প্ল্যানার টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-backlink-checker' => [
            'name' => 'AI Backlink Analyzer',
            'name_bn' => 'ব্যাকলিংক অ্যানালাইজার',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Analyze backlinks for any domain.',
            'desc_bn' => 'ব্যাকলিংক অ্যানালাইজার টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-story-generator' => [
            'name' => 'AI Story Generator',
            'name_bn' => 'স্টোরি জেনারেটর',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Generate creative stories for kids or adults.',
            'desc_bn' => 'স্টোরি জেনারেটর টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-poem-writer' => [
            'name' => 'AI Poem Writer',
            'name_bn' => 'কবিতা রাইটার',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Write beautiful poems on any theme.',
            'desc_bn' => 'কবিতা রাইটার টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-code-converter' => [
            'name' => 'AI Code Converter',
            'name_bn' => 'কোড কনভার্টার',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Convert code from one language to another.',
            'desc_bn' => 'কোড কনভার্টার টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-sql-query' => [
            'name' => 'AI SQL Query Builder',
            'name_bn' => 'এসকিউএল কোয়েরি বিল্ডার',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Generate complex SQL queries easily.',
            'desc_bn' => 'এসকিউএল কোয়েরি বিল্ডার টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-regex-generator' => [
            'name' => 'AI Regex Generator',
            'name_bn' => 'রেজেক্স জেনারেটর',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Create regular expressions automatically.',
            'desc_bn' => 'রেজেক্স জেনারেটর টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-css-animator' => [
            'name' => 'AI CSS Animation',
            'name_bn' => 'সিএসএস অ্যানিমেশন',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Generate CSS animations.',
            'desc_bn' => 'সিএসএস অ্যানিমেশন টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-color-palette' => [
            'name' => 'AI Color Palette Generator',
            'name_bn' => 'কালার প্যালেট মেকার',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Generate beautiful color schemes.',
            'desc_bn' => 'কালার প্যালেট মেকার টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-password-gen' => [
            'name' => 'AI Secure Password',
            'name_bn' => 'পাসওয়ার্ড জেনারেটর',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Generate unbreakable passwords.',
            'desc_bn' => 'পাসওয়ার্ড জেনারেটর টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-fake-data' => [
            'name' => 'AI Fake Data Generator',
            'name_bn' => 'ফেক ডাটা জেনারেটর',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Generate test data for developers.',
            'desc_bn' => 'ফেক ডাটা জেনারেটর টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-json-formatter' => [
            'name' => 'AI JSON Formatter',
            'name_bn' => 'জেসন ফরম্যাটার',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Format and validate JSON data.',
            'desc_bn' => 'জেসন ফরম্যাটার টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-cron-parser' => [
            'name' => 'AI Cron Job Parser',
            'name_bn' => 'ক্রন জব পার্সার',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Understand and generate cron schedules.',
            'desc_bn' => 'ক্রন জব পার্সার টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-hash-generator' => [
            'name' => 'AI Hash Generator',
            'name_bn' => 'হ্যাশ জেনারেটর',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Generate MD5, SHA-1, SHA-256 hashes.',
            'desc_bn' => 'হ্যাশ জেনারেটর টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-qr-code' => [
            'name' => 'AI QR Code Generator',
            'name_bn' => 'কিউআর কোড জেনারেটর',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Generate high-quality QR codes.',
            'desc_bn' => 'কিউআর কোড জেনারেটর টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-pdf-merger' => [
            'name' => 'AI PDF Merger',
            'name_bn' => 'পিডিএফ মার্জার',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Merge multiple PDF files into one.',
            'desc_bn' => 'পিডিএফ মার্জার টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-image-compressor' => [
            'name' => 'AI Image Compressor',
            'name_bn' => 'ইমেজ কম্প্রেসার',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Compress images without losing quality.',
            'desc_bn' => 'ইমেজ কম্প্রেসার টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-bg-remover' => [
            'name' => 'AI Background Remover',
            'name_bn' => 'ব্যাকগ্রাউন্ড রিমুভার',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Remove background from any image.',
            'desc_bn' => 'ব্যাকগ্রাউন্ড রিমুভার টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-video-compressor' => [
            'name' => 'AI Video Compressor',
            'name_bn' => 'ভিডিও কম্প্রেসার',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Compress video files easily.',
            'desc_bn' => 'ভিডিও কম্প্রেসার টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-audio-extractor' => [
            'name' => 'AI Audio Extractor',
            'name_bn' => 'অডিও এক্সট্রাক্টর',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Extract audio from video files.',
            'desc_bn' => 'অডিও এক্সট্রাক্টর টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-subtitle-generator' => [
            'name' => 'AI Subtitle Generator',
            'name_bn' => 'সাবটাইটেল মেকার',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Generate subtitles for videos automatically.',
            'desc_bn' => 'সাবটাইটেল মেকার টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-voiceover' => [
            'name' => 'AI Voiceover Generator',
            'name_bn' => 'ভয়েসওভার জেনারেটর',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Generate realistic human voices from text.',
            'desc_bn' => 'ভয়েসওভার জেনারেটর টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-translation' => [
            'name' => 'AI Language Translator',
            'name_bn' => 'ল্যাঙ্গুয়েজ ট্রান্সলেটর',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Translate text between multiple languages.',
            'desc_bn' => 'ল্যাঙ্গুয়েজ ট্রান্সলেটর টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-plagiarism-checker' => [
            'name' => 'AI Plagiarism Checker',
            'name_bn' => 'প্লাগারিজম চেকার',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Check your text for plagiarism accurately.',
            'desc_bn' => 'প্লাগারিজম চেকার টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ]
        ,
'ai-business-plan' => [
            'name' => 'AI Business Plan Generator',
            'name_bn' => 'বিজনেস প্ল্যান জেনারেটর',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Create a professional business plan.',
            'desc_bn' => 'বিজনেস প্ল্যান জেনারেটর টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-interview-prep' => [
            'name' => 'AI Interview Prep',
            'name_bn' => 'ইন্টারভিউ প্রস্তুতি এআই',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Prepare for job interviews with AI.',
            'desc_bn' => 'ইন্টারভিউ প্রস্তুতি এআই টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-workout-planner' => [
            'name' => 'AI Workout Planner',
            'name_bn' => 'ওয়ার্কআউট প্ল্যানার',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Personalized fitness and workout plans.',
            'desc_bn' => 'ওয়ার্কআউট প্ল্যানার টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-diet-plan' => [
            'name' => 'AI Diet Plan Generator',
            'name_bn' => 'ডায়েট প্ল্যান এআই',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Generate customized diet plans.',
            'desc_bn' => 'ডায়েট প্ল্যান এআই টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-math-solver' => [
            'name' => 'AI Math Problem Solver',
            'name_bn' => 'অংক সমাধান এআই',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Solve complex math problems instantly.',
            'desc_bn' => 'অংক সমাধান এআই টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-travel-planner' => [
            'name' => 'AI Travel Itinerary',
            'name_bn' => 'ট্রাভেল প্ল্যানার',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Plan your next vacation or trip.',
            'desc_bn' => 'ট্রাভেল প্ল্যানার টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-gift-ideas' => [
            'name' => 'AI Gift Idea Generator',
            'name_bn' => 'গিফট আইডিয়া এআই',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Find the perfect gift for anyone.',
            'desc_bn' => 'গিফট আইডিয়া এআই টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-name-generator' => [
            'name' => 'AI Baby Name Generator',
            'name_bn' => 'শিশুর নাম জেনারেটর',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Find beautiful names with meanings.',
            'desc_bn' => 'শিশুর নাম জেনারেটর টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-book-summarizer' => [
            'name' => 'AI Book Summarizer',
            'name_bn' => 'বই সামারাইজার',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Get key insights from any book.',
            'desc_bn' => 'বই সামারাইজার টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ],
        'ai-code-explainer' => [
            'name' => 'AI Code Explainer',
            'name_bn' => 'কোড এক্সপ্লেইনার',
            'category' => 'enterprise-ai-tools',
            'desc_en' => 'Understand complex code snippets.',
            'desc_bn' => 'কোড এক্সপ্লেইনার টুলটি ব্যবহার করুন সম্পূর্ণ ফ্রিতে।',
            'features' => ['ফ্রি টুল', 'সহজ ব্যবহার', 'নো-লিমিট'],
            'benefits' => ['সময় বাঁচাবে', 'কাজের স্পিড বাড়াবে'],
            'faqs' => []
        ]
    ];
}
