<?php
/**
 * Next-Gen PHP Syntax Validator & Safe Storage Engine
 * Part of IBD Cyber Next-Gen Ecosystem
 */

if (!defined('ABSPATH')) exit;

class ILYBD_Syntax_Validator {

    /**
     * Validates a string of PHP code for syntax errors.
     * 
     * @param string $code The PHP code to validate.
     * @return array|bool Returns true if valid, or an array with error details.
     */
    public static function validate($code) {
        $test_code = trim($code);
        
        // Ensure we have a PHP opening tag for the tokenizer
        if (strpos($test_code, '<?php') !== 0) {
            $test_code = '<?php ' . $test_code;
        }

        try {
            if (!function_exists('token_get_all')) {
                return self::simple_balance_check($test_code);
            }

            $tokens = token_get_all($test_code);
            
            $braces = 0;
            $parentheses = 0;
            $brackets = 0;
            
            foreach ($tokens as $token) {
                if (is_array($token)) {
                    // Check for bad characters or incomplete strings
                    if (defined('T_BAD_CHARACTER') && $token[0] === T_BAD_CHARACTER) {
                        return [
                            'status' => 'error',
                            'message' => 'Syntax Error: Bad character detected on line ' . $token[2],
                            'line' => $token[2]
                        ];
                    }
                    // Handle opening curly braces in string interpolation (e.g. "{$var}" or "${var}")
                    if (defined('T_CURLY_OPEN') && $token[0] === T_CURLY_OPEN) {
                        $braces++;
                    }
                    if (defined('T_DOLLAR_OPEN_CURLY_BRACES') && $token[0] === T_DOLLAR_OPEN_CURLY_BRACES) {
                        $braces++;
                    }
                } else {
                    if ($token === '{') $braces++;
                    if ($token === '}') $braces--;
                    if ($token === '(') $parentheses++;
                    if ($token === ')') $parentheses--;
                    if ($token === '[') $brackets++;
                    if ($token === ']') $brackets--;
                }
            }
            
            if ($braces !== 0) {
                return ['status' => 'error', 'message' => 'Mismatched curly braces {}. Balance: ' . $braces];
            }
            if ($parentheses !== 0) {
                return ['status' => 'error', 'message' => 'Mismatched parentheses (). Balance: ' . $parentheses];
            }
            if ($brackets !== 0) {
                return ['status' => 'error', 'message' => 'Mismatched brackets []. Balance: ' . $brackets];
            }
            
            return true;
        } catch (Throwable $e) {
            return [
                'status' => 'error',
                'message' => 'Fatal Parser Error: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Simple fallback balance check
     */
    private static function simple_balance_check($code) {
        $braces = substr_count($code, '{') - substr_count($code, '}');
        $parens = substr_count($code, '(') - substr_count($code, ')');
        $brackets = substr_count($code, '[') - substr_count($code, ']');
        
        if ($braces !== 0 || $parens !== 0 || $brackets !== 0) {
            return [
                'status' => 'error',
                'message' => "Mismatched tokens detected (Braces: $braces, Parens: $parens, Brackets: $brackets)"
            ];
        }
        return true;
    }

    /**
     * Safe File Writer: Performs lint check before writing to disk.
     */
    public static function safe_write($filepath, $content) {
        $validation = self::validate($content);
        
        if ($validation === true) {
            $result = @file_put_contents($filepath, $content);
            if ($result !== false) {
                return true;
            }
            return ['status' => 'error', 'message' => 'FileSystem Error: Could not write to ' . $filepath];
        }
        
        return $validation;
    }

    /**
     * Emergency Failsafe: Checks if a file is readable and valid PHP
     */
    public static function is_file_safe($file_path) {
        if (!file_exists($file_path)) return false;
        $content = @file_get_contents($file_path);
        if ($content === false) return false;
        return self::validate($content) === true;
    }
}

/**
 * Global helper functions for backward compatibility
 */
function ilybd_validate_php_syntax($code) {
    return ILYBD_Syntax_Validator::validate($code);
}

function ilybd_safe_file_put_contents($filepath, $content) {
    return ILYBD_Syntax_Validator::safe_write($filepath, $content);
}

function ilybd_is_file_safe($file_path) {
    return ILYBD_Syntax_Validator::is_file_safe($file_path);
}

