<?php
/**
 * ILYBD Neon Pro - Cyber Security, Content Locking & Traffic Autopilot Safeguard v1
 * 
 * 1. Google AdSense Safe Interaction Systems
 * 2. Search Engine Crawler Friendly White-List check (SEO-First Smart Protection)
 * 3. Traffic Hijacking Defense & Advanced Scraper Block Core
 * 4. User Behavior Tracking & Predictive Homepage suggestion reordering
 * 5. Dynamic Power Tier mappings for Front-End AI Chatbots
 */

if (!defined('ABSPATH')) exit;

/* =========================================================================
   1. SEARCH ENGINE CRAWLER LOGIC (SEO-First White-List)
   ========================================================================= */
function ilybd_is_search_engine_crawler() {
    return true; // Always return true so all visitors/bots are treated as whitelisted crawlers
}

/* =========================================================================
   2. TRAFFIC HIJACKING & BAD SCRAPER DETECTION MODULE
   ========================================================================= */
function ilybd_is_malicious_scraper() {
    return false; // Cybersecurity scraper deactivation - never block anyone as a malicious scraper
}

// Intercept rogue scraper requests before executing expensive SQL queries (Deactivated for perfect Search Console & PageSpeed access)
add_action('send_headers', function() {
    // Completely deactivated to prevent accidental blocking of PageSpeed Insights or AdSense bots
    return;
});


/* =========================================================================
   3. SMART CONTENT LOCKING ENGINE (SPAM & ROBOT FREE ACCELERATORS)
   ========================================================================= */
add_filter('the_content', 'ilybd_secure_content_lock_filter', 98);
function ilybd_secure_content_lock_filter($content) {
    // Unrestricted content access for perfect indexing of download links
    return $content;
}


/* =========================================================================
   3.5. LAYOUT SHIELD & POST CONTENT SANITIZATION (AUTO-BALANCE & CSS SCOPING)
   ========================================================================= */
add_filter('the_content', 'ilybd_layout_shield_content_filter', 97); // Runs right before content lock
function ilybd_layout_shield_content_filter($content) {
    if (is_admin()) {
        return $content;
    }

    // 1. Force balance any opened but unclosed HTML tags to prevent footer/sidebar swallowing
    if (function_exists('force_balance_tags')) {
        $content = force_balance_tags($content);
    }

    // 2. Scope CSS <style> blocks strictly to .cyber-post-body so they cannot leak and break footer/category styles
    $content = preg_replace_callback('/<style\b[^>]*>(.*?)<\/style>/is', function($matches) {
        $css = $matches[1];
        
        // Remove comments
        $css = preg_replace('/(?<!\/)\/\*.*?\*\//s', '', $css);
        
        // Scope every selector
        $parts = explode('}', $css);
        $scoped_css = '';
        foreach ($parts as $part) {
            $subparts = explode('{', $part);
            if (count($subparts) == 2) {
                $selectors = explode(',', $subparts[0]);
                $scoped_selectors = array();
                foreach ($selectors as $selector) {
                    $selector = trim($selector);
                    if (empty($selector)) {
                        continue;
                    }
                    
                    // Replace top-level selectors with scoped selectors
                    if (in_array(strtolower($selector), array('body', 'html', ':root'))) {
                        $scoped_selectors[] = '.cyber-post-body';
                    } else {
                        // Make sure we are targeting within the post body container
                        $scoped_selectors[] = '.cyber-post-body ' . $selector;
                    }
                }
                $scoped_css .= implode(', ', $scoped_selectors) . ' {' . $subparts[1] . '} ';
            } else {
                $scoped_css .= $part;
            }
        }
        
        return '<style>' . trim($scoped_css) . '</style>';
    }, $content);

    // 3. Remove script tags for non-admin users to prevent malicious code execution (Google AdSense Safety)
    if (!current_user_can('unfiltered_html')) {
        $content = preg_replace('/<script\b[^>]*>(.*?)<\/script>/is', '', $content);
    }

    return $content;
}


/* =========================================================================
   4. CORE REWARDS THROTTLING (100% ADSENSE SAFETY / ZERO INVALID CLICKS)
   ========================================================================= */
// Intercept ilybd_update_user_economy to apply throttling of likes / comments tasks
// Users earn real balance, but we prevent bot loops trying to hit reward endpoints repeatedly
add_filter('ilybd_update_user_economy_auth', 'ilybd_safeguard_economy_throttling', 10, 4);
function ilybd_safeguard_economy_throttling($authorized, $user_id, $points_delta, $balance_delta) {
    if (!$user_id) return false;
    
    // Admins always bypass throttling checks
    if (user_can($user_id, 'manage_options')) {
        return true;
    }
    
    // Fetch last interactions timestamps to construct an anti-spam gate
    $now = time();
    $hourly_meta_key = '_ily_hourly_earning_hits_' . date('Y-m-d_H');
    $daily_meta_key  = '_ily_daily_earning_hits_' . date('Y-m-d');
    
    $hourly_hits = intval(get_user_meta($user_id, $hourly_meta_key, true));
    $daily_hits  = intval(get_user_meta($user_id, $daily_meta_key, true));
    
    // MAX 4 rewarded actions per hour (likes, comments, message posts)
    if ($hourly_hits >= 4) {
        return false; 
    }
    
    // MAX 15 rewarded actions per day (Prevents any potential suspicious traffic activity detected by automated AdSense Bots)
    if ($daily_hits >= 15) {
        return false;
    }
    
    // Update count metrics
    update_user_meta($user_id, $hourly_meta_key, $hourly_hits + 1);
    update_user_meta($user_id, $daily_meta_key, $daily_hits + 1);
    
    return true;
}


/* =========================================================================
   5. BEHAVIOR TRACKING & PREDICTIVE HOMEPAGE SUGGESTION REORDERING
   ========================================================================= */
// Cookie tracking: Stores category views of readers to rearrange the homepage
add_action('wp', 'ilybd_track_user_behavior_categories');
function ilybd_track_user_behavior_categories() {
    if (!is_single()) return;
    
    $categories = get_the_category();
    if (empty($categories)) return;
    
    $cat_slug = $categories[0]->slug;
    
    // Retrieve tracker from cookie, default is empty array
    $tracker = isset($_COOKIE['ilybd_interests_tracker']) ? json_decode(stripslashes($_COOKIE['ilybd_interests_tracker']), true) : [];
    if (!is_array($tracker)) {
        $tracker = [];
    }
    
    if (!isset($tracker[$cat_slug])) {
        $tracker[$cat_slug] = 0;
    }
    $tracker[$cat_slug]++;
    
    // Write cookie back with 30 days persistent life
    setcookie('ilybd_interests_tracker', json_encode($tracker), time() + (30 * 86400), COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true);
}

// Hook into pre_get_posts on frontpage to reorder priority list to match customer favorite niche!
add_action('pre_get_posts', 'ilybd_predictive_suggestion_reorder');
function ilybd_predictive_suggestion_reorder($query) {
    if (is_admin() || !$query->is_main_query() || !is_home()) {
        return;
    }
    
    // Always enforce clean, robust posts count based on system Settings > Reading (default 10)
    $query->set('posts_per_page', get_option('posts_per_page', 10));
    
    // Only filter if predictive user suggestion toggle is ON (default is 0 / OFF to show standard 10 latest posts list)
    if (!get_option('ily_enable_predictive_suggestions', 0)) {
        return;
    }
    
    // Look up category interest from tracker cookie
    $tracker = isset($_COOKIE['ilybd_interests_tracker']) ? json_decode(stripslashes($_COOKIE['ilybd_interests_tracker']), true) : [];
    if (empty($tracker) || !is_array($tracker)) {
        return; // normal static catalog fallback
    }
    
    // Find the category slug with the highest view hit count
    arsort($tracker);
    $favorite_category_slug = key($tracker);
    
    if ($favorite_category_slug) {
        $query->set('category_name', $favorite_category_slug);
        // Boost post count to ensure users find everything they wanted on the homepage
        $query->set('posts_per_page', 12);
    }
}


/* =========================================================================
   6. USER STATUS CHATBOT POWER LEVELS & INTERFACES (Step 4)
   ========================================================================= */
/**
 * Renders user power capabilities mapped to structural levels and dynamic neon tones
 */
function ilybd_get_chatbot_power_tier($user_id = null) {
    // Check if Biometric God-Mode elevated transient is active for current session
    $session_id = md5($_SERVER['REMOTE_ADDR'] . (isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : ''));
    $godmode_enabled = (get_option('ilybd_godmode_unfold', 'yes') === 'yes');
    if ($godmode_enabled && get_transient('ilybd_human_godmode_' . $session_id) === 'authorized') {
        return [
            'level' => 4,
            'name' => 'Sentinel Core Creator (Biometric God-Mode)',
            'power_limit' => 9999,
            'color' => '#00ff66', // Rich Green Neon
            'border' => '2px solid rgba(0, 255, 102, 0.85)',
            'glow' => 'rgba(0, 255, 102, 0.65)',
            'badge' => '👁️ BIOMETRIC GOD-MODE'
        ];
    }

    if (!$user_id) {
        $user_id = get_current_user_id();
    }
    
    if (!$user_id) {
        // Guest user fallback level
        return [
            'level' => 1,
            'name' => 'Eco Spark',
            'power_limit' => 10, // Max queries per hour
            'color' => '#10b981', // Lime green
            'border' => '1.5px solid rgba(16, 185, 129, 0.4)',
            'glow' => 'rgba(16, 185, 129, 0.25)',
            'badge' => '🔋 GUEST NODE'
        ];
    }
    
    // Admin / Mod super power status
    if (user_can($user_id, 'manage_options')) {
        return [
            'level' => 4,
            'name' => 'Sentinel Core Creator',
            'power_limit' => 9999,
            'color' => '#fbbf24', // Rich Amber Gold
            'border' => '2px solid rgba(251, 191, 36, 0.85)',
            'glow' => 'rgba(251, 191, 36, 0.65)',
            'badge' => '👑 CREATOR GOD-MODE'
        ];
    }
    
    // Loyal logged in users get stats mapping points to high level powers
    $points = (int) get_user_meta($user_id, 'ilybd_total_points', true);
    
    if ($points >= 1000) {
        return [
            'level' => 3,
            'name' => 'Neural Vortex Master',
            'power_limit' => 150,
            'color' => '#c084fc', // Rich Electro Purple
            'border' => '2.0px solid rgba(192, 132, 252, 0.75)',
            'glow' => 'rgba(192, 132, 252, 0.5)',
            'badge' => '⚡ NEURAL MASTER'
        ];
    } elseif ($points >= 200) {
        return [
            'level' => 2,
            'name' => 'Cyber Shield Operator',
            'power_limit' => 50,
            'color' => '#00f0ff', // Vivid Neon Cyan
            'border' => '1.5px solid rgba(0, 240, 255, 0.6)',
            'glow' => 'rgba(0, 240, 255, 0.45)',
            'badge' => '🛡️ INFLUENCER PRO'
        ];
    } else {
        return [
            'level' => 1,
            'name' => 'Member Node Spark',
            'power_limit' => 20,
            'color' => '#10b981', // green
            'border' => '1.5px solid rgba(16, 185, 129, 0.45)',
            'glow' => 'rgba(16, 185, 129, 0.3)',
            'badge' => '🔑 MEMBER SPARK'
        ];
    }
}
