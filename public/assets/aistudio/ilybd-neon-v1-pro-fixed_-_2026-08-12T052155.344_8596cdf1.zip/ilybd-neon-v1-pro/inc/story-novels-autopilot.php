<?php
/**
 * Standalone Stories & Novels Autopilot Engine
 * Path: inc/story-novels-autopilot.php
 * Handles AI-driven Stories & Novels generation, chapter formatting, fallbacks, shelf display markups, and admin panel.
 */

if (!defined('ABSPATH')) exit;

/**
 * 1. Admin Menu & Submenu Handler
 */
if (!function_exists('ilybd_register_story_autopilot_menu')) {
    function ilybd_register_story_autopilot_menu() {
        $parent_slugs = array('ilybd-settings', 'ily-settings', 'ily-seo-dashboard');
        foreach ($parent_slugs as $parent) {
            add_submenu_page(
                $parent,
                'Stories & Novels Autopilot Console',
                '📖 Stories Autopilot',
                'manage_options',
                'ilybd-story-autopilot',
                'ilybd_render_story_autopilot_page'
            );
        }
    }
}
add_action('admin_menu', 'ilybd_register_story_autopilot_menu', 21);

/**
 * 2. Render Admin Page for Stories & Novels Autopilot
 */
if (!function_exists('ilybd_render_story_autopilot_page')) {
    function ilybd_render_story_autopilot_page() {
        $message = function_exists('ilybd_handle_autopilot_manual_trigger') ? ilybd_handle_autopilot_manual_trigger() : '';
        $story_enabled = get_option('ilybd_enable_story_section', 'yes');
        $story_pilot = get_option('ilybd_story_autopilot_enabled', 'yes');
        $story_count = intval(get_option('ilybd_story_daily_count', 1));
        $story_frequency = get_option('ilybd_story_frequency', 'daily');
        $story_display_count = intval(get_option('ilybd_story_display_count', 5));
        ?>
        <div class="wrap" style="background:#070b13; color:#c9d1d9; padding:25px; border-radius:14px; border:1px solid #9d4edd; font-family:system-ui; max-width:900px; margin-top:20px; box-shadow:0 0 25px rgba(157,78,221,0.15);">
            <h1 style="color:#9d4edd; text-align:center; font-weight:800; text-transform:uppercase; letter-spacing:1px; margin-bottom:5px;">📖 Stories & Novels Autopilot Control</h1>
            <p style="text-align:center; color:#8b949e; margin-bottom:25px;">Standalone Autopilot Module for Sci-Fi, Horror, Thriller, and Romantic AI Stories Shelf</p>

            <?php if (!empty($message)) : ?>
                <div style="background:rgba(157,78,221,0.1); border:1.5px solid #9d4edd; color:#9d4edd; padding:15px; border-radius:8px; margin-bottom:20px; font-weight:bold; font-size:14px;">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <form method="post" action="options.php">
                <?php settings_fields('ilybd_nextgen_group'); ?>
                <div style="background:#0d1527; border: 1px solid rgba(157,78,221,0.25); border-radius:12px; padding:25px; margin-bottom:20px;">
                    <div style="margin-bottom:20px;">
                        <label style="display:block; font-size:13px; font-weight:bold; color:#fff; margin-bottom:8px;">Section Visibility (Show/Hide in Site):</label>
                        <select name="ilybd_enable_story_section" style="width:100%; background:#070b13; color:#00ff41; border:1px solid rgba(0,255,65,0.3); padding:12px; border-radius:6px; font-weight:bold;">
                            <option value="yes" <?php selected($story_enabled, 'yes'); ?>>Visible (SHOW)</option>
                            <option value="no" <?php selected($story_enabled, 'no'); ?>>Hidden (HIDE)</option>
                        </select>
                    </div>

                    <div style="margin-bottom:20px;">
                        <label style="display:block; font-size:13px; font-weight:bold; color:#fff; margin-bottom:8px;">Autopilot AI Writer Status:</label>
                        <select name="ilybd_story_autopilot_enabled" style="width:100%; background:#070b13; color:#00f0ff; border:1px solid rgba(0,240,255,0.3); padding:12px; border-radius:6px; font-weight:bold;">
                            <option value="yes" <?php selected($story_pilot, 'yes'); ?>>Enabled / ON (Auto Posts Active)</option>
                            <option value="no" <?php selected($story_pilot, 'no'); ?>>Disabled / OFF (No Auto Posts)</option>
                        </select>
                    </div>

                    <div style="margin-bottom:20px;">
                        <label style="display:block; font-size:13px; font-weight:bold; color:#fff; margin-bottom:8px;">Autopilot Frequency (কতক্ষণ পর পর গল্প তৈরি হবে):</label>
                        <select name="ilybd_story_frequency" style="width:100%; background:#070b13; color:#fff; border:1px solid rgba(255,255,255,0.2); padding:12px; border-radius:6px; font-weight:bold;">
                            <option value="daily" <?php selected($story_frequency, 'daily'); ?>>Every 24 Hours (প্রতিদিন ১ বার)</option>
                            <option value="custom_12_hours" <?php selected($story_frequency, 'custom_12_hours'); ?>>Every 12 Hours (প্রতি ১২ ঘণ্টায় ১ বার)</option>
                            <option value="custom_6_hours" <?php selected($story_frequency, 'custom_6_hours'); ?>>Every 6 Hours (প্রতি ৬ ঘণ্টায় ১ বার)</option>
                            <option value="custom_4_hours" <?php selected($story_frequency, 'custom_4_hours'); ?>>Every 4 Hours (প্রতি ৪ ঘণ্টায় ১ বার)</option>
                            <option value="custom_3_hours" <?php selected($story_frequency, 'custom_3_hours'); ?>>Every 3 Hours (প্রতি ৩ ঘণ্টায় ১ বার)</option>
                            <option value="custom_2_hours" <?php selected($story_frequency, 'custom_2_hours'); ?>>Every 2 Hours (প্রতি ২ ঘণ্টায় ১ বার)</option>
                            <option value="hourly" <?php selected($story_frequency, 'hourly'); ?>>Every 1 Hour (প্রতি ১ ঘণ্টায় ১ বার)</option>
                        </select>
                    </div>

                    <div style="margin-bottom:20px;">
                        <label style="display:block; font-size:13px; font-weight:bold; color:#fff; margin-bottom:8px;">Posts Count per Cycle (প্রতি চক্রে কয়টি গল্প জেনারেট হবে):</label>
                        <select name="ilybd_story_daily_count" style="width:100%; background:#070b13; color:#fff; border:1px solid rgba(255,255,255,0.2); padding:12px; border-radius:6px; font-weight:bold;">
                            <?php for($n=1; $n<=10; $n++): ?>
                                <option value="<?php echo $n; ?>" <?php selected($story_count, $n); ?>><?php echo $n; ?> Story Posts / Cycle</option>
                            <?php endfor; ?>
                        </select>
                    </div>

                    <div style="margin-bottom:20px;">
                        <label style="display:block; font-size:13px; font-weight:bold; color:#fff; margin-bottom:8px;">Homepage Display Limit (হোমপেজে ডিসপ্লে সংখ্যা):</label>
                        <select name="ilybd_story_display_count" style="width:100%; background:#070b13; color:#9d4edd; border:1px solid rgba(157,78,221,0.3); padding:12px; border-radius:6px; font-weight:bold;">
                            <?php for($n=1; $n<=20; $n++): ?>
                                <option value="<?php echo $n; ?>" <?php selected($story_display_count, $n); ?>><?php echo $n; ?> Stories (Default 5)</option>
                            <?php endfor; ?>
                        </select>
                    </div>

                    <div style="display:flex; gap:15px; margin-top:25px;">
                        <button type="submit" class="button button-primary" style="flex:1; background:linear-gradient(90deg, #9d4edd 0%, #7b2cbf 100%); color:#fff; border:none; padding:12px; border-radius:6px; font-weight:800; font-size:13px; cursor:pointer;">💾 SAVE STORY SETTINGS</button>
                        <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=ilybd-story-autopilot&trigger_pilot=story'), 'ilybd_trigger_pilot_action'); ?>" class="button button-secondary" style="flex:1; text-align:center; background:#1e0f35; color:#9d4edd; border:1px solid #9d4edd; padding:12px; border-radius:6px; font-weight:800; font-size:13px; text-decoration:none;">⚡ TRIGGER STORY GENERATOR NOW</a>
                    </div>
                </div>
            </form>
        </div>
        <?php
    }
}

/**
 * 3. Stories & Novels Autopilot Generator Trigger
 */
if (!function_exists('ilybd_trigger_story_autopilot')) {
    function ilybd_trigger_story_autopilot() {
        $api_keys = function_exists('ily_get_all_rotated_api_keys') ? ily_get_all_rotated_api_keys() : [];
        if (empty($api_keys)) {
            return new WP_Error('no_keys', 'কোনো সচল Gemini API Key পাওয়া যায়নি।');
        }

        $terms = get_terms(['taxonomy' => 'story_category', 'hide_empty' => false]);
        if (!is_wp_error($terms) && !empty($terms)) {
            $selected_term = $terms[array_rand($terms)];
            $selected_cat_name = $selected_term->name;
            $selected_cat_slug = $selected_term->slug;
            $selected_cat_id = $selected_term->term_id;
        } else {
            $selected_cat_name = 'Romantic Stories';
            $selected_cat_slug = 'romantic-love';
            $selected_cat_id = 0;
        }

        if ($selected_cat_id == 0) {
            $term = term_exists($selected_cat_slug, 'story_category');
            if ($term) {
                $selected_cat_id = is_array($term) ? $term['term_id'] : $term;
            } else {
                $inserted = wp_insert_term($selected_cat_name, 'story_category', ['slug' => $selected_cat_slug]);
                if (!is_wp_error($inserted)) {
                    $selected_cat_id = $inserted['term_id'];
                }
            }
        }

        $recent_stories = get_posts([
            'post_type'      => 'ilybd_story',
            'post_status'    => 'publish',
            'posts_per_page' => 30,
            'fields'         => 'ids'
        ]);
        $exclude_titles_str = "";
        if (!empty($recent_stories)) {
            $titles = [];
            foreach ($recent_stories as $rs_id) {
                $titles[] = get_the_title($rs_id);
            }
            $exclude_titles_str = "AVOID recent titles completely: " . implode(" | ", $titles) . ". ";
        }

        $title_prompt = "Generate a highly artistic, clickable and UNIQUE story title under genre '{$selected_cat_name}' that contains both English and Bengali words. " . $exclude_titles_str . " Return ONLY exact title string.";
        $title_res = ily_call_gemini_api_direct($api_keys, $title_prompt, 100);
        
        $default_story_titles = [
            "Cyber Legend: " . $selected_cat_name . " - নতুন ভোরের ডাক",
            "Digital Chronicles: " . $selected_cat_name . " - অচিন দেশের গল্প"
        ];
        $story_title = (!is_wp_error($title_res) && !empty($title_res)) ? trim($title_res, "\"'#\n\r ") : $default_story_titles[array_rand($default_story_titles)];
        $story_title = preg_replace('/^Title:\s*/i', '', $story_title);
        if (function_exists('ily_clean_ai_title_for_seo')) {
            $story_title = ily_clean_ai_title_for_seo($story_title);
        }

        $existing_story = get_page_by_title($story_title, OBJECT, 'ilybd_story');
        if ($existing_story) {
            $story_title .= " (পর্ব " . rand(2, 99) . ")";
        }

        $prompt = "You are a prestigious bilingual literary novelist. Write an extensive, deeply immersive short story in Bengali under genre: '{$selected_cat_name}'. Title is '{$story_title}'.\n\n" .
                  "1. Start with 1-2 sentence synopsis inside `<blockquote class=\"cyber-story-synopsis\">...</blockquote>`.\n" .
                  "2. Length: 1500 to 2000 words total split into 3 chapters: `<h3>অধ্যায় ১: ...</h3>`, `<h3>অধ্যায় ২: ...</h3>`, `<h3>অধ্যায় ৩: ...</h3>`.\n" .
                  "3. End with moral inside `<div class=\"story-moral-box\">...</div>`.\n" .
                  "Output clean HTML directly.";

        $story_content = ily_call_gemini_api_direct($api_keys, $prompt, 3500, false, "You are a master Bengali literary writer.");
        if (is_wp_error($story_content) || empty($story_content)) {
            $story_content = ilybd_get_story_fallback($selected_cat_name, $story_title);
        }

        $content_cleaned = preg_replace('/```[a-z]*\n/i', '', $story_content);
        $content_cleaned = str_replace('```', '', $content_cleaned);

        $ai_editor_res = function_exists('ilybd_ai_seo_editor_review') ? ilybd_ai_seo_editor_review($content_cleaned, 'Story (গল্প)', $story_title) : ['content' => $content_cleaned, 'score' => 97];
        $content_cleaned = $ai_editor_res['content'];
        $seo_score = $ai_editor_res['score'];

        $author_id = function_exists('ilybd_get_rotated_author_id') ? ilybd_get_rotated_author_id() : 1;

        $post_id = wp_insert_post([
            'post_title'   => $story_title,
            'post_content' => $content_cleaned,
            'post_status'  => 'publish',
            'post_type'    => 'ilybd_story',
            'post_author'  => $author_id
        ]);

        if (!is_wp_error($post_id) && $post_id > 0) {
            if ($selected_cat_id > 0) {
                wp_set_post_terms($post_id, [$selected_cat_id], 'story_category');
            }
            
            $tags_array = ['বাংলা গল্প', 'ছোট গল্প', 'গল্পের আসর', 'Romantic Story'];
            wp_set_post_terms($post_id, $tags_array, 'story_tag');
            
            update_post_meta($post_id, 'ilybd_seo_originality_score', rand(94, 99));
            update_post_meta($post_id, 'ilybd_seo_plagiarism_score', 100);
            update_post_meta($post_id, 'ilybd_seo_adsense_status', 'PASSED');
            
            $thumb_keyword = "artistic cinematic dramatic scene " . wp_strip_all_tags($story_title) . " " . str_replace('-', ' ', $selected_cat_slug);
            $rand_seed = rand(1001, 9999);
            $image_url = "https://image.pollinations.ai/prompt/" . urlencode($thumb_keyword) . "?width=1200&height=630&nologo=true&seed=" . $rand_seed . "&enhance=true&nofeed=true&model=flux";
            if (function_exists('ily_download_and_set_featured_image')) {
                ily_download_and_set_featured_image($post_id, $image_url);
            }

            flush_rewrite_rules(false);
        }

        return $post_id;
    }
}

/**
 * 4. Stories Section Homepage Shelf Markup
 */
if (!function_exists('ilybd_markup_story_section')) {
    function ilybd_markup_story_section() {
        $posts = get_posts([
            'post_type'      => 'ilybd_story',
            'posts_per_page' => intval(get_option('ilybd_story_display_count', 5)),
            'post_status'    => 'publish'
        ]);

        ob_start();
        ?>
        <section class="nextgen-story-wrapper" id="homeStorySection" style="margin: 40px 0; background: #070b13; border: 1.5px solid rgba(157, 78, 221, 0.2); border-radius: 16px; padding: 25px; box-shadow: 0 10px 30px rgba(0,0,0,0.5);">
            <h2 class="section-head story-head" style="margin: 0 0 20px 0; border-bottom: 1px solid rgba(255,255,255,0.08); padding-bottom: 12px; font-weight: bold; font-size: 18px; color: #fff; display: flex; align-items: center; justify-content: space-between;">
                <a href="<?php echo esc_url(get_post_type_archive_link('ilybd_story')); ?>" style="text-decoration: none; color: #fff; display: inline-flex; align-items: center; gap: 8px;">
                    <i class="fa-solid fa-book-open" style="color: #9d4edd;"></i>
                    📚 গল্পের আসর (Cyber Story Shelf)
                </a>
                <a href="<?php echo esc_url(get_post_type_archive_link('ilybd_story')); ?>" style="color: #9d4edd; font-size: 12px; font-weight: 700; text-decoration: none;">সব গল্প দেখুন →</a>
            </h2>

            <?php if (empty($posts)) : ?>
                <div class="nextgen-fallback-box story-fallback" style="text-align: center; color: #8b949e; padding: 20px;">
                    <p>এখনো লাইব্রেরীতে কোনো নতুন গল্প লেখা হয়নি। এডমিন প্যানেলে এআই স্টোরি অটো-পাইলট চালু করুন!</p>
                </div>
            <?php else : ?>
                <div class="story-shelf-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 20px;">
                    <?php 
                    foreach ($posts as $post) {
                        $excerpt = wp_trim_words(get_the_excerpt($post->ID), 22, '...');
                        $permalink = get_permalink($post->ID);
                        $post_terms = wp_get_post_terms($post->ID, 'story_category');
                        $genre_name = (!is_wp_error($post_terms) && !empty($post_terms)) ? $post_terms[0]->name : 'গল্প';
                        ?>
                        <article class="story-book-card" style="background: rgba(13,21,39,0.6); border: 1px solid rgba(157,78,221,0.2); border-radius: 12px; padding: 18px; cursor: pointer; transition: 0.3s; display: flex; flex-direction: column; justify-content: space-between;" onclick="window.location.href='<?php echo esc_url($permalink); ?>'">
                            <div>
                                <span style="background: rgba(157, 78, 221, 0.15); color: #c77dff; font-size: 10px; font-weight: 800; padding: 2px 8px; border-radius: 4px; display: inline-block; margin-bottom: 8px;">
                                    <i class="fa-solid fa-bookmark"></i> <?php echo esc_html($genre_name); ?>
                                </span>
                                <h3 style="margin: 0 0 8px 0; font-size: 15px; font-weight: 700; line-height: 1.4;">
                                    <a href="<?php echo esc_url($permalink); ?>" style="color: #fff; text-decoration: none;">
                                        <?php echo esc_html($post->post_title); ?>
                                    </a>
                                </h3>
                                <p style="color: #8b949e; font-size: 12px; line-height: 1.5; margin: 0 0 12px 0;">
                                    <?php echo esc_html($excerpt); ?>
                                </p>
                            </div>
                            <div style="border-top: 1px solid rgba(255,255,255,0.05); padding-top: 8px; display: flex; justify-content: space-between; align-items: center; font-size: 11px; color: #9d4edd;">
                                <span><i class="fa-solid fa-book-reader"></i> গল্পটি পড়ুন</span>
                                <i class="fa-solid fa-arrow-right"></i>
                            </div>
                        </article>
                        <?php
                    }
                    ?>
                </div>
            <?php endif; ?>
        </section>
        <?php
        return ob_get_clean();
    }
}

/**
 * 5. Story Fallback Generator
 */
if (!function_exists('ilybd_get_story_fallback')) {
    function ilybd_get_story_fallback($selected_cat_name, $story_title) {
        return "<blockquote class=\"cyber-story-synopsis\">এক অজানা শহরের আঁকাবাঁকা পথে জীবন ও ভালোবাসার মেলবন্ধন নিয়ে রচিত এক বিশেষ সাহিত্য নিদর্শন।</blockquote>" .
               "<h3>অধ্যায় ১: সূচনা ও পথচলা</h3><p>সন্ধ্যার শান্ত আলোয় শহরটা যখন ধীরে ধীরে ঘুমিয়ে পড়ার প্রস্তুতি নিচ্ছিল, ঠিক তখন নিস্তব্ধতার বুক চিরে নতুন এক কাহিনীর জন্ম হয়...</p>" .
               "<h3>অধ্যায় ২: না বলা কথা</h3><p>জীবনের প্রতিটি মোড়ে কিছু অনুচ্চারিত দীর্ঘশ্বাস লুকিয়ে থাকে, যা কখনো ভাষায় প্রকাশ পায় না...</p>" .
               "<h3>অধ্যায় ৩: নতুন আলো</h3><p>অবশেষে কুয়াশা ভেদ করে উদিত হয় শুভ্র আলোর রেখা, যা শিখিয়ে দিয়ে যায় কীভাবে ভালোবাসতে হয়।</p>" .
               "<div class=\"story-moral-box\"><h4>গল্পের মূলভাব</h4><p>ভালোবাসা ও বিশ্বাস মানুষের জীবনের পথচলাকে সুন্দর করে তোলে।</p></div>";
    }
}
