<?php
/**
 * Standalone Community Q&A Autopilot Engine & Solution Management Console
 * Path: inc/community-qa-autopilot.php
 * Handles AI-driven Q&A generation, forum settings, custom Q&A solution/answer box submission, and admin management.
 */

if (!defined('ABSPATH')) exit;

/**
 * 1. Admin Menu & Submenu Handler
 */
if (!function_exists('ilybd_register_qa_autopilot_menu')) {
    function ilybd_register_qa_autopilot_menu() {
        $parent_slugs = array('ilybd-settings', 'ily-settings', 'ily-seo-dashboard');
        foreach ($parent_slugs as $parent) {
            add_submenu_page(
                $parent,
                'Community Q&A Autopilot Console',
                '🙋 Q&A Autopilot & Forum',
                'manage_options',
                'ilybd-qa-autopilot',
                'ilybd_render_qa_autopilot_page'
            );
        }
    }
}
add_action('admin_menu', 'ilybd_register_qa_autopilot_menu', 23);

/**
 * 2. Render Admin Page for Community Q&A Autopilot
 */
if (!function_exists('ilybd_render_qa_autopilot_page')) {
    function ilybd_render_qa_autopilot_page() {
        $message = function_exists('ilybd_handle_autopilot_manual_trigger') ? ilybd_handle_autopilot_manual_trigger() : '';
        $qa_enabled = get_option('ily_enable_community_qa', 1);
        $qa_pilot = get_option('ily_enable_ai_qa_autopilot', 1);
        $qa_frequency = get_option('ily_ai_qa_frequency', 'every_4_hours');
        $qa_daily_limit = intval(get_option('ily_ai_qa_daily_limit', 5));
        $qa_home_count = intval(get_option('ilybd_qa_home_count', 5));
        ?>
        <div class="wrap" style="background:#070b13; color:#c9d1d9; padding:25px; border-radius:14px; border:1px solid #00ff41; font-family:system-ui; max-width:900px; margin-top:20px; box-shadow:0 0 25px rgba(0,255,65,0.15);">
            <h1 style="color:#00ff41; text-align:center; font-weight:800; text-transform:uppercase; letter-spacing:1px; margin-bottom:5px;">🙋 Community Q&A Autopilot & Solution Engine</h1>
            <p style="text-align:center; color:#8b949e; margin-bottom:25px;">Standalone Autopilot & Management Panel for Tech Q&A Discussions, Verified Solutions, and Organic SEO Rankings</p>

            <?php if (!empty($message)) : ?>
                <div style="background:rgba(0,255,65,0.1); border:1.5px solid #00ff41; color:#00ff41; padding:15px; border-radius:8px; margin-bottom:20px; font-weight:bold; font-size:14px;">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <form method="post" action="options.php">
                <?php settings_fields('ilybd_nextgen_group'); ?>
                <div style="background:#0d1527; border: 1px solid rgba(0,255,65,0.25); border-radius:12px; padding:25px; margin-bottom:20px;">
                    <div style="margin-bottom:20px;">
                        <label style="display:block; font-size:13px; font-weight:bold; color:#fff; margin-bottom:8px;">Q&A Forum System Status:</label>
                        <select name="ily_enable_community_qa" style="width:100%; background:#070b13; color:#00ff41; border:1px solid rgba(0,255,65,0.3); padding:12px; border-radius:6px; font-weight:bold;">
                            <option value="1" <?php selected($qa_enabled, 1); ?>>Active / Enabled (SHOW FORUM)</option>
                            <option value="0" <?php selected($qa_enabled, 0); ?>>Inactive / Disabled (HIDE FORUM)</option>
                        </select>
                    </div>

                    <div style="margin-bottom:20px;">
                        <label style="display:block; font-size:13px; font-weight:bold; color:#fff; margin-bottom:8px;">AI Autopilot Auto-Question & Answer Writer:</label>
                        <select name="ily_enable_ai_qa_autopilot" style="width:100%; background:#070b13; color:#00f0ff; border:1px solid rgba(0,240,255,0.3); padding:12px; border-radius:6px; font-weight:bold;">
                            <option value="1" <?php selected($qa_pilot, 1); ?>>Enabled / ON (Auto Q&A Active)</option>
                            <option value="0" <?php selected($qa_pilot, 0); ?>>Disabled / OFF (Manual Only)</option>
                        </select>
                    </div>

                    <div style="margin-bottom:20px;">
                        <label style="display:block; font-size:13px; font-weight:bold; color:#fff; margin-bottom:8px;">Autopilot Generation Cycle Frequency:</label>
                        <select name="ily_ai_qa_frequency" style="width:100%; background:#070b13; color:#fff; border:1px solid rgba(255,255,255,0.2); padding:12px; border-radius:6px; font-weight:bold;">
                            <option value="hourly" <?php selected($qa_frequency, 'hourly'); ?>>Every 1 Hour (প্রতি ১ ঘণ্টায়)</option>
                            <option value="every_2_hours" <?php selected($qa_frequency, 'every_2_hours'); ?>>Every 2 Hours (প্রতি ২ ঘণ্টায়)</option>
                            <option value="every_3_hours" <?php selected($qa_frequency, 'every_3_hours'); ?>>Every 3 Hours (প্রতি ৩ ঘণ্টায়)</option>
                            <option value="every_4_hours" <?php selected($qa_frequency, 'every_4_hours'); ?>>Every 4 Hours (প্রতি ৪ ঘণ্টায়)</option>
                            <option value="every_6_hours" <?php selected($qa_frequency, 'every_6_hours'); ?>>Every 6 Hours (প্রতি ৬ ঘণ্টায়)</option>
                            <option value="twicedaily" <?php selected($qa_frequency, 'twicedaily'); ?>>Every 12 Hours (প্রতি ১২ ঘণ্টায়)</option>
                            <option value="daily" <?php selected($qa_frequency, 'daily'); ?>>Every 24 Hours (প্রতিদিন ১ বার)</option>
                        </select>
                    </div>

                    <div style="margin-bottom:20px;">
                        <label style="display:block; font-size:13px; font-weight:bold; color:#fff; margin-bottom:8px;">Daily Autopilot Post Limit:</label>
                        <select name="ily_ai_qa_daily_limit" style="width:100%; background:#070b13; color:#fff; border:1px solid rgba(255,255,255,0.2); padding:12px; border-radius:6px; font-weight:bold;">
                            <?php for($n=1; $n<=15; $n++): ?>
                                <option value="<?php echo $n; ?>" <?php selected($qa_daily_limit, $n); ?>><?php echo $n; ?> Q&A Threads / Day</option>
                            <?php endfor; ?>
                        </select>
                    </div>

                    <div style="margin-bottom:20px;">
                        <label style="display:block; font-size:13px; font-weight:bold; color:#fff; margin-bottom:8px;">Homepage Q&A Display Limit:</label>
                        <select name="ilybd_qa_home_count" style="width:100%; background:#070b13; color:#00ff41; border:1px solid rgba(0,255,65,0.3); padding:12px; border-radius:6px; font-weight:bold;">
                            <?php for($n=1; $n<=20; $n++): ?>
                                <option value="<?php echo $n; ?>" <?php selected($qa_home_count, $n); ?>><?php echo $n; ?> Threads (Default 5)</option>
                            <?php endfor; ?>
                        </select>
                    </div>

                    <div style="display:flex; gap:15px; margin-top:25px;">
                        <button type="submit" class="button button-primary" style="flex:1; background:linear-gradient(90deg, #00ff41 0%, #00b32d 100%); color:#000; border:none; padding:12px; border-radius:6px; font-weight:800; font-size:13px; cursor:pointer;">💾 SAVE Q&A SETTINGS</button>
                        <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=ilybd-qa-autopilot&trigger_pilot=qa'), 'ilybd_trigger_pilot_action'); ?>" class="button button-secondary" style="flex:1; text-align:center; background:#08200f; color:#00ff41; border:1px solid #00ff41; padding:12px; border-radius:6px; font-weight:800; font-size:13px; text-decoration:none;">⚡ TRIGGER Q&A GENERATOR NOW</a>
                    </div>
                </div>
            </form>
        </div>
        <?php
    }
}

/**
 * 3. AJAX Solution / Answer Handler for Single Q&A Pages
 */
if (!function_exists('ilybd_ajax_submit_qa_solution_handler')) {
    function ilybd_ajax_submit_qa_solution_handler() {
        check_ajax_referer('ilybd_qa_solution_nonce', 'security');

        $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
        $author_name = isset($_POST['author_name']) ? sanitize_text_field($_POST['author_name']) : '';
        $author_email = isset($_POST['author_email']) ? sanitize_email($_POST['author_email']) : '';
        $solution_content = isset($_POST['solution_content']) ? wp_kses_post($_POST['solution_content']) : '';

        if ($post_id <= 0 || get_post_type($post_id) !== 'ilybd_question') {
            wp_send_json_error(['message' => 'অকার্যকর প্রশ্ন আইডি সরবরাহ করা হয়েছে!']);
        }

        if (empty($author_name)) {
            $author_name = is_user_logged_in() ? wp_get_current_user()->display_name : 'Cyber Contributor';
        }

        if (empty($solution_content) || mb_strlen(wp_strip_all_tags($solution_content)) < 10) {
            wp_send_json_error(['message' => 'অনুগ্রহ করে অন্তত ১০ অক্ষরের একটি স্পষ্ট প্রযুক্তিগত সমাধান সরবরাহ করুন।']);
        }

        $user_id = is_user_logged_in() ? get_current_user_id() : 0;

        $commentdata = array(
            'comment_post_ID'      => $post_id,
            'comment_author'       => $author_name,
            'comment_author_email' => $author_email,
            'comment_content'      => $solution_content,
            'comment_type'         => 'qa_solution',
            'comment_parent'       => 0,
            'user_id'              => $user_id,
            'comment_approved'     => 1,
        );

        $comment_id = wp_insert_comment($commentdata);

        if ($comment_id) {
            update_comment_meta($comment_id, 'is_qa_solution', '1');
            update_comment_meta($comment_id, 'qa_upvotes', rand(1, 5));
            
            wp_send_json_success([
                'message'    => '✅ আপনার উত্তর ও সমাধান সফলভাবে পোস্ট করা হয়েছে!',
                'comment_id' => $comment_id
            ]);
        } else {
            wp_send_json_error(['message' => 'উত্তর সাবমিট করতে সমস্যা হয়েছে, পুনরায় চেষ্টা করুন।']);
        }
    }
}
add_action('wp_ajax_ilybd_submit_qa_solution', 'ilybd_ajax_submit_qa_solution_handler');
add_action('wp_ajax_nopriv_ilybd_submit_qa_solution', 'ilybd_ajax_submit_qa_solution_handler');

/**
 * 4. Dedicated Professional Q&A Answer & Solution Box Renderer
 * Replaces the default blog post comment box on single-ilybd_question.php
 */
if (!function_exists('ilybd_render_qa_solutions_and_form')) {
    function ilybd_render_qa_solutions_and_form($post_id) {
        $comments = get_comments(array(
            'post_id' => $post_id,
            'status'  => 'approve',
            'order'   => 'ASC'
        ));

        $nonce = wp_create_nonce('ilybd_qa_solution_nonce');
        $current_user = wp_get_current_user();
        $logged_name = is_user_logged_in() ? $current_user->display_name : '';
        $logged_email = is_user_logged_in() ? $current_user->user_email : '';
        ?>
        <div class="cyber-qa-solutions-container" style="font-family: system-ui, -apple-system, sans-serif;">
            <!-- Solution List Header -->
            <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1.5px solid rgba(0,255,65,0.2); padding-bottom: 15px; margin-bottom: 25px;">
                <h3 style="color: #fff; font-size: 18px; font-weight: 800; margin: 0; display: flex; align-items: center; gap: 10px;">
                    <i class="fa-solid fa-square-check" style="color: #00ff41; font-size: 20px;"></i>
                    <span>প্রযুক্তিগত উত্তর ও সমাধান সমূহ (<?php echo count($comments); ?>)</span>
                </h3>
                <span style="background: rgba(0,255,65,0.1); color: #00ff41; border: 1px solid rgba(0,255,65,0.3); font-size: 11px; font-weight: 800; padding: 4px 12px; border-radius: 20px; font-family: monospace;">
                    EXPERT FORUM
                </span>
            </div>

            <!-- Render Solutions List -->
            <?php if (!empty($comments)) : ?>
                <div class="qa-solutions-feed" style="display: flex; flex-direction: column; gap: 20px; margin-bottom: 35px;">
                    <?php foreach ($comments as $idx => $c) : 
                        $is_accepted = ($idx === 0);
                        $upvotes = get_comment_meta($c->comment_ID, 'qa_upvotes', true) ?: rand(2, 12);
                        $c_author = $c->comment_author ?: 'Cyber Developer';
                        $c_date = human_time_diff(strtotime($c->comment_date), current_time('timestamp')) . ' আগে';
                        $avatar_url = get_avatar_url($c->comment_author_email, ['size' => 45]) ?: 'https://www.gravatar.com/avatar/?d=mp';
                    ?>
                        <div class="qa-solution-card <?php echo $is_accepted ? 'accepted-solution' : ''; ?>" style="background: #090e17; border: 1.5px solid <?php echo $is_accepted ? 'rgba(0, 255, 65, 0.4)' : 'rgba(255, 255, 255, 0.08)'; ?>; border-radius: 14px; padding: 20px; box-shadow: <?php echo $is_accepted ? '0 0 20px rgba(0, 255, 65, 0.12)' : 'none'; ?>; position: relative;">
                            
                            <?php if ($is_accepted) : ?>
                                <div style="position: absolute; top: -12px; right: 20px; background: linear-gradient(135deg, #00ff41 0%, #00b32d 100%); color: #000; font-size: 10px; font-weight: 900; padding: 3px 12px; border-radius: 20px; text-transform: uppercase; letter-spacing: 0.5px; box-shadow: 0 4px 10px rgba(0,255,65,0.3);">
                                    <i class="fa-solid fa-circle-check"></i> Verified Best Solution
                                </div>
                            <?php endif; ?>

                            <!-- Solution Top Bar -->
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; border-bottom: 1px dashed rgba(255,255,255,0.06); padding-bottom: 12px;">
                                <div style="display: flex; align-items: center; gap: 12px;">
                                    <img src="<?php echo esc_url($avatar_url); ?>" alt="<?php echo esc_attr($c_author); ?>" style="width: 40px; height: 40px; border-radius: 50%; border: 1.5px solid <?php echo $is_accepted ? '#00ff41' : '#00f0ff'; ?>;" />
                                    <div>
                                        <div style="color: #fff; font-weight: 800; font-size: 14px; display: flex; align-items: center; gap: 6px;">
                                            <?php echo esc_html($c_author); ?>
                                            <span style="background: rgba(0, 240, 255, 0.1); color: #00f0ff; border: 1px solid rgba(0, 240, 255, 0.3); font-size: 9.5px; padding: 1px 6px; border-radius: 4px; font-family: monospace;">EXPERT NODE</span>
                                        </div>
                                        <div style="color: #8b949e; font-size: 11px; margin-top: 2px;">
                                            <i class="fa-regular fa-clock"></i> <?php echo esc_html($c_date); ?>
                                        </div>
                                    </div>
                                </div>

                                <div style="display: flex; align-items: center; gap: 8px; background: rgba(13,17,23,0.8); border: 1px solid rgba(255,255,255,0.08); padding: 4px 10px; border-radius: 20px; font-size: 12px; color: #00ff41; font-family: monospace;">
                                    <i class="fa-solid fa-thumbs-up"></i>
                                    <span><?php echo intval($upvotes); ?> Upvotes</span>
                                </div>
                            </div>

                            <!-- Solution Body Text -->
                            <div class="qa-solution-body" style="color: #e6edf3; font-size: 15px; line-height: 1.7; font-family: system-ui, sans-serif;">
                                <?php echo wpautop($c->comment_content); ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else : ?>
                <div style="background: rgba(13,21,39,0.5); border: 1px dashed rgba(0,255,65,0.2); border-radius: 12px; padding: 25px; text-align: center; color: #8b949e; margin-bottom: 30px;">
                    <p style="margin: 0 0 5px 0; font-weight: bold; color: #fff;">এখনো কোনো ব্যবহারকারী বা বিশেষজ্ঞ উত্তর প্রকাশ করেননি!</p>
                    <p style="margin: 0; font-size: 12.5px;">নিচের কমেন্ট ও উত্তর বক্সে আপনার টেকনিক্যাল সমাধানটি প্রথম পোস্ট করুন।</p>
                </div>
            <?php endif; ?>

            <!-- DEDICATED PROFESSIONAL Q&A SOLUTION SUBMISSION FORM -->
            <div class="qa-solution-submit-wrapper" style="background: #0d1527; border: 1.5px solid rgba(0,240,255,0.25); border-radius: 16px; padding: 25px; box-shadow: 0 10px 30px rgba(0,0,0,0.5);">
                <div style="margin-bottom: 20px; border-bottom: 1px solid rgba(255,255,255,0.08); padding-bottom: 12px;">
                    <h3 style="color: #00f0ff; font-size: 17px; font-weight: 850; margin: 0 0 5px 0; display: flex; align-items: center; gap: 8px;">
                        <i class="fa-solid fa-pen-nib" style="color: #00f0ff;"></i>
                        আপনার প্রযুক্তিগত উত্তর ও সমাধান পোস্ট করুন (Submit Expert Answer)
                    </h3>
                    <p style="color: #8b949e; font-size: 12.5px; margin: 0;">কোড স্নিপেট, সঠিক বিবরণ বা টিপস সহ সুন্দরভাবে আপনার সমাধানটি নিচে সাবমিট করুন:</p>
                </div>

                <form id="qa-solution-form" style="display: flex; flex-direction: column; gap: 15px;">
                    <input type="hidden" name="action" value="ilybd_submit_qa_solution" />
                    <input type="hidden" name="post_id" value="<?php echo esc_attr($post_id); ?>" />
                    <input type="hidden" name="security" value="<?php echo esc_attr($nonce); ?>" />

                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 15px;">
                        <div>
                            <label style="display: block; color: #c9d1d9; font-size: 12px; font-weight: bold; margin-bottom: 6px;">আপনার নাম (Author Name):</label>
                            <input type="text" name="author_name" value="<?php echo esc_attr($logged_name); ?>" placeholder="উদা: Tanvir Hossain" required style="width: 100%; background: #070a10; color: #fff; border: 1px solid rgba(255,255,255,0.15); padding: 10px 14px; border-radius: 8px; outline: none; font-size: 13px; box-sizing: border-box;" />
                        </div>
                        <div>
                            <label style="display: block; color: #c9d1d9; font-size: 12px; font-weight: bold; margin-bottom: 6px;">ইমেইল ঠিকানা (Email Address):</label>
                            <input type="email" name="author_email" value="<?php echo esc_attr($logged_email); ?>" placeholder="yourname@gmail.com" style="width: 100%; background: #070a10; color: #fff; border: 1px solid rgba(255,255,255,0.15); padding: 10px 14px; border-radius: 8px; outline: none; font-size: 13px; box-sizing: border-box;" />
                        </div>
                    </div>

                    <div>
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                            <label style="color: #c9d1d9; font-size: 12px; font-weight: bold;">বিস্তারিত সমাধান (Detailed Technical Solution):</label>
                            <button type="button" onclick="insertCodeTemplate()" style="background: rgba(0, 240, 255, 0.1); color: #00f0ff; border: 1px solid rgba(0, 240, 255, 0.3); padding: 3px 10px; border-radius: 4px; font-size: 10.5px; font-weight: bold; cursor: pointer;">
                                <i class="fa-solid fa-code"></i> Insert Code Block
                            </button>
                        </div>
                        <textarea id="qa_solution_content" name="solution_content" rows="6" placeholder="সমস্যার সুনির্দিষ্ট সমাধান, কোড স্নিপেট বা প্রয়োজনীয় দিকনির্দেশনা লিখুন..." required style="width: 100%; background: #070a10; color: #fff; border: 1px solid rgba(0,240,255,0.2); padding: 12px 15px; border-radius: 8px; outline: none; font-size: 14px; line-height: 1.6; font-family: system-ui, sans-serif; box-sizing: border-box; resize: vertical;"></textarea>
                    </div>

                    <div id="qa-solution-response-msg" style="display: none; padding: 12px; border-radius: 8px; font-size: 13px; font-weight: bold;"></div>

                    <button type="submit" id="qa-submit-solution-btn" style="background: linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color: #000; border: none; padding: 12px 25px; border-radius: 8px; font-weight: 900; font-size: 13.5px; cursor: pointer; transition: 0.2s; align-self: flex-start; display: inline-flex; align-items: center; gap: 8px; text-transform: uppercase;">
                        <span>🚀 সমাধান পোস্ট করুন (Submit Solution)</span>
                    </button>
                </form>
            </div>
        </div>

        <script>
        function insertCodeTemplate() {
            var textarea = document.getElementById('qa_solution_content');
            var codeBlock = "\n<pre><code>\n// এখানে আপনার সাইবার কোড বা সমাধান টি লিখুন\n</code></pre>\n";
            textarea.value += codeBlock;
            textarea.focus();
        }

        document.addEventListener('DOMContentLoaded', function() {
            var form = document.getElementById('qa-solution-form');
            if (!form) return;

            form.addEventListener('submit', function(e) {
                e.preventDefault();
                var btn = document.getElementById('qa-submit-solution-btn');
                var msgBox = document.getElementById('qa-solution-response-msg');
                
                btn.disabled = true;
                btn.style.opacity = '0.6';
                btn.innerHTML = '<span>⏳ উত্তর পোস্ট হচ্ছে...</span>';

                var formData = new FormData(form);

                fetch('<?php echo esc_url(admin_url("admin-ajax.php")); ?>', {
                    method: 'POST',
                    body: formData
                })
                .then(function(res) { return res.json(); })
                .then(function(data) {
                    msgBox.style.display = 'block';
                    if (data.success) {
                        msgBox.style.background = 'rgba(0, 255, 65, 0.15)';
                        msgBox.style.color = '#00ff41';
                        msgBox.style.border = '1px solid #00ff41';
                        msgBox.innerHTML = data.data.message;
                        form.reset();
                        setTimeout(function() {
                            window.location.reload();
                        }, 1200);
                    } else {
                        msgBox.style.background = 'rgba(255, 0, 60, 0.15)';
                        msgBox.style.color = '#ff003c';
                        msgBox.style.border = '1px solid #ff003c';
                        msgBox.innerHTML = data.data.message || 'ত্রুটি ঘটেছে!';
                        btn.disabled = false;
                        btn.style.opacity = '1';
                        btn.innerHTML = '<span>🚀 সমাধান পোস্ট করুন (Submit Solution)</span>';
                    }
                })
                .catch(function(err) {
                    msgBox.style.display = 'block';
                    msgBox.style.background = 'rgba(255, 0, 60, 0.15)';
                    msgBox.style.color = '#ff003c';
                    msgBox.style.border = '1px solid #ff003c';
                    msgBox.innerHTML = 'সার্ভার রেসপন্স দিতে সমস্যা হয়েছে!';
                    btn.disabled = false;
                    btn.style.opacity = '1';
                    btn.innerHTML = '<span>🚀 সমাধান পোস্ট করুন (Submit Solution)</span>';
                });
            });
        });
        </script>
        <?php
    }
}
