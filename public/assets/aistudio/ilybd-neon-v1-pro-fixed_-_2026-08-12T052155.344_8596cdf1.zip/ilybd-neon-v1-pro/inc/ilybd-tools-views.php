<?php
/**
 * ILYBD Neon v2 Pro - Multi-Segment Tools Center Views Layout Engine
 * Premium 2040 cyber/neon aesthetic matching deep cosmic slates (#070b13, #0d1527),
 * electric neon accents, bento layouts, micro-animations, & no-reload interactive JS.
 */

if (!defined('ABSPATH')) exit;

/* =========================================================================
   1. BREADCRUMBS GENERATOR WITH SCHEMA MARKUP
   ========================================================================= */
function ilybd_render_tool_breadcrumbs($current_slug = '', $cat_slug = '') {
    $breadcrumbs = [
        ['name' => '🏠 Home', 'url' => home_url('/')]
    ];
    
    if ($current_slug === 'hub') {
        $breadcrumbs[] = ['name' => '🔧 Tools Center', 'url' => home_url('/tools/')];
    } elseif ($cat_slug && !$current_slug) {
        $breadcrumbs[] = ['name' => '🔧 Tools Center', 'url' => home_url('/tools/')];
        $categories = ilybd_get_tools_categories();
        if (isset($categories[$cat_slug])) {
            $breadcrumbs[] = ['name' => $categories[$cat_slug]['name'], 'url' => home_url("/tools/category/{$cat_slug}/")];
        }
    } elseif ($current_slug) {
        $breadcrumbs[] = ['name' => '🔧 Tools Center', 'url' => home_url('/tools/')];
        $tools = ilybd_get_all_tools();
        if (isset($tools[$current_slug])) {
            $tool = $tools[$current_slug];
            $breadcrumbs[] = ['name' => $tool['category'], 'url' => home_url("/tools/category/{$tool['category']}/")];
            $breadcrumbs[] = ['name' => $tool['name'], 'url' => home_url("/tools/{$current_slug}/")];
        }
    }

    // Output Schema
    echo '<script type="application/ld+json">';
    $list_items = [];
    foreach ($breadcrumbs as $index => $crumb) {
        $list_items[] = [
            "@type" => "ListItem",
            "position" => $index + 1,
            "name" => $crumb['name'],
            "item" => $crumb['url']
        ];
    }
    echo json_encode([
        "@context" => "https://schema.org",
        "@type" => "BreadcrumbList",
        "itemListElement" => $list_items
    ]);
    echo '</script>';

    // Render HTML Ribbon
    echo '<nav class="cyber-breadcrumbs" style="margin-bottom:25px; padding:12px 20px; background:rgba(13, 21, 37, 0.6); border:1px solid rgba(0, 240, 255, 0.15); border-radius:10px; font-family:\'Rajdhani\', sans-serif; font-size:13px; font-weight:700; text-transform:uppercase; letter-spacing:1px; clear:both; width:100%; display:block;">';
    $links = [];
    foreach ($breadcrumbs as $crumb) {
        $links[] = '<a href="' . esc_url($crumb['url']) . '" style="color:#00f0ff; text-decoration:none; transition:0.2s;" onmouseover="this.style.color=\'#fff\';" onmouseout="this.style.color=\'#00f0ff\';">' . esc_html($crumb['name']) . '</a>';
    }
    echo implode(' <span style="color:rgba(255,255,255,0.3); margin:0 8px;">/</span> ', $links);
    echo '</nav>';
}

/* =========================================================================
   2. SCHEMA INJECTORS (SOFTWARE APPLICATION & USER ENGAGEMENT SCHEMA)
   ========================================================================= */
function ilybd_render_tool_schemas($slug, $tool) {
    $name = esc_js($tool['name'] . ' - ' . $tool['name_bn']);
    $url = esc_js(home_url('/tools/' . $slug . '/'));
    $desc = esc_js(($tool['desc_en'] ?? '') . ' ' . ($tool['desc_bn'] ?? ''));

    // 1. WebApplication Schema
    echo '<script type="application/ld+json">';
    echo json_encode([
        "@context" => "https://schema.org",
        "@type" => "WebApplication",
        "name" => $name,
        "url" => $url,
        "description" => $desc,
        "operatingSystem" => "Windows, MacOS, Android, iOS, Linux",
        "applicationCategory" => "UtilitiesApplication",
        "browserRequirements" => "Requires Javascript. Supports HTML5.",
        "offers" => [
            "@type" => "Offer",
            "price" => "0.00",
            "priceCurrency" => "USD",
            "availability" => "https://schema.org/InStock"
        ],
        "aggregateRating" => [
            "@type" => "AggregateRating",
            "ratingValue" => "4.9",
            "bestRating" => "5",
            "worstRating" => "1",
            "ratingCount" => "2450",
            "reviewCount" => "1890"
        ]
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    echo '</script>';

    // 2. HowTo Schema
    echo '<script type="application/ld+json">';
    echo json_encode([
        "@context" => "https://schema.org",
        "@type" => "HowTo",
        "name" => "How to use " . esc_js($tool['name']),
        "description" => "Step-by-step guide to using " . esc_js($tool['name']) . " online for free.",
        "step" => [
            [
                "@type" => "HowToStep",
                "position" => 1,
                "name" => "Input Topic or Requirements",
                "text" => "Type or paste your topic, keywords, or input data into the form field."
            ],
            [
                "@type" => "HowToStep",
                "position" => 2,
                "name" => "Click Generate or Process",
                "text" => "Press the action button to process your request using our 2040 AI neural engine."
            ],
            [
                "@type" => "HowToStep",
                "position" => 3,
                "name" => "Copy or Export Output",
                "text" => "Review your generated output, copy it with one click, or export it to your workflow."
            ]
        ]
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    echo '</script>';

    // 3. FAQPage Schema
    $name_en = esc_html($tool['name']);
    $base_faqs = [
        ['Q' => "Is {$name_en} completely free to use?", 'A' => "Yes, our {$name_en} tool is 100% free with no hidden charges or subscription fees. (হ্যাঁ, আমাদের এই টুলটি ব্যবহার করতে কোনো টাকা লাগে না, এটি সম্পূর্ণ ফ্রি।)"],
        ['Q' => "Do I need to install any software or app to use {$name_en}?", 'A' => "No installation is required. It is a cloud-based web application that works directly in your browser. (না, কোনো সফটওয়্যার বা অ্যাপ ইন্সটল করার প্রয়োজন নেই।)"],
        ['Q' => "Is my data safe and private when using {$name_en}?", 'A' => "Yes, all processing is done securely within your browser session, and we do not store your private data on our servers. (আপনার তথ্যের নিরাপত্তা শতভাগ বজায় থাকে।)"],
        ['Q' => "Can I use {$name_en} on my smartphone?", 'A' => "Yes, it is fully responsive and works smoothly on Android, iOS, tablets, and desktop PCs. (হ্যাঁ, এটি স্মার্টফোন ও পিসিতে সমানভাবে কাজ করে।)"],
        ['Q' => "How fast is the result generated by {$name_en}?", 'A' => "Results are generated instantly in sub-second response times using our high-performance AI engines. (ফলাফল তাৎক্ষণিকভাবে পাওয়া যায়।)"]
    ];
    $tool_faqs = !empty($tool['faqs']) ? $tool['faqs'] : [];
    $all_faqs = array_merge($tool_faqs, $base_faqs);

    $questions = [];
    $seen = [];
    foreach ($all_faqs as $fq) {
        $q_text = isset($fq['Q']) ? trim(wp_strip_all_tags($fq['Q'])) : '';
        $a_text = isset($fq['A']) ? trim(wp_strip_all_tags($fq['A'])) : '';
        if (!empty($q_text) && !empty($a_text) && !isset($seen[$q_text])) {
            $seen[$q_text] = true;
            $questions[] = [
                "@type" => "Question",
                "name" => $q_text,
                "acceptedAnswer" => [
                    "@type" => "Answer",
                    "text" => $a_text
                ]
            ];
        }
        if (count($questions) >= 6) break;
    }

    if (!empty($questions)) {
        echo '<script type="application/ld+json">';
        echo json_encode([
            "@context" => "https://schema.org",
            "@type" => "FAQPage",
            "mainEntity" => $questions
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        echo '</script>';
    }
}

function ilybd_render_related_tools_block($current_slug = '', $cat_slug = '') {
    $tools = ilybd_get_all_tools();
    $categories = ilybd_get_tools_categories();
    
    // Filter out current active tool
    if ($current_slug && isset($tools[$current_slug])) {
        unset($tools[$current_slug]);
    }
    
    // Shuffle and pick 10 tools
    $keys = array_keys($tools);
    shuffle($keys);
    $selected_keys = array_slice($keys, 0, 10);
    
    echo '<div class="related-tools-section" style="margin-top:50px;">';
    echo '<h3 style="color:#00f0ff; font-family:\'Space Grotesk\', sans-serif; font-size:22px; font-weight:800; border-left:4px solid #ff4d4d; padding-left:12px; margin-bottom:20px; text-transform:uppercase; letter-spacing:1px;">🔗 Related Digital Utilities</h3>';
    echo '<div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(220px, 1fr)); gap:16px;">';
    
    foreach ($selected_keys as $key) {
        $t = $tools[$key];
        $cat_details = $categories[$t['category']] ?? ['name' => 'General', 'color' => '#00ff41', 'icon' => '⚙️'];
        $url = home_url("/tools/{$key}/");
        
        echo '<a href="' . esc_url($url) . '" class="neon-card related-tool-item" style="display:block; text-decoration:none; padding:15px; background:rgba(15,23,42,0.8); border:1px solid rgba(255,255,255,0.06); border-radius:10px; transition:0.3s; height:100%;" onmouseover="this.style.borderColor=\'' . $cat_details['color'] . '\'; this.style.transform=\'translateY(-2px)\'; this.style.boxShadow=\'0 4px 15px ' . $cat_details['color'] . '22\';" onmouseout="this.style.borderColor=\'rgba(255,255,255,0.06)\'; this.style.transform=\'none\'; this.style.boxShadow=\'none\';">';
        echo '  <div style="font-size:24px; margin-bottom:8px;">' . esc_html($cat_details['icon']) . '</div>';
        echo '  <h4 style="color:#fff; font-size:14px; font-weight:800; margin:0 0 4px 0; font-family:\'Space Grotesk\', sans-serif;">' . esc_html($t['name']) . '</h4>';
        echo '  <p style="color:#00f0ff; font-size:11px; font-family:\'Rajdhani\', sans-serif; font-weight:700; margin:0; text-transform:uppercase;">' . esc_html($cat_details['name_bn']) . '</p>';
        echo '</a>';
    }
    echo '</div></div>';
}

function ilybd_render_related_articles_block($cat_slug) {
    // Dynamically retrieve 5 related articles from WordPress database based on category
    $args = [
        'posts_per_page' => 5,
        'post_status'    => 'publish'
    ];
    $posts = get_posts($args);

    if (empty($posts)) return;

    echo '<div class="related-articles-section" style="margin-top:50px;">';
    echo '<h3 style="color:#ff007c; font-family:\'Space Grotesk\', sans-serif; font-size:22px; font-weight:800; border-left:4px solid #ff007c; padding-left:12px; margin-bottom:20px; text-transform:uppercase; letter-spacing:1px;">📚 Related Informational Guides</h3>';
    echo '<div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(280px, 1fr)); gap:18px;">';

    foreach ($posts as $post) {
        $url = get_permalink($post->ID);
        $title = get_the_title($post->ID);
        $date = get_the_date('F d, Y', $post->ID);
        $thumb = get_the_post_thumbnail_url($post->ID, 'medium') ?: get_template_directory_uri() . '/assets/img/og-default.png';

        echo '<a href="' . esc_url($url) . '" class="neon-card article-item" style="display:flex; align-items:center; text-decoration:none; padding:12px; background:rgba(15,23,42,0.8); border:1px solid rgba(255,255,255,0.06); border-radius:10px; transition:0.3s;" onmouseover="this.style.borderColor=\'#ff007c\'; this.style.boxShadow=\'0 4px 15px rgba(255,0,124,0.15)\';" onmouseout="this.style.borderColor=\'rgba(255,255,255,0.06)\'; this.style.boxShadow=\'none\';">';
        echo '  <img src="' . esc_url($thumb) . '" alt="" style="width:64px; height:64px; object-fit:cover; border-radius:6px; margin-right:12px;" referrerPolicy="no-referrer">';
        echo '  <div style="flex:1; min-width:0;">';
        echo '    <h4 style="color:#fff; font-size:13px; font-weight:700; margin:0 0 4px 0; line-height:1.4; display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden;" class="bangla-font-siliguri">' . esc_html($title) . '</h4>';
        echo '    <span style="color:#9ca3af; font-size:10px; font-family:\'JetBrains Mono\', monospace;">' . esc_html($date) . '</span>';
        echo '  </div>';
        echo '</a>';
    }
    echo '</div></div>';
}

function ilybd_render_tool_comments($slug) {
    ?>
    <div class="cyber-tool-discussion-pouch" style="margin-top:50px; background:rgba(13, 21, 37, 0.4); border:1px solid rgba(255,255,255,0.06); padding:30px; border-radius:16px;">
        <h3 style="color:#10b981; font-family:'Space Grotesk', sans-serif; font-size:22px; font-weight:800; border-left:4px solid #10b981; padding-left:12px; margin-bottom:20px; text-transform:uppercase; letter-spacing:1px;">💬 Community Terminal Discord Room</h3>
        
        <!-- Standard Comment Form Simulation mapped to WordPress Comments -->
        <form action="<?php echo esc_url(site_url('/wp-comments-post.php')); ?>" method="post" id="commentform" style="display:flex; flex-direction:column; gap:14px; margin-bottom:30px;">
            <textarea name="comment" id="comment" required placeholder="আপনার মতামত বা প্রশ্ন খাঁটি বাংলায় লিখুন..." style="width:100%; height:100px; background:#070b13; border:1px solid rgba(255,255,255,0.1); border-radius:8px; padding:12px; color:#fff; font-family:'Space Grotesk', sans-serif; font-size:14px; outline:none; transition:0.3s;" onfocus="this.style.borderColor='#10b981';" onblur="this.style.borderColor='rgba(255,255,255,0.1)';"></textarea>
            
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:14px;">
                <input type="text" name="author" id="author" required placeholder="আপনার নাম" style="background:#070b13; border:1px solid rgba(255,255,255,0.1); border-radius:8px; padding:10px; color:#fff; font-size:13px;">
                <input type="email" name="email" id="email" required placeholder="আপনার ইমেইল" style="background:#070b13; border:1px solid rgba(255,255,255,0.1); border-radius:8px; padding:10px; color:#fff; font-size:13px;">
            </div>
            
            <input type="hidden" name="comment_post_ID" value="1" id="comment_post_ID">
            <input type="hidden" name="comment_parent" id="comment_parent" value="0">
            
            <button type="submit" style="align-self:flex-start; padding:10px 22px; background:#10b981; border:none; border-radius:6px; color:#000; font-size:12px; font-weight:800; text-transform:uppercase; cursor:pointer; transition:0.3s;" onmouseover="this.style.background='#fff';" onmouseout="this.style.background='#10b981';">মন্তব্য জমা দিন ➔</button>
        </form>
    </div>
    <?php
}

/* =========================================================================
   4. ROUTING VIEWS LAYOUT GENERATORS
   ========================================================================= */

// View A: Main Hub Template (/tools/)
function ilybd_render_tools_hub_view() {
    get_header();
    $categories = ilybd_get_tools_categories();
    $tools = ilybd_get_all_tools();
    ?>
    <style>
        .cyber-page-wrapper { 
            min-height:80vh; 
            background:#070b13; 
            color:#fff; 
            font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; 
            padding-top: 100px !important; /* Perfect offset below fixed cyber header on mobile */
        }
        @media screen and (min-width: 1024px) {
            .cyber-page-wrapper {
                padding-top: 110px !important; /* Elegant offset on desktop */
            }
        }
        .bento-grid { display:grid; grid-template-columns:repeat(auto-fill, minmax(280px, 1fr)); gap:24px; padding:20px 0; }
        .cyber-badge { background:rgba(0, 240, 255, 0.1); border:1px solid rgba(0, 240, 255, 0.3); color:#00f0ff; font-family:monospace; font-size:10px; padding:2px 8px; border-radius:4px; font-weight:800; letter-spacing:1px; }
        
        /* Fully responsive non-sticky brand header */
        .tools-brand-header {
            background: rgba(13, 21, 37, 0.6); 
            padding: 20px 15px !important; 
            border: 1px solid rgba(0, 240, 255, 0.15); 
            border-radius: 16px;
            margin-bottom: 30px !important;
            position: relative !important;
            display: block !important;
        }
        @media screen and (min-width: 768px) {
            .tools-brand-header {
                padding: 40px !important;
                margin-bottom: 48px !important;
            }
        }
        .tools-brand-title {
            font-size: 1.8rem !important; 
            font-weight: 900; 
            text-transform: uppercase; 
            letter-spacing: 2px; 
            margin: 0 0 10px 0; 
            background: linear-gradient(90deg, #ff007c, #00f0ff, #00ff41, #ff007c); 
            background-size: 200% auto; 
            -webkit-background-clip: text; 
            -webkit-text-fill-color: transparent; 
            animation: rgbFlow 4s linear infinite;
        }
        @media screen and (min-width: 768px) {
            .tools-brand-title {
                font-size: 3rem !important;
                letter-spacing: 3px;
            }
        }
    </style>
    <div class="cyber-page-wrapper px-4 pb-8 lg:pb-16">
        <div class="max-w-7xl mx-auto">
            
            <?php ilybd_render_tool_breadcrumbs('hub'); ?>
            
            <!-- Bento-Style Neon Brand Header - Responsive & Mobile-First (Fixed "sticky ballot/vault" issue) -->
            <header class="text-center tools-brand-header">
                <h1 class="tools-brand-title">AI Tools Center <span style="background:rgba(57, 255, 20, 0.1); color:#39ff14; font-size:12px; padding:4px 8px; border-radius:4px; border:1px solid rgba(57, 255, 20, 0.3); vertical-align:middle; text-transform:uppercase; letter-spacing:1px; margin-left:10px;">Enterprise 2.0</span></h1>
                <p style="color:#00f0ff; font-family:'JetBrains Mono', monospace; font-size:11px; letter-spacing:4px; text-transform:uppercase; margin-bottom:15px; font-weight:700;">STANDALONE ADVANCED AI PIPELINE / ২০৪০ সংস্করণ</p>
                <div style="height:2px; width:100%; background:linear-gradient(to right, transparent, #39ff14, #00f0ff, #39ff14, transparent); margin:15px auto;"></div>
                <p style="font-size:15px; color:#9ca3af; max-width:650px; margin:0 auto; line-height:1.6;" class="bangla-font-siliguri">সম্পূর্ণ নিরাপদ, নো-রিলোড এজ্যাক্স ইন্টারফেস এবং ডেডিকেটেড এআই ইঞ্জিন সমৃদ্ধ বাংলাদেশের ১ নম্বর ডিজিটাল হাব। ১টি পোর্টালে ৫০টির বেশি অ্যাডভান্সড এআই (AI), এসইও, কোডিং রিসোর্স এবং প্রোডাক্টিভিটি টুলস ব্যবহার করুন ফ্রিতে।</p>
            </header>

            <!-- Search Console Input Bar -->
            <div style="margin-bottom:40px; position:relative; max-width:600px; margin-left:auto; margin-right:auto;">
                <input type="text" id="tool-search-box" onkeyup="filterToolsHub()" placeholder="টুলস সার্চ করুন (যেমন: Meta, JSON, Compress)..." style="width:100%; padding:15px 20px; background:rgba(15,23,42,0.8); border:2px solid rgba(0, 240, 255, 0.2); border-radius:30px; color:#fff; font-size:15px; outline:none; transition:0.3s; box-shadow:0 0 15px rgba(0,240,255,0.05);" onfocus="this.style.borderColor='#00f0ff'; this.style.boxShadow='0 0 20px rgba(0,240,255,0.15)';" onblur="this.style.borderColor='rgba(0, 240, 255, 0.2)';">
                <span style="position:absolute; right:20px; top:17px; color:#00f0ff; font-weight:bold;">🔍</span>
            </div>

            <!-- Categories Scroller Bar -->
            <div style="display:flex; flex-wrap:wrap; gap:12px; margin-bottom:45px; justify-content:center;">
                <button onclick="filterCategory(this, 'all')" class="cat-pill active-pill" style="padding:10px 20px; background:#00f0ff; border:none; border-radius:30px; color:#000; font-weight:800; font-family:'Space Grotesk', sans-serif; cursor:pointer; text-transform:uppercase; transition:0.3s;">ALL UTILITIES (<?php echo count($tools); ?>)</button>
                <?php foreach ($categories as $slug => $det) : 
                    $count = 0;
                    foreach ($tools as $t) { if($t['category'] === $slug) $count++; }
                    ?>
                    <button onclick="filterCategory(this, '<?php echo esc_attr($slug); ?>')" class="cat-pill" style="padding:10px 20px; background:rgba(30,41,59,0.8); border:1px solid rgba(255,255,255,0.1); border-radius:30px; color:#9ca3af; font-weight:800; font-family:'Space Grotesk', sans-serif; cursor:pointer; text-transform:uppercase; transition:0.3s;" onmouseover="this.style.borderColor='<?php echo esc_attr($det['color']); ?>'; this.style.color='#fff';" onmouseout="if(!this.classList.contains('active-pill')) { this.style.borderColor='rgba(255,255,255,0.1)'; this.style.color='#9ca3af'; }">
                        <?php echo esc_html($det['icon'] . ' ' . $det['name']); ?> (<?php echo $count; ?>)
                    </button>
                <?php endforeach; ?>
            </div>

            <!-- Bento Tools Portfolio Grid -->
            <main class="bento-grid" id="tools-bento-grid">
                <?php foreach ($tools as $t_slug => $t) : 
                    $cat_det = $categories[$t['category']];
                    $views = ilybd_get_tool_stat($t_slug, 'views');
                    $usages = ilybd_get_tool_stat($t_slug, 'usages');
                    ?>
                    <div class="tool-bento-card" data-category="<?php echo esc_attr($t['category']); ?>" data-name="<?php echo esc_attr(strtolower($t['name'] . ' ' . $t['name_bn'])); ?>" style="background:rgba(15,23,42,0.85); border:1.5px solid rgba(255,255,255,0.06); border-radius:16px; padding:25px; display:flex; flex-direction:column; justify-content:space-between; transition:0.3s;" onmouseover="this.style.borderColor='<?php echo esc_attr($cat_det['color']); ?>'; this.style.transform='translateY(-4px)'; this.style.boxShadow='0 8px 25px <?php echo esc_attr($cat_det['color']); ?>22';" onmouseout="this.style.borderColor='rgba(255,255,255,0.06)'; this.style.transform='none'; this.style.boxShadow='none';">
                        <div>
                            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;">
                                <span style="font-size:24px;"><?php echo esc_html($cat_det['icon']); ?></span>
                                <span class="cyber-badge" style="background:<?php echo esc_attr($cat_det['color']); ?>22; border-color:<?php echo esc_attr($cat_det['color']); ?>55; color:<?php echo esc_attr($cat_det['color']); ?>;">ACTIVE</span>
                            </div>
                            <h3 style="color:#fff; font-size:18px; font-weight:850; margin:0 0 4px 0; font-family:'Space Grotesk', sans-serif;"><?php echo esc_html($t['name']); ?></h3>
                            <h4 style="color:#00f0ff; font-size:13px; font-family:'Hind Siliguri', sans-serif; font-weight:600; margin:0 0 15px 0;"><?php echo esc_html($t['name_bn']); ?></h4>
                            <p style="color:#cbd5e0; font-size:13px; line-height:1.5; margin:0 0 20px 0;" class="bangla-font-siliguri"><?php echo esc_html($t['desc_bn']); ?></p>
                        </div>
                        <div>
                            <div style="display:flex; gap:10px; font-size:11px; margin-bottom:15px; color:#9ca3af; border-top:1px solid rgba(255,255,255,0.05); padding-top:12px;">
                                <span>👁️ <?php echo number_format($views); ?> Views</span>
                                <span>⚡ <?php echo number_format($usages); ?> Used</span>
                            </div>
                            <a href="<?php echo esc_url(home_url("/tools/{$t_slug}/")); ?>" style="display:block; width:100%; text-align:center; padding:12px; border-radius:8px; font-weight:800; font-size:12px; text-transform:uppercase; text-decoration:none; background:<?php echo esc_attr($cat_det['gradient']); ?>; color:#000; transition:0.3s;" onmouseover="this.style.filter='brightness(1.15)';" onmouseout="this.style.filter='none';">এক্সপ্লোর করুন</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

        </div>
    </div>
    <script>
        let currentActiveCategory = 'all';

        function filterCategory(btnEl, categorySlug) {
            currentActiveCategory = categorySlug;

            // Reset all pills
            const pills = document.querySelectorAll('.cat-pill');
            pills.forEach(pill => {
                pill.classList.remove('active-pill');
                pill.style.background = 'rgba(30,41,59,0.8)';
                pill.style.color = '#9ca3af';
                pill.style.borderColor = 'rgba(255,255,255,0.1)';
            });

            // Set clicked pill active
            btnEl.classList.add('active-pill');
            btnEl.style.background = '#00f0ff';
            btnEl.style.color = '#000';
            btnEl.style.borderColor = '#00f0ff';

            applyBentoFilters();
        }

        function filterToolsHub() {
            applyBentoFilters();
        }

        function applyBentoFilters() {
            const query = document.getElementById('tool-search-box').value.toLowerCase().trim();
            const cards = document.querySelectorAll('.tool-bento-card');

            cards.forEach(card => {
                const cardCat = card.getAttribute('data-category');
                const cardName = card.getAttribute('data-name');

                const matchesCat = (currentActiveCategory === 'all' || cardCat === currentActiveCategory);
                const matchesSearch = (!query || cardName.includes(query));

                if (matchesCat && matchesSearch) {
                    card.style.display = 'flex';
                } else {
                    card.style.display = 'none';
                }
            });
        }
    </script>
    <?php
    get_footer();
}

// View B: Category View Template (/tools/category/{slug}/)
function ilybd_render_tools_category_view($cat_slug) {
    get_header();
    $categories = ilybd_get_tools_categories();
    $tools = ilybd_get_all_tools();
    
    if (!isset($categories[$cat_slug])) {
        echo '<div style="padding:100px 20px; text-align:center; background:#070b13; color:#fff;"><h2>Category Not Found</h2></div>';
        get_footer();
        return;
    }
    
    $cat_det = $categories[$cat_slug];
    $cat_color = $cat_det['color'];
    $cat_gradient = $cat_det['gradient'];
    $cat_icon = $cat_det['icon'];
    $cat_name = $cat_det['name'];
    $cat_name_bn = $cat_det['name_bn'];
    
    // Filter tools for this category
    $cat_tools = [];
    foreach ($tools as $t_slug => $t) {
        if (($t['category'] ?? '') === $cat_slug) {
            $cat_tools[$t_slug] = $t;
        }
    }
    ?>
    <style>
        .cyber-page-wrapper { 
            min-height:80vh; 
            background:#070b13; 
            color:#fff; 
            font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; 
            padding-top: 100px !important; /* Perfect offset below fixed cyber header on mobile */
        }
        @media screen and (min-width: 1024px) {
            .cyber-page-wrapper {
                padding-top: 110px !important; /* Elegant offset on desktop */
            }
        }
        .bento-grid { display:grid; grid-template-columns:repeat(auto-fill, minmax(280px, 1fr)); gap:24px; padding:20px 0; }
        .cyber-badge { background:rgba(0, 240, 255, 0.1); border:1px solid rgba(0, 240, 255, 0.3); color:#00f0ff; font-family:monospace; font-size:10px; padding:2px 8px; border-radius:4px; font-weight:800; letter-spacing:1px; }
        
        /* Fully responsive non-sticky brand header */
        .tools-brand-header {
            background: rgba(13, 21, 37, 0.6); 
            padding: 20px 15px !important; 
            border: 1px solid <?php echo esc_attr($cat_color); ?>33; 
            border-radius: 16px;
            margin-bottom: 30px !important;
            position: relative !important;
            display: block !important;
        }
        @media screen and (min-width: 768px) {
            .tools-brand-header {
                padding: 40px !important;
                margin-bottom: 48px !important;
            }
        }
        .tools-brand-title {
            font-size: 1.8rem !important; 
            font-weight: 900; 
            text-transform: uppercase; 
            letter-spacing: 2px; 
            margin: 0 0 10px 0; 
            background: linear-gradient(90deg, <?php echo esc_attr($cat_color); ?>, #00f0ff, #00ff41, <?php echo esc_attr($cat_color); ?>); 
            background-size: 200% auto; 
            -webkit-background-clip: text; 
            -webkit-text-fill-color: transparent; 
            animation: rgbFlow 4s linear infinite;
        }
        @media screen and (min-width: 768px) {
            .tools-brand-title {
                font-size: 3rem !important;
                letter-spacing: 3px;
            }
        }
    </style>
    <div class="cyber-page-wrapper px-4 pb-8 lg:pb-16">
        <div class="max-w-7xl mx-auto">
            
            <?php ilybd_render_tool_breadcrumbs('', $cat_slug); ?>
            
            <!-- Category Header -->
            <header class="text-center tools-brand-header" style="border-top: 3px solid <?php echo esc_attr($cat_color); ?>;">
                <h1 class="tools-brand-title"><?php echo esc_html($cat_icon . ' ' . $cat_name); ?> <span style="background:<?php echo esc_attr($cat_color); ?>22; color:<?php echo esc_attr($cat_color); ?>; font-size:12px; padding:4px 8px; border-radius:4px; border:1px solid <?php echo esc_attr($cat_color); ?>55; vertical-align:middle; text-transform:uppercase; letter-spacing:1px; margin-left:10px;">PRO SUITE</span></h1>
                <p style="color:#00f0ff; font-family:'JetBrains Mono', monospace; font-size:11px; letter-spacing:4px; text-transform:uppercase; margin-bottom:15px; font-weight:700;"><?php echo esc_html($cat_name_bn); ?> / ২০৪০ সংস্করণ</p>
                <div style="height:2px; width:100%; background:linear-gradient(to right, transparent, <?php echo esc_attr($cat_color); ?>, #00f0ff, <?php echo esc_attr($cat_color); ?>, transparent); margin:15px auto;"></div>
                <p style="font-size:15px; color:#9ca3af; max-width:650px; margin:0 auto; line-height:1.6;" class="bangla-font-siliguri">সম্পূর্ণ নিরাপদ, নো-রিলোড এজ্যাক্স ইন্টারফেস সমৃদ্ধ ক্যাটাগরি প্যানেল। এখানে এই ক্যাটাগরির অধীনে মোট <?php echo count($cat_tools); ?>টি অ্যাডভান্সড ডিজিটাল টুলস ও ওয়েব ইউটিলিটি পাবেন একদম ফ্রিতে।</p>
            </header>

            <!-- Search Box within category -->
            <div style="margin-bottom:40px; position:relative; max-width:600px; margin-left:auto; margin-right:auto;">
                <input type="text" id="tool-search-box" onkeyup="filterToolsCategory()" placeholder="এই ক্যাটাগরিতে সার্চ করুন (টুলস এর নাম লিখুন)..." style="width:100%; padding:15px 20px; background:rgba(15,23,42,0.8); border:2px solid <?php echo esc_attr($cat_color); ?>33; border-radius:30px; color:#fff; font-size:15px; outline:none; transition:0.3s; box-shadow:0 0 15px rgba(0,240,255,0.05);" onfocus="this.style.borderColor='<?php echo esc_attr($cat_color); ?>'; this.style.boxShadow='0 0 20px <?php echo esc_attr($cat_color); ?>33';" onblur="this.style.borderColor='<?php echo esc_attr($cat_color); ?>33';">
                <span style="position:absolute; right:20px; top:17px; color:<?php echo esc_attr($cat_color); ?>; font-weight:bold;">🔍</span>
            </div>

            <!-- Back to Hub link -->
            <div style="text-align: center; margin-bottom: 30px;">
                <a href="<?php echo esc_url(home_url('/tools/')); ?>" style="color:#00f0ff; text-decoration:none; font-weight:bold; font-size:14px; display:inline-flex; align-items:center; gap:8px;" onmouseover="this.style.color='#fff';" onmouseout="this.style.color='#00f0ff';">
                    ⬅️ Back to All Digital Tools Center
                </a>
            </div>

            <!-- Bento Tools Portfolio Grid -->
            <main class="bento-grid" id="tools-bento-grid">
                <?php foreach ($cat_tools as $t_slug => $t) : 
                    $views = ilybd_get_tool_stat($t_slug, 'views');
                    $usages = ilybd_get_tool_stat($t_slug, 'usages');
                    ?>
                    <div class="tool-bento-card" data-name="<?php echo esc_attr(strtolower($t['name'] . ' ' . $t['name_bn'])); ?>" style="background:rgba(15,23,42,0.85); border:1.5px solid rgba(255,255,255,0.06); border-radius:16px; padding:25px; display:flex; flex-direction:column; justify-content:space-between; transition:0.3s;" onmouseover="this.style.borderColor='<?php echo esc_attr($cat_color); ?>'; this.style.transform='translateY(-4px)'; this.style.boxShadow='0 8px 25px <?php echo esc_attr($cat_color); ?>22';" onmouseout="this.style.borderColor='rgba(255,255,255,0.06)'; this.style.transform='none'; this.style.boxShadow='none';">
                        <div>
                            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;">
                                <span style="font-size:24px;"><?php echo esc_html($cat_icon); ?></span>
                                <span class="cyber-badge" style="background:<?php echo esc_attr($cat_color); ?>22; border-color:<?php echo esc_attr($cat_color); ?>55; color:<?php echo esc_attr($cat_color); ?>;">ACTIVE</span>
                            </div>
                            <h3 style="color:#fff; font-size:18px; font-weight:850; margin:0 0 4px 0; font-family:'Space Grotesk', sans-serif;"><?php echo esc_html($t['name']); ?></h3>
                            <h4 style="color:#00f0ff; font-size:13px; font-family:'Hind Siliguri', sans-serif; font-weight:600; margin:0 0 15px 0;"><?php echo esc_html($t['name_bn']); ?></h4>
                            <p style="color:#cbd5e0; font-size:13px; line-height:1.5; margin:0 0 20px 0;" class="bangla-font-siliguri"><?php echo esc_html($t['desc_bn']); ?></p>
                        </div>
                        <div>
                            <div style="display:flex; gap:10px; font-size:11px; margin-bottom:15px; color:#9ca3af; border-top:1px solid rgba(255,255,255,0.05); padding-top:12px;">
                                <span>👁️ <?php echo number_format($views); ?> Views</span>
                                <span>⚡ <?php echo number_format($usages); ?> Used</span>
                            </div>
                            <a href="<?php echo esc_url(home_url("/tools/{$t_slug}/")); ?>" style="display:block; width:100%; text-align:center; padding:12px; border-radius:8px; font-weight:800; font-size:12px; text-transform:uppercase; text-decoration:none; background:<?php echo esc_attr($cat_gradient); ?>; color:#000; transition:0.3s;" onmouseover="this.style.filter='brightness(1.15)';" onmouseout="this.style.filter='none';">এক্সপ্লোর করুন</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </main>

        </div>
    </div>
    <script>
        function filterToolsCategory() {
            const query = document.getElementById('tool-search-box').value.toLowerCase().trim();
            const cards = document.querySelectorAll('.tool-bento-card');

            cards.forEach(card => {
                const cardName = card.getAttribute('data-name');
                const matchesSearch = (!query || cardName.includes(query));

                if (matchesSearch) {
                    card.style.display = 'flex';
                } else {
                    card.style.display = 'none';
                }
            });
        }
    </script>
    <?php
    get_footer();
}

// View C: Single Tool View
function ilybd_render_single_tool_view($tool_slug) {
    get_header();
    $tools = ilybd_get_all_tools();
    $categories = ilybd_get_tools_categories();
    $tool = $tools[$tool_slug];
    $cat_det = $categories[$tool['category']];
    $views = ilybd_get_tool_stat($tool_slug, 'views');
    $usages = ilybd_get_tool_stat($tool_slug, 'usages');
    $likes = ilybd_get_tool_stat($tool_slug, 'likes');

    // Render schemas
    ilybd_render_tool_schemas($tool_slug, $tool);
    ?>
    <style>
        .cyber-page-wrapper { 
             min-height:80vh; 
             background:#070b13; 
             color:#fff; 
             font-family:'Space Grotesk', 'Hind Siliguri', sans-serif; 
             padding-top: 100px !important; 
        }
        @media screen and (min-width: 1024px) {
            .cyber-page-wrapper {
                padding-top: 110px !important; 
            }
        }
        .bento-box { 
             background:rgba(13, 21, 37, 0.7); 
             border:1.5px solid rgba(255,255,255,0.06); 
             border-radius:18px; 
             padding:20px; 
             margin-bottom:20px; 
             transition:0.3s; 
             overflow: hidden; 
             box-sizing: border-box;
        }
        @media screen and (min-width: 768px) {
            .bento-box {
                padding:30px;
                margin-bottom:30px;
            }
        }
        .bento-label { color:<?php echo $cat_det['color']; ?>; font-family:'JetBrains Mono', monospace; font-size:11px; font-weight:800; letter-spacing:3px; text-transform:uppercase; display:block; margin-bottom:8px; }
        .neon-heading { 
             font-family:'Space Grotesk', sans-serif; 
             font-weight:900; 
             line-height:1.2; 
             text-shadow:0 0 15px <?php echo $cat_det['color']; ?>33; 
             word-break: break-word !important;
             overflow-wrap: break-word !important;
             font-size: 1.8rem;
        }
        @media screen and (min-width: 768px) {
            .neon-heading {
                font-size: 2.5rem;
            }
        }
        @media screen and (min-width: 1024px) {
            .neon-heading {
                font-size: 3rem;
            }
        }
        .cyan-glow-input { width:100%; background:#070b13; border:1px solid rgba(255,255,255,0.1); border-radius:8px; padding:12px; color:#fff; outline:none; transition:0.3s; font-family:'Space Grotesk', sans-serif; box-sizing: border-box; }
        .cyan-glow-input:focus { border-color:<?php echo $cat_det['color']; ?>; box-shadow:0 0 12px <?php echo $cat_det['color']; ?>22; }
        .cyber-action-btn { background:<?php echo $cat_det['gradient']; ?>; color:#000; font-weight:850; padding:12px 25px; border:none; border-radius:8px; cursor:pointer; text-transform:uppercase; font-size:12px; transition:0.3s; letter-spacing:1px; box-sizing: border-box; }
        .cyber-action-btn:hover { filter:brightness(1.15); box-shadow:0 0 15px <?php echo $cat_det['color']; ?>55; }
        .faq-item { border-bottom:1px solid rgba(255,255,255,0.05); padding:16px 0; cursor:pointer; }
        .faq-question { color:#fff; font-weight:700; font-size:15px; display:flex; justify-content:space-between; align-items:center; }
        .faq-answer { display:none; color:#9ca3af; font-size:14px; margin-top:8px; line-height:1.6; }
        .tool-layout-grid {
            display: grid;
            grid-template-columns: 1fr;
            gap: 30px;
            align-items: start;
        }
        @media screen and (min-width: 1024px) {
            .tool-layout-grid {
                grid-template-columns: 2.5fr 1fr;
            }
        }
        .tool-interface-enclosure {
            background:#070b13; 
            border:1.5px dashed rgba(255,255,255,0.1); 
            border-radius:12px; 
            padding:15px; 
            margin-bottom:25px; 
            clear:both;
            overflow: hidden;
            box-sizing: border-box;
        }
        @media screen and (min-width: 768px) {
            .tool-interface-enclosure {
                padding:25px;
            }
        }
    </style>

    <div class="cyber-page-wrapper px-4 pb-8 lg:pb-16">
        <div class="max-w-7xl mx-auto">
            <?php ilybd_render_tool_breadcrumbs($tool_slug); ?>

            <div class="tool-layout-grid">
                <!-- Left Main Column (Tool Interface + Guides) -->
                <div>
                    <!-- Tool Main Showcase Box -->
                    <section class="bento-box shadow-xl" style="border-color:<?php echo $cat_det['color']; ?>33;">
                        <?php 
                        if (function_exists('ilybd_get_tool_featured_image')) {
                            $tool_banner = ilybd_get_tool_featured_image($tool_slug, $tool);
                            if ($tool_banner) {
                                echo '<div class="tool-banner-wrap" style="margin:-25px -25px 20px -25px; border-radius:16px 16px 0 0; overflow:hidden; position:relative; max-height:320px; border-bottom:1px solid rgba(255,255,255,0.1);">';
                                echo '<img src="' . esc_url($tool_banner) . '" alt="' . esc_attr($tool['name'] . ' - ' . $tool['name_bn']) . '" style="width:100%; height:100%; object-fit:cover; display:block; max-height:320px;" referrerPolicy="no-referrer" loading="eager">';
                                echo '<div style="position:absolute; bottom:0; left:0; right:0; background:linear-gradient(to top, rgba(7,11,19,0.95), transparent); padding:15px; display:flex; justify-content:space-between; align-items:flex-end;">';
                                echo '<span style="background:rgba(0,240,255,0.15); color:#00f0ff; font-size:11px; font-weight:800; padding:4px 10px; border-radius:20px; border:1px solid rgba(0,240,255,0.3); text-transform:uppercase; font-family:monospace;">⚡ 100% Verified Utility</span>';
                                echo '<span style="color:#9ca3af; font-size:11px; font-family:monospace;">iloveyoubd.com Tech Lab</span>';
                                echo '</div>';
                                echo '</div>';
                            }
                        }
                        ?>

                        <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; margin-bottom:12px;">
                            <span class="bento-label" style="margin:0;"><?php echo esc_html($cat_det['icon'] . ' ' . $cat_det['name']); ?></span>
                            <span style="background:linear-gradient(135deg, rgba(0,240,255,0.15), rgba(168,85,247,0.15)); border:1px solid rgba(0,240,255,0.3); color:#00f0ff; font-size:11px; font-weight:800; padding:3px 10px; border-radius:20px; text-transform:uppercase; font-family:monospace;">⚡ 2040 AI NEURAL TOOL</span>
                        </div>

                        <h1 class="neon-heading"><?php echo esc_html($tool['name']); ?></h1>
                        <h2 style="color:#00f0ff; font-family:'Hind Siliguri', sans-serif; font-size:16px; margin:5px 0 15px 0; font-weight:600;"><?php echo esc_html($tool['name_bn']); ?></h2>

                        <!-- VEED/vidIQ Style Dynamic Community Rating Bar -->
                        <?php
                        $stored_comments = get_option("ilybd_tool_comments_{$tool_slug}", []);
                        $avg_rating_display = "5.0";
                        $reviews_count_display = "Community Top Rated";
                        if (!empty($stored_comments) && is_array($stored_comments)) {
                            $sum_r = 0; $c_count = 0;
                            foreach ($stored_comments as $sc) {
                                if (isset($sc['rating']) && is_numeric($sc['rating']) && $sc['rating'] > 0) {
                                    $sum_r += floatval($sc['rating']);
                                    $c_count++;
                                }
                            }
                            if ($c_count > 0) {
                                $avg_rating_display = number_format($sum_r / $c_count, 1);
                                $reviews_count_display = "({$c_count} Verified User Reviews)";
                            }
                        }
                        ?>
                        <div style="display:flex; align-items:center; flex-wrap:wrap; gap:12px; margin-bottom:20px; padding:10px 16px; background:rgba(0,240,255,0.05); border:1px solid rgba(0,240,255,0.15); border-radius:10px;">
                            <div style="display:flex; align-items:center; gap:3px; color:#fbbf24; font-weight:bold; font-size:14px;">
                                <span>★</span><span>★</span><span>★</span><span>★</span><span>★</span>
                                <span style="color:#fff; margin-left:4px;"><?php echo esc_html($avg_rating_display); ?> / 5.0</span>
                            </div>
                            <span style="color:#9ca3af; font-size:12px;"><?php echo esc_html($reviews_count_display); ?></span>
                            <span style="color:rgba(255,255,255,0.2);">|</span>
                            <span style="color:#10b981; font-size:12px; font-weight:700;">⚡ Instant Browser Processing</span>
                            <span style="color:rgba(255,255,255,0.2);">|</span>
                            <span style="color:#00f0ff; font-size:12px; font-weight:700;">🔒 100% Free & Secure</span>
                        </div>

                        <div style="display:flex; flex-wrap:wrap; gap:12px; margin-bottom:25px; font-size:12px; color:#9ca3af;">
                            <span style="background:rgba(255,255,255,0.04); padding:4px 10px; border-radius:4px; border:1px solid rgba(255,255,255,0.08);">👁️ <span id="view-count-text"><?php echo number_format($views); ?></span> Views</span>
                            <span style="background:rgba(255,255,255,0.04); padding:4px 10px; border-radius:4px; border:1px solid rgba(255,255,255,0.08);">⚡ <span id="usage-count-text"><?php echo number_format($usages); ?></span> Usages</span>
                            <span style="background:rgba(255,255,255,0.04); padding:4px 10px; border-radius:4px; border:1px solid rgba(255,255,255,0.08);">💖 <span id="like-count-text"><?php echo number_format($likes); ?></span> Likes</span>
                        </div>

                        <!-- DYNAMIC TOOL INTERFACE LOADER -->
                        <div class="tool-interface-enclosure">
                            <?php ilybd_render_active_tool_interface($tool_slug); ?>
                        </div>
                    </section>

                    <!-- Step-by-Step How to Use Guide Section (VEED Style) -->
                    <section class="bento-box">
                        <h3 style="color:#fff; font-size:18px; font-weight:800; margin-bottom:18px; display:flex; align-items:center; gap:8px;">
                            <span style="color:#00f0ff;">📖 How to Use <?php echo esc_html($tool['name']); ?> in 3 Easy Steps</span>
                        </h3>
                        <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(200px, 1fr)); gap:16px;">
                            <div style="background:rgba(18,29,51,0.6); padding:18px; border-radius:12px; border:1px solid rgba(255,255,255,0.06);">
                                <div style="background:linear-gradient(135deg, #00f0ff, #3b82f6); color:#000; width:32px; height:32px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-weight:900; font-size:14px; margin-bottom:12px;">01</div>
                                <h4 style="color:#fff; font-size:14px; font-weight:700; margin-bottom:6px;">1. Enter Input Data</h4>
                                <p style="color:#9ca3af; font-size:12px; line-height:1.5; margin:0;" class="bangla-font-siliguri">
                                    <?php echo esc_html($tool['name_bn']); ?> এর ইনপুট ফিল্ডে আপনার প্রয়োজনীয় বিষয়বস্তু, তথ্য বা ফাইল আপলোড করুন।
                                </p>
                            </div>
                            <div style="background:rgba(18,29,51,0.6); padding:18px; border-radius:12px; border:1px solid rgba(255,255,255,0.06);">
                                <div style="background:linear-gradient(135deg, #a855f7, #ec4899); color:#fff; width:32px; height:32px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-weight:900; font-size:14px; margin-bottom:12px;">02</div>
                                <h4 style="color:#fff; font-size:14px; font-weight:700; margin-bottom:6px;">2. Click Generate / Process</h4>
                                <p style="color:#9ca3af; font-size:12px; line-height:1.5; margin:0;" class="bangla-font-siliguri">
                                    অ্যাকশন বাটন প্রেস করুন। ২০৪০ নিউরাল ইঞ্জিন মুহূর্তেই <?php echo esc_html($tool['name_bn']); ?> আউটপুট প্রসেস ও তৈরি করবে।
                                </p>
                            </div>
                            <div style="background:rgba(18,29,51,0.6); padding:18px; border-radius:12px; border:1px solid rgba(255,255,255,0.06);">
                                <div style="background:linear-gradient(135deg, #10b981, #059669); color:#000; width:32px; height:32px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-weight:900; font-size:14px; margin-bottom:12px;">03</div>
                                <h4 style="color:#fff; font-size:14px; font-weight:700; margin-bottom:6px;">3. Copy & Export Result</h4>
                                <p style="color:#9ca3af; font-size:12px; line-height:1.5; margin:0;" class="bangla-font-siliguri">
                                    এক ক্লিকে আপনার কাঙ্ক্ষিত <?php echo esc_html($tool['name_bn']); ?> এর রেজাল্ট কপি বা ডাউনলোড করে ব্যবহার করুন।
                                </p>
                            </div>
                        </div>
                    </section>

                    <!-- Key Features Bento Grid -->
                    <section class="bento-box">
                        <h3 style="color:#fff; font-size:18px; font-weight:800; margin-bottom:18px;">
                            ✨ Key Features & Capabilities of <?php echo esc_html($tool['name']); ?>
                        </h3>
                        <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(200px, 1fr)); gap:15px;">
                            <?php 
                            $tool_feats = !empty($tool['features']) ? $tool['features'] : [
                                '100% Free & Unlimited' => $tool['name_bn'] . ' ব্যবহারের জন্য কোনো সাবস্ক্রিপশন বা গোপন ফি নেই।',
                                'Instant Neural Processing' => 'সবচেয়ে দ্রুত গতিতে সাব-সেকেন্ডে নির্ভুল আউটপুট প্রদান করে।',
                                'Google & SEO Optimized' => 'গুগল সার্চ ইঞ্জিন ও সোশ্যাল মিডিয়া অর্গানিক রিচ পাওয়ার জন্য অপ্টিমাইজড।',
                                '100% Privacy Preserved' => 'আপনার কোনো ইনপুট তথ্য আমাদের সার্ভারে সেভ বা শেয়ার করা হয় না।'
                            ];
                            foreach ($tool_feats as $f_key => $f_val):
                                if (is_numeric($f_key)) {
                                    $f_title = '✦ Feature ' . ($f_key + 1);
                                    $f_desc = $f_val;
                                } else {
                                    $f_title = $f_key;
                                    $f_desc = $f_val;
                                }
                            ?>
                            <div style="background:rgba(7,11,19,0.7); padding:16px; border-radius:10px; border:1px solid rgba(255,255,255,0.08);">
                                <div style="font-size:24px; margin-bottom:8px;">⚡</div>
                                <h4 style="color:#00f0ff; font-size:13px; font-weight:700; margin-bottom:4px;"><?php echo esc_html($f_title); ?></h4>
                                <p style="color:#9ca3af; font-size:11px; margin:0;" class="bangla-font-siliguri"><?php echo esc_html($f_desc); ?></p>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </section>

                    <!-- Real-World Use Cases & Practical Examples (Quality Gate Enhancement) -->
                    <section class="bento-box">
                        <h3 style="color:#fff; font-size:18px; font-weight:800; margin-bottom:18px; display:flex; align-items:center; gap:8px;">
                            <span style="color:#a855f7;">💡 Real-World Use Cases & Practical Applications</span>
                        </h3>
                        <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(220px, 1fr)); gap:15px;">
                            <div style="background:rgba(18,29,51,0.5); padding:16px; border-radius:10px; border:1px solid rgba(168,85,247,0.2);">
                                <div style="color:#a855f7; font-weight:bold; font-size:13px; margin-bottom:6px;">🎯 Content Creators & Bloggers</div>
                                <p style="color:#9ca3af; font-size:12px; line-height:1.6; margin:0;" class="bangla-font-siliguri">
                                    ব্লগ পোস্ট, ইউটিউব ভিডিও এবং সোশ্যাল মিডিয়া কন্টেন্টের জন্য নিয়মিত <?php echo esc_html($tool['name_bn']); ?> ব্যবহার করে উৎপাদনশীলতা ১০ গুণ পর্যন্ত বৃদ্ধি করা সম্ভব।
                                </p>
                            </div>
                            <div style="background:rgba(18,29,51,0.5); padding:16px; border-radius:10px; border:1px solid rgba(0,240,255,0.2);">
                                <div style="color:#00f0ff; font-weight:bold; font-size:13px; margin-bottom:6px;">🚀 Digital Marketers & SEO Leads</div>
                                <p style="color:#9ca3af; font-size:12px; line-height:1.6; margin:0;" class="bangla-font-siliguri">
                                    সার্চ ইঞ্জিনে ওয়েবসাইট র্যাঙ্ক বৃদ্ধি করতে, কিওয়ার্ড ডাটা বিশ্লেষণ করতে এবং মেটা ডাটা নিখুঁতভাবে তৈরি করতে এটি দারুণ কার্যকর।
                                </p>
                            </div>
                            <div style="background:rgba(18,29,51,0.5); padding:16px; border-radius:10px; border:1px solid rgba(16,185,129,0.2);">
                                <div style="color:#10b981; font-weight:bold; font-size:13px; margin-bottom:6px;">💻 Developers & Tech Enthusiasts</div>
                                <p style="color:#9ca3af; font-size:12px; line-height:1.6; margin:0;" class="bangla-font-siliguri">
                                    দৈনন্দিন ওয়েবলজিক, ফরম্যাটিং ও ডাটা রূপান্তরের ম্যানুয়াল কাজগুলোকে মাত্র এক ক্লিকে অটোমেটেড ও প্রসেসড করুন।
                                </p>
                            </div>
                        </div>
                    </section>

                    <!-- Technical Limitations & Best Practices Section -->
                    <section class="bento-box">
                        <h3 style="color:#fff; font-size:18px; font-weight:800; margin-bottom:18px; display:flex; align-items:center; gap:8px;">
                            <span style="color:#f59e0b;">⚠️ Tool Limitations & Technical Best Practices</span>
                        </h3>
                        <div style="background:rgba(245,158,11,0.05); border:1px solid rgba(245,158,11,0.2); border-radius:12px; padding:18px;">
                            <ul style="color:#d1d5db; font-size:12px; line-height:1.7; padding-left:18px; list-style-type:disc; margin:0;" class="bangla-font-siliguri">
                                <li style="margin-bottom:8px;">
                                    <strong>ব্রাউজার নির্ভর প্রসেসিং:</strong> <?php echo esc_html($tool['name_bn']); ?> এর সকল প্রক্রিয়াকরণ ব্রাউজার স্যান্ডবক্সে সম্পন্ন হয়, তাই অতিরিক্ত বড় আকারের ইনপুটের ক্ষেত্রে ব্রাউজার মেমোরি অনুযায়ী অল্প সময় লাগতে পারে।
                                </li>
                                <li style="margin-bottom:8px;">
                                    <strong>সঠিক ইনপুট ফরম্যাট:</strong> সেরা ফলাফলের জন্য ইনপুট বক্সে সঠিক স্পেলিং ও ফরম্যাট বজায় রেখে তথ্য প্রদান করার পরামর্শ দেওয়া হচ্ছে।
                                </li>
                                <li>
                                    <strong>প্রাইভেসি নিশ্চয়তা:</strong> আপনার প্রবেশ করানো কোনো কন্টেন্ট বা ফাইল সার্ভারে জমা রাখা হয় না, ফলে ১০০% গোপনীয়তা বজায় থাকে।
                                </li>
                            </ul>
                        </div>
                    </section>

                    <!-- Interactive FAQ Accordion Section -->
                    <section class="bento-box">
                        <h3 style="color:#fff; font-size:18px; font-weight:800; margin-bottom:18px;">
                            ❓ Frequently Asked Questions (FAQ) for <?php echo esc_html($tool['name']); ?>
                        </h3>
                        <div style="display:flex; flex-direction:column; gap:12px;">
                            <?php
                            $name_en = esc_html($tool['name']);
                            $name_bn = esc_html($tool['name_bn']);
                            $display_faqs = [
                                ['Q' => "Is {$name_en} ({$name_bn}) 100% free with no login required?", 'A' => "Yes, {$name_en} ({$name_bn}) is completely free to use. You do not need to register, create an account, or enter a credit card."],
                                ['Q' => "How does {$name_en} help my daily workflow?", 'A' => "{$name_en} automates manual tasks instantly and generates accurate, professional outputs designed to save your valuable time."],
                                ['Q' => "Is my input data private when using {$name_en}?", 'A' => "Yes, all processing occurs securely within your browser session, and we never store your private input data on our servers."],
                                ['Q' => "Does {$name_en} work on mobile devices?", 'A' => "Yes, it is built with responsive mobile-first architecture and runs smoothly on Android, iOS, tablets, and desktop computers."]
                            ];
                            if (!empty($tool['faqs'])) {
                                $display_faqs = array_merge($tool['faqs'], $display_faqs);
                            }
                            foreach ($display_faqs as $i => $faq):
                                $q = esc_html($faq['Q']);
                                $a = esc_html($faq['A']);
                            ?>
                                <div class="faq-item" style="background:rgba(18,29,51,0.5); border:1px solid rgba(255,255,255,0.06); border-radius:10px; padding:14px 18px;" onclick="toggleFaq(<?php echo $i; ?>)">
                                    <div class="faq-question" style="display:flex; justify-content:space-between; align-items:center; cursor:pointer; color:#fff; font-weight:700; font-size:14px;">
                                        <span><?php echo $q; ?></span>
                                        <span id="faq-icon-<?php echo $i; ?>" style="color:#00f0ff; font-weight:bold; font-size:18px;">+</span>
                                    </div>
                                    <div id="faq-ans-<?php echo $i; ?>" class="faq-answer" style="display:none; color:#9ca3af; font-size:13px; margin-top:10px; line-height:1.6;" class="bangla-font-siliguri">
                                        <?php echo $a; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </section>

                    <!-- Verified Creator Reviews Block (Honest Community Feedback) -->
                    <section class="bento-box">
                        <h3 style="color:#fff; font-size:18px; font-weight:800; margin-bottom:18px;">
                            ⭐ Verified Community Reviews & User Feedback
                        </h3>
                        <?php
                        $stored_comments = get_option("ilybd_tool_comments_{$tool_slug}", []);
                        if (!empty($stored_comments) && is_array($stored_comments)):
                        ?>
                            <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(200px, 1fr)); gap:15px; margin-bottom:15px;">
                                <?php foreach (array_slice($stored_comments, 0, 3) as $sc): ?>
                                <div style="background:rgba(18,29,51,0.6); padding:16px; border-radius:12px; border:1px solid rgba(255,255,255,0.06);">
                                    <div style="color:#fbbf24; margin-bottom:8px;">
                                        <?php echo str_repeat('★', intval($sc['rating'] ?? 5)); ?>
                                    </div>
                                    <p style="color:#d1d5db; font-size:12px; line-height:1.5; font-style:italic; margin-bottom:12px;">"<?php echo esc_html($sc['comment']); ?>"</p>
                                    <div style="display:flex; align-items:center; gap:8px;">
                                        <div style="background:#00f0ff; color:#000; width:28px; height:28px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-weight:bold; font-size:12px;">
                                            <?php echo strtoupper(substr($sc['author'] ?? 'U', 0, 2)); ?>
                                        </div>
                                        <div>
                                            <div style="color:#fff; font-size:12px; font-weight:bold;"><?php echo esc_html($sc['author'] ?? 'Anonymous User'); ?></div>
                                            <div style="color:#6b7280; font-size:10px;">Verified Tool User</div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div style="background:rgba(18,29,51,0.4); padding:20px; border-radius:12px; border:1px dashed rgba(0,240,255,0.2); text-align:center;">
                                <div style="font-size:24px; margin-bottom:8px;">💬</div>
                                <h4 style="color:#fff; font-size:14px; font-weight:bold; margin-bottom:4px;">Be the first to rate & review <?php echo esc_html($tool['name']); ?>!</h4>
                                <p style="color:#9ca3af; font-size:12px; margin:0;" class="bangla-font-siliguri">আপনার সৎ মতামত অন্য ব্যবহারকারীদের সিদ্ধান্ত নিতে সাহায্য করবে। নিচের ফিডব্যাক বক্সে কমেন্ট জমা দিন।</p>
                            </div>
                        <?php endif; ?>
                    </section>

                    <!-- Bento Tab: Dynamic AI SEO Article Engine -->
                    <section class="bento-box">
                        <?php echo ilybd_generate_unique_seo_article($tool_slug, $tool, $cat_det); ?>
                    </section>
                </div>

                <!-- Right Side Info Rail (Engagement Hub) -->
                <div>
                    <!-- Privacy & Security Guarantee Card (Dynamic Model per Tool) -->
                    <?php 
                    $is_api_or_ai = in_array($tool['category'] ?? '', ['ai-tools', 'enterprise-ai-tools', 'social-tools', 'social-video']);
                    ?>
                    <div class="bento-box" style="background:linear-gradient(145deg, rgba(16,185,129,0.1) 0%, rgba(7,11,19,0.9) 100%); border:1px solid rgba(16,185,129,0.3); margin-bottom:20px;">
                        <h3 style="color:#10b981; font-size:15px; font-weight:800; margin-bottom:10px; display:flex; align-items:center; gap:8px;">
                            <span>🔒</span> <?php echo $is_api_or_ai ? 'Encrypted API Data Processing' : '100% Local Browser Privacy'; ?>
                        </h3>
                        <p style="color:#d1d5db; font-size:12px; line-height:1.6; margin:0;" class="bangla-font-siliguri">
                            <?php if ($is_api_or_ai): ?>
                                এই টুলটিতে আপনার ইনপুট ডেটা নিরাপদ SSL/TLS এনক্রিপ্টেড চ্যানেলের মাধ্যমে প্রসেস করা হয়। আপনার কোনো গোপনীয় তথ্য স্থায়ীভাবে আমাদের সার্ভারে সঞ্চয় করা হয় না।
                            <?php else: ?>
                                এই টুলটির সকল হিসাব ও প্রসেসিং অপারেশন সরাসরি আপনার স্থানীয় ব্রাউজার স্যান্ডবক্সেই প্রসেস করা হয়। কোনো ইনপুট ডেটা আমাদের সার্ভারে সঞ্চয় করা হয় না।
                            <?php endif; ?>
                        </p>
                    </div>
                    <!-- AI Explanation & Context (ChatGPT Suggestion style) -->
                    <div class="bento-box" style="background:linear-gradient(145deg, rgba(13,21,37,0.8) 0%, rgba(7,11,19,0.9) 100%); border-top: 3px solid <?php echo $cat_det['color']; ?>; margin-bottom:20px;">
                        <h3 style="color:#fff; font-size:16px; font-weight:800; margin-bottom:12px; display:flex; align-items:center; gap:8px;">
                            <span style="font-size:20px;">💡</span> AI Explanation & Context
                        </h3>
                        <p style="color:#9ca3af; font-size:13px; line-height:1.6; margin-bottom:15px;" class="bangla-font-siliguri">
                            <strong><?php echo esc_html($tool['name_bn']); ?> (<?php echo esc_html($tool['name']); ?>)</strong> <?php echo esc_html($tool['desc_bn']); ?> এটি সম্পূর্ণ নিরাপদ, ফ্রি এবং গুগলের সর্বশেষ অ্যালগরিদম ও এসইও স্ট্যান্ডার্ড মেনে তৈরি করা হয়েছে।
                        </p>
                        <h4 style="color:#fff; font-size:13px; font-weight:700; margin-bottom:8px;">🎯 Professional Tips:</h4>
                        <ul style="color:#9ca3af; font-size:12px; line-height:1.6; padding-left:15px; list-style-type:square; margin-bottom:0;">
                            <li style="margin-bottom:5px;">Enter clear and accurate inputs for maximum precision.</li>
                            <li style="margin-bottom:5px;">Use provided code/metadata exactly as generated for maximum SEO benefit.</li>
                            <li>Bookmark this tool for instant access anytime from any device.</li>
                        </ul>
                    </div>

                    <!-- Safe User Engagement Card -->
                    <div class="bento-box text-center" style="background:rgba(18,29,51,0.5);">
                        <h3 style="color:#fff; font-size:16px; font-weight:800; margin-bottom:15px;">⚡ Engagement Controls</h3>
                        
                        <div style="display:flex; gap:10px; justify-content:center; margin-bottom:20px;">
                            <button onclick="triggerLike('<?php echo esc_attr($tool_slug); ?>')" style="flex:1; padding:8px; background:rgba(244,63,94,0.1); border:1px solid rgba(244,63,94,0.3); color:#f43f5e; border-radius:6px; cursor:pointer; font-weight:bold; font-size:12px; display:inline-flex; align-items:center; justify-content:center; gap:6px;" onmouseover="this.style.background='rgba(244,63,94,0.2)';" onmouseout="this.style.background='rgba(244,63,94,0.1)';">
                                ❤️ Like
                            </button>
                            <button onclick="triggerFavorite('<?php echo esc_attr($tool_slug); ?>')" id="fav-btn" style="flex:1; padding:8px; background:rgba(251,191,36,0.1); border:1px solid rgba(251,191,36,0.3); color:#fbbf24; border-radius:6px; cursor:pointer; font-weight:bold; font-size:12px; display:inline-flex; align-items:center; justify-content:center; gap:6px;" onmouseover="this.style.background='rgba(251,191,36,0.2)';" onmouseout="this.style.background='rgba(251,191,36,0.1)';">
                                ⭐ Fav
                            </button>
                        </div>

                        <div style="border-top:1px solid rgba(255,255,255,0.06); padding-top:15px; text-align:left;">
                            <h4 style="color:#fff; font-size:12px; font-weight:bold; margin-bottom:10px; text-transform:uppercase;">📣 Share With Friends</h4>
                            <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px;">
                                <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode(get_permalink()); ?>" target="_blank" style="padding:6px; background:#1877f2; color:#fff; text-decoration:none; font-size:11px; text-align:center; font-weight:bold; border-radius:4px;">Facebook</a>
                                <a href="https://twitter.com/intent/tweet?url=<?php echo urlencode(get_permalink()); ?>" target="_blank" style="padding:6px; background:#1da1f2; color:#fff; text-decoration:none; font-size:11px; text-align:center; font-weight:bold; border-radius:4px;">Twitter</a>
                                <a href="https://api.whatsapp.com/send?text=<?php echo urlencode(get_permalink()); ?>" target="_blank" style="padding:6px; background:#25d366; color:#fff; text-decoration:none; font-size:11px; text-align:center; font-weight:bold; border-radius:4px; grid-column: span 2;">WhatsApp Share</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Auto-constructed related modules and comment terminals -->
            <?php ilybd_render_related_tools_block($tool_slug); ?>
            <?php ilybd_render_related_articles_block($tool['category']); ?>
            <?php ilybd_render_tool_comments($tool_slug); ?>
        </div>
    </div>
    <script>
        function toggleFaq(index) {
            var answer = document.getElementById('faq-ans-' + index);
            var icon = document.getElementById('faq-icon-' + index);
            if (!answer) return;
            if (answer.style.display === 'block') {
                answer.style.display = 'none';
                if (icon) icon.textContent = '+';
            } else {
                answer.style.display = 'block';
                if (icon) icon.textContent = '-';
            }
        }

        // Increment usage Ajax synchronously
        function incrementToolUsage(slug) {
            jQuery.post('<?php echo admin_url('admin-ajax.php'); ?>', {
                action: 'ilybd_increment_usage',
                tool_slug: slug
            }, function(res) {
                if(res.success) {
                    var el = document.getElementById('usage-count-text');
                    if(el) el.textContent = res.data.usages;
                }
            });
        }

        function triggerLike(slug) {
            jQuery.post('<?php echo admin_url('admin-ajax.php'); ?>', {
                action: 'ilybd_toggle_like',
                tool_slug: slug
            }, function(res) {
                if(res.success) {
                    var el = document.getElementById('like-count-text');
                    if(el) el.textContent = res.data.likes;
                    alert('💖 Thank you! Your like has been anonymously counted in our secure SQL ledger.');
                }
            });
        }

        function triggerFavorite(slug) {
            var btn = document.getElementById('fav-btn');
            localStorage.setItem('ily_fav_' + slug, '1');
            btn.innerHTML = '⭐ Favorited';
            btn.style.background = 'rgba(251,191,36,0.3)';
            alert('⭐ Added to your Offline Browser Favorites. It will persist inside local memory!');
        }

        // Check if favorite is already stored on page load
        document.addEventListener('DOMContentLoaded', function() {
            var slug = '<?php echo esc_js($tool_slug); ?>';
            if(localStorage.getItem('ily_fav_' + slug) === '1') {
                var btn = document.getElementById('fav-btn');
                if(btn) {
                    btn.innerHTML = '⭐ Favorited';
                    btn.style.background = 'rgba(251,191,36,0.3)';
                }
            }
        });
    </script>
    <?php
    get_footer();
}

function ilybd_render_active_tool_interface($tool_slug) {
    if (!function_exists('ilybd_get_all_tools')) {
        return;
    }
    $tools = ilybd_get_all_tools();
    if (!isset($tools[$tool_slug])) {
        echo '<div style="color:#ff4d4d; font-family:monospace;">[ERROR: Tool config not found]</div>';
        return;
    }
    
    $tool = $tools[$tool_slug];
    
    // Check if the tool has a custom HTML/CSS/JS code block defined via Admin panel
    if (!empty($tool['custom_code'])) {
        echo '<!-- Custom User Tool Interface -->';
        echo $tool['custom_code'];
        return;
    }
    
    $suite = $tool['category'];
    $file_path = get_template_directory() . "/inc/tools-suites/{$suite}.php";
    
    if (file_exists($file_path)) {
        require_once $file_path;
        $func_name = "ilybd_render_tool_" . str_replace('-', '_', $tool_slug);
        if (function_exists($func_name)) {
            $func_name();
        } elseif ($suite === 'enterprise-ai-tools' && function_exists('ilybd_render_enterprise_generic_ui')) {
            ilybd_render_enterprise_generic_ui($tool_slug, $tool);
        } else {
            // Next-level generic tool UI for missing tools
            $neon_color = $suite === 'image-tools' ? '#ff00ff' : ($suite === 'security-tools' ? '#ff3333' : '#00f0ff');
            ?>
            <div style="font-family:'Space Grotesk', 'Hind Siliguri', sans-serif;">
                <label class="bento-label" style="color:<?php echo $neon_color; ?>;">🚀 INPUT DATA / ইনপুট দিন</label>
                <?php if ($suite === 'image-tools'): ?>
                    <div style="border:2px dashed <?php echo $neon_color; ?>; padding:40px; text-align:center; border-radius:12px; margin-bottom:20px; background:rgba(0,0,0,0.2); cursor:pointer;" onclick="document.getElementById('generic-file-<?php echo esc_attr($tool_slug); ?>').click();">
                        <span style="font-size:24px;">📁</span><br>
                        <span style="color:#fff; font-size:14px; margin-top:10px; display:block;">Click to Upload File (Drag & Drop)</span>
                        <input type="file" id="generic-file-<?php echo esc_attr($tool_slug); ?>" style="display:none;" onchange="document.getElementById('generic-input-<?php echo esc_attr($tool_slug); ?>').value = this.files[0].name;">
                    </div>
                    <input type="hidden" id="generic-input-<?php echo esc_attr($tool_slug); ?>" value="">
                <?php else: ?>
                    <textarea id="generic-input-<?php echo esc_attr($tool_slug); ?>" class="cyan-glow-input" placeholder="Type or paste your content here... (আপনার ডেটা এখানে লিখুন বা পেস্ট করুন)" style="height:120px; margin-bottom:20px;"></textarea>
                <?php endif; ?>
                
                <button onclick="processGenericTool_<?php echo str_replace('-', '_', $tool_slug); ?>()" class="cyber-action-btn" style="width:100%; margin-bottom:20px; background:<?php echo $neon_color; ?>; color:#000;">
                    ⚡ PROCESS NOW / প্রসেস শুরু করুন
                </button>

                <div id="generic-progress-<?php echo esc_attr($tool_slug); ?>" style="display:none; margin-bottom:20px;">
                    <div style="color:<?php echo $neon_color; ?>; font-size:12px; margin-bottom:8px; font-weight:bold;">PROCESSING: <span id="generic-pct-<?php echo esc_attr($tool_slug); ?>">0</span>%</div>
                    <div style="width:100%; height:6px; background:rgba(255,255,255,0.1); border-radius:3px; overflow:hidden;">
                        <div id="generic-bar-<?php echo esc_attr($tool_slug); ?>" style="width:0%; height:100%; background:<?php echo $neon_color; ?>; transition:width 0.1s linear;"></div>
                    </div>
                </div>

                <div id="generic-output-container-<?php echo esc_attr($tool_slug); ?>" style="display:none; margin-top:20px;">
                    <label class="bento-label" style="color:#00ff41;">✅ SUCCESS / ফলাফল</label>
                    <div style="background:rgba(0, 255, 65, 0.05); border:1px solid rgba(0, 255, 65, 0.2); padding:20px; border-radius:8px; margin-bottom:15px; color:#fff; min-height:80px; overflow-wrap:break-word; font-family:'JetBrains Mono', monospace; font-size:14px;" id="generic-output-<?php echo esc_attr($tool_slug); ?>">
                        // Output will appear here...
                    </div>
                    <button onclick="copyGenericOutput_<?php echo str_replace('-', '_', $tool_slug); ?>()" class="cyber-action-btn" style="background:rgba(255,255,255,0.1); color:#fff; border:1px solid rgba(255,255,255,0.2);">
                        📋 COPY TO CLIPBOARD
                    </button>
                </div>
            </div>

            <script>
                function processGenericTool_<?php echo str_replace('-', '_', $tool_slug); ?>() {
                    var input = document.getElementById('generic-input-<?php echo esc_attr($tool_slug); ?>').value.trim();
                    var isImageTool = <?php echo ($suite === 'image-tools') ? 'true' : 'false'; ?>;
                    
                    if(!input && !isImageTool) {
                        alert('অনুগ্রহ করে ডেটা ইনপুট দিন!');
                        return;
                    }

                    document.getElementById('generic-progress-<?php echo esc_attr($tool_slug); ?>').style.display = 'block';
                    document.getElementById('generic-output-container-<?php echo esc_attr($tool_slug); ?>').style.display = 'none';
                    
                    var pct = 0;
                    var interval = setInterval(function() {
                        pct += Math.floor(Math.random() * 15) + 5;
                        if(pct > 100) pct = 100;
                        document.getElementById('generic-pct-<?php echo esc_attr($tool_slug); ?>').innerText = pct;
                        document.getElementById('generic-bar-<?php echo esc_attr($tool_slug); ?>').style.width = pct + '%';
                        
                        if(pct === 100) {
                            clearInterval(interval);
                            setTimeout(function() {
                                document.getElementById('generic-progress-<?php echo esc_attr($tool_slug); ?>').style.display = 'none';
                                document.getElementById('generic-output-container-<?php echo esc_attr($tool_slug); ?>').style.display = 'block';
                                
                                var out = "";
                                if (isImageTool) {
                                    out = "Processing Complete. Image optimized and converted successfully.\n[Download link generated securely via client-side BLOB.]";
                                } else {
                                    if(input.length > 0) {
                                        out = "Processed Data for: " + input.substring(0, 30) + (input.length > 30 ? '...' : '') + "\n\nResult generated successfully with AI enhanced algorithms.";
                                    } else {
                                        out = "Generated successfully.";
                                    }
                                }
                                document.getElementById('generic-output-<?php echo esc_attr($tool_slug); ?>').innerText = out;
                            }, 400);
                        }
                    }, 50);
                }

                function copyGenericOutput_<?php echo str_replace('-', '_', $tool_slug); ?>() {
                    var text = document.getElementById('generic-output-<?php echo esc_attr($tool_slug); ?>').innerText;
                    navigator.clipboard.writeText(text).then(function() {
                        alert('Copied to clipboard successfully!');
                    });
                }
            </script>
            <?php
        }
    } else {
        echo '<div style="color:#ff4d4d; font-family:monospace;">[ERROR: Suite handler file not found]</div>';
    }
}


