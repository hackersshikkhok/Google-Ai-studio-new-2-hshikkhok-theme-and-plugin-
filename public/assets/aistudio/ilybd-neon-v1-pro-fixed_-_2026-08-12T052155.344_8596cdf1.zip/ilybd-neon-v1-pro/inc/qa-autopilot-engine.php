<?php
/**
 * AI Autopilot Q&A Engine (Next-Level Autonomous Generation)
 * This engine handles auto-creation of community questions and answers.
 * It simulates real users and publishes questions & answers organically for SEO value.
 */

if (!defined('ABSPATH')) exit;

class ILYBD_QA_Autopilot_Engine {

    public function __construct() {
        // Add custom cron schedules
        add_filter('cron_schedules', [$this, 'add_custom_cron_schedules']);
        
        // Setup cron logic on init
        add_action('init', [$this, 'setup_cron_schedules_from_settings']);
        
        // The cron action
        add_action('ilybd_ai_qa_autopilot_cron_hook', [$this, 'execute_autopilot_cycle']);
        
        // Single events for staggered organic posting
        add_action('ilybd_qa_insert_answer_event', [$this, 'insert_scheduled_answer'], 10, 6);
        add_action('ilybd_qa_mark_solution_event', [$this, 'mark_scheduled_solution'], 10, 4);

        // Listen to newly published user questions to auto-answer them
        add_action('transition_post_status', [$this, 'auto_answer_new_user_question'], 10, 3);
        
        // Event to generate answers for a user question
        add_action('ilybd_generate_user_question_answers_event', [$this, 'generate_user_question_answers']);

        // Manual trigger for Admin
        add_action('admin_post_trigger_qa_autopilot', [$this, 'manual_trigger_from_admin']);
    }

    public function add_custom_cron_schedules($schedules) {
        $schedules['every_4_hours'] = array('interval' => 14400, 'display' => 'Every 4 Hours');
        $schedules['every_6_hours'] = array('interval' => 21600, 'display' => 'Every 6 Hours');
        return $schedules;
    }

    public function setup_cron_schedules_from_settings() {
        $is_enabled = get_option('ily_enable_ai_qa_autopilot', 0);
        $frequency = get_option('ily_ai_qa_frequency', 'every_4_hours'); 
        $hook = 'ilybd_ai_qa_autopilot_cron_hook';
        
        // Clean up old hook if it exists
        $old_hook = 'ilybd_daily_autopilot_qa_cron';
        if (wp_next_scheduled($old_hook)) {
            wp_clear_scheduled_hook($old_hook);
        }

        if ($is_enabled == 1) {
            $scheduled_freq = wp_get_schedule($hook);
            if ($scheduled_freq !== $frequency) {
                wp_clear_scheduled_hook($hook);
                wp_schedule_event(time() + 60, $frequency, $hook); // start 1 min from now on change
            }
        } else {
            wp_clear_scheduled_hook($hook);
        }
    }

    public function execute_autopilot_cycle() {
        // Enforce daily limit
        $daily_limit = intval(get_option('ily_ai_qa_daily_limit', 5));
        $today_date = date('Y-m-d');
        $qa_count_today = get_option('ily_ai_qa_count_' . $today_date, 0);
        
        if ($qa_count_today >= $daily_limit) {
            return; // Skip if limit reached
        }

        // Generate Q&A content with strict retry loop to guarantee unique topics
        $exclude_titles = array();
        $content = null;
        $max_attempts = 5;

        for ($attempt = 1; $attempt <= $max_attempts; $attempt++) {
            $generated_content = $this->generate_ai_qa_content($exclude_titles);
            if (!$generated_content || empty($generated_content['question_title'])) {
                break;
            }

            $title = $generated_content['question_title'];

            // Check duplicate status using the robust moderator class
            $is_duplicate = false;
            if (class_exists('ILYBD_QA_AI_Moderator')) {
                $dup_check = ILYBD_QA_AI_Moderator::check_duplicate_question($title);
                if ($dup_check['status']) {
                    $is_duplicate = true;
                }
            } else {
                // Fallback direct check if moderator class is not loaded yet
                $existing = get_page_by_title($title, OBJECT, 'ilybd_question');
                if ($existing) {
                    $is_duplicate = true;
                }
            }

            if (!$is_duplicate) {
                $content = $generated_content;
                break;
            }

            // If duplicate is found, log/add to exclusion list and retry
            $exclude_titles[] = $title;
        }

        if (!$content) {
            return; // Skip this cycle if we fail to generate a unique question after max attempts
        }

        // Generate a random user profile or pick an existing simulated user for asker
        $asker_id = $this->get_or_create_simulated_user('asker');

        // 1. Publish the Question
        $question_data = array(
            'post_title'    => sanitize_text_field($content['question_title']),
            'post_content'  => wp_kses_post($content['question_body']),
            'post_status'   => 'publish',
            'post_type'     => 'ilybd_question',
            'post_author'   => $asker_id,
            'meta_input'    => array(
                'qa_views_count' => rand(25, 250), // Matches single-ilybd_question.php name
                'qa_votes'       => rand(1, 15),   // Matches single-ilybd_question.php name
                'is_autopilot_generated' => 1,
            )
        );
        $question_id = wp_insert_post($question_data);

        // 2. Set Category and Tags for SEO in question_category taxonomy
        if ($question_id && !is_wp_error($question_id)) {
            // Category set
            $cat_name = !empty($content['category']) ? sanitize_text_field($content['category']) : 'Ai';
            $term = term_exists($cat_name, 'question_category');
            if (!$term) {
                $term = wp_insert_term($cat_name, 'question_category');
            }
            if (!is_wp_error($term) && isset($term['term_id'])) {
                wp_set_post_terms($question_id, array((int)$term['term_id']), 'question_category');
            } else if (is_array($term) && isset($term['term_id'])) {
                wp_set_post_terms($question_id, array((int)$term['term_id']), 'question_category');
            }

            // Tags set
            $tags = !empty($content['tags']) && is_array($content['tags']) ? $content['tags'] : array('Tech Q&A', 'কমিউনিটি ফোরাম', 'এআই টিপস');
            $clean_tags = array_map('sanitize_text_field', $tags);
            wp_set_post_terms($question_id, $clean_tags, 'post_tag');
            if (taxonomy_exists('question_tag')) {
                wp_set_post_terms($question_id, $clean_tags, 'question_tag');
            }

            // 3. Publish Multiple Answers as Comments (Simulating active community interaction)
            $answers_list = !empty($content['answers']) && is_array($content['answers']) ? $content['answers'] : [];
            
            if (empty($answers_list)) {
                $answers_list = [
                    [
                        'author_name' => 'cyber_expert_bd',
                        'answer_body' => !empty($content['answer_body']) ? $content['answer_body'] : 'ধন্যবাদ এই গাইডলাইনের জন্য।'
                    ]
                ];
            }

            // DYNAMICALLY RANDOMIZE ANSWER VOLUME: Each question gets a completely random number of replies (e.g. 1, 2, 3, 4, 5, 6, 7 or 8 replies)
            // This is perfect to make it look organic, and mimics a thriving human forum center!
            $target_answers_count = rand(1, 8);
            
            if (count($answers_list) > $target_answers_count) {
                // If generated too many answers, slice down to the target to maintain random diversity
                $answers_list = array_slice($answers_list, 0, $target_answers_count);
            } elseif (count($answers_list) < $target_answers_count) {
                // If we need more answers to reach the target count, dynamically append organic comments
                $organic_pool = [
                    'ধন্যবাদ ভাই! এই প্রবলেমটা নিয়ে অনেক দিন ধরে টেনশনে ছিলাম, চমৎকার গাইডলাইন।',
                    'This is extremely helpful! Highly detailed and easy-to-follow solution.',
                    'খুব সুন্দর এবং বিস্তারিত সমাধান। ধন্যবাদ আইটি টিম!',
                    'আমিও এই সমস্যায় পড়েছিলাম, ট্রাই করে দেখলাম কাজ করেছে! থ্যাংক ইউ!',
                    'Great insights. The step-by-step instructions are highly professional.',
                    'ধন্যবাদ ভাইয়া, বুকমার্ক করে রাখলাম। ভবিষ্যতে কাজে লাগবে।',
                    'Wonderful guide! Exactly what I was searching for on Google.',
                    'এই ফোরাম সেন্টারটি আসলেও অসাধারণ। সরাসরি নির্ভুল সমাধান পাওয়া যায়।',
                    'Is there any additional server settings required or this basic configuration is enough?',
                    'Highly appreciated! Thanks for taking the time to write this step-by-step guide.',
                    'চমৎকার সমাধান! এটি আমার সাইটের স্পিড ও সিকিউরিটি উভয়ই উন্নত করেছে।',
                    'Really happy to find this authentic solution. Thanks for sharing!'
                ];
                $users_pool = ['tech_seeker_bd', 'rakib_freelancer', 'tasnim_ahmed', 'muna_cyber', 'niloy_is_online', 'digital_sabbir', 'blogger_farhan', 'shakil_dev', 'cyber_warrior', 'wp_lover_bd'];
                
                $needed_count = $target_answers_count - count($answers_list);
                for ($i = 0; $i < $needed_count; $i++) {
                    $random_comment = $organic_pool[array_rand($organic_pool)];
                    $random_user_slug = $users_pool[array_rand($users_pool)] . rand(10, 999);
                    $answers_list[] = [
                        'author_name' => $random_user_slug,
                        'answer_body' => $random_comment
                    ];
                }
            }

            $current_delay = rand(180, 600); // initial delay 3 to 10 minutes
            foreach ($answers_list as $index => $ans) {
                // Determine if this is the accepted solution
                $is_solution = ($index === 0 || ($index === 1 && rand(1, 100) > 50)) ? 1 : 0;
                
                $schedule_time = time() + $current_delay;
                wp_schedule_single_event(
                    $schedule_time, 
                    'ilybd_qa_insert_answer_event', 
                    array($question_id, $ans['author_name'], $ans['answer_body'], $is_solution, count($answers_list), $asker_id)
                );
                
                $current_delay += rand(300, 1800); // add 5 to 30 mins delay for next answer
            }
            
            // Increment daily count
            update_option('ily_ai_qa_count_' . $today_date, $qa_count_today + 1);

            // Flush rewrite rules dynamically
            flush_rewrite_rules(false);
        }
    }

    public function insert_scheduled_answer($question_id, $author_name, $answer_body, $is_solution, $total_answers, $asker_id) {
        $responder_id = $this->get_or_create_simulated_user_by_name($author_name);
        $responder = get_userdata($responder_id);
        
        $comment_data = array(
            'comment_post_ID'      => $question_id,
            'comment_author'       => $responder->display_name,
            'comment_author_email' => $responder->user_email,
            'comment_content'      => wp_kses_post($answer_body),
            'comment_type'         => 'comment',
            'user_id'              => $responder_id,
            'comment_approved'     => 1,
            'comment_date'         => date('Y-m-d H:i:s', current_time('timestamp')),
        );
        
        $comment_id = wp_insert_comment($comment_data);
        
        if ($comment_id) {
            $current_count = (int) get_post_meta($question_id, 'answers_count', true);
            update_post_meta($question_id, 'answers_count', $current_count + 1);
            update_comment_meta($comment_id, 'votes_count', rand(2, 25));
            
            if ($is_solution) {
                $solution_delay = rand(1800, 7200); // 30 mins to 2 hours after the answer is posted
                wp_schedule_single_event(
                    time() + $solution_delay, 
                    'ilybd_qa_mark_solution_event', 
                    array($question_id, $comment_id, $responder_id, $asker_id)
                );
            }
        }
    }

    public function mark_scheduled_solution($question_id, $comment_id, $responder_id, $asker_id) {
        update_post_meta($question_id, 'accepted_answer_id', $comment_id);
        
        // Add a "thank you" reply from the original asker to the person who provided the solution
        $asker = get_userdata($asker_id);
        if ($asker) {
            $thank_you_pool = [
                'ধন্যবাদ ভাই! এই প্রবলেমটা নিয়ে অনেক দিন ধরে টেনশনে ছিলাম, আপনার ট্রিকসটা কাজ করেছে।',
                'This is extremely helpful! Highly detailed and easy-to-follow solution. It solved my issue!',
                'খুব সুন্দর এবং বিস্তারিত সমাধান। ধন্যবাদ আইটি টিম! সল্যুশন মার্ক করে দিলাম।',
                'Great insights. I followed your steps and it worked perfectly. Thank you!',
                'ভাই, অনেক অনেক ধন্যবাদ। আপনার দেখানো পদ্ধতিতেই কাজ হয়েছে।'
            ];
            $thank_you_msg = $thank_you_pool[array_rand($thank_you_pool)];
            
            $reply_data = array(
                'comment_post_ID'      => $question_id,
                'comment_author'       => $asker->display_name,
                'comment_author_email' => $asker->user_email,
                'comment_content'      => wp_kses_post($thank_you_msg),
                'comment_type'         => 'comment',
                'user_id'              => $asker_id,
                'comment_parent'       => $comment_id,
                'comment_approved'     => 1,
                'comment_date'         => date('Y-m-d H:i:s', current_time('timestamp')),
            );
            
            $reply_id = wp_insert_comment($reply_data);
            if ($reply_id) {
                update_comment_meta($reply_id, 'votes_count', rand(1, 10));
            }
        }
    }

    public function auto_answer_new_user_question($new_status, $old_status, $post) {
        if ($new_status !== 'publish' || $old_status === 'publish' || $post->post_type !== 'ilybd_question') {
            return;
        }

        $is_enabled = get_option('ily_enable_ai_qa_autopilot', 0);
        if ($is_enabled != 1) {
            return;
        }

        // Avoid double answering autopilot questions
        $is_autopilot = get_post_meta($post->ID, 'is_autopilot_generated', true);
        if ($is_autopilot) {
            return;
        }

        // Avoid double scheduling if already processed
        if (get_post_meta($post->ID, 'ilybd_user_q_scheduled', true)) {
            return;
        }
        update_post_meta($post->ID, 'ilybd_user_q_scheduled', 1);

        // Schedule a background hook/event to generate answers (to avoid blocking the HTTP request when publishing)
        wp_schedule_single_event(time() + 15, 'ilybd_generate_user_question_answers_event', array($post->ID));
    }

    public function generate_user_question_answers($post_id) {
        $post = get_post($post_id);
        if (!$post || $post->post_type !== 'ilybd_question') {
            return;
        }

        $title = $post->post_title;
        $body = strip_tags($post->post_content);

        // Generate answers using Gemini or fallback
        $answers_data = $this->generate_ai_answers_for_title($title, $body);
        if (empty($answers_data)) {
            return;
        }

        // Schedule insertion of these answers
        $current_delay = rand(60, 180); // first reply in 1 to 3 minutes
        $asker_id = $post->post_author;

        foreach ($answers_data as $index => $ans) {
            $is_solution = ($index === 0) ? 1 : 0; // Mark first expert answer as the accepted solution
            
            wp_schedule_single_event(
                time() + $current_delay, 
                'ilybd_qa_insert_answer_event', 
                array($post_id, $ans['author_name'], $ans['answer_body'], $is_solution, count($answers_data), $asker_id)
            );
            
            $current_delay += rand(180, 600); // subsequent replies every 3 to 10 mins
        }
    }

    private function generate_ai_answers_for_title($title, $body) {
        if (function_exists('ily_get_all_rotated_api_keys') && function_exists('ily_call_gemini_api_direct')) {
            $api_keys = ily_get_all_rotated_api_keys();
            if (!empty($api_keys)) {
                $prompt = "You are an elite, world-class Tech Q&A and Expert Solution Architect.\n" .
                          "A user has posted a question on our tech community forum:\n" .
                          "Title: " . $title . "\n" .
                          "Details: " . $body . "\n\n" .
                          "Please generate 2 to 4 realistic, helpful, highly detailed expert replies/solutions to this question.\n" .
                          "Rules:\n" .
                          "- Frame the answers in the same language as the question (e.g. if the question is in Bengali/Bilingual, use natural Bengali/Bilingual for answers).\n" .
                          "- Make the solutions highly technical, step-by-step, accurate, and completely factual (using lists, code, etc.).\n" .
                          "- Use 2 to 4 different simulated usernames (e.g., 'cyber_expert', 'freelancer_rakib', 'wp_guru').\n\n" .
                          "YOU MUST RESPOND ONLY WITH A JSON OBJECT containing the 'answers' array:\n" .
                          "{\n" .
                          "  \"answers\": [\n" .
                          "    {\n" .
                          "      \"author_name\": \"(simulated username)\",\n" .
                          "      \"answer_body\": \"(First response: Detailed step-by-step expert solution)\"\n" .
                          "    },\n" .
                          "    {\n" .
                          "      \"author_name\": \"(different simulated username)\",\n" .
                          "      \"answer_body\": \"(Second response: additional/complementary advice)\"\n" .
                          "    }\n" .
                          "  ]\n" .
                          "}\n" .
                          "Do NOT use markdown code blocks (```json ... ```), print the clean JSON text directly.";

                $json_res = ily_call_gemini_api_direct($api_keys, $prompt, 3000, true, "You are a professional JSON generator.");
                
                if (!is_wp_error($json_res) && !empty($json_res)) {
                    $json_res_clean = preg_replace('/^```[a-z]*\s*/i', '', trim($json_res));
                     $json_res_clean = preg_replace('/\s*```$/', '', $json_res_clean);
                     
                     $data = json_decode($json_res_clean, true);
                     if (json_last_error() === JSON_ERROR_NONE && !empty($data['answers'])) {
                         return $data['answers'];
                     }
                 }
             }
         }

         // Fallback if API keys are missing or API fails
         return [
             [
                 'author_name' => 'cyber_expert_bd',
                 'answer_body' => 'ধন্যবাদ প্রশ্নটি করার জন্য। আমরা আপনার বিষয়টি নিয়ে আলোচনা করছি এবং খুব শীঘ্রই বিস্তারিত টেকনিক্যাল সলিউশন এখানে পোস্ট করা হবে। সাধারণত এই সমস্যার সমাধান পেতে আপনার সার্ভার কনফিগারেশন এবং পিএইচপি লিমিট চেক করা প্রয়োজন।'
             ],
             [
                 'author_name' => 'tech_guru_99',
                 'answer_body' => 'আমিও এই প্রবলেমে পড়েছিলাম। আপনার পিএইচপি ভার্সনটি ৮.১ বা ৮.২ তে আপডেট করে ট্রাই করে দেখতে পারেন। বেশির ভাগ প্লাগইন ও থিম লেটেস্ট পিএইচপি ভার্সনে অনেক ভালো কাজ করে।'
             ]
         ];
     }

    private function generate_ai_qa_content($exclude_titles = array()) {
        if (function_exists('ily_get_all_rotated_api_keys') && function_exists('ily_call_gemini_api_direct')) {
            $api_keys = ily_get_all_rotated_api_keys();
            if (!empty($api_keys)) {
                // Fetch published tools to suggest dynamically
                $tools = get_posts([
                    'post_type' => 'ilybd_tools',
                    'posts_per_page' => 12,
                    'post_status' => 'publish'
                ]);
                $tools_list_str = "";
                if (!empty($tools)) {
                    foreach ($tools as $t) {
                        $tools_list_str .= "- " . $t->post_title . " (URL: " . get_permalink($t->ID) . ")\n";
                    }
                } else {
                    $tools_list_str = "- Free IP Lookup, Free Website Speed Test, Password Generator, QR Code Generator, Word Counter, DNS Checker, Port Scanner.";
                }

                $exclude_clause = "";
                if (!empty($exclude_titles)) {
                    $exclude_clause = "CRITICAL EXCLUSION MANDATE:\n" .
                                      "Do NOT generate questions or titles similar to these already existing/rejected topics:\n";
                    foreach ($exclude_titles as $ext) {
                        $exclude_clause .= "- " . $ext . "\n";
                    }
                    $exclude_clause .= "Choose a COMPLETELY DIFFERENT topic, different brand name, and different wording.\n\n";
                }

                $prompt = "You are an elite, world-class Tech Q&A and SEO Growth Architect. Your goal is to generate an extremely engaging, realistic, and ultra-high-value technical question and multiple expert replies for a leading Tech Forum.\n\n" .
                          $exclude_clause .
                          "CRITICAL LANGUAGE & VARIETY DIRECTIVE:\n" .
                          "- Do NOT restrict yourself to only Bengali! Real users search in a mix of languages. Dynamically rotate between:\n" .
                          "  1. 35% Pure English: Highly technical, search-friendly developer/blogger/freelancer queries (e.g., 'How to bypass Upwork identity verification with local documents', 'Fixing Facebook reels monetization eligibility issue 2026', 'How to resolve Hostinger database connection established error in WordPress').\n" .
                          "  2. 35% Bilingual/Banglish Mix: Conversational tech talk common in Bangladesh (e.g., 'bKash Merchant Account খোলার নিয়ম ও ট্রানজেকশন চার্জ কত?', 'Fiverr-এ নতুন উপায়ে গিগ র‍্যাঙ্ক করার এবং বায়ার পাওয়ার সিক্রেট ট্রিকস', 'Google AdSense Identity Verification করার সময় পিন না পাওয়ার সমাধান').\n" .
                          "  3. 30% Grammatically Pristine Bengali: Pure high-intent queries (e.g., 'ক্যানভা প্রিমিয়াম ফ্রিতে পাওয়ার টিম লিংক ব্যবহারের ঝুঁকি কী?', 'ফেসবুক পেজ হ্যাক হলে মেটা চ্যাট সাপোর্টের মাধ্যমে ফিরিয়ে আনার উপায়').\n\n" .
                          "STRICT MANDATE (NO HALLUCINATIONS): You must keep the Q&A strictly logical, fully factual, and highly relevant. Do not include random facts or hallucinate features that don't exist. Keep replies highly on-topic.\n\n" .
                          "CRITICAL BRAND HIGH-JACKING & SEO DRIFT:\n" .
                          "- You MUST target high-volume search queries and issues containing names of major global/local websites, competitor brands, and digital tools. Examples of brands to target include: Google AdSense, Facebook Ads, YouTube Monetization, WordPress, ChatGPT, Hostinger, Namecheap, Cloudflare, bKash, Nagad, Canva, CapCut, TikTok, Github, Firebase, Fiverr, Upwork, LinkedIn, or Google Search Console.\n" .
                          "- Frame the question title exactly like high-intent search queries that users type in Google when they are desperate for solutions to problems on these sites. Focus heavily on remote jobs, high-paying skills, online earnings, bank transfers, MFS fees, and social media reach drops.\n\n" .
                          "CRITICAL EXPERT ANSWERS DIRECTIVE:\n" .
                          "- Generate a completely dynamic number of replies (anywhere from 1 to 6 distinct replies; choose a different number of replies for each run to ensure maximum structural variety, e.g., some runs get 1 or 2 replies, some get 3, some get 5 or 6).\n" .
                          "- The replies must match the language of the question (e.g., if the question is in English, replies must be in English or natural bilingual Tech English; if the question is in Bengali/Bilingual, replies should be in natural Bengali/Bilingual).\n" .
                          "- Provide extremely detailed, high-value, and accurate step-by-step solutions (including lists, sub-headings, and code snippets or configuration steps).\n" .
                          "- One of the replies MUST organically recommend and suggest using one of our actual tools listed below, linking to its URL using a standard HTML anchor tag (e.g., <a href='URL' target='_blank'>Tool Name</a>) with engaging, natural text around it:\n" .
                          $tools_list_str . "\n\n" .
                          "Choose a category and 3-5 highly optimized, search-friendly tags/keywords relevant to the question in lowercase English (e.g. 'chatgpt-fix', 'adsense-pin-verification', 'facebook-security-bypass', 'bkash-charge', 'fiverr-verification', 'reels-monetization'). These tags must represent actual search terms containing brand names or high-intent topics. The category must be a short, clean name (e.g., 'SEO Guide', 'Android', 'Cyber Security', 'Online Earning', 'Web Development', 'Ai').\n\n" .
                          "YOU MUST RESPOND ONLY WITH A JSON OBJECT containing the following fields:\n" .
                          "{\n" .
                          "  \"question_title\": \"(A short, clickable, search-friendly title mirroring actual Google searches in the appropriate language format)\",\n" .
                          "  \"question_body\": \"(Detailed question body explaining the technical problem or brand issue with full context, errors faced, etc.)\",\n" .
                          "  \"category\": \"(A suitable single category name, e.g. 'Cyber Security' or 'SEO Guide')\",\n" .
                          "  \"tags\": [\"brandname-problem\", \"tag2\", \"tag3\"],\n" .
                          "  \"answers\": [\n" .
                          "    {\n" .
                          "      \"author_name\": \"(A simulated username slug, e.g., 'wp_architect' or 'freelancer_rakib')\",\n" .
                          "      \"answer_body\": \"(First response: Detailed step-by-step solution, beautifully formatted with HTML lists or sub-headings)\"\n" .
                          "    },\n" .
                          "    {\n" .
                          "      \"author_name\": \"(A different simulated username slug, e.g., 'cyber_shield_agent')\",\n" .
                          "      \"answer_body\": \"(Second response: Alternating/complementary advice, organically containing the HTML link to our tool if appropriate)\"\n" .
                          "    },\n" .
                          "    {\n" .
                          "      \"author_name\": \"(Third simulated username slug, e.g., 'noc_engineer')\",\n" .
                          "      \"answer_body\": \"(Third response: Final tips or optimization instructions)\"\n" .
                          "    }\n" .
                          "  ]\n" .
                          "}\n\n" .
                          "Do NOT use markdown code blocks (```json ... ```), print the clean JSON text directly.";

                $json_res = ily_call_gemini_api_direct($api_keys, $prompt, 2500, true, "You are a professional JSON generator.");
                
                if (!is_wp_error($json_res) && !empty($json_res)) {
                    // Strip any leading/trailing backticks or wrappers if present
                    $json_res_clean = preg_replace('/^```[a-z]*\s*/i', '', trim($json_res));
                    $json_res_clean = preg_replace('/\s*```$/', '', $json_res_clean);
                    
                    $data = json_decode($json_res_clean, true);
                    if (json_last_error() === JSON_ERROR_NONE && !empty($data['question_title'])) {
                        return [
                            'question_title' => $data['question_title'],
                            'question_body'  => $data['question_body'],
                            'category'       => $data['category'],
                            'tags'           => $data['tags'],
                            'answers'        => $data['answers']
                        ];
                    }
                }
            }
        }

        // Fallback procedural AI Content Engine for BD Tech Niche (Infinite Variety, Zero Duplication)
        return $this->generate_procedural_fallback_topic($exclude_titles);
    }

    private function generate_procedural_fallback_topic($exclude_titles = array()) {
        $php_versions = ['8.1', '8.2', '8.3', '8.4'];
        $wp_versions = ['6.5', '6.6', '6.7', '6.8'];
        $hosting_providers = ['Hostinger Business', 'Namecheap Stellar Plus', 'Cloudflare Free CDN', 'DigitalOcean Droplet', 'Vercel Edge', 'AWS Lightsail', 'Kinsta Managed WP'];
        $mfs_options = ['bKash Personal Retail Account', 'Nagad Commercial Merchant', 'Rocket Agent Account', 'CellFin DBBL Smart App', 'Upay Merchant Account'];
        $qualifiers = ['(2026 Updated Method)', '[Step-by-Step Fix]', 'সমস্যার স্থায়ী সমাধান', '[100% Working Guide]', 'সমাধানের প্রফেশনাল নিয়ম', '[অফিশিয়াল গাইডলাইন]', '[২০২৬ নতুন নিয়ম]'];

        $topic_blueprints = [
            // 1. SEO & Search Engine
            [
                'cat' => 'SEO & Search Engine',
                'tags' => ['adsense-approval', 'low-value-content-fix', 'google-policy', 'seo-guidelines'],
                't_pattern' => "Google AdSense Approval-এ '%s' সমস্যার স্থায়ী সমাধান কী?",
                'b_pattern' => "আমার ব্লগ সাইটে প্রায় %dটি মানসম্মত পোস্ট প্রকাশ করেছি। কিন্তু গুগল এডসেন্স-এ আবেদন করার পর প্রতিবারই '%s' এরর দেখিয়ে রিজেক্ট করে দিচ্ছে। এই পলিসি ভায়োলেশন থেকে বাঁচার এবং দ্রুত এডসেন্স এপ্রুভাল পাওয়ার উপায় কী?",
                'vars' => [
                    ['Low Value Content', 'Valueless Inventory', 'Site Behavior: Navigation', 'Publishing Policy Violation', 'Minimum Content Requirements'],
                    [15, 22, 30, 45, 60]
                ],
                'a_builder' => function($var1, $var2) {
                    return "গুগল এডসেন্স (Google AdSense) এপ্রুভালের জন্য <b>{$var1}</b> একটি কমন সমস্যা। এটি সমাধান করার প্রফেশনাল পদক্ষেপসমূহ নিচে দেওয়া হলো:<br><br>" .
                           "1. <b>আর্টিকেলের গভীরতা ও শব্দ সংখ্যা:</b> আপনার প্রকাশিত {$var2}টি পোস্টের প্রতিটির শব্দ সংখ্যা কমপক্ষে ১২০০-১৫০০ শব্দের হওয়া আবশ্যক। কোনো এআই টুল দিয়ে জেনারেট করা ডাইরেক্ট কন্টেন্ট কপি-পেস্ট না করে নিজস্ব অভিজ্ঞতা ও টেবিল/ইমেজ যুক্ত করুন।<br>" .
                           "2. <b>অর্গানিক ইনডেক্সিং:</b> Google Search Console-এ আপনার সমস্ত পেজ সঠিকভাবে ইনডেক্স করা আছে কিনা তা নিশ্চিত করুন।<br>" .
                           "3. <b>প্রয়োজনীয় আইনি পেজ:</b> Privacy Policy, Disclaimer, About Us এবং Contact Us পেজ অবশ্যই সাইটের মেইন ফুটার মেনুতে যুক্ত রাখুন।<br><br>" .
                           "আপনার সাইটের অন-পেজ এসইও ও স্পিড অডিট করতে আমাদের <a href='/free-tools/' target='_blank'>Free Tools Suite</a> ব্যবহার করে রিপোর্ট দেখে নিতে পারেন।";
                }
            ],
            [
                'cat' => 'SEO & Search Engine',
                'tags' => ['google-search-console', 'indexing-fix', 'sitemap-error', 'seo-crawling'],
                't_pattern' => "Google Search Console-এ '%s' স্ট্যাটাস আটকে থাকলে দ্রুত ইনডেক্স করানোর উপায় কী?",
                'b_pattern' => "আমার ব্লগে নিয়মিত ইউনিক কন্টেন্ট প্রকাশ করার পরেও গুগল সার্চ কনসোলে %dটি ইউআরএল '%s' হিসেবে দেখাচ্ছে। সার্চ কনসোলে রিকোয়েস্ট ইনডেক্সিং দিলে ও সমাধান হচ্ছে না। কীভাবে দ্রুত গুগল বোটে ক্রল ও ইনডেক্স করাবো?",
                'vars' => [
                    ['Discovered - currently not indexed', 'Crawled - currently not indexed', 'Alternate page with proper canonical tag', 'Page with redirect error'],
                    [8, 14, 25, 40]
                ],
                'a_builder' => function($var1, $var2) {
                    return "গুগল সার্চ কনসোলে <b>{$var1}</b> সমস্যা সলভ করার কার্যকরী উপায়:<br><br>" .
                           "1. <b>ইন্টারনাল লিংকিং:</b> সাইটের অলরেডি ইনডেক্সড করা বড় আর্টিকেলের ভেতরে আপনার এই {$var2}টি পোস্টের অ্যাঙ্কর টেক্সট লিংক যুক্ত করুন।<br>" .
                           "2. <b>গুগল ইনডেক্সিং এপিআই (Google Indexing API):</b> ইনস্ট্যান্ট ইনডেক্সিং সার্ভিস চালু করতে গুগল ক্লাউড সার্ভিস অ্যাকাউন্ট যুক্ত করুন।<br>" .
                           "3. <b>সাইটম্যাপ রি-সাবমিশন:</b> XML sitemap ক্লিয়ার করে পুনরায় সার্চ কনসোলে জমা দিন।";
                }
            ],

            // 2. Web Development
            [
                'cat' => 'Web Development',
                'tags' => ['wordpress-ssl', 'cloudflare-mixed-content', 'https-rewrite', 'web-security'],
                't_pattern' => "How to fix WordPress mixed content error after activating Cloudflare SSL on %s?",
                'b_pattern' => "I activated free SSL on my WordPress blog hosted on %s running PHP %s. But my browser shows 'parts of this page are not secure' and some CSS/image files are breaking over HTTP. How can I resolve this mixed content issue permanently?",
                'vars' => [
                    $hosting_providers,
                    $php_versions
                ],
                'a_builder' => function($var1, $var2) {
                    return "This mixed content issue on <b>{$var1}</b> (PHP {$var2}) happens when assets are loaded over http:// instead of https://.<br><br>" .
                           "<b>Step-by-step resolution:</b><br>" .
                           "1. Open your <code>wp-config.php</code> file and insert:<br><code>define('FORCE_SSL_ADMIN', true);</code><br>" .
                           "2. Go to Cloudflare Dashboard -> <b>SSL/TLS -> Edge Certificates</b> and toggle ON <b>'Always Use HTTPS'</b> and <b>'Automatic HTTPS Rewrites'</b>.<br>" .
                           "3. Clear your WordPress transient cache and test your URL headers.";
                }
            ],
            [
                'cat' => 'Web Development',
                'tags' => ['nextjs-seo', 'react-og-tags', 'ssr-rendering', 'frontend-dev'],
                't_pattern' => "%s অ্যাপে Open Graph (OG Meta Tags) এবং ডাইনামিক এসইও সেটআপ করার উপায় কী?",
                'b_pattern' => "আমি %s দিয়ে একটি ওয়েব অ্যাপ্লিকেশন বানাচ্ছি। কিন্তু ফেসবুক বা লিংকডইনে সাইটের লিংক শেয়ার করলে কোনো থাম্বনেইল বা সোশ্যাল মেটা ট্যাগ দেখায় না। গুগল বটও সিএসআর (CSR) মোডে ডাটা রিড করতে সমস্যা করে। কীভাবে এসইও মেটাট্যাগ ডায়নামিক করবো?",
                'vars' => [
                    ['Next.js 14 App Router', 'React SPA', 'Vue 3 Nuxt', 'Laravel Blade'],
                ],
                'a_builder' => function($var1) {
                    return "<b>{$var1}</b>-এ ক্লায়েন্ট ও সোশ্যাল মিডিয়া বটের জন্য সঠিক মেটাডাটা রেন্ডারিং মেথড:<br><br>" .
                           "1. <b>Server-Side Rendering (SSR):</b> ক্লায়েন্ট সাইড রেন্ডারিংয়ের বদলে SSR বা SSG ব্যবহার করুন যাতে বট সরাসরি পেজের HTML Head অংশে OG Tags দেখতে পায়।<br>" .
                           "2. <b>Dynamic Metadata Export:</b> Next.js App Router-এ <code>export async function generateMetadata()</code> ব্যবহার করে সার্ভার থেকে ডাটাবেজ কন্টেন্ট অনুযায়ী মেটা অবজেক্ট রিটার্ন করুন।";
                }
            ],

            // 3. Online Earning & Freelancing
            [
                'cat' => 'Online Earning & Freelancing',
                'tags' => ['fiverr-verification', 'upwork-nid', 'freelancing-bd', 'identity-verify'],
                't_pattern' => "%s অ্যাকাউন্ট Identity Verification-এ NID/Smart Card রিজেকশন এড়ানোর উপায় কী?",
                'b_pattern' => "আমি %s-এ প্রথম প্রজেক্টের কাজ সম্পন্ন করার পর আইডি ভেরিফিকেশনের নোটিফিকেশন পেয়েছি। আমার কাছে শুধুমাত্র লেমিনেটেড ভোটার আইডি কার্ড আছে। কীভাবে ছবি তুললে ভেরিফিকেশন প্রথম বারেই সফল হবে?",
                'vars' => [
                    ['Fiverr Marketplace', 'Upwork Freelance', 'Payoneer Global Card', 'LinkedIn Service Page'],
                ],
                'a_builder' => function($var1) {
                    return "<b>{$var1}</b> অ্যাকাউন্ট আইডি ভেরিফিকেশনের সময় রিজেক্ট হওয়া এড়ানোর উপায়:<br><br>" .
                           "1. <b>ক্যামেরা ও লাইটিং:</b> কার্ডটি সমতল জায়গায় রেখে ফ্ল্যাশ ছাড়া দিনের আলোতে স্পষ্ট ছবি তুলুন। কোনো রিফ্লেকশন থাকা যাবে না।<br>" .
                           "2. <b>নামের বানান মিল:</b> আপনার একাউন্টের নাম এবং এনআইডি কার্ডের ইংরেজি নামের বানান হুবহু এক হতে হবে।<br>" .
                           "3. <b>স্মার্ট আইডি কার্ড PDF:</b> নির্বাচন কমিশনের ওয়েবসাইট থেকে ই-এনআইডি ডাউনলোড করে ছবি জমা দিলে এপ্রুভাল রেট ১০০%%।";
                }
            ],
            [
                'cat' => 'Online Earning & Freelancing',
                'tags' => ['remote-jobs', 'linkedin-networking', 'foreign-clients', 'software-career'],
                't_pattern' => "বাংলাদেশ থেকে LinkedIn/Upwork দিয়ে বিদেশি রিমোট ক্লায়েন্ট পাওয়ার সেরা স্ট্র্যাটেজি কী?",
                'b_pattern' => "আমি %s হিসেবে কাজ করছি। ফাইবার বা আপওয়ার্কে অতিরিক্ত প্রতিযোগিতার কারণে বিড করে কাজ পাওয়া কঠিন হয়ে যাচ্ছে। কীভাবে সরাসরি যুক্তরাষ্ট্র বা ইউরোপের কোম্পানি থেকে রিমোট জব বা ক্লায়েন্ট কন্ট্রাক্ট জোগাড় করা যায়?",
                'vars' => [
                    ['WordPress & Web Developer', 'React & Next.js Engineer', 'UI/UX Designer', 'SEO & Digital Marketer', 'Python & AI Engineer'],
                ],
                'a_builder' => function($var1) {
                    return "একজন <b>{$var1}</b> হিসেবে আউটরিচ করে সরাসরি হাই-পেয়িং বিদেশি ক্লায়েন্ট পাওয়ার গাইড:<br><br>" .
                           "1. <b>LinkedIn Profile Optimization:</b> প্রোফাইল হেডলাইনে কেবল টাইটেল না লিখে আপনি ক্লায়েন্টের কী প্রবলেম সলভ করেন তা লিখুন।<br>" .
                           "2. <b>Portfolio & Case Study:</b> আপনার সেরা ৩টি লাইভ প্রজেক্টের গিটহাব এবং লাইভ লিংক প্রোফাইলের Feature সেকশনে পিন করে রাখুন।<br>" .
                           "3. <b>Cold Outreach & Video Intro:</b> রিক্রুটার বা ডিসিশন মেকারদের উদ্দেশ্যে কাস্টমাইজড প্রোপোজাল ও ভিডিও মেসেজ পাঠান।";
                }
            ],

            // 4. Artificial Intelligence & AI
            [
                'cat' => 'Artificial Intelligence & AI',
                'tags' => ['chatgpt-api', 'openai-quota-error', 'gemini-api', 'ai-integration'],
                't_pattern' => "How to fix API %s error in custom PHP/Node.js web app?",
                'b_pattern' => "I am integrating AI features in my custom web platform running PHP %s. However, I am frequently encountering the error '%s' when sending concurrent prompt requests. How can I optimize API rate limits?",
                'vars' => [
                    ['429 Too Many Requests', 'Quota Limit Exceeded', 'Invalid API Key / Unauthorized', 'Model Overloaded Status 503'],
                    $php_versions,
                    ['429 Rate Limit Exceeded', 'Insufficient Quota Credits', 'Timeout Error status 504']
                ],
                'a_builder' => function($var1, $var2, $var3) {
                    return "The <b>{$var1}</b> / <b>{$var3}</b> error on PHP {$var2} indicates rate limits or credit exhaustion.<br><br>" .
                           "<b>Fixing methods:</b><br>" .
                           "1. <b>Billing Tier:</b> Ensure your developer account has a valid payment method attached.<br>" .
                           "2. <b>Exponential Backoff:</b> Implement a retry loop with exponential delay in your API client script.<br>" .
                           "3. <b>Key Rotation:</b> Rotate between multiple valid API keys or use Google Gemini API for generous free tier quotas.";
                }
            ],

            // 5. Cyber Security & Privacy
            [
                'cat' => 'Cyber Security & Privacy',
                'tags' => ['wordpress-security', 'malware-cleanup', 'backdoor-removal', 'hacked-site'],
                't_pattern' => "WordPress সাইটে হ্যাকিং ও মালওয়্যার ইনজেকশন হলে কীভাবে ক্লিয়ার করবেন?",
                'b_pattern' => "আমার ওয়ার্ডপ্রেস সাইটে গুগল সার্চ করলে জাপানিজ বা রিডাইরেক্ট লিংক দেখাচ্ছে। সাইটের `wp-content/uploads` এবং `index.php` ফাইলে অজ্ঞাত কোড ঢুকে গেছে। হ্যাক হওয়া সাইট কীভাবে সম্পূর্ণ ক্লিন ও সিকিউর করবো?",
                'vars' => [
                    ['Japanese SEO Redirect', 'Redirection Script Malware', 'Crypto Miner Injection', 'Spam Doorway Injection']
                ],
                'a_builder' => function($var1) {
                    return "ওয়ার্ডপ্রেস সাইট থেকে <b>{$var1}</b> মালওয়্যার রিমুভ করার অফিশিয়াল প্রসেস:<br><br>" .
                           "1. <b>Core Files Replacement:</b> WordPress.org থেকে ফ্রেশ ওয়ার্ডপ্রেস জিপ ফাইল নামিয়ে `wp-includes` এবং `wp-admin` ফোল্ডার প্রতিস্থাপন করুন।<br>" .
                           "2. <b>Uploads Folder Cleaning:</b> `wp-content/uploads/` ফোল্ডারের ভেতর কোনো `.php` ফাইল থাকলে তা সাথে সাথে ডিলিট করুন।<br>" .
                           "3. <b>Database Cleaning:</b> ডাটাবেজের `wp_options` এবং `wp_posts` টেবিলে থাকা ক্ষতিকারক সাশ্রয়ী স্ক্রিপ্টগুলো `wp-cli` বা SQL দিয়ে মুছে ফেলুন।";
                }
            ],

            // 6. WordPress & Blogging
            [
                'cat' => 'WordPress & Blogging',
                'tags' => ['wordpress-speed', 'wp-rocket', 'lcp-optimization', 'page-speed'],
                't_pattern' => "WordPress সাইটে PageSpeed Insights-এ %s স্কোর বাড়ানোর উপায় কী?",
                'b_pattern' => "আমার ওয়ার্ডপ্রেস নিউজ/ব্লগ সাইটে এলিমেন্টর ও প্রচুর প্লাগইন ব্যবহারের কারণে মোবাইলে গুগল পেজস্পিড স্কোর মাত্র %d দেখাচ্ছে। LCP এবং INP ফিক্স করে কীভাবে ৯০+ স্কোর অর্জন করবো?",
                'vars' => [
                    ['Mobile LCP & Speed', 'Core Web Vitals', 'Desktop & Mobile Performance'],
                    [25, 38, 45, 52]
                ],
                'a_builder' => function($var1, $var2) {
                    return "ওয়ার্ডপ্রেস মোবাইল স্কোর {$var2} থেকে বাড়িয়ে ৯০+ করার কার্যকরী টিপস:<br><br>" .
                           "1. <b>Unused CSS/JS Defer:</b> WP Rocket, Perfmatters বা LiteSpeed Cache দিয়ে অব্যবহৃত সিএসএস ও জাভাস্ক্রিপ্ট ডিফার রেন্ডারিং মোডে সেট করুন।<br>" .
                           "2. <b>WebP/AVIF Image Compression:</b> সমস্ত ইমেজ WebP বা AVIF ফরম্যাটে কম্প্রেস করুন।<br>" .
                           "3. <b>Redis / Object Cache:</b> সার্ভার লেভেলে Redis অবজেক্ট ক্যাশিং সক্রিয় করুন।";
                }
            ],

            // 7. Meta & Facebook Growth
            [
                'cat' => 'Meta & Facebook Growth',
                'tags' => ['facebook-reach-drop', 'shadowban-fix', 'social-media-security', 'meta-policy'],
                't_pattern' => "Facebook Page-এ হঠাৎ রিচ ডাউন ও শ্যাডৌব্যান (Shadowban %s) সমাধান করবেন কীভাবে?",
                'b_pattern' => "আমার টেক/নিউজ পেজে আগে নিয়মিত হাজার হাজার অর্গানিক রিচ আসতো। কিন্তু গত কয়েকদিন ধরে নতুন কোনো পোস্ট দিলে রিচ একেবারেই হচ্ছে না। এটি কি ফেক রিপোর্ট বা শ্যাডৌব্যান? কীভাবে পেজের হেলথ স্ট্যাটাস %s ফিরে পাবেন?",
                'vars' => [
                    ['2026 Update', 'Policy Violation Flag', 'Unoriginal Content Warning'],
                    ['100% Green Status', 'Recommendation Eligible', 'Active Monetization Safe']
                ],
                'a_builder' => function($var1, $var2) {
                    return "ফেসবুক পেজ রিচ ডাউন ও শ্যাডৌব্যান ({$var1}) ফিক্স করার অফিশিয়াল স্টেপস:<br><br>" .
                           "1. <b>Page Quality & Recommendation Check:</b> আপনার পেজের Profile Recommendation ট্যাবে গিয়ে কোনো 'Flagged Content' থাকলে তা সঙ্গে সঙ্গে ডিলিট করুন।<br>" .
                           "2. <b>অর্গানিক কন্টেন্ট ও রিলস (Reels):</b> প্রতিদিন অন্তত ২-৩টি ইউনিক ভিডিও রিলস আপলোড করুন। এটি অ্যালগরিদমে ইতিবাচক সিগন্যাল পাঠায়।<br>" .
                           "3. <b>স্প্যাম শেয়ার বন্ধ করা:</b> একই আইডি বা আইপি থেকে বারবার পোস্ট গ্রুপে শেয়ার করা থেকে বিরত থাকুন।";
                }
            ],

            // 8. YouTube & Content Creation
            [
                'cat' => 'YouTube & Content Creation',
                'tags' => ['youtube-reused-content', 'monetization-rejected', 'appeal-video', 'gaming-channel'],
                't_pattern' => "YouTube Channel-এ %s সমস্যার কারণে মনিটাইজেশন রিজেক্ট হলে কীভাবে আপিল ভিডিও তৈরি করবেন?",
                'b_pattern' => "আমি নিজের ইউটিউব চ্যানেলে ভয়েসওভার ও গেমপ্লে আপলোড করার পর ইউটিউব থেকে বলা হয়েছে 'Channel not approved due to %s'। এই রিজেকশন সলভ করে রি-এপ্লাই বা আপিল ভিডিও পাঠানোর সঠিক নিয়ম কী?",
                'vars' => [
                    ['Reused Content', 'Repetitive Content', 'Ineligible Monetization Policy', 'Misleading Metadata'],
                ],
                'a_builder' => function($var1) {
                    return "ইউটিউব <b>{$var1}</b> আপিল ভিডিও সফল করার গাইডলাইন:<br><br>" .
                           "1. <b>৫ মিনিটের আপিল ভিডিও:</b> ভিডিওতে আপনার চেহারার সাথে ইংরেজি বা সাবটাইটেল সহ আপনার ভিডিও এডিটিং সফ্টওয়্যার (CapCut/Premiere Pro) স্ক্রিন রেকর্ড করে দেখান।<br>" .
                           "2. <b>অরিজিনাল ভয়েস প্রমাণ:</b> আপনি কীভাবে ভয়েস রেকর্ড করেন এবং অডিও প্রসেস করেন তা ধাপে ধাপে ভিডিওতে বিস্তারিত ব্যাখ্যা করুন।<br>" .
                           "3. <b>Unlisted Link Submit:</b> ভিডিওটি ইউটিউবে Unlisted হিসেবে আপলোড করে আপিল বক্সে লিংক পেস্ট করুন।";
                }
            ],

            // 9. FinTech & MFS Bangladesh
            [
                'cat' => 'FinTech & MFS Bangladesh',
                'tags' => ['bkash-merchant', 'mfs-limit', 'online-payment', 'bangladesh-fintech'],
                't_pattern' => "%s: চার্জ, দৈনিক লেনদেনের লিমিট ও অ্যাকাউন্ট খোলার নিয়ম কী?",
                'b_pattern' => "আমি একটি নতুন ই-কমার্স পেজ ও ওয়েবসাইট শুরু করতে যাচ্ছি। কাস্টমারদের কাছ থেকে পেমেন্ট নেওয়ার জন্য %s ব্যবহার করা কতটা সুবিধাজনক? এর জন্য ট্রেড লাইসেন্স লাগবে কি না এবং ক্যাশআউট চার্জ কত?",
                'vars' => [
                    $mfs_options
                ],
                'a_builder' => function($var1) {
                    return "<b>{$var1}</b> ব্যবহারের বিস্তারিত নির্দেশিকা নিচে দেওয়া হলো:<br><br>" .
                           "1. <b>প্রয়োজনীয় কাগজপত্র:</b> ট্রেড লাইসেন্স, মালিকের NID কার্ডের কপি, পাসপোর্ট সাইজ ছবি এবং ব্যাংক অ্যাকাউন্ট ডিটেইলস প্রয়োজন হবে।<br>" .
                           "2. <b>চার্জ ও লিমিট:</b> সাধারণ পেমেন্ট রিসিভে মার্চেন্ট কমিশন কাটে (সাধারণত ১.২%% - ১.৫%%)। তবে দৈনন্দিন ও মাসিক লেনদেনের লিমিট সাধারণ অ্যাকাউন্টের চেয়ে বহুগুণ বেশি।<br>" .
                           "3. <b>API ইন্টিগ্রেশন:</b> ওয়েবসাইটের সাথে অটোমেটেড পেমেন্ট গেটওয়ে প্লাগইন যুক্ত করে অটো-কনফার্মেশন চালু করা সম্ভব।";
                }
            ],

            // 10. Domain & Web Hosting
            [
                'cat' => 'Domain & Web Hosting',
                'tags' => ['domain-dns', 'hosting-migration', 'cpanel-nameservers', 'a-record'],
                't_pattern' => "%s থেকে হোস্টিং কিনার পর DNS Nameserver ও A Record আপডেট করার সঠিক নিয়ম কী?",
                'b_pattern' => "আমি অন্য একটি ডোমেইন রেজিস্টার থেকে ডোমেইন কিনে %s হোস্টিংয়ের সাথে পয়েন্ট করাতে চাচ্ছি। নেমসার্ভার চেঞ্জ করার পর কতক্ষণ সময় লাগে এবং ডিএনএস প্রোপাগেশন দ্রুত চেক করবেন কীভাবে?",
                'vars' => [
                    $hosting_providers
                ],
                'a_builder' => function($var1) {
                    return "<b>{$var1}</b> হোস্টিংয়ে ডোমেইন কানেক্ট করার স্টেপ-バイ-স্টেপ নিয়ম:<br><br>" .
                           "1. <b>Nameservers Update:</b> ডোমেইন কন্ট্রোল প্যানেলে গিয়ে ডোমেইনের কাস্টম নেমসার্ভার আপডেট করে দেওয়া।<br>" .
                           "2. <b>DNS Propagation Check:</b> নেমসার্ভার ও A Record সম্পূর্ণ প্রোপাগেট হতে ২ থেকে ২৪ ঘণ্টা লাগতে পারে। আমাদের <a href='/free-tools/' target='_blank'>Free DNS Checker Tool</a> ব্যবহার করে বিশ্বব্যাপী স্ট্যাটাস দেখে নিতে পারেন।";
                }
            ],

            // 11. Affiliate & Digital Marketing
            [
                'cat' => 'Affiliate & Digital Marketing',
                'tags' => ['amazon-affiliate', 'bangladesh-marketers', 'affiliate-commission', 'niche-site'],
                't_pattern' => "বাংলাদেশ থেকে %s একাউন্ট এপ্রুভ করানো এবং প্রথম ৩টি সেল পাওয়ার উপায় কী?",
                'b_pattern' => "আমি নিস সাইট বা ফেসবুক পেজের মাধ্যমে %s এ এফিলিয়েট মার্কেটিং শুরু করেছি। কিন্তু প্রথম ১৮০ দিনের মধ্যে ৩টি কোয়ালিফাইড সেল না পেলে অ্যাকাউন্ট ব্যান হয়ে যাওয়ার ভয় থাকে। কীভাবে দ্রুত সেল জেনারেট করবো?",
                'vars' => [
                    ['Amazon Associate Program', 'Impact Radius Affiliate', 'ShareASale Network', 'CJ Affiliate Network']
                ],
                'a_builder' => function($var1) {
                    return "<b>{$var1}</b> এপ্রুভাল এবং সফলভাবে সেলস বাড়ানোর কৌশল:<br><br>" .
                           "1. <b>Buying Intent Content:</b> সরাসরি প্রোডাক্ট লিংক শেয়ার না করে 'Best Top 5 Product Review' ও তুলনামূলক গাইড পোস্ট লিখুন।<br>" .
                           "2. <b>US/EU Targeted Traffic:</b> সোশ্যাল মিডিয়ায় পিন্টারেস্ট (Pinterest) ও মিডিয়াম (Medium) ব্যবহার করে অর্গানিক টার্গেটেড ট্রাফিক আনুন।";
                }
            ],

            // 12. Graphics & UI/UX Design
            [
                'cat' => 'Graphics & UI/UX Design',
                'tags' => ['canva-pro', 'figma-ui', 'design-privacy', 'vector-graphics'],
                't_pattern' => "ফ্রি %s টিম ইনভাইটেশন লিংক ব্যবহারের সাইবার নিরাপত্তা ও প্রাইভেসি ঝুঁকি কেমন?",
                'b_pattern' => "অনেকেই বিভিন্ন সোশ্যাল মিডিয়ায় ফ্রিতে %s প্রো ব্যবহারের জয়েনিং লিংক শেয়ার করে। এগুলো ব্যবহার করে পার্সোনাল ফটো বা ক্লায়েন্টের জন্য ডিজাইন করা কতটা নিরাপদ? ডিজাইন কি টিমের অন্যরা দেখতে পায়?",
                'vars' => [
                    ['Canva Pro Team', 'Adobe Creative Cloud Team', 'Figma Pro Team']
                ],
                'a_builder' => function($var1) {
                    return "ফ্রি <b>{$var1}</b> লিংক ব্যবহারের ক্ষেত্রে যে ঝুঁকিগুলো থাকে:<br><br>" .
                           "1. <b>Design Visibility:</b> ভুলবশত টিম শেয়ারিং অন থাকলে আপনার তৈরি সমস্ত প্রাইভেট ফাইল ও ক্লায়েন্ট প্রজেক্ট টিমের এডমিন বা মেম্বারদের কাছে দৃশ্যমান হয়ে যায়।<br>" .
                           "2. <b>Account Suspension:</b> অনফিশিয়াল জয়েনিং লিংক ক্যানভা বা এডোবি টিম ব্যান করে দিলে আপনার সমস্ত কাজ চিরতরে হারিয়ে যেতে পারে।";
                }
            ],

            // 13. E-Commerce & F-Commerce
            [
                'cat' => 'E-Commerce & F-Commerce',
                'tags' => ['f-commerce-bd', 'courier-api', 'steadfast-pathao', 'online-shop'],
                't_pattern' => "বাংলাদেশে ই-কমার্স/এফ-কমার্স শপের জন্য %s কুরিয়ার এপিআই ইন্টিগ্রেশন ও অটোমেটেড ট্র্যাকিং নিয়ম?",
                'b_pattern' => "আমি ওয়ার্ডপ্রেস ও পেজে নিজের অনলাইন শপ পরিচালনা করি। কাস্টমারের পার্সেল বুকিং অটোমেটিক করার জন্য %s এপিআই (Courier API) কীভাবে সাইটে কানেক্ট করবো?",
                'vars' => [
                    ['Steadfast Courier API', 'Pathao Courier API', 'Paperfly Express API', 'RedX Logistics API']
                ],
                'a_builder' => function($var1) {
                    return "ওয়ার্ডপ্রেসে <b>{$var1}</b> যুক্ত করার প্রফেশনাল মেথড:<br><br>" .
                           "1. <b>API Key Generation:</b> কুরিয়ারের মার্চেন্ট প্যানেল থেকে Secret Key এবং Client ID সংগ্রহ করুন।<br>" .
                           "2. <b>Automated Order Status:</b> অর্ডার প্লেস হওয়ার সাথে সাথেই কুরিয়ার প্যানেলে কনসাইনমেন্ট তৈরি হবে এবং কাস্টমার এসএমএসে ট্র্যাকিং লিংক পেয়ে যাবে।";
                }
            ],

            // 14. Mobile Apps & Android
            [
                'cat' => 'Mobile Apps & Android',
                'tags' => ['google-play-console', 'duns-number', 'app-publishing', 'android-dev'],
                't_pattern' => "Google Play Console-এ %s অ্যাকাউন্ট ভেরিফিকেশন ও D-U-N-S নাম্বার পাওয়ার সঠিক উপায়?",
                'b_pattern' => "আমি প্লে কনসোলে মোবাইল অ্যাপ পাবলিশ করার জন্য ডেভেলপার একাউন্ট খুলেছি। কিন্তু অর্গানাইজেশন টাইপ একাউন্টের জন্য ডান অ্যান্ড ব্র্যান্ডস্ট্রিট (DUNS) নাম্বার চাচ্ছে। বাংলাদেশ থেকে কীভাবে এটি সহজে রেজিস্ট্রেশন করা যায়?",
                'vars' => [
                    ['Organization Developer', 'Individual App Developer', 'Merchant Billing Account']
                ],
                'a_builder' => function($var1) {
                    return "গুগল প্লে কনসোল <b>{$var1}</b> ভেরিফিকেশনের নিয়মাবলী:<br><br>" .
                           "1. <b>Official D-U-N-S Portal:</b> D&B ওয়েবসাইটে গিয়ে ট্রেড লাইসেন্সের তথ্য দিয়ে বিনামূল্যে DUNS নাম্বারের আবেদন করুন।<br>" .
                           "2. <b>Matching Address & Bank:</b> প্লে কনসোলের নাম ও অ্যাড্রেস যেন ট্রেড লাইসেন্সের সাথে হুবহু মিল থাকে তা নিশ্চিত করুন।";
                }
            ],

            // 15. Programming & Coding
            [
                'cat' => 'Programming & Coding',
                'tags' => ['javascript-async', 'php-performance', 'python-fastapi', 'coding-best-practices'],
                't_pattern' => "%s-এ Async/Await এবং Memory Leak মেমরি অপ্টিমাইজেশনের সঠিক নিয়ম কী?",
                'b_pattern' => "আমি %s দিয়ে একটি হাই-ট্রাফিক অ্যাপ্লিকেশন ডেভেলপ করছি। কিন্তু ব্যাকএন্ডে কনকারেন্ট রিকোয়েস্ট আসার পর সার্ভারের RAM ব্যবহার ১০০%% হয়ে ক্র্যাশ করছে। কীভাবে মেমরি লিক ডায়াগনোজ ও ফিক্স করবো?",
                'vars' => [
                    ['JavaScript / Node.js', 'PHP 8.3 ReactPHP', 'Python AsyncIO / FastAPI', 'Go Golang Goroutines']
                ],
                'a_builder' => function($var1) {
                    return "<b>{$var1}</b> অ্যাপ্লিকেশনে মেমরি লিক প্রিভেনশন গাইড:<br><br>" .
                           "1. <b>Event Listener Cleanup:</b> অনাকাঙ্ক্ষিত গ্লোবাল ভ্যারিয়েবল ও আনক্লোজড ইভেন্ট লিসেনারগুলো এক্সিকিউশন শেষে মেমরি থেকে রিলিজ করুন।<br>" .
                           "2. <b>Database Connection Pooling:</b> প্রতি রিকোয়েস্টে নতুন ডাটাবেজ কানেকশন না খুলে কানেকশন পুলিং ব্যবহার করুন।";
                }
            ],

            // 16. Cloud & Server Management
            [
                'cat' => 'Cloud & Server Management',
                'tags' => ['nginx-reverse-proxy', 'docker-container', 'ubuntu-server', 'cloud-infrastructure'],
                't_pattern' => "Ubuntu Server-এ Nginx Reverse Proxy এবং %s কনফিগারেশনের সঠিক নিয়ম কী?",
                'b_pattern' => "%s ক্লাউড সার্ভারে Docker Container রান করে Port 3000 রিডাইরেক্ট করে পোর্ট 80/443-এ ওয়েবসাইট লাইভ করতে চাই। Nginx server block ফাইল কীভাবে কনফিগার করবো?",
                'vars' => [
                    ['Docker Compose Stack', 'Node.js Express App', 'Python Gunicorn App'],
                    ['DigitalOcean Droplet', 'AWS EC2 Instance', 'Hetzner Cloud Server']
                ],
                'a_builder' => function($var1, $var2) {
                    return "<b>{$var2}</b>-এ Nginx Reverse Proxy সহ <b>{$var1}</b> সেটআপ করার স্ট্যান্ডার্ড ব্লক কোড:<br><br>" .
                           "<code>location / { proxy_pass http://127.0.0.1:3000; proxy_set_header Host \$host; }</code><br><br>" .
                           "কনফিগারেশনের পর `sudo nginx -t` দিয়ে সিনট্যাক্স টেস্ট করে `sudo systemctl reload nginx` রান করুন।";
                }
            ],

            // 17. Hardware & PC Building
            [
                'cat' => 'Hardware & PC Building',
                'tags' => ['pc-build-bd', 'gpu-bottleneck', 'nvme-ssd', 'editing-pc'],
                't_pattern' => "বাংলাদেশে ৫০,০০০-৮০,০০০ টাকার মধ্যে %s-এর জন্য সেরা বাজেট PC Build গাইড?",
                'b_pattern' => "আমি ফ্রিল্যান্সিং ও ভিডিও এডিটিংয়ের কাজের জন্য একটি নতুন কাস্টম ডেস্কটপ পিসি বানাতে চাই। প্রসেসর (Intel/Ryzen), RAM (Dual Channel) এবং NVMe SSD বাছাইয়ে কোন কম্পোনেন্টগুলো সেরা কম্বিনেশন হবে?",
                'vars' => [
                    ['Video Editing & Motion Graphics', 'Full-Stack Web Development & Docker', 'Gaming & Live Streaming', 'AI Model Training & Machine Learning']
                ],
                'a_builder' => function($var1) {
                    return "<b>{$var1}</b>-এর জন্য প্রফেশনাল পিসি বিল্ডিং সাজেশন:<br><br>" .
                           "1. <b>Processor:</b> Intel Core i5 13th/14th Gen অথবা Ryzen 5 5600G/7600X বেছে নিন।<br>" .
                           "2. <b>RAM & SSD:</b> ন্যূনতম 16GB DDR4/DDR5 Dual Channel RAM এবং PCIe Gen4 512GB NVMe M.2 SSD ব্যবহার করুন যা রেন্ডারিং স্পিড ৪ গুণ বাড়িয়ে দেবে।";
                }
            ],

            // 18. Tech News & Gadgets
            [
                'cat' => 'Tech News & Gadgets',
                'tags' => ['esim-bangladesh', '5g-network', 'mobile-technology', 'gadget-reviews'],
                't_pattern' => "বাংলাদেশে %s সিম টু eSIM মাইগ্রেশন করার প্রসেস ও সুবিধা কী কী?",
                'b_pattern' => "আমার স্মার্টফোনে ই-সিম (eSIM) সাপোর্ট করে। প্লাস্টিক ফিজিক্যাল সিম পরিবর্তন করে ই-সিম কার্ড একটিভ করতে কাস্টমার কেয়ারে কত টাকা লাগে এবং সুবিধা কী কী?",
                'vars' => [
                    ['Grameenphone', 'Robi Axiata', 'Banglalink', 'Teletalk 5G']
                ],
                'a_builder' => function($var1) {
                    return "<b>{$var1}</b> ই-সিম (eSIM) মাইগ্রেশন গাইড:<br><br>" .
                           "1. <b>নির্ধারিত ফি:</b> আপনার নিকটস্থ কাস্টমার কেয়ার সেন্টারে NID ভেরিফিকেশন করিয়ে ৩০০-৪োর টাকায় ই-সিম কিউআর কোড (QR Code) সংগ্রহ করতে পারবেন।<br>" .
                           "2. <b>সুবিধা:</b> ফোন হারিয়ে গেলেও সিম কখনো খুলতে পারবে না এবং একই সাথে একটি ডিভাইসে একাধিক নম্বর ব্যবহার করা সম্ভব।";
                }
            ],

            // 19. Software & Tools Guide
            [
                'cat' => 'Software & Tools Guide',
                'tags' => ['vs-code-extensions', 'developer-productivity', 'windows-speedup', 'dev-tools'],
                't_pattern' => "%s ডেভেলপারদের জন্য ২০২৬ সালের সেরা ১০টি VS Code Extensions কী কী?",
                'b_pattern' => "আমি ভিএস কোডে কোডিং করার স্পিড এবং কোয়ালিটি বাড়াতে চাই। এমন কিছু কাজের এক্সটেনশন এবং শটকার্ট ট্রিক্স দরকার যা প্রতিদিনের কোডিংয়ের সময় বাঁচাবে।",
                'vars' => [
                    ['Web & Full-Stack', 'Python & Data Science', 'Flutter & Mobile App', 'PHP & WordPress']
                ],
                'a_builder' => function($var1) {
                    return "একজন <b>{$var1}</b> ডেভেলপারের জন্য অতীব প্রয়োজনীয় ভিএস কোড প্লাগইনসমূহ:<br><br>" .
                           "1. <b>Prettier & ESLint:</b> কোড ফরম্যাটিং ও সিনট্যাক্স এরর সাথে সাথে ফিক্স করার জন্য।<br>" .
                           "2. <b>GitHub Copilot / Tabnine:</b> এআই কোড অটো-কমপ্লিশন।<br>" .
                           "3. <b>GitLens:</b> লাইনে লাইনে গিট কমিট হিস্ট্রি দেখার জন্য।";
                }
            ],

            // 20. Networking & Broadband
            [
                'cat' => 'Networking & Broadband',
                'tags' => ['fiber-router', 'dual-band-wifi', 'bandwidth-test', 'isp-bangladesh'],
                't_pattern' => "ব্রডব্যান্ড ইন্টারনেটে %s রাউটার কনফিগারেশন এবং ওয়াইফাই স্পিড বাড়ানোর উপায়?",
                'b_pattern' => "আমার অন নেটওয়ার্কে ফাইবার অপটিক ব্রডব্যান্ড কানেকশন আছে। কিন্তু ঘরের অন্য রুমে গেলে ওয়াইফাই সিগন্যাল ড্রপ করে এবং স্পিড কমে যায়। 2.4GHz নাকি 5GHz ব্যান্ড কোনটা অন রাখা উচিত?",
                'vars' => [
                    ['Dual-Band Gigabit', 'Wi-Fi 6 Mesh System', 'ONU Optical Fiber Router']
                ],
                'a_builder' => function($var1) {
                    return "<b>{$var1}</b> রাউটারে সর্বোচ্চ ওয়াইফাই কাভারেজ পাওয়ার উপায়:<br><br>" .
                           "1. <b>5GHz Frequency:</b> রাউটারের কাছে থাকলে 5GHz ব্যান্ড ব্যবহার করুন যা সর্বোচ্চ স্পিড দেবে।<br>" .
                           "2. <b>Channel Width:</b> 2.4GHz ব্যান্ডের জন্য Channel Width 20MHz এবং 5GHz ব্যান্ডের জন্য 80MHz সেট করুন।";
                }
            ],

            // 21. Career & Remote Jobs
            [
                'cat' => 'Career & Remote Jobs',
                'tags' => ['resume-ats', 'software-engineer-interview', 'tech-career', 'fresher-job'],
                't_pattern' => "Software Engineer/Web Developer পদের জন্য ATS Friendly Resume বানানোর উপায় কী?",
                'b_pattern' => "আমি বিভিন্ন আইটি ফার্ম ও প্রজেক্টে সিভি পাঠাচ্ছি কিন্তু কোনো ইন্টারভিউ কল পাচ্ছি না। কীভাবে ATS (Applicant Tracking System) অপটিমাইজড রেজুমে বানাবো যাতে আন্তর্জাতিক রিক্রুটিং সফটওয়্যার পাস করে?",
                'vars' => [
                    ['Full-Stack Engineer', 'Frontend React Developer', 'SQA & Test Automation', 'DevOps Engineer']
                ],
                'a_builder' => function($var1) {
                    return "একজন <b>{$var1}</b> হিসেবে ATS ফ্রেন্ডলি রেজুমে ফরম্যাট করার নিয়ম:<br><br>" .
                           "1. <b>Simple One-Column Layout:</b> গ্রাফিক ক্যানভা ডিজাইন এড়িয়ে একদম সাধারণ এক কলাম বিশিষ্ট ওয়ার্ড বা টেক্সট পিডিএফ ব্যবহার করুন।<br>" .
                           "2. <b>Action Verbs & Metrics:</b> 'Developed a web app' না লিখে লিখুন 'Architected scalable React frontend improving page load by 40%%'।";
                }
            ],

            // 22. Banking & Credit Cards
            [
                'cat' => 'Banking & Credit Cards',
                'tags' => ['dual-currency-card', 'passport-endorsement', 'ebl-aqua', 'foreign-payment'],
                't_pattern' => "পাসপোর্ট ছাড়াই %s ডুয়াল কারেন্সি প্রিপেইড কার্ড নেওয়ার উপায় ও ট্রানজেকশন লিমিট?",
                'b_pattern' => "আমি আন্তর্জাতিক ওয়েবসাইটে কেনাকাটা বা ডোমেইন-হোস্টিং কিনার জন্য কার্ড তৈরি করতে চাই। পাসপোর্ট ছাড়া ব্যাংক থেকে কোন ব্যাংক কী কার্ড প্রদান করে এবং ক্যাশ ইন বা লোড করার নিয়ম কী?",
                'vars' => [
                    ['EBL Aqua Mastercard', 'UCB Real Prepaid Card', 'City Bank American Express', 'DBBL Visa Prepaid Card']
                ],
                'a_builder' => function($var1) {
                    return "<b>{$var1}</b> ডুয়াল কারেন্সি কার্ড ব্যবহারের সরকারি নিয়মাবলী:<br><br>" .
                           "1. <b>Passport Endorsement:</b> পাসপোর্ট ছাড়া শুধুমাত্র টাকার পার্টে (NID দিয়ে) লোকাল কেনাকাটা করা যায়। তবে ডলার পার্ট এনডোর্স করতে অবশ্যই ভ্যালিড পাসপোর্ট লাগবে।<br>" .
                           "2. <b>Travel Quota Limit:</b> একজন নাগরিক বছরে সর্বোচ্চ ১২,০০০ মার্কিন ডলার পর্যন্ত ব্যবহার করতে পারেন।";
                }
            ],

            // 23. Database & SQL
            [
                'cat' => 'Database & SQL',
                'tags' => ['mysql-optimization', 'n-plus-one-query', 'database-indexing', 'sql-tuning'],
                't_pattern' => "MySQL/PostgreSQL ডাটাবেজে %s সমস্যা সমাধান ও ক্যোয়ারি স্পিড বাড়াবেন কীভাবে?",
                'b_pattern' => "আমার ওয়েবসাইটের ডাটাবেজে লাখের উপর রেকর্ড জমা হওয়ার পর পেজ লোড হতে ৫-১০ সেকেন্ড সময় লাগছে। `EXPLAIN` রান করে দেখা যাচ্ছে ফুল টেবিল স্ক্যান হচ্ছে। কীভাবে সঠিক ইন্ডেক্সিং (Indexing) যুক্ত করবো?",
                'vars' => [
                    ['Slow Query Execution', 'N+1 Query Overhead', 'Database Lock Wait Timeout', 'High CPU Usage']
                ],
                'a_builder' => function($var1) {
                    return "ডাটাবেজের <b>{$var1}</b> সলভ করার প্রফেশনাল পদ্ধতি:<br><br>" .
                           "1. <b>Add Composite Indexes:</b> WHERE, JOIN এবং ORDER BY ক্লজে ব্যবহৃত ফিল্ডগুলোতে সঠিক ইন্ডেক্স যুক্ত করুন।<br>" .
                           "2. <b>Eager Loading:</b> লুপের ভেতর বার বার ডাটাবেজ ক্যোয়ারি না চালিয়ে ORM-এর Eager Loading (With Query) ব্যবহার করুন।";
                }
            ],

            // 24. Video Editing & Animation
            [
                'cat' => 'Video Editing & Animation',
                'tags' => ['capcut-desktop', 'premiere-pro-export', 'reels-video-editing', '4k-export'],
                't_pattern' => "%s দিয়ে ফেসবুক ও ইউটিউব রিলসের জন্য হাই কোয়ালিটি 4K Export Settings?",
                'b_pattern' => "আমি সোশ্যাল মিডিয়ার জন্য ভিডিও এডিট করি। কিন্তু আপলোড করার পর ফেসবুক বা ইউটিউবে ভিডিও ব্লার হয়ে কোয়ালিটি নষ্ট হয়ে যায়। কোন বিটরেট (Bitrate) এবং ফ্রেমরেটে (60fps) এক্সপোর্ট করা উচিত?",
                'vars' => [
                    ['CapCut Desktop', 'Adobe Premiere Pro', 'DaVinci Resolve', 'Mobile Video Editors']
                ],
                'a_builder' => function($var1) {
                    return "<b>{$var1}</b>-এ ক্রিস্পি ক্লিয়ার ভিডিও এক্সপোর্ট করার সেটিংস:<br><br>" .
                           "1. <b>Resolution & Codec:</b> 1080x1920 (Vertical 9:16) অথবা 4K রেন্ডার করে H.264 MP4 ফরম্যাটে এক্সপোর্ট করুন।<br>" .
                           "2. <b>Target Bitrate:</b> রিলসের জন্য Target Bitrate ১৫-২০ Mbps এবং VBR 2-Pass নির্বাচন করুন।";
                }
            ],

            // 25. General Tech Q&A
            [
                'cat' => 'General Tech Q&A',
                'tags' => ['cyber-safety', 'ai-deepfake-protection', 'digital-footprint', 'tech-tips'],
                't_pattern' => "অনলাইনে নিজের ছবি ও পার্সোনাল ডাটা %s থেকে নিরাপদ রাখার নিয়ম কী?",
                'b_pattern' => "বর্তমান সময়ে সাইবার স্পেসে প্রাইভেসি রক্ষা করা একটি বড় চ্যালেঞ্জ। এআই ডিপফেক বা ফেক অ্যাকাউন্ট থেকে নিজের ডিজিটাল আইডেন্টিটি এবং ছবি সুরক্ষিত রাখার জন্য জরুরি পদক্ষেপগুলো কী কী?",
                'vars' => [
                    ['AI Deepfake & Identity Theft', 'Phishing Links & Scams', 'Data Leak & Privacy Loss']
                ],
                'a_builder' => function($var1) {
                    return "অনলাইনে <b>{$var1}</b> থেকে সুরক্ষিত থাকার জন্য প্রফেশনাল টিপস:<br><br>" .
                           "1. <b>Two-Factor Authentication (2FA):</b> প্রতিটি ইমেইল ও সোশ্যাল একাউন্টে গুগল অথেনটিকেটর অ্যাপ দিয়ে 2FA চালু রাখুন।<br>" .
                           "2. <b>Watermark Photos:</b> সোশ্যাল মিডিয়ায় ফুল রেজুলেশন ফটো আপলোড করা থেকে বিরত থাকুন এবং প্রাইভেসি সেটিংস অন রাখুন।";
                }
            ]
        ];

        // Try generating a unique procedural topic
        for ($attempt = 0; $attempt < 30; $attempt++) {
            $bp = $topic_blueprints[array_rand($topic_blueprints)];
            
            // Pick random vars
            $chosen_vars = [];
            foreach ($bp['vars'] as $v_list) {
                $chosen_vars[] = $v_list[array_rand($v_list)];
            }
            
            $q_title = vsprintf($bp['t_pattern'], array_slice($chosen_vars, 0, substr_count($bp['t_pattern'], '%s')));
            $q_body  = vsprintf($bp['b_pattern'], array_slice($chosen_vars, 0, substr_count($bp['b_pattern'], '%s')));
            
            // Append random qualifier if attempt > 0 or randomly to guarantee uniqueness
            if ($attempt > 0 || rand(0, 1) === 1) {
                $q_title .= ' ' . $qualifiers[array_rand($qualifiers)];
            }
            
            // Check duplication against exclude list and DB
            $is_dup = false;
            foreach ($exclude_titles as $ext) {
                if (strtolower(trim($q_title)) === strtolower(trim($ext))) {
                    $is_dup = true;
                    break;
                }
            }
            
            if (!$is_dup && class_exists('ILYBD_QA_AI_Moderator')) {
                $dup_check = ILYBD_QA_AI_Moderator::check_duplicate_question($q_title);
                if ($dup_check['status']) {
                    $is_dup = true;
                }
            } else if (!$is_dup) {
                $existing = get_page_by_title($q_title, OBJECT, 'ilybd_question');
                if ($existing) {
                    $is_dup = true;
                }
            }
            
            if (!$is_dup) {
                // Build dynamic answer using closure
                $a_func = $bp['a_builder'];
                $a_body = call_user_func_array($a_func, $chosen_vars);
                
                $answers = [
                    [
                        'author_name' => 'cyber_expert_bd',
                        'answer_body' => $a_body
                    ],
                    [
                        'author_name' => 'tech_guru_99',
                        'answer_body' => 'ধন্যবাদ প্রশ্নটির জন্য! সমাধানটি অত্যন্ত নিখুঁত এবং কার্যকর। আপনি চাইলে সাইটের অপ্টিমাইজেশন পরীক্ষা করতে আমাদের <a href="/free-tools/" target="_blank">Free Tools</a> ব্যবহার করে দেখতে পারেন।'
                    ],
                    [
                        'author_name' => 'dev_milon',
                        'answer_body' => 'ধন্যবাদ প্রফেশনাল গাইডের জন্য। এটি অনুসরণ করে সমস্যার সমাধান পেয়েছি।'
                    ]
                ];
                
                return [
                    'question_title' => $q_title,
                    'question_body'  => $q_body,
                    'category'       => $bp['cat'],
                    'tags'           => $bp['tags'],
                    'answers'        => $answers
                ];
            }
        }

        // Absolute fail-safe unique title with timestamp if loop somehow exhausted
        $rand_id = rand(1000, 9999);
        $fail_title = "How to optimize server PHP performance and resolve database timeout errors [Guide #" . $rand_id . "]";
        return [
            'question_title' => $fail_title,
            'question_body'  => "What are the best practices for increasing memory_limit and max_execution_time in WordPress wp-config.php and php.ini for high traffic forums?",
            'category'       => 'Web Development',
            'tags'           => ['server-optimization', 'php-memory-limit', 'wordpress-speed', 'database-timeout'],
            'answers'        => [
                [
                    'author_name' => 'sys_admin_expert',
                    'answer_body' => 'To fix memory limit issues in WordPress, add <code>define("WP_MEMORY_LIMIT", "256M");</code> to your <code>wp-config.php</code> file.'
                ]
            ]
        ];
    }

    private function get_or_create_simulated_user_by_name($name_slug) {
        $first_names = ['Rahim', 'Karim', 'Sajid', 'Tanvir', 'Hasan', 'Arafat', 'Fahim', 'Nafis', 'Sharif', 'Monir', 'Sabina', 'Nadia', 'Rashed'];
        $last_names = ['Islam', 'Ahmed', 'Hossain', 'Rahman', 'Chowdhury', 'Mahmud', 'Khan', 'Siddique'];
        
        $username = sanitize_key(str_replace(' ', '_', strtolower($name_slug)));
        if (strlen($username) < 4) {
            $username .= rand(100, 999);
        }
        $email = $username . '@example.com';
        
        $user_id = username_exists($username);
        
        if (!$user_id) {
            $random_password = wp_generate_password(12, false);
            $user_id = wp_create_user($username, $random_password, $email);
            
            if (!is_wp_error($user_id)) {
                $fname = $first_names[array_rand($first_names)];
                $lname = $last_names[array_rand($last_names)];
                wp_update_user([
                    'ID' => $user_id,
                    'display_name' => $fname . ' ' . $lname,
                    'first_name' => $fname,
                    'last_name' => $lname
                ]);
            } else {
                return 1; // Fallback to admin if creation fails
            }
        }
        return $user_id;
    }

    private function get_or_create_simulated_user($role_type) {
        $usernames = ['cyber_expert_bd', 'tech_master99', 'pro_developer', 'seo_ninja', 'network_guru', 'ai_enthusiast_2040'];
        $first_names = ['Rahim', 'Karim', 'Sajid', 'Tanvir', 'Hasan', 'Arafat', 'Fahim', 'Nafis'];
        $last_names = ['Islam', 'Ahmed', 'Hossain', 'Rahman', 'Chowdhury', 'Mahmud'];
        
        $username = $usernames[array_rand($usernames)] . rand(100, 999);
        $email = $username . '@example.com';
        
        $user_id = username_exists($username);
        
        if (!$user_id) {
            $random_password = wp_generate_password(12, false);
            $user_id = wp_create_user($username, $random_password, $email);
            
            if (!is_wp_error($user_id)) {
                $fname = $first_names[array_rand($first_names)];
                $lname = $last_names[array_rand($last_names)];
                wp_update_user([
                    'ID' => $user_id,
                    'display_name' => $fname . ' ' . $lname,
                    'first_name' => $fname,
                    'last_name' => $lname
                ]);
            } else {
                // Fallback to admin if creation fails
                return 1; 
            }
        }
        return $user_id;
    }

    public function manual_trigger_from_admin() {
        if (!current_user_can('manage_options')) return;
        $this->execute_autopilot_cycle();
        wp_redirect(admin_url('admin.php?page=ilybd-nextgen-autopilot&autopilot_fired=true'));
        exit;
    }
}

new ILYBD_QA_Autopilot_Engine();
