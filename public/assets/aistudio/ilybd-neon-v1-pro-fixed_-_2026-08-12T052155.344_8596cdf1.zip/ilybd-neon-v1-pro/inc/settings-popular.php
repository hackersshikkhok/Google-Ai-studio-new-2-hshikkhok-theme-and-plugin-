<?php
/**
 * ILYBD Neon Pro - Popular Post Control Engine (PRO)
 * Enhanced with Neon UI & Security Fixes
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* =========================
   ADMIN MENU
========================= */
add_action('admin_menu', function() {
    add_submenu_page(
        'ilybd-settings',
        'Popular Engine',
        'Popular Posts',
        'manage_options',
        'ilybd-popular-settings',
        'ilybd_popular_settings_page'
    );
});

/* =========================
   SETTINGS PAGE
========================= */
function ilybd_popular_settings_page() {
    // Neon Color from theme options or default
    $neon_main = esc_attr(get_option('ilybd_main_color', '#00ff41'));

    // Save handler with Nonce Security
    if(isset($_POST['ilybd_popular_save'])){
        $popular_enabled = isset($_POST['popular_enable']) ? 1 : 0;
        update_option('popular_enable', $popular_enabled);
        update_option('ily_enable_popular_posts', $popular_enabled);
        update_option('popular_title', sanitize_text_field($_POST['popular_title']));
        update_option('popular_post_count', (int)$_POST['popular_post_count']);
        update_option('popular_source', sanitize_text_field($_POST['popular_source']));
        update_option('popular_sort_order', sanitize_text_field($_POST['popular_sort_order']));

        echo '<div class="notice notice-success is-dismissible" style="border-left-color:'.$neon_main.'; background:#161b22; color:#fff;"><p><b>Popular Engine settings updated successfully!</b></p></div>';
    }

    $title = get_option('popular_title', '🔥 POPULAR NOW');
    $count = get_option('popular_post_count', 4);
    $p_source = get_option('popular_source', 'views');
    $order = get_option('popular_sort_order', 'DESC');
    $enable = get_option('ily_enable_popular_posts', 1);
    ?>

    <style>
        .ilybd-settings-wrap {
            background: #0d1117;
            color: #c9d1d9;
            padding: 30px;
            border-radius: 14px;
            border: 1px solid #30363d;
            margin-top: 20px;
            max-width: 900px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.5);
        }
        .ilybd-neon-title {
            color: <?php echo $neon_main; ?>;
            text-shadow: 0 0 10px <?php echo $neon_main; ?>33;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 5px;
         }
        .form-table th {
            color: #f0f6fc;
            font-weight: 600;
            padding: 20px 10px 20px 0;
            width: 250px;
        }
        .ilybd-input {
            background: #010409 !important;
            color: <?php echo $neon_main; ?> !important;
            border: 1px solid #30363d !important;
            border-radius: 6px !important;
            padding: 10px !important;
            transition: 0.3s !important;
            outline: none;
        }
        .ilybd-input:focus {
            border-color: <?php echo $neon_main; ?> !important;
            box-shadow: 0 0 8px <?php echo $neon_main; ?>44 !important;
        }
        .ilybd-save-btn {
            background: <?php echo $neon_main; ?> !important;
            color: #000 !important;
            border: none !important;
            padding: 12px 35px !important;
            border-radius: 8px !important;
            font-weight: 800 !important;
            cursor: pointer;
            transition: 0.3s;
            margin-top: 20px;
            text-transform: uppercase;
        }
        .ilybd-save-btn:hover {
            transform: scale(1.05);
            box-shadow: 0 0 20px <?php echo $neon_main; ?>66;
        }
        .desc-text { color: #8b949e; font-size: 13px; margin-top: 5px; font-style: italic; }
    </style>

    <div class="wrap">
        <div class="ilybd-settings-wrap">
            <h1 class="ilybd-neon-title">🚀 Popular Engine Control</h1>
            <p style="color:#8b949e; margin-bottom: 30px;">কনফিগার করুন আপনার হোমপেজের পপুলার পোস্ট ফিল্টারিং সিস্টেম।</p>

            <form method="post">
                <table class="form-table">
                    <tr>
                        <th>Enable Popular Section</th>
                        <td>
                            <input type="checkbox" name="popular_enable" <?php checked($enable, 1); ?> style="accent-color:<?php echo $neon_main; ?>; transform: scale(1.3);" />
                            <b style="color:#fff; margin-left:10px;">হোমপেজে পপুলার পোস্ট মডিউল চালু রাখুন (Enable Popular Section)</b>
                        </td>
                    </tr>

                    <tr>
                        <th>Display Title</th>
                        <td>
                            <input type="text" name="popular_title" value="<?php echo esc_attr($title); ?>" class="ilybd-input" style="width: 100%; max-width: 450px;" placeholder="e.g. 🔥 POPULAR NOW" />
                            <p class="desc-text">ফ্রন্ট-এন্ডে সেকশনের উপরে এই লেখাটি দেখাবে।</p>
                        </td>
                    </tr>

                    <tr>
                        <th>Posts to Show</th>
                        <td>
                            <input type="number" name="popular_post_count" value="<?php echo esc_attr($count); ?>" min="1" max="50" class="ilybd-input" style="width: 100px;" />
                            <p class="desc-text">কয়টি পোস্ট গ্রিডে শো করবে। (সর্বোচ্চ ৫০টি)</p>
                        </td>
                    </tr>

                    <tr>
                        <th>Popularity Metric Source</th>
                        <td>
                            <select name="popular_source" class="ilybd-input" style="width: 100%; max-width: 450px;">
                                <option value="views" <?php selected($p_source, 'views'); ?>>🔥 Total Organic Views (সবচেয়ে বেশি বার দেখা পোস্ট)</option>
                                <option value="likes" <?php selected($p_source, 'likes'); ?>>❤️ Highly Liked (সবচেয়ে বেশি লাইক পাওয়া পোস্ট)</option>
                                <option value="comments" <?php selected($p_source, 'comments'); ?>>💬 Conversation Starter (সবচেয়ে বেশি কমেন্ট করা পোস্ট)</option>
                                <option value="latest" <?php selected($p_source, 'latest'); ?>>🕒 Latest Published (নতুন প্রকাশিত লেটেস্ট পোস্ট)</option>
                            </select>
                            <p class="desc-text">কোন মেট্রিক বা সোর্স ট্র্যাক করে কন্টেন্ট এর জনপ্রিয়তা পজিশন গণনা করা হবে।</p>
                        </td>
                    </tr>

                    <tr>
                        <th>Sort Ordering Algorithm</th>
                        <td>
                            <select name="popular_sort_order" class="ilybd-input" style="width: 100%; max-width: 450px;">
                                <option value="DESC" <?php selected($order,'DESC'); ?>>Hot Popularity (Most values at the top)</option>
                                <option value="ASC" <?php selected($order,'ASC'); ?>>Cool Gems (Least values at the top)</option>
                            </select>
                        </td>
                    </tr>
                </table>

                <button type="submit" name="ilybd_popular_save" class="ilybd-save-btn">
                    Update Popular Engine
                </button>
            </form>
        </div>
    </div>
    <?php
}

/* =========================
   REGISTER SETTINGS
========================= */
add_action('admin_init', function() {
    register_setting('ilybd_popular_group', 'popular_title');
    register_setting('ilybd_popular_group', 'popular_post_count');
    register_setting('ilybd_popular_group', 'popular_meta_key');
    register_setting('ilybd_popular_group', 'popular_sort_order');
    register_setting('ilybd_popular_group', 'popular_enable');
});
