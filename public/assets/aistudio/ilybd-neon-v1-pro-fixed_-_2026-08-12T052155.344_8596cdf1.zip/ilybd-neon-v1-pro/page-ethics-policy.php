<?php
/**
 * Template Name: Cyber Ethics Policy Pro
 * Description: Fully Professional E-E-A-T and AdSense Compliant Ethics Policy Page
 */
get_header();
$neon = get_option('ilybd_main_color', '#00ff41');
?>
<div class="cyber-page-wrapper">
    <div class="container-fluid" style="max-width: 1100px; margin: 0 auto; padding: 40px 20px;">
        
        <header class="cyber-section-header">
            <h1 class="rgb-text-lighting">Ethics Policy</h1>
            <p class="section-subtext">নৈতিকতা নীতিমালা / MORAL & ETHICAL FRAMEWORK</p>
            <div class="sticky-rgb-line"></div>
        </header>

        <div class="slim-rgb-container">
            <div class="inner-page-content">
                
                <section class="policy-block">
                    <h2>🇧🇩 আমাদের সাংবাদিকতা ও প্রকাশনা নৈতিকতা</h2>
                    <p>ILOVEYOUBD.COM (IBD Cyber Ecosystem) সাংবাদিকতার সর্বোচ্চ নৈতিক মানদণ্ড অনুসরণ করে। প্রযুক্তি নির্ভর তথ্য, সাইবার সিকিউরিটি এলার্ট বা যেকোনো টিউটোরিয়াল প্রকাশে আমরা সততা, স্বচ্ছতা এবং পেশাদারিত্ব বজায় রাখি। ব্যবহারকারীদের গোপনীয়তা ও সুরক্ষা নিশ্চিত করাই আমাদের অন্যতম নৈতিক দায়িত্ব।</p>
                </section>
                <div class="policy-divider"></div>

                <div class="policy-grid">
                    <!-- 1. Independence and Integrity -->
                    <div class="policy-card">
                        <h3><i class="fa-solid fa-crown"></i> 1. Independence & Integrity</h3>
                        <p><strong>Bengali (স্বাধীনতা ও সততা):</strong> আমরা স্বাধীনভাবে কাজ করি এবং কোনো আর্থিক অনুদান বা রাজনৈতিক চাপে আমাদের কন্টেন্ট প্রভাবিত হয় না। আমাদের রিভিউ সম্পূর্ণ নিরপেক্ষ।</p>
                        <p><strong>English:</strong> We operate independently. Our content and reviews are never influenced by financial contributions or political pressure, maintaining absolute editorial integrity.</p>
                    </div>

                    <!-- 2. No Clickbait -->
                    <div class="policy-card">
                        <h3><i class="fa-solid fa-ban"></i> 2. Zero Clickbait Policy</h3>
                        <p><strong>Bengali (ক্লিকবেইট মুক্ত):</strong> আমরা শিরোনামে অতিরঞ্জিত বা মিথ্যা তথ্য দিয়ে ভিজিটরদের আকৃষ্ট করার তীব্র বিরোধিতা করি। শিরোনামের সাথে কন্টেন্টের পূর্ণ মিল থাকে।</p>
                        <p><strong>English:</strong> We strictly oppose misleading headlines or clickbait to attract visitors. Article titles accurately reflect the core content without exaggeration.</p>
                    </div>
                </div>

                <div class="policy-grid" style="margin-top: 25px;">
                    <!-- 3. Respect for Privacy -->
                    <div class="policy-card">
                        <h3><i class="fa-solid fa-user-shield"></i> 3. Respect for Privacy</h3>
                        <p><strong>Bengali (গোপনীয়তার প্রতি সম্মান):</strong> আমরা ব্যবহারকারীদের ব্যক্তিগত তথ্যের গোপনীয়তাকে সর্বোচ্চ সম্মান জানাই। কোনো অননুমোদিত সোর্স বা হ্যাকিং করে কারো ব্যক্তিগত তথ্য আমরা প্রচার করি না।</p>
                        <p><strong>English:</strong> We respect the privacy of individuals and users. We do not publish personal data obtained through unauthorized sources or unethical hacking.</p>
                    </div>

                    <!-- 4. Transparency in AI Usage -->
                    <div class="policy-card">
                        <h3><i class="fa-solid fa-robot"></i> 4. AI & Tech Transparency</h3>
                        <p><strong>Bengali (এআই ব্যবহারে স্বচ্ছতা):</strong> কন্টেন্ট তৈরিতে বা অনুবাদে এআই ব্যবহৃত হলে আমরা তা স্পষ্টভাবে জানিয়ে দিই। এআই দ্বারা প্রাপ্ত তথ্যও আমাদের এক্সপার্টরা রিচেক করে থাকেন।</p>
                        <p><strong>English:</strong> We transparently disclose the use of AI in content generation or translation. All AI-assisted data is thoroughly reviewed by human experts.</p>
                    </div>
                </div>
                
                <div class="about-card hero-card" style="margin-top: 30px; background: rgba(0,255,204,0.02); border-color: rgba(0,255,204,0.15); border-radius: 12px; padding: 25px;">
                    <h3 style="color: var(--cyber-neon, #00ff41); margin-top: 0; font-size: 16px; text-transform: uppercase;"><i class="fa-solid fa-scale-balanced"></i> Editorial Independence</h3>
                    <p style="margin: 0; font-size: 13.5px; line-height: 1.7; color: #a0aec0;">Our commitment to ethical publishing ensures that readers always receive objective, accurate, and fair information, elevating the standards of technical reporting in the region.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .cyber-page-wrapper {
        background: #070a0f;
        min-height: 100vh;
        color: #e1e7ef;
        font-family: 'Inter', system-ui, -apple-system, sans-serif;
    }
    .cyber-section-header {
        text-align: center;
        margin-bottom: 40px;
    }
    .rgb-text-lighting {
        font-size: 2.8rem;
        font-weight: 900;
        text-transform: uppercase;
        letter-spacing: 3px;
        margin: 0 0 10px 0;
        background: linear-gradient(to right, #ff0000, #ffff00, #00ff00, #00ffff, #0000ff, #ff00ff, #ff0000);
        background-size: 200% auto;
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        animation: rgb_flow 4s linear infinite;
    }
    .section-subtext {
        color: <?php echo $neon; ?>;
        font-size: 11px;
        letter-spacing: 5px;
        margin-bottom: 20px;
    }
    .sticky-rgb-line {
        height: 2px;
        width: 100%;
        background: linear-gradient(to right, #ff0000, #ffff00, #00ff00, #00ffff, #0000ff, #ff00ff, #ff0000);
        background-size: 200% auto;
        animation: rgb_flow 4s linear infinite;
        box-shadow: 0 0 15px <?php echo $neon; ?>dd;
    }
    .slim-rgb-container {
        position: relative;
        padding: 1px;
        background: linear-gradient(var(--angle), #ff0000, #00ff00, #0000ff, #ff0000);
        animation: rotate-border 6s linear infinite;
        border-radius: 20px;        overflow: hidden;
    }
    @property --angle {
        syntax: '<angle>';
        initial-value: 0deg;
        inherits: false;
    }
    @keyframes rotate-border {
        to { --angle: 360deg; }
    }
    .inner-page-content {
        background: #0a0e14;
        border-radius: 19px;
        padding: 40px;
    }
    .policy-block h2 {
        color: #fff;
        font-size: 22px;        margin-top: 0;
        margin-bottom: 15px;
    }
    .policy-block p {
        line-height: 1.8;
        color: #a0aec0;
        font-size: 15px;
    }
    .policy-divider {
        height: 1px;
        background: rgba(255,255,255,0.08);
        margin: 30px 0;
    }
    .policy-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 25px;
    }
    .policy-card {
        background: rgba(255,255,255,0.01);
        border: 1px solid rgba(255,255,255,0.05);
        border-radius: 12px;
        padding: 25px;
        transition: 0.3s;
    }
    .policy-card:hover {
        border-color: <?php echo $neon; ?>;
        box-shadow: 0 0 15px <?php echo $neon; ?>1d;
    }
    .policy-card h3 {
        color: <?php echo $neon; ?>;
        font-size: 16px;        margin-top: 0;
        margin-bottom: 15px;
        text-transform: uppercase;
        letter-spacing: 1px;
        border-bottom: 1px solid rgba(255,255,255,0.05);
        padding-bottom: 8px;
    }
    .policy-card p {
        font-size: 13.5px;
        line-height: 1.7;
        color: #a0aec0;
        margin-bottom: 12px;
    }
    @media (max-width: 768px) {
        .policy-grid {
            grid-template-columns: 1fr;
        }
        .inner-page-content {
            padding: 20px;
        }
    }
    @keyframes rgb_flow {
        0% { background-position: 0% 50%; }
        50% { background-position: 100% 50%; }
        100% { background-position: 0% 50%; }
    }
</style>
<?php get_footer(); ?>
