<?php
/**
 * Template Name: Cyber Fact-Checking Policy Pro
 * Description: Fully Professional E-E-A-T and AdSense Compliant Fact-Checking Policy Page
 */
get_header();
$neon = get_option('ilybd_main_color', '#00ff41');
?>
<div class="cyber-page-wrapper">
    <div class="container-fluid" style="max-width: 1100px; margin: 0 auto; padding: 40px 20px;">
        
        <header class="cyber-section-header">
            <h1 class="rgb-text-lighting">Fact-Checking Policy</h1>
            <p class="section-subtext">তথ্য যাচাইকরণ নীতিমালা / DATA INTEGRITY PROTOCOL</p>
            <div class="sticky-rgb-line"></div>
        </header>

        <div class="slim-rgb-container">
            <div class="inner-page-content">
                
                <section class="policy-block">
                    <h2>🇧🇩 আমাদের ফ্যাক্ট-চেকিং লক্ষ্য ও নীতিমালা</h2>
                    <p>ILOVEYOUBD.COM (IBD Cyber Ecosystem) সর্বদাই সত্য, নির্ভুল এবং নির্ভরযোগ্য তথ্য প্রদান করতে প্রতিশ্রুতিবদ্ধ। আমাদের প্রতিটি নিউজ, আর্টিকেল এবং টিউটোরিয়াল প্রকাশের পূর্বে একটি নির্দিষ্ট ফ্যাক্ট-চেকিং (তথ্য-যাচাই) প্রক্রিয়ার মধ্য দিয়ে যায়। আমরা প্রযুক্তি ও সাইবার স্পেসের গুরুত্বপূর্ণ তথ্যগুলো শুধুমাত্র বিশ্বস্ত সূত্র থেকে সংগ্রহ করে পাঠকদের নিকট তুলে ধরি।</p>
                </section>
                <div class="policy-divider"></div>

                <div class="policy-grid">
                    <!-- 1. Verification Process -->
                    <div class="policy-card">
                        <h3><i class="fa-solid fa-magnifying-glass-chart"></i> 1. Verification Process</h3>
                        <p><strong>Bengali (তথ্য যাচাই প্রক্রিয়া):</strong> প্রতিটি কন্টেন্ট লেখার সময় আমাদের লেখকরা একাধিক নির্ভরযোগ্য সূত্র যাচাই করেন। অফিসিয়াল সোর্স, প্রেস রিলিজ এবং অথেনটিক ডকুমেন্টেশন ছাড়া কোনো তথ্য প্রকাশ করা হয় না।</p>
                        <p><strong>English:</strong> Our content undergoes rigorous verification. Writers cross-reference multiple authoritative sources, official press releases, and authentic documentation before any data is published.</p>
                    </div>

                    <!-- 2. Source Transparency -->
                    <div class="policy-card">
                        <h3><i class="fa-solid fa-link"></i> 2. Source Transparency</h3>
                        <p><strong>Bengali (উৎস স্বচ্ছতা):</strong> আমরা সংগৃহীত তথ্যের স্পষ্ট রেফারেন্স এবং সোর্স লিংক প্রদান করি, যাতে পাঠকরা চাইলে মূল উৎস থেকে তথ্যের সত্যতা যাচাই করতে পারেন।</p>
                        <p><strong>English:</strong> We provide clear references and source links for collected data, enabling readers to independently verify the authenticity of the information from the original source.</p>
                    </div>
                </div>

                <div class="policy-grid" style="margin-top: 25px;">
                    <!-- 3. Correction Policy -->
                    <div class="policy-card">
                        <h3><i class="fa-solid fa-pen-to-square"></i> 3. Continuous Updates</h3>
                        <p><strong>Bengali (নিয়মিত আপডেট):</strong> যদি প্রকাশিত কোনো তথ্যে ভুল বা অসঙ্গতি পাওয়া যায়, তবে আমরা দ্রুততম সময়ের মধ্যে তা সংশোধন বা আপডেট করি এবং পাঠকদের তা জানিয়ে থাকি।</p>
                        <p><strong>English:</strong> If errors or discrepancies are discovered in published content, we correct or update them immediately, ensuring continuous accuracy.</p>
                    </div>

                    <!-- 4. Unbiased Reporting -->
                    <div class="policy-card">
                        <h3><i class="fa-solid fa-scale-balanced"></i> 4. Unbiased Reporting</h3>
                        <p><strong>Bengali (নিরপেক্ষতা):</strong> আমরা কোনো নির্দিষ্ট কোম্পানি বা প্রোডাক্টের প্রতি পক্ষপাতিত্ব করি না। আমাদের উদ্দেশ্য প্রকৃত সত্য ও সঠিক কারিগরি তথ্য সরবরাহ করা।</p>
                        <p><strong>English:</strong> We maintain strict neutrality and do not favor any specific company or product. Our objective is to deliver factual and accurate technical information.</p>
                    </div>
                </div>
                
                <div class="about-card hero-card" style="margin-top: 30px; background: rgba(0,255,204,0.02); border-color: rgba(0,255,204,0.15); border-radius: 12px; padding: 25px;">
                    <h3 style="color: var(--cyber-neon, #00ff41); margin-top: 0; font-size: 16px; text-transform: uppercase;"><i class="fa-solid fa-shield-halved"></i> Commitment to Accuracy</h3>
                    <p style="margin: 0; font-size: 13.5px; line-height: 1.7; color: #a0aec0;">Accuracy is the foundation of the IBD Cyber Ecosystem. We adhere strictly to E-E-A-T guidelines to ensure that our platform remains a trusted and highly authoritative tech resource in Bangladesh and globally.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .cyber-page-wrapper {
        background: #070a0f;
        min-height: 100vh;
        color: #e1e7ef;
        font-family: 'Inter', system-ui, -apple-system, sans-serif;
    }
    .cyber-section-header {
        text-align: center;
        margin-bottom: 40px;
    }
    .rgb-text-lighting {
        font-size: 2.8rem;
        font-weight: 900;
        text-transform: uppercase;
        letter-spacing: 3px;
        margin: 0 0 10px 0;
        background: linear-gradient(to right, #ff0000, #ffff00, #00ff00, #00ffff, #0000ff, #ff00ff, #ff0000);
        background-size: 200% auto;
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        animation: rgb_flow 4s linear infinite;
    }
    .section-subtext {
        color: <?php echo $neon; ?>;
        font-size: 11px;
        letter-spacing: 5px;
        margin-bottom: 20px;
    }
    .sticky-rgb-line {
        height: 2px;
        width: 100%;
        background: linear-gradient(to right, #ff0000, #ffff00, #00ff00, #00ffff, #0000ff, #ff00ff, #ff0000);
        background-size: 200% auto;
        animation: rgb_flow 4s linear infinite;
        box-shadow: 0 0 15px <?php echo $neon; ?>dd;
    }
    .slim-rgb-container {
        position: relative;
        padding: 1px;
        background: linear-gradient(var(--angle), #ff0000, #00ff00, #0000ff, #ff0000);
        animation: rotate-border 6s linear infinite;
        border-radius: 20px;        overflow: hidden;
    }
    @property --angle {
        syntax: '<angle>';
        initial-value: 0deg;
        inherits: false;
    }
    @keyframes rotate-border {
        to { --angle: 360deg; }
    }
    .inner-page-content {
        background: #0a0e14;
        border-radius: 19px;
        padding: 40px;
    }
    .policy-block h2 {
        color: #fff;
        font-size: 22px;        margin-top: 0;
        margin-bottom: 15px;
    }
    .policy-block p {
        line-height: 1.8;
        color: #a0aec0;
        font-size: 15px;
    }
    .policy-divider {
        height: 1px;
        background: rgba(255,255,255,0.08);
        margin: 30px 0;
    }
    .policy-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 25px;
    }
    .policy-card {
        background: rgba(255,255,255,0.01);
        border: 1px solid rgba(255,255,255,0.05);
        border-radius: 12px;
        padding: 25px;
        transition: 0.3s;
    }
    .policy-card:hover {
        border-color: <?php echo $neon; ?>;
        box-shadow: 0 0 15px <?php echo $neon; ?>1d;
    }
    .policy-card h3 {
        color: <?php echo $neon; ?>;
        font-size: 16px;        margin-top: 0;
        margin-bottom: 15px;
        text-transform: uppercase;
        letter-spacing: 1px;
        border-bottom: 1px solid rgba(255,255,255,0.05);
        padding-bottom: 8px;
    }
    .policy-card p {
        font-size: 13.5px;
        line-height: 1.7;
        color: #a0aec0;
        margin-bottom: 12px;
    }
    @media (max-width: 768px) {
        .policy-grid {
            grid-template-columns: 1fr;
        }
        .inner-page-content {
            padding: 20px;
        }
    }
    @keyframes rgb_flow {
        0% { background-position: 0% 50%; }
        50% { background-position: 100% 50%; }
        100% { background-position: 0% 50%; }
    }
</style>
<?php get_footer(); ?>
