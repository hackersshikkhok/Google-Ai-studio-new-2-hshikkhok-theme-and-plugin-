<?php
/**
 * Template Name: Google AI Studio - Ultimate Platform Clone
 * Description: Public-facing Google AI Studio workspace for iloveyoubd.com (iloveyoubd.com/ai-studio/)
 * Focus Keywords: google ai studio, ai studio bangladesh, এআই স্টুডিও, iloveyoubd ai studio
 */

if (!defined('ABSPATH')) exit;

get_header();
?>

<!-- JSON-LD SCHEMA FOR GOOGLE SEARCH BOOST -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebPage",
  "name": "Google AI Studio Clone - iloveyoubd.com",
  "description": "গুগল এআই স্টুডিওর মত সেম টু সেম প্রফেশনাল ডেভেলপমেন্ট ওয়ার্কস্পেস। আপনার নিজস্ব এপিআই কি ব্যবহার করে জেমিনি মডেল টিউন, টেস্ট ও কোড এক্সপোর্ট করুন সম্পূর্ণ ফ্রিতে।",
  "url": "https://iloveyoubd.com/ai-studio/",
  "publisher": {
    "@type": "Organization",
    "name": "ILOVEYOUBD.COM"
  }
}
</script>

<div id="ai-studio-root" style="display: flex; height: calc(100vh - 120px); min-height: 650px; background: #070b13; color: #f1f5f9; font-family: 'Space Grotesk', 'Hind Siliguri', sans-serif; overflow: hidden; position: relative;">
    
    <!-- LEFT CONTROL PANEL: Prompts Library, API Key & System Instructions -->
    <aside id="studio-left-sidebar" style="width: 280px; background: #0b111e; border-right: 1px solid rgba(255, 255, 255, 0.08); display: flex; flex-direction: column; flex-shrink: 0; z-index: 40; transition: all 0.3s ease;">
        
        <!-- API Key Manager Box -->
        <div style="padding: 16px; border-bottom: 1px solid rgba(255, 255, 255, 0.06);">
            <div style="font-size: 11px; font-weight: bold; color: #00f0ff; letter-spacing: 1px; text-transform: uppercase; margin-bottom: 8px; font-family: 'JetBrains Mono', monospace;">🔑 Gemini API Key</div>
            <div style="display: flex; gap: 6px;">
                <input type="password" id="studio-api-key" placeholder="Paste your API key here..." style="flex: 1; background: #111827; border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 6px; padding: 6px 10px; font-size: 12px; color: #fff; outline: none;" onchange="saveStudioApiKey()">
                <button onclick="toggleApiKeyVisibility()" style="background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; padding: 0 10px; color: #cbd5e0; cursor: pointer; font-size: 12px;">👁️</button>
            </div>
            <div style="font-size: 10px; color: #64748b; margin-top: 6px; line-height: 1.3;">
                Don't have a key? <a href="https://aistudio.google.com/" target="_blank" style="color: #fbbf24; text-decoration: underline;">Get free API key</a>. If blank, it uses local balancer securely.
            </div>
        </div>

        <!-- System Instructions Container -->
        <div style="padding: 16px; border-bottom: 1px solid rgba(255, 255, 255, 0.06); display: flex; flex-direction: column; gap: 8px;">
            <div style="font-size: 11px; font-weight: bold; color: #fbbf24; letter-spacing: 1px; text-transform: uppercase; font-family: 'JetBrains Mono', monospace;">🧠 System Instructions</div>
            <textarea id="studio-system-instruction" placeholder="You are a helpful assistant writing pristine React components and answering queries precisely..." style="width: 100%; height: 110px; background: #111827; border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 8px; padding: 10px; font-size: 12px; color: #e2e8f0; line-height: 1.4; resize: none; outline: none; font-family: inherit;" onchange="autoSaveCurrentPromptState()"></textarea>
        </div>

        <!-- Prompt Library / Saved States -->
        <div style="flex: 1; overflow-y: auto; padding: 16px; display: flex; flex-direction: column;">
            <div style="font-size: 11px; font-weight: bold; color: #64748b; letter-spacing: 1.2px; text-transform: uppercase; margin-bottom: 12px; font-family: 'JetBrains Mono', monospace;">Prompt Library</div>
            
            <button onclick="createNewStudioPrompt()" style="background: rgba(251, 191, 36, 0.06); border: 1px solid rgba(251, 191, 36, 0.2); color: #fbbf24; border-radius: 6px; padding: 8px 12px; font-size: 12.5px; font-weight: bold; cursor: pointer; text-align: center; margin-bottom: 14px; transition: all 0.2s;" onmouseover="this.style.background='rgba(251, 191, 36, 0.1)'" onmouseout="this.style.background='rgba(251, 191, 36, 0.06)'">
                + Create New Prompt
            </button>

            <div id="studio-saved-prompts-list" style="display: flex; flex-direction: column; gap: 6px;">
                <!-- Saved prompts list loaded dynamically -->
            </div>
        </div>

        <!-- Left Sidebar Footer Info -->
        <div style="padding: 14px; border-top: 1px solid rgba(255,255,255,0.05); background: rgba(0,0,0,0.15); font-size: 11px; color: #64748b; line-height: 1.4;">
            <div style="display: flex; justify-content: space-between; margin-bottom: 3px;">
                <span>Session Core:</span>
                <span id="key-status-badge" style="color: #64748b; font-weight: bold;">WP BALANCER</span>
            </div>
            <div>
                <span>Workspace:</span> <span style="font-family: 'JetBrains Mono', monospace; font-size: 10.5px; color: #cbd5e0;">ILYBD Studio v2040</span>
            </div>
        </div>
    </aside>

    <!-- CENTER WORKSPACE: Editor & Prompt Runner -->
    <main style="flex: 1; display: flex; flex-direction: column; background: #070b13; position: relative;">
        
        <!-- Header View Bar -->
        <header style="height: 60px; background: #0b111e; border-bottom: 1px solid rgba(255, 255, 255, 0.08); display: flex; align-items: center; justify-content: space-between; padding: 0 24px;">
            <div style="display: flex; align-items: center; gap: 14px;">
                <button onclick="toggleStudioLeftSidebar()" style="background: none; border: none; color: #94a3b8; font-size: 18px; cursor: pointer;" title="Toggle Sidebar">☰</button>
                <div style="display: flex; align-items: center; gap: 8px;">
                    <span style="font-size: 18px;">🛠️</span>
                    <span style="font-size: 15px; font-weight: bold; color: #f1f5f9;" id="current-prompt-title-label">Untitled Prompt</span>
                </div>
            </div>

            <!-- Get Code and Save buttons -->
            <div style="display: flex; align-items: center; gap: 10px;">
                <button onclick="openGetCodeModal()" style="background: #111827; border: 1px solid rgba(255, 255, 255, 0.12); color: #f1f5f9; border-radius: 6px; padding: 7px 14px; font-size: 12.5px; font-weight: 600; cursor: pointer; display: flex; align-items: center; gap: 6px; transition: all 0.2s;" onmouseover="this.style.borderColor='#00f0ff'" onmouseout="this.style.borderColor='rgba(255,255,255,0.12)'">
                    <span>💻</span> Get Code
                </button>
                <button onclick="saveCurrentPromptToLibrary()" style="background: #fbbf24; border: none; color: #000; border-radius: 6px; padding: 7px 16px; font-size: 12.5px; font-weight: bold; cursor: pointer; display: flex; align-items: center; gap: 6px; transition: all 0.2s;" onmouseover="this.style.background='#f59e0b'" onmouseout="this.style.background='#fbbf24'">
                    <span>💾</span> Save Prompt
                </button>
            </div>
        </header>

        <!-- Main Workspace Area -->
        <div style="flex: 1; display: flex; overflow: hidden; position: relative;">
            
            <!-- EDITOR VIEW -->
            <div style="flex: 1; display: flex; flex-direction: column; overflow-y: auto; padding: 24px; gap: 20px;">
                
                <!-- Prompt Input Editor Section -->
                <div style="background: #0b111e; border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 12px; padding: 16px; display: flex; flex-direction: column; gap: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.2);">
                    <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid rgba(255, 255, 255, 0.06); padding-bottom: 8px;">
                        <span style="font-size: 12px; font-weight: bold; color: #94a3b8; font-family: 'JetBrains Mono', monospace;">PROMPT INPUT EDITOR</span>
                        <span id="token-counter" style="font-size: 11px; font-family: 'JetBrains Mono', monospace; color: #64748b;">0 characters</span>
                    </div>
                    
                    <textarea id="studio-prompt-input" placeholder="Type your instruction or design prompt here, click 'Run' at the bottom or press Ctrl+Enter to test the output..." style="width: 100%; height: 180px; background: transparent; border: none; outline: none; color: #f1f5f9; font-size: 14px; line-height: 1.6; resize: vertical; font-family: inherit;" oninput="updateStudioTokenCount()"></textarea>
                </div>

                <!-- Run Console Actions -->
                <div style="display: flex; align-items: center; gap: 14px; margin-top: -5px;">
                    <button id="studio-run-btn" onclick="executeStudioPrompt()" style="background: linear-gradient(135deg, #00f0ff, #3b82f6); border: none; color: #fff; border-radius: 8px; padding: 12px 30px; font-size: 14px; font-weight: bold; cursor: pointer; transition: all 0.2s; box-shadow: 0 4px 12px rgba(0, 240, 255, 0.2);" onmouseover="this.style.filter='brightness(1.1)'" onmouseout="this.style.filter='none'">
                        ⚡ Run / Execute
                    </button>
                    <button onclick="clearStudioOutput()" style="background: transparent; border: 1px solid rgba(255, 255, 255, 0.08); color: #94a3b8; border-radius: 8px; padding: 10px 20px; font-size: 13px; font-weight: 600; cursor: pointer; transition: all 0.2s;" onmouseover="this.style.background='rgba(255,255,255,0.03)'" onmouseout="this.style.background='transparent'">
                        Clear Output
                    </button>
                    <div id="studio-loading-indicator" style="display: none; align-items: center; gap: 8px; font-size: 12px; color: #00f0ff; font-family: 'JetBrains Mono', monospace;">
                        <span class="studio-pulse-dot"></span>
                        <span>GENERATING CONTENT STREAM...</span>
                    </div>
                </div>

                <!-- Output Display Section -->
                <div style="background: #0b111e; border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 12px; padding: 20px; display: flex; flex-direction: column; gap: 14px; min-height: 250px; box-shadow: 0 4px 15px rgba(0,0,0,0.2);">
                    <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid rgba(255, 255, 255, 0.06); padding-bottom: 10px;">
                        <span style="font-size: 12px; font-weight: bold; color: #00f0ff; font-family: 'JetBrains Mono', monospace;">MODEL OUTPUT RESPONSE</span>
                        <span id="generation-metrics" style="font-size: 11px; font-family: 'JetBrains Mono', monospace; color: #64748b;">Idle</span>
                    </div>

                    <div id="studio-output-view" class="bangla-font-siliguri" style="color: #e2e8f0; font-size: 14px; line-height: 1.6; word-wrap: break-word;">
                        <span style="color: #475569; font-style: italic;">Response will stream here. Hit the Run button to execute.</span>
                    </div>
                </div>

            </div>

            <!-- RIGHT CONTROL PANEL: Parameter Settings -->
            <aside id="studio-right-sidebar" style="width: 280px; background: #0b111e; border-left: 1px solid rgba(255, 255, 255, 0.08); display: flex; flex-direction: column; overflow-y: auto; padding: 20px; gap: 20px;">
                
                <div style="font-size: 11px; font-weight: bold; color: #94a3b8; letter-spacing: 1px; text-transform: uppercase; font-family: 'JetBrains Mono', monospace; border-bottom: 1px solid rgba(255,255,255,0.06); padding-bottom: 8px;">
                    Configurations
                </div>

                <!-- Model Selector -->
                <div style="display: flex; flex-direction: column; gap: 6px;">
                    <label style="font-size: 11px; font-weight: bold; color: #cbd5e0;">Model</label>
                    <select id="studio-model" style="width: 100%; background: #111827; border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 6px; padding: 8px 12px; color: #fff; font-size: 12.5px; font-family: 'JetBrains Mono', monospace; outline: none;" onchange="autoSaveCurrentPromptState()">
                        <option value="gemini-3.6-flash">Gemini 3.6 Flash (Fast)</option>
                        <option value="gemini-3.1-pro-preview">Gemini 3.1 Pro (Reasoning)</option>
                        <option value="gemini-1.5-pro">Gemini 1.5 Pro</option>
                    </select>
                </div>

                <!-- Temperature Slider -->
                <div style="display: flex; flex-direction: column; gap: 8px;">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <label style="font-size: 11px; font-weight: bold; color: #cbd5e0;">Temperature</label>
                        <span id="temp-val" style="font-size: 11px; font-family: 'JetBrains Mono', monospace; color: #fbbf24;">1.0</span>
                    </div>
                    <input type="range" id="studio-temperature" min="0" max="2" step="0.1" value="1.0" style="width: 100%; accent-color: #fbbf24;" oninput="updateParamLabel('temp-val', this.value); autoSaveCurrentPromptState();">
                    <div style="display: flex; justify-content: space-between; font-size: 9px; color: #475569;">
                        <span>0.0 (Deterministic)</span>
                        <span>2.0 (Creative)</span>
                    </div>
                </div>

                <!-- Top P Slider -->
                <div style="display: flex; flex-direction: column; gap: 8px;">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <label style="font-size: 11px; font-weight: bold; color: #cbd5e0;">Top P</label>
                        <span id="topp-val" style="font-size: 11px; font-family: 'JetBrains Mono', monospace; color: #00f0ff;">0.95</span>
                    </div>
                    <input type="range" id="studio-topp" min="0" max="1" step="0.05" value="0.95" style="width: 100%; accent-color: #00f0ff;" oninput="updateParamLabel('topp-val', this.value); autoSaveCurrentPromptState();">
                </div>

                <!-- Top K Input -->
                <div style="display: flex; flex-direction: column; gap: 6px;">
                    <label style="font-size: 11px; font-weight: bold; color: #cbd5e0;">Top K</label>
                    <input type="number" id="studio-topk" min="1" max="40" value="40" style="width: 100%; background: #111827; border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 6px; padding: 6px 10px; color: #fff; font-size: 12px; font-family: 'JetBrains Mono', monospace; outline: none;" onchange="autoSaveCurrentPromptState()">
                </div>

                <!-- Max Output Tokens -->
                <div style="display: flex; flex-direction: column; gap: 6px;">
                    <label style="font-size: 11px; font-weight: bold; color: #cbd5e0;">Max Output Tokens</label>
                    <input type="number" id="studio-max-tokens" min="1" max="8192" value="2048" style="width: 100%; background: #111827; border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 6px; padding: 6px 10px; color: #fff; font-size: 12px; font-family: 'JetBrains Mono', monospace; outline: none;" onchange="autoSaveCurrentPromptState()">
                </div>

                <!-- Safety Threshold settings -->
                <div style="display: flex; flex-direction: column; gap: 6px;">
                    <label style="font-size: 11px; font-weight: bold; color: #cbd5e0;">Safety Block Level</label>
                    <select id="studio-safety" style="width: 100%; background: #111827; border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 6px; padding: 8px 12px; color: #fff; font-size: 12.5px; outline: none;" onchange="autoSaveCurrentPromptState()">
                        <option value="BLOCK_MEDIUM_AND_ABOVE">Block Medium & Above</option>
                        <option value="BLOCK_LOW_AND_ABOVE">Block Low & Above</option>
                        <option value="BLOCK_NONE">Block None (Experimental)</option>
                    </select>
                </div>

                <!-- Quick Export Code info -->
                <div style="background: rgba(255,255,255,0.02); border: 1px solid rgba(255, 255, 255, 0.05); border-radius: 8px; padding: 12px; font-size: 11px; color: #94a3b8; line-height: 1.4; margin-top: 10px;">
                    <div style="font-weight: bold; color: #fbbf24; margin-bottom: 4px;">⚡ Real-time Export</div>
                    Code generator instantly compiles your active configuration parameters into production-ready libraries.
                </div>

            </aside>
        </div>

    </main>
</div>

<!-- CODE EXPORT MODAL -->
<div id="get-code-modal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.85); z-index: 1000; align-items: center; justify-content: center; padding: 16px;">
    <div style="width: 100%; max-width: 680px; background: #0b111e; border: 1px solid rgba(255, 255, 255, 0.12); border-radius: 16px; display: flex; flex-direction: column; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.5);">
        
        <!-- Modal Header -->
        <div style="padding: 16px 24px; border-bottom: 1px solid rgba(255, 255, 255, 0.08); display: flex; justify-content: space-between; align-items: center; background: rgba(0,0,0,0.2);">
            <div style="font-weight: bold; font-size: 16px; color: #f1f5f9; display: flex; align-items: center; gap: 8px;">
                <span>💻</span> Get Code / কোড জেনারেটর
            </div>
            <button onclick="closeGetCodeModal()" style="background: none; border: none; color: #ef4444; font-size: 18px; cursor: pointer;">✕</button>
        </div>

        <!-- Language Tabs -->
        <div style="display: flex; background: rgba(0,0,0,0.15); border-bottom: 1px solid rgba(255, 255, 255, 0.05); padding: 0 16px;">
            <button onclick="switchCodeTab('curl')" id="tab-curl" class="code-tab active" style="background: none; border: none; border-bottom: 2px solid #00f0ff; color: #00f0ff; padding: 12px 20px; cursor: pointer; font-family: 'JetBrains Mono', monospace; font-size: 12px; font-weight: bold;">cURL</button>
            <button onclick="switchCodeTab('python')" id="tab-python" class="code-tab" style="background: none; border: none; border-bottom: 2px solid transparent; color: #94a3b8; padding: 12px 20px; cursor: pointer; font-family: 'JetBrains Mono', monospace; font-size: 12px; font-weight: bold;">Python</button>
            <button onclick="switchCodeTab('javascript')" id="tab-javascript" class="code-tab" style="background: none; border: none; border-bottom: 2px solid transparent; color: #94a3b8; padding: 12px 20px; cursor: pointer; font-family: 'JetBrains Mono', monospace; font-size: 12px; font-weight: bold;">JavaScript</button>
            <button onclick="switchCodeTab('php')" id="tab-php" class="code-tab" style="background: none; border: none; border-bottom: 2px solid transparent; color: #94a3b8; padding: 12px 20px; cursor: pointer; font-family: 'JetBrains Mono', monospace; font-size: 12px; font-weight: bold;">PHP (WordPress)</button>
        </div>

        <!-- Code Content Block -->
        <div style="padding: 24px; position: relative; background: #070b13; flex: 1;">
            <button onclick="copyGeneratedCode()" style="position: absolute; right: 24px; top: 24px; background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.15); border-radius: 4px; padding: 4px 10px; color: #fbbf24; cursor: pointer; font-size: 11px; font-weight: bold;" id="code-modal-copy-btn">COPY CODE</button>
            <pre style="margin: 0; background: transparent !important; border: none !important; padding: 0 !important; max-height: 350px; overflow-y: auto;"><code id="exported-code-block" style="background: transparent !important; border: none !important; color: #e2e8f0 !important; font-size: 12px; font-family: 'JetBrains Mono', monospace !important; white-space: pre-wrap; word-break: break-all;">Loading code...</code></pre>
        </div>

        <!-- Modal Footer -->
        <div style="padding: 12px 24px; background: rgba(0,0,0,0.2); border-top: 1px solid rgba(255,255,255,0.08); display: flex; justify-content: flex-end;">
            <button onclick="closeGetCodeModal()" style="background: #1e293b; border: 1px solid rgba(255,255,255,0.1); color: #fff; border-radius: 6px; padding: 8px 20px; cursor: pointer; font-size: 12px; font-weight: 600;">Close / বন্ধ করুন</button>
        </div>

    </div>
</div>

<style>
/* CSS styles for tabs and elements */
.code-tab {
    transition: all 0.2s ease;
}
.code-tab:hover {
    color: #fff !important;
}
.studio-saved-item {
    padding: 8px 12px;
    background: transparent;
    border: 1px solid transparent;
    border-radius: 6px;
    font-size: 13px;
    color: #cbd5e0;
    cursor: pointer;
    display: flex;
    justify-content: space-between;
    align-items: center;
    transition: all 0.15s;
}
.studio-saved-item:hover {
    background: rgba(255, 255, 255, 0.03);
    border-color: rgba(255,255,255,0.05);
    color: #fff;
}
.studio-saved-item.active {
    background: rgba(0, 240, 255, 0.04);
    border-color: rgba(0, 240, 255, 0.15);
    color: #00f0ff;
    font-weight: bold;
}
.studio-pulse-dot {
    display: inline-block;
    width: 6px;
    height: 6px;
    background: #00f0ff;
    border-radius: 50%;
    box-shadow: 0 0 8px #00f0ff;
    animation: studioPulse 1s infinite alternate;
}
@keyframes studioPulse {
    0% { opacity: 0.4; transform: scale(0.9); }
    100% { opacity: 1; transform: scale(1.1); }
}
#ai-studio-root pre {
    background: #0d1527 !important;
    border: 1px solid rgba(255,255,255,0.06) !important;
    border-radius: 8px !important;
    padding: 14px !important;
    color: #e2e8f0 !important;
    font-family: 'JetBrains Mono', monospace !important;
    font-size: 12.5px !important;
    overflow-x: auto;
    position: relative;
    margin: 16px 0;
}
#ai-studio-root pre code {
    background: transparent !important;
    padding: 0 !important;
    border: none !important;
    color: inherit !important;
}
#ai-studio-root code {
    background: rgba(251, 191, 36, 0.08) !important;
    border: 1px solid rgba(251, 191, 36, 0.2) !important;
    color: #f59e0b !important;
    padding: 2px 6px !important;
    border-radius: 4px !important;
    font-family: 'JetBrains Mono', monospace !important;
    font-size: 12px;
}
.pre-studio-copy-btn {
    position: absolute;
    right: 8px;
    top: 8px;
    background: rgba(255, 255, 255, 0.08);
    border: 1px solid rgba(255, 255, 255, 0.15);
    color: #fbbf24;
    font-size: 10.5px;
    padding: 3px 8px;
    border-radius: 4px;
    cursor: pointer;
    font-weight: bold;
    z-index: 10;
}
.pre-studio-copy-btn:hover {
    background: #fbbf24;
    color: #000;
}
</style>

<!-- GOOGLE AI STUDIO RUNNER ENGINE JAVASCRIPT -->
<script>
var studioApiKey = "";
var activePromptId = null;
var promptsLibrary = {};
var currentActiveTab = "curl";

document.addEventListener("DOMContentLoaded", function() {
    loadStudioKey();
    initPromptsLibrary();
});

// Load saved key from localStorage
function loadStudioKey() {
    var saved = localStorage.getItem("ilybd_studio_api_key");
    if (saved) {
        studioApiKey = saved;
        document.getElementById("studio-api-key").value = saved;
        document.getElementById("key-status-badge").innerText = "CLIENT KEY";
        document.getElementById("key-status-badge").style.color = "#00f0ff";
    }
}

function saveStudioApiKey() {
    var val = document.getElementById("studio-api-key").value.trim();
    studioApiKey = val;
    if (val) {
        localStorage.setItem("ilybd_studio_api_key", val);
        document.getElementById("key-status-badge").innerText = "CLIENT KEY";
        document.getElementById("key-status-badge").style.color = "#00f0ff";
    } else {
        localStorage.removeItem("ilybd_studio_api_key");
        document.getElementById("key-status-badge").innerText = "WP BALANCER";
        document.getElementById("key-status-badge").style.color = "#64748b";
    }
}

function toggleApiKeyVisibility() {
    var inp = document.getElementById("studio-api-key");
    if (inp.type === "password") {
        inp.type = "text";
    } else {
        inp.type = "password";
    }
}

function initPromptsLibrary() {
    var stored = localStorage.getItem("ilybd_studio_prompts");
    if (stored) {
        try {
            promptsLibrary = JSON.parse(stored);
        } catch(e) {
            promptsLibrary = {};
        }
    }
    
    var keys = Object.keys(promptsLibrary);
    if (keys.length === 0) {
        createNewStudioPrompt();
    } else {
        activePromptId = keys[keys.length - 1];
        renderSavedPromptsList();
        loadActivePromptState();
    }
}

function savePromptsLibrary() {
    localStorage.setItem("ilybd_studio_prompts", JSON.stringify(promptsLibrary));
    renderSavedPromptsList();
}

function createNewStudioPrompt() {
    var id = "prompt-" + Date.now();
    promptsLibrary[id] = {
        id: id,
        title: "Untitled Prompt",
        instruction: "",
        prompt: "",
        model: "gemini-3.6-flash",
        temperature: "1.0",
        topp: "0.95",
        topk: "40",
        maxtokens: "2048",
        safety: "BLOCK_MEDIUM_AND_ABOVE",
        output: ""
    };
    activePromptId = id;
    savePromptsLibrary();
    loadActivePromptState();
}

function selectStudioPrompt(id) {
    if (activePromptId === id) return;
    activePromptId = id;
    loadActivePromptState();
    renderSavedPromptsList();
}

function deleteStudioPrompt(id, e) {
    if (e) e.stopPropagation();
    if (confirm("Are you sure you want to delete this saved prompt?")) {
        delete promptsLibrary[id];
        var keys = Object.keys(promptsLibrary);
        if (keys.length === 0) {
            createNewStudioPrompt();
        } else {
            if (activePromptId === id) {
                activePromptId = keys[keys.length - 1];
            }
            savePromptsLibrary();
            loadActivePromptState();
        }
    }
}

function loadActivePromptState() {
    var state = promptsLibrary[activePromptId];
    if (!state) return;
    
    document.getElementById("current-prompt-title-label").innerText = state.title;
    document.getElementById("studio-system-instruction").value = state.instruction || "";
    document.getElementById("studio-prompt-input").value = state.prompt || "";
    document.getElementById("studio-model").value = state.model || "gemini-3.6-flash";
    
    var temp = state.temperature || "1.0";
    document.getElementById("studio-temperature").value = temp;
    document.getElementById("temp-val").innerText = temp;
    
    var topp = state.topp || "0.95";
    document.getElementById("studio-topp").value = topp;
    document.getElementById("topp-val").innerText = topp;
    
    document.getElementById("studio-topk").value = state.topk || "40";
    document.getElementById("studio-max-tokens").value = state.maxtokens || "2048";
    document.getElementById("studio-safety").value = state.safety || "BLOCK_MEDIUM_AND_ABOVE";
    
    var outView = document.getElementById("studio-output-view");
    if (state.output) {
        outView.innerHTML = formatMarkdownText(state.output);
    } else {
        outView.innerHTML = `<span style="color: #475569; font-style: italic;">Response will stream here. Hit the Run button to execute.</span>`;
    }
    
    updateStudioTokenCount();
}

function autoSaveCurrentPromptState() {
    var state = promptsLibrary[activePromptId];
    if (!state) return;
    
    state.instruction = document.getElementById("studio-system-instruction").value;
    state.prompt = document.getElementById("studio-prompt-input").value;
    state.model = document.getElementById("studio-model").value;
    state.temperature = document.getElementById("studio-temperature").value;
    state.topp = document.getElementById("studio-topp").value;
    state.topk = document.getElementById("studio-topk").value;
    state.maxtokens = document.getElementById("studio-max-tokens").value;
    state.safety = document.getElementById("studio-safety").value;
    
    savePromptsLibrary();
}

function saveCurrentPromptToLibrary() {
    var title = prompt("Enter prompt title / নাম লিখুন:", promptsLibrary[activePromptId].title);
    if (title === null) return;
    title = title.trim() || "Untitled Prompt";
    promptsLibrary[activePromptId].title = title;
    autoSaveCurrentPromptState();
}

function renderSavedPromptsList() {
    var list = document.getElementById("studio-saved-prompts-list");
    if (!list) return;
    list.innerHTML = "";
    
    var keys = Object.keys(promptsLibrary).reverse();
    keys.forEach(function(key) {
        var state = promptsLibrary[key];
        var item = document.createElement("div");
        item.className = "studio-saved-item" + (activePromptId === key ? " active" : "");
        item.onclick = function() { selectStudioPrompt(key); };
        
        var titleSpan = document.createElement("span");
        titleSpan.style.overflow = "hidden";
        titleSpan.style.textOverflow = "ellipsis";
        titleSpan.style.whiteSpace = "nowrap";
        titleSpan.style.maxWidth = "180px";
        titleSpan.textContent = state.title;
        
        var delBtn = document.createElement("button");
        delBtn.style.background = "none";
        delBtn.style.border = "none";
        delBtn.style.color = "#64748b";
        delBtn.style.cursor = "pointer";
        delBtn.style.fontSize = "12px";
        delBtn.innerHTML = "🗑️";
        delBtn.onclick = function(e) { deleteStudioPrompt(key, e); };
        delBtn.onmouseover = function() { this.style.color = "#ef4444"; };
        delBtn.onmouseout = function() { this.style.color = "#64748b"; };
        
        item.appendChild(titleSpan);
        item.appendChild(delBtn);
        list.appendChild(item);
    });
}

function updateStudioTokenCount() {
    var promptTxt = document.getElementById("studio-prompt-input").value;
    document.getElementById("token-counter").innerText = promptTxt.length + " characters (~" + Math.round(promptTxt.length / 4) + " tokens)";
}

function updateParamLabel(id, val) {
    document.getElementById(id).innerText = val;
}

function clearStudioOutput() {
    document.getElementById("studio-output-view").innerHTML = `<span style="color: #475569; font-style: italic;">Response will stream here. Hit the Run button to execute.</span>`;
    document.getElementById("generation-metrics").innerText = "Cleared";
    if (promptsLibrary[activePromptId]) {
        promptsLibrary[activePromptId].output = "";
        savePromptsLibrary();
    }
}

// EXECUTE RUN PROMPT (Direct API integration or Secure WordPress Balancer Fallback)
function executeStudioPrompt() {
    var sysInst = document.getElementById("studio-system-instruction").value.trim();
    var promptTxt = document.getElementById("studio-prompt-input").value.trim();
    
    if (!promptTxt) {
        alert("Please enter a prompt to execute.");
        return;
    }
    
    autoSaveCurrentPromptState();
    
    var loader = document.getElementById("studio-loading-indicator");
    var outView = document.getElementById("studio-output-view");
    var metrics = document.getElementById("generation-metrics");
    
    loader.style.display = "flex";
    outView.innerHTML = `<span style="color:#64748b; font-family:'JetBrains Mono', monospace; font-size:13px;">Executing request across secure cloud...</span>`;
    metrics.innerText = "Processing...";
    
    var t0 = performance.now();
    
    var modelVal = document.getElementById("studio-model").value;
    var tempVal = parseFloat(document.getElementById("studio-temperature").value);
    var toppVal = parseFloat(document.getElementById("studio-topp").value);
    var topkVal = parseInt(document.getElementById("studio-topk").value);
    var maxTokVal = parseInt(document.getElementById("studio-max-tokens").value);
    var safetyVal = document.getElementById("studio-safety").value;
    
    // Check if client provided API key
    if (studioApiKey) {
        // DIRECT CLIENT ENDPOINT CALL (Bypasses server bandwidth!)
        // Map model value to actual model versions
        var modelMapping = {
            "gemini-3.6-flash": "gemini-1.5-flash", // fallbacks to latest available in current SDK scopes
            "gemini-3.1-pro-preview": "gemini-1.5-pro",
            "gemini-1.5-pro": "gemini-1.5-pro"
        };
        var actualModel = modelMapping[modelVal] || "gemini-1.5-flash";
        
        var apiEndpoint = "https://generativelanguage.googleapis.com/v1beta/models/" + actualModel + ":generateContent?key=" + studioApiKey;
        
        // Prepare API payload matching Google developer standard
        var contents = [];
        if (sysInst) {
            // Include system instruction or custom configuration
        }
        contents.push({
            role: "user",
            parts: [{ text: promptTxt }]
        });
        
        var reqPayload = {
            contents: contents,
            generationConfig: {
                temperature: tempVal,
                topP: toppVal,
                topK: topkVal,
                maxOutputTokens: maxTokVal
            }
        };
        
        if (sysInst) {
            reqPayload.systemInstruction = {
                parts: [{ text: sysInst }]
            };
        }
        
        jQuery.ajax({
            url: apiEndpoint,
            type: "POST",
            contentType: "application/json",
            dataType: "json",
            data: JSON.stringify(reqPayload),
            success: function(res) {
                loader.style.display = "none";
                var t1 = performance.now();
                var duration = ((t1 - t0) / 1000).toFixed(2);
                
                var reply = "";
                if (res.candidates && res.candidates[0] && res.candidates[0].content && res.candidates[0].content.parts) {
                    reply = res.candidates[0].content.parts[0].text;
                } else {
                    reply = "Empty response received or blocked by safety filter.";
                }
                
                outView.innerHTML = formatMarkdownText(reply);
                metrics.innerText = "Generated in " + duration + "s (~" + Math.round(reply.length / 4) + " tokens)";
                
                if (promptsLibrary[activePromptId]) {
                    promptsLibrary[activePromptId].output = reply;
                    savePromptsLibrary();
                }
            },
            error: function(xhr) {
                loader.style.display = "none";
                metrics.innerText = "API Error";
                var errorMsg = "Direct API Call Failed. Please check your API key validity or security filters.";
                if (xhr.responseJSON && xhr.responseJSON.error) {
                    errorMsg = "Google API Error: " + xhr.responseJSON.error.message;
                }
                outView.innerHTML = `<span style="color:#ef4444; font-family:'JetBrains Mono', monospace;">${errorMsg}</span>`;
            }
        });
        
    } else {
        // SECURE WORDPRESS BALANCER FALLBACK
        jQuery.ajax({
            url: "<?php echo admin_url('admin-ajax.php'); ?>",
            type: "POST",
            dataType: "json",
            data: {
                action: "ilybd_ai_chat",
                nonce: "<?php echo wp_create_nonce('ilybd_ai_nonce'); ?>",
                message: (sysInst ? "[System: " + sysInst + "]\n" : "") + promptTxt,
                model: modelVal
            },
            success: function(response) {
                loader.style.display = "none";
                var t1 = performance.now();
                var duration = ((t1 - t0) / 1000).toFixed(2);
                
                var reply = "No output returned.";
                if (response.success && response.data && response.data.reply) {
                    reply = response.data.reply;
                }
                
                outView.innerHTML = formatMarkdownText(reply);
                metrics.innerText = "Generated in " + duration + "s (Via Balancer proxy)";
                
                if (promptsLibrary[activePromptId]) {
                    promptsLibrary[activePromptId].output = reply;
                    savePromptsLibrary();
                }
            },
            error: function() {
                loader.style.display = "none";
                metrics.innerText = "Server Error";
                outView.innerHTML = `<span style="color:#ef4444; font-family:'JetBrains Mono', monospace;">WordPress connection error. Please refresh or enter your own Gemini API key for self-governing high-speed throughput.</span>`;
            }
        });
    }
}

// Markdown formatting helper
function escapeHtmlText(text) {
    if (!text) return "";
    return text
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}

function formatMarkdownText(text) {
    if (!text) return "";
    
    let escaped = escapeHtmlText(text);

    // Format Code Blocks ```lang ... ```
    escaped = escaped.replace(/```(?:[a-zA-Z0-9]+)?\n([\s\S]*?)```/g, function(match, code) {
        return '<div style="position:relative;"><button class="pre-studio-copy-btn" onclick="copyPreStudioCodePayload(this)">COPY</button><pre><code>' + code.trim() + '</code></pre></div>';
    });

    // Inline codes `code`
    escaped = escaped.replace(/`([^`]+)`/g, '<code>$1</code>');

    // Bold **text**
    escaped = escaped.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');

    // Bullet lists
    escaped = escaped.replace(/^\s*-\s+([^\n]+)/gm, '<li style="margin-left:15px; list-style-type:square; color:#cbd5e0;">$1</li>');
    escaped = escaped.replace(/^\s*\*\s+([^\n]+)/gm, '<li style="margin-left:15px; list-style-type:circle; color:#cbd5e0;">$1</li>');

    // Double line breaks
    escaped = escaped.replace(/\n\n/g, '<br><br>');
    // Single line breaks
    escaped = escaped.replace(/\n/g, '<br>');

    return escaped;
}

function copyPreStudioCodePayload(btn) {
    var code = btn.nextElementSibling.innerText;
    navigator.clipboard.writeText(code).then(function() {
        var prev = btn.innerHTML;
        btn.innerHTML = "COPIED!";
        btn.style.background = "#00ff41";
        btn.style.color = "#000";
        setTimeout(function() {
            btn.innerHTML = prev;
            btn.style.background = "rgba(255, 255, 255, 0.08)";
            btn.style.color = "#fbbf24";
        }, 1500);
    });
}

function toggleStudioLeftSidebar() {
    var sidebar = document.getElementById("studio-left-sidebar");
    if (sidebar) {
        if (sidebar.style.width === "0px" || sidebar.style.display === "none") {
            sidebar.style.width = "280px";
            sidebar.style.display = "flex";
        } else {
            sidebar.style.width = "0px";
            setTimeout(function() {
                if(sidebar.style.width === "0px") sidebar.style.display = "none";
            }, 300);
        }
    }
}

// CODE EXPORT SYSTEM (cURL, Python, Node.js, PHP WordPress integration)
function openGetCodeModal() {
    document.getElementById("get-code-modal").style.display = "flex";
    switchCodeTab(currentActiveTab);
}

function closeGetCodeModal() {
    document.getElementById("get-code-modal").style.display = "none";
}

function switchCodeTab(lang) {
    currentActiveTab = lang;
    
    var tabs = document.getElementsByClassName("code-tab");
    for (var i = 0; i < tabs.length; i++) {
        tabs[i].classList.remove("active");
        tabs[i].style.borderColor = "transparent";
        tabs[i].style.color = "#94a3b8";
    }
    
    var activeTab = document.getElementById("tab-" + lang);
    if (activeTab) {
        activeTab.classList.add("active");
        activeTab.style.borderColor = "#00f0ff";
        activeTab.style.color = "#00f0ff";
    }
    
    generateModalCodePayload(lang);
}

function generateModalCodePayload(lang) {
    var sysInst = document.getElementById("studio-system-instruction").value.replace(/"/g, '\\"');
    var promptTxt = document.getElementById("studio-prompt-input").value.replace(/"/g, '\\"');
    var modelVal = document.getElementById("studio-model").value;
    var tempVal = document.getElementById("studio-temperature").value;
    var toppVal = document.getElementById("studio-topp").value;
    var maxTokVal = document.getElementById("studio-max-tokens").value;
    
    var code = "";
    
    if (lang === "curl") {
        code = `curl "https://generativelanguage.googleapis.com/v1beta/models/${modelVal === 'gemini-3.6-flash' ? 'gemini-1.5-flash' : 'gemini-1.5-pro'}:generateContent?key=\${YOUR_GEMINI_API_KEY}" \\
-H "Content-Type: application/json" \\
-d '{
  "contents": [
    {
      "role": "user",
      "parts": [{ "text": "${promptTxt}" }]
    }
  ],
  "generationConfig": {
    "temperature": ${tempVal},
    "topP": ${toppVal},
    "maxOutputTokens": ${maxTokVal}
  }${sysInst ? ',\n  "systemInstruction": {\n    "parts": [{ "text": "' + sysInst + '" }]\n  }' : ''}
}'`;
    } 
    else if (lang === "python") {
        code = `import google.generativeai as genai

# Configure your secure client key
genai.configure(api_key="YOUR_GEMINI_API_KEY")

# Create the model configuration
generation_config = {
    "temperature": ${tempVal},
    "top_p": ${toppVal},
    "max_output_tokens": ${maxTokVal},
    "response_mime_type": "text/plain",
}

model = genai.GenerativeModel(
    model_name="${modelVal === 'gemini-3.6-flash' ? 'gemini-1.5-flash' : 'gemini-1.5-pro'}",
    generation_config=generation_config,
    ${sysInst ? 'system_instruction="' + sysInst + '",' : ''}
)

chat_session = model.start_chat(history=[])
response = chat_session.send_message("${promptTxt}")

print(response.text)`;
    } 
    else if (lang === "javascript") {
        code = `import { GoogleGenAI } from "@google/genai";

// Initialize Gemini SDK securely
const ai = new GoogleGenAI({ apiKey: "YOUR_GEMINI_API_KEY" });

async function runStudioPrompt() {
  const response = await ai.models.generateContent({
    model: "${modelVal === 'gemini-3.6-flash' ? 'gemini-1.5-flash' : 'gemini-1.5-pro'}",
    contents: "${promptTxt}",
    config: {
      temperature: ${tempVal},
      topP: ${toppVal},
      maxOutputTokens: ${maxTokVal},
      ${sysInst ? 'systemInstruction: "' + sysInst + '",' : ''}
    }
  });

  console.log(response.text);
}

runStudioPrompt();`;
    } 
    else if (lang === "php") {
        code = `\\x3C?php
/**
 * WordPress integration snippet generated in iloveyoubd.com AI Studio
 */

function ilybd_execute_custom_gemini_prompt() {
    $api_key = defined('GEMINI_API_KEY') ? GEMINI_API_KEY : 'YOUR_GEMINI_API_KEY';
    $model = '${modelVal === 'gemini-3.6-flash' ? 'gemini-1.5-flash' : 'gemini-1.5-pro'}';
    $endpoint = "https://generativelanguage.googleapis.com/v1beta/models/" . $model . ":generateContent?key=" . $api_key;

    $payload = array(
        'contents' => array(
            array(
                'role' => 'user',
                'parts' => array(
                    array('text' => "${promptTxt}")
                )
            )
        ),
        'generationConfig' => array(
            'temperature' => ${tempVal},
            'topP' => ${toppVal},
            'maxOutputTokens' => ${maxTokVal}
        )
    );

    ${sysInst ? '$payload[\'systemInstruction\'] = array(\'parts\' => array(array(\'text\' => "' + sysInst + '")));' : ''}

    $response = wp_remote_post($endpoint, array(
        'headers'     => array('Content-Type' => 'application/json'),
        'body'        => json_encode($payload),
        'method'      => 'POST',
        'data_format' => 'body',
        'timeout'     => 45
    ));

    if (is_wp_error($response)) {
        return "WordPress Connection Error: " . $response->get_error_message();
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if (isset($data['candidates'][0]['content']['parts'][0]['text'])) {
        return $data['candidates'][0]['content']['parts'][0]['text'];
    }

    return "Empty or blocked content response.";
}`;
    }
    
    document.getElementById("exported-code-block").innerText = code;
}

function copyGeneratedCode() {
    var code = document.getElementById("exported-code-block").innerText;
    navigator.clipboard.writeText(code).then(function() {
        var btn = document.getElementById("code-modal-copy-btn");
        var prev = btn.innerHTML;
        btn.innerHTML = "COPIED!";
        btn.style.background = "#00ff41";
        btn.style.color = "#000";
        setTimeout(function() {
            btn.innerHTML = prev;
            btn.style.background = "rgba(255, 255, 255, 0.08)";
            btn.style.color = "#fbbf24";
        }, 1500);
    });
}
</script>

<?php
get_footer();
