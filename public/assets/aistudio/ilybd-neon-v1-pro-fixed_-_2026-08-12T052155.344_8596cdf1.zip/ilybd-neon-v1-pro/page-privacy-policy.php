<?php
/**
 * Template Name: Cyber Privacy Pro
 * Description: Fully Professional SEO-Optimized Cyberpunk Privacy Policy Page
 */

get_header();
$neon = get_option('ilybd_main_color', '#00ff41');
?>

<div class="cyber-page-wrapper">
    <div class="container-fluid" style="max-width: 1200px; margin: 0 auto; padding: 40px 20px;">
        
        <header class="cyber-section-header">
            <h1 class="rgb-text-lighting">Privacy Policy</h1>
            <p class="section-subtext">ILYBD SYSTEM / CORE SECURE NODE</p>
            <div class="sticky-rgb-line"></div>
        </header>

        <div class="slim-rgb-container">
            <div class="inner-page-content">
                <div class="privacy-intro">
                    <p>At <strong>ILYBD System (iloveyoubd.com)</strong>, protecting your digital identity is our absolute priority. This document outlines how your data is processed, saved, and secured within our high-speed networks and WordPress databases.</p>
                </div>

                <div class="policy-grid">
                    <div class="policy-card">
                        <h3>🔑 1. Identity & Profile Data</h3>
                        <p>When you create an account, register on our forums, or edit your dashboard, we store your email address, username, IP routing trace, and any uploaded images (such as your customized profile avatar). Your custom avatar is processed locally on our secure host before being converted to optimized high-speed thumbnails to prevent bulk file injection.</p>
                    </div>

                    <div class="policy-card">
                        <h3>🍪 2. Cookies, Google AdSense & Third-Party Advertising</h3>
                        <p>We use system cookies to maintain connection state (login persistence, theme colors, forum like states, and user sessions). Furthermore, we partner with <strong>Google AdSense</strong> to serve advertisements on our network. Google, as a third-party vendor, uses cookies (including the DoubleClick DART cookie) to serve ads on ilybd.com based on users' visits to our site and other sites on the Internet. You may opt out of the use of the DART cookie by visiting the Google Ad and Content Network privacy policy.</p>
                    </div>

                    <div class="policy-card">
                        <h3>🛡️ 3. Security Protocols & Google Publisher Policies</h3>
                        <p>All trans-gateway communications inside our web application are protected via SSL encryption. We monitor server ports and actively block brute force access attempts. We strictly adhere to Google Publisher Policies, ensuring that no malicious scripts, adult content, or copyrighted materials are hosted or transmitted via our services.</p>
                    </div>

                    <div class="policy-card">
                        <h3>📜 4. Consent, California Consumer Privacy Act (CCPA) & GDPR</h3>
                        <p>By using the ILYBD system, you consent to our security routing. In accordance with CCPA, GDPR, and Google's consent framework, users can opt out of personalized tracking or request complete removal of their account nodes from our systems by using the self-deletion interface inside the user dashboard.</p>
                    </div>
                </div>

                <div class="policy-footer-note">
                    <p>If you have questions regarding our automated secure gateway or wish to request an encrypted diagnostic report, please reach out to our team at <strong>support@iloveyoubd.com</strong>.</p>
                </div>
            </div>
        </div>

    </div>
</div>

<style>
    .cyber-page-wrapper {
        background: #070a0f;
        min-height: 100vh;
        color: #e1e7ef;
        font-family: 'Inter', system-ui, -apple-system, sans-serif;
    }

    .cyber-section-header {
        text-align: center;
        margin-bottom: 40px;
    }

    .rgb-text-lighting {
        font-size: 2.8rem;
        font-weight: 900;
        text-transform: uppercase;
        letter-spacing: 3px;
        margin: 0 0 10px 0;
        background: linear-gradient(to right, #ff0000, #ffff00, #00ff00, #00ffff, #0000ff, #ff00ff, #ff0000);
        background-size: 200% auto;
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        animation: rgb_flow 4s linear infinite;
    }

    .section-subtext {
        color: <?php echo $neon; ?>;
        font-size: 11px;
        letter-spacing: 5px;
        margin-bottom: 20px;
    }

    .sticky-rgb-line {
        height: 2px;
        width: 100%;
        background: linear-gradient(to right, #ff0000, #ffff00, #00ff00, #00ffff, #0000ff, #ff00ff, #ff0000);
        background-size: 200% auto;
        animation: rgb_flow 4s linear infinite;
        box-shadow: 0 0 15px <?php echo $neon; ?>dd;
    }

    .slim-rgb-container {
        position: relative;
        padding: 1px;
        background: linear-gradient(var(--angle), #ff0000, #00ff00, #0000ff, #ff0000);
        animation: rotate-border 6s linear infinite;
        border-radius: 20px;
        overflow: hidden;
    }

    @property --angle {
        syntax: '<angle>';
        initial-value: 0deg;
        inherits: false;
    }

    @keyframes rotate-border {
        to { --angle: 360deg; }
    }

    .inner-page-content {
        background: #0a0e14;
        border-radius: 19px;
        padding: 40px;
    }

    .privacy-intro {
        margin-bottom: 35px;
        border-left: 3px solid <?php echo $neon; ?>;
        padding-left: 20px;
        font-size: 16px;
        line-height: 1.8;
        color: #a0aec0;
    }

    .policy-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 25px;
        margin-bottom: 35px;
    }

    .policy-card {
        background: rgba(255,255,255,0.02);
        border: 1px solid rgba(255,255,255,0.06);
        border-radius: 12px;
        padding: 25px;
        transition: all 0.3s ease;
    }

    .policy-card:hover {
        border-color: <?php echo $neon; ?>;
        box-shadow: 0 0 20px <?php echo $neon; ?>33;
        transform: translateY(-2px);
    }

    .policy-card h3 {
        color: #fff;
        font-size: 18px;
        margin-top: 0;
        margin-bottom: 15px;
        border-bottom: 1px solid rgba(255,255,255,0.06);
        padding-bottom: 8px;
    }

    .policy-card p {
        line-height: 1.7;
        color: #a0aec0;
        font-size: 14.5px;
        margin: 0;
    }

    .policy-footer-note {
        background: rgba(0, 255, 65, 0.04);
        border: 1px dashed <?php echo $neon; ?>44;
        border-radius: 10px;
        padding: 20px;
        text-align: center;
        color: #a0aec0;
        font-size: 15px;
    }

    @keyframes rgb_flow {
        to { background-position: 200% center; }
    }

    @media (max-width: 768px) {
        .policy-grid { grid-template-columns: 1fr; }
    }

    @media (max-width: 480px) {
        .inner-page-content { padding: 20px; }
        .rgb-text-lighting { font-size: 2rem; }
    }
</style>

<?php
get_footer();
?>
