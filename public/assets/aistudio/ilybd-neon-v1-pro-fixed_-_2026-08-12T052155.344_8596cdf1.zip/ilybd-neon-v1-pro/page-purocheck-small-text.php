<?php
/**
 * Template Name: PuroCheck - Small Text Generator
 */
get_header(); ?>

<!-- Advanced Schema for Small Text Generator (2040 Search Optimization) -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "SoftwareApplication",
      "@id": "https://iloveyoubd.com/purocheck-small-text/#app",
      "name": "PuroCheck™ Free Small Text Generator",
      "url": "https://iloveyoubd.com/purocheck-small-text/",
      "operatingSystem": "All",
      "applicationCategory": "EducationalApplication",
      "description": "Convert regular text into small caps, superscript, subscript, bubbles, and fancy unicode fonts instantly. Free font generator for social media profiles.",
      "offers": {
        "@type": "Offer",
        "price": "0.00",
        "priceCurrency": "USD",
        "priceValidUntil": "2030-12-31",
        "validFrom": "2024-01-01",
        "itemCondition": "https://schema.org/NewCondition",
        "availability": "https://schema.org/InStock"
      }
    }
  ]
}
</script>

<?php
if (function_exists('ilybd_render_tool_breadcrumbs')) {
    ilybd_render_tool_breadcrumbs('purocheck-small-text');
}
?>

<div class="puro-master-theme">
    <div class="puro-bg-particles"></div>
    
    <div class="puro-wrapper">
        
        <!-- Header Hero Section -->
        <div class="ilybd-purocheck-hero-wrap">
            <div class="ilybd-purocheck-badge-glow">PUROCHECK™ TEXT UTILITY</div>
            <h1 class="ilybd-purocheck-title-neon">স্মল টেক্সট জেনারেটর (Small Text Generator)</h1>
            <p class="ilybd-purocheck-subtitle">Generate custom Small Caps, Superscript, Bubbles, and Fancy Fonts instantly • 100% Free</p>
        </div>

        <!-- Main Workspace -->
        <main class="puro-grid-workspace" style="grid-template-columns: 1fr;">
            
            <section class="puro-bento-card" style="padding: 30px; background: rgba(13, 21, 37, 0.6); border: 1.5px solid var(--puro-border); border-radius: 20px; box-shadow: 0 0 30px rgba(0, 240, 255, 0.05);">
                
                <div style="margin-bottom: 25px;">
                    <label style="display:block; font-size: 14px; font-weight:800; color:#bd00ff; margin-bottom: 10px; text-transform:uppercase; font-family: var(--font-puro-mono);">এখানে আপনার সাধারণ টেক্সট লিখুন (Write Your Text Here):</label>
                    <textarea id="plainTextInput" placeholder="যেমন: Hello World! এখানে বাংলায় বা ইংরেজিতে লিখুন..." style="width:100%; height: 100px; background: rgba(3,5,9,0.8); border: 1.5px solid var(--puro-border); border-radius:12px; padding: 15px; color:#fff; font-size:16px; outline:none; transition:0.3s; resize:none;" oninput="generateSmallFonts()"></textarea>
                </div>

                <!-- Font Outputs -->
                <div style="display:flex; flex-direction:column; gap: 20px;">
                    <!-- 1. Small Caps -->
                    <div style="background: rgba(3,5,9,0.5); border: 1px solid rgba(255,255,255,0.04); padding: 18px; border-radius:12px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:15px;">
                        <div style="flex:1; min-width: 250px;">
                            <span style="display:block; font-size:11px; font-weight:800; color:var(--puro-cyan); text-transform:uppercase; margin-bottom: 5px;">Small Caps (ছোট ক্যাপিটাল)</span>
                            <span id="outputSmallCaps" style="font-size:18px; color:#fff; font-family:var(--font-puro-sans); word-break:break-all;">Hᴇʟʟᴏ Wᴏʀʟᴅ﹗</span>
                        </div>
                        <button class="puro-btn-action" onclick="copyTextFromElement('outputSmallCaps')" style="padding: 10px 18px; font-size:12px;">Copy 📋</button>
                    </div>

                    <!-- 2. Superscript -->
                    <div style="background: rgba(3,5,9,0.5); border: 1px solid rgba(255,255,255,0.04); padding: 18px; border-radius:12px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:15px;">
                        <div style="flex:1; min-width: 250px;">
                            <span style="display:block; font-size:11px; font-weight:800; color:var(--puro-violet); text-transform:uppercase; margin-bottom: 5px;">Superscript (পাওয়ার টেক্সট)</span>
                            <span id="outputSuperscript" style="font-size:18px; color:#fff; font-family:var(--font-puro-sans); word-break:break-all;">ᴴᵉˡˡᵒ ᵂᵒʳˡᵈ﹗</span>
                        </div>
                        <button class="puro-btn-action" onclick="copyTextFromElement('outputSuperscript')" style="padding: 10px 18px; font-size:12px;">Copy 📋</button>
                    </div>

                    <!-- 3. Bubble Text -->
                    <div style="background: rgba(3,5,9,0.5); border: 1px solid rgba(255,255,255,0.04); padding: 18px; border-radius:12px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:15px;">
                        <div style="flex:1; min-width: 250px;">
                            <span style="display:block; font-size:11px; font-weight:800; color:var(--puro-emerald); text-transform:uppercase; margin-bottom: 5px;">Bubble Text (বৃত্ত টেক্সট)</span>
                            <span id="outputBubbles" style="font-size:18px; color:#fff; font-family:var(--font-puro-sans); word-break:break-all;">Ⓗⓔⓛⓛⓞ Ⓦⓞⓡⓛⓓ﹗</span>
                        </div>
                        <button class="puro-btn-action" onclick="copyTextFromElement('outputBubbles')" style="padding: 10px 18px; font-size:12px;">Copy 📋</button>
                    </div>

                    <!-- 4. Monospace -->
                    <div style="background: rgba(3,5,9,0.5); border: 1px solid rgba(255,255,255,0.04); padding: 18px; border-radius:12px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:15px;">
                        <div style="flex:1; min-width: 250px;">
                            <span style="display:block; font-size:11px; font-weight:800; color:var(--puro-amber); text-transform:uppercase; margin-bottom: 5px;">Monospace (টাইপরাইটার ফন্ট)</span>
                            <span id="outputMonospace" style="font-size:18px; color:#fff; font-family:var(--font-puro-mono); word-break:break-all;">𝙷𝚎𝚕𝚕𝚘 𝚆𝚘𝚛𝚕𝚍!</span>
                        </div>
                        <button class="puro-btn-action" onclick="copyTextFromElement('outputMonospace')" style="padding: 10px 18px; font-size:12px;">Copy 📋</button>
                    </div>
                </div>

            </section>

        </main>

        <!-- SEO Content, Popular and Other Tools Include -->
        <?php include __DIR__ . '/page-purocheck-seo-block-include.php'; ?>

    </div>
</div>

<script>
const smallCapsMap = {
    'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴘ', 'q': 'ǫ', 'r': 'ʀ', 's': 's', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ',
    'A': 'ᴀ', 'B': 'ʙ', 'C': 'ᴄ', 'D': 'ᴅ', 'E': 'ᴇ', 'F': 'ꜰ', 'G': 'ɢ', 'H': 'ʜ', 'I': 'ɪ', 'J': 'ᴊ', 'K': 'ᴋ', 'L': 'ʟ', 'M': 'ᴍ', 'N': 'ɴ', 'O': 'ᴏ', 'P': 'ᴘ', 'Q': 'ǫ', 'R': 'ʀ', 'S': 's', 'T': 'ᴛ', 'U': 'ᴜ', 'V': 'ᴠ', 'W': 'ᴡ', 'X': 'x', 'Y': 'ʏ', 'Z': 'ᴢ'
};

const superscriptMap = {
    'a': 'ᵃ', 'b': 'ᵇ', 'c': 'ᶜ', 'd': 'ᵈ', 'e': 'ᵉ', 'f': 'ᶠ', 'g': 'ᵍ', 'h': 'ʰ', 'i': 'ⁱ', 'j': 'ʲ', 'k': 'ᵏ', 'l': 'ˡ', 'm': 'ᵐ', 'n': 'ⁿ', 'o': 'ᵒ', 'p': 'ᵖ', 'r': 'ʳ', 's': 'ˢ', 't': 'ᵗ', 'u': 'ᵘ', 'v': 'ᵛ', 'w': 'ʷ', 'x': 'ˣ', 'y': 'ʸ', 'z': 'ᶻ',
    'A': 'ᴬ', 'B': 'ᴮ', 'C': 'ᶜ', 'D': 'ᴰ', 'E': 'ᴱ', 'F': 'ᶠ', 'G': 'ᴳ', 'H': 'ᴴ', 'I': 'ᴵ', 'J': 'ᴶ', 'K': 'ᴷ', 'L': 'ᴸ', 'M': 'ᴹ', 'N': 'ᴺ', 'O': 'ᴼ', 'P': 'ᴾ', 'R': 'ᴿ', 'S': 'ˢ', 'T': 'ᵀ', 'U': 'ᵁ', 'V': 'ᵛ', 'W': 'ᵂ', 'X': 'ˣ', 'Y': 'ʸ', 'Z': 'ᶻ',
    '0': '⁰', '1': '¹', '2': '²', '3': '³', '4': '⁴', '5': '⁵', '6': '⁶', '7': '⁷', '8': '⁸', '9': '⁹'
};

const bubblesMap = {
    'a': 'ⓐ', 'b': 'ⓑ', 'c': 'ⓒ', 'd': 'ⓓ', 'e': 'ⓔ', 'f': 'ⓕ', 'g': 'ⓖ', 'h': 'ⓗ', 'i': 'ⓘ', 'j': 'ⓙ', 'k': 'ⓚ', 'l': 'ⓛ', 'm': 'ⓜ', 'n': 'ⓝ', 'o': 'ⓞ', 'p': 'ⓟ', 'q': 'ⓠ', 'r': 'ⓡ', 's': 'ⓢ', 't': 'ⓣ', 'u': 'ⓤ', 'v': 'ⓥ', 'w': 'ⓦ', 'x': 'ⓧ', 'y': 'ⓨ', 'z': 'ⓩ',
    'A': 'Ⓐ', 'B': 'Ⓑ', 'C': 'Ⓒ', 'D': 'Ⓓ', 'E': 'Ⓔ', 'F': 'Ⓕ', 'G': 'Ⓖ', 'H': 'Ⓗ', 'I': 'Ⓘ', 'J': 'Ⓙ', 'K': 'Ⓚ', 'L': 'Ⓛ', 'M': 'Ⓜ', 'N': 'Ⓝ', 'O': 'Ⓞ', 'P': 'Ⓟ', 'Q': 'Ⓠ', 'R': 'Ⓡ', 'S': 'Ⓢ', 'T': 'Ⓣ', 'U': 'Ⓤ', 'V': 'Ⓥ', 'W': 'Ⓦ', 'X': 'Ⓧ', 'Y': 'Ⓨ', 'Z': 'Ⓩ',
    '0': '⓪', '1': '①', '2': '②', '3': '③', '4': '④', '5': '⑤', '6': '⑥', '7': '⑦', '8': '⑧', '9': '⑨'
};

const monospaceMap = {
    'a': '𝚊', 'b': '𝚋', 'c': '𝚌', 'd': '𝚍', 'e': '𝚎', 'f': '𝚏', 'g': '𝚐', 'h': '𝚑', 'i': '𝚒', 'j': '𝚓', 'k': '𝚔', 'l': '𝚕', 'm': '𝚖', 'n': '𝚗', 'o': '𝚘', 'p': '𝚙', 'q': '𝚚', 'r': '𝚛', 's': '𝚜', 't': '𝚝', 'u': '𝚞', 'v': '𝚟', 'w': '𝚠', 'x': '𝚡', 'y': '𝚢', 'z': '𝚣',
    'A': '𝙰', 'B': '𝙱', 'C': '𝙲', 'D': '𝙳', 'E': '𝙴', 'F': '𝙵', 'G': '𝙶', 'H': '𝙷', 'I': '𝙸', 'J': '𝙹', 'K': '𝙺', 'L': '𝙻', 'M': '𝙼', 'N': '𝙽', 'O': '𝙾', 'P': '𝙿', 'Q': '𝚀', 'R': '𝚁', 'S': '𝚂', 'T': '𝚃', 'U': '𝚄', 'V': '𝚅', 'W': '𝚆', 'X': '𝚇', 'Y': '𝚈', 'Z': '𝚉',
    '0': '𝟶', '1': '𝟷', '2': '𝟸', '3': '𝟹', '4': '𝟺', '5': '𝟻', '6': '𝟼', '7': '𝟽', '8': '𝟾', '9': '𝟿'
};

function generateSmallFonts() {
    const input = document.getElementById('plainTextInput').value;
    if (!input) {
        document.getElementById('outputSmallCaps').innerText = 'Hᴇʟʟᴏ Wᴏʀʟᴅ﹗';
        document.getElementById('outputSuperscript').innerText = 'ᴴᵉˡˡᵒ ᵂᵒʳˡᵈ﹗';
        document.getElementById('outputBubbles').innerText = 'Ⓗⓔⓛⓛⓞ Ⓦⓞⓡⓛⓓ﹗';
        document.getElementById('outputMonospace').innerText = '𝙷𝚎𝚕𝚕𝚘 𝚠𝚘𝚛𝚕𝚍!';
        return;
    }

    let smallCaps = '';
    let superscript = '';
    let bubbles = '';
    let monospace = '';

    for (let char of input) {
        smallCaps += smallCapsMap[char] || char;
        superscript += superscriptMap[char] || char;
        bubbles += bubblesMap[char] || char;
        monospace += monospaceMap[char] || char;
    }

    document.getElementById('outputSmallCaps').innerText = smallCaps;
    document.getElementById('outputSuperscript').innerText = superscript;
    document.getElementById('outputBubbles').innerText = bubbles;
    document.getElementById('outputMonospace').innerText = monospace;
}

function copyTextFromElement(id) {
    const textVal = document.getElementById(id).innerText;
    navigator.clipboard.writeText(textVal);
    
    // Quick copy indicator
    const btn = event.target;
    const prevText = btn.innerHTML;
    btn.innerHTML = '✓ Copied!';
    setTimeout(() => {
        btn.innerHTML = prevText;
    }, 1500);
}
</script>

<?php get_footer(); ?>
