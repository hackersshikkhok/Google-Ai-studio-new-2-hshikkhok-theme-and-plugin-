<?php
/**
 * Template Name: PuroCheck - Word Counter
 */
get_header(); ?>

<!-- Advanced Schema for Word Counter (2040 Search Optimization) -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "SoftwareApplication",
      "@id": "https://iloveyoubd.com/purocheck-word-counter/#app",
      "name": "PuroCheck™ Free Online Word Counter",
      "url": "https://iloveyoubd.com/purocheck-word-counter/",
      "operatingSystem": "All",
      "applicationCategory": "EducationalApplication",
      "description": "Calculate characters, words, sentences, paragraphs, and estimated reading time of your text instantly in a beautiful, responsive neon terminal.",
      "offers": {
        "@type": "Offer",
        "price": "0.00",
        "priceCurrency": "USD",
        "priceValidUntil": "2030-12-31",
        "validFrom": "2024-01-01",
        "itemCondition": "https://schema.org/NewCondition",
        "availability": "https://schema.org/InStock"
      }
    }
  ]
}
</script>

<?php
if (function_exists('ilybd_render_tool_breadcrumbs')) {
    ilybd_render_tool_breadcrumbs('purocheck-word-counter');
}
?>

<div class="puro-master-theme">
    <div class="puro-bg-particles"></div>
    
    <div class="puro-wrapper">
        
        <!-- Header Hero Section -->
        <div class="ilybd-purocheck-hero-wrap">
            <div class="ilybd-purocheck-badge-glow">PUROCHECK™ WORD COUNTER</div>
            <h1 class="ilybd-purocheck-title-neon">ফ্রি অনলাইন ওয়ার্ড কাউন্টার</h1>
            <p class="ilybd-purocheck-subtitle">Real-time Character, Word, Sentence, and Paragraph Analyzer • 100% Free</p>
        </div>

        <!-- Main Workspace -->
        <main class="puro-grid-workspace" style="grid-template-columns: 1fr;">
            
            <section class="puro-bento-card" style="padding: 30px; background: rgba(13, 21, 37, 0.6); border: 1.5px solid var(--puro-border); border-radius: 20px; box-shadow: 0 0 30px rgba(0, 240, 255, 0.05);">
                
                <!-- Stat Grid -->
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 15px; margin-bottom: 25px;">
                    <div style="background: rgba(3,5,9,0.6); border: 1px solid rgba(255,255,255,0.05); padding: 15px; border-radius: 12px; text-align: center;">
                        <span style="display:block; font-size: 11px; font-weight:800; color: #94a3b8; text-transform: uppercase;">Words (শব্দ)</span>
                        <span id="statWords" style="display:block; font-size: 28px; font-weight:900; color: var(--puro-cyan); margin-top: 5px;">0</span>
                    </div>
                    <div style="background: rgba(3,5,9,0.6); border: 1px solid rgba(255,255,255,0.05); padding: 15px; border-radius: 12px; text-align: center;">
                        <span style="display:block; font-size: 11px; font-weight:800; color: #94a3b8; text-transform: uppercase;">Characters (অক্ষর)</span>
                        <span id="statChars" style="display:block; font-size: 28px; font-weight:900; color: var(--puro-violet); margin-top: 5px;">0</span>
                    </div>
                    <div style="background: rgba(3,5,9,0.6); border: 1px solid rgba(255,255,255,0.05); padding: 15px; border-radius: 12px; text-align: center;">
                        <span style="display:block; font-size: 11px; font-weight:800; color: #94a3b8; text-transform: uppercase;">Sentences (বাক্য)</span>
                        <span id="statSentences" style="display:block; font-size: 28px; font-weight:900; color: var(--puro-emerald); margin-top: 5px;">0</span>
                    </div>
                    <div style="background: rgba(3,5,9,0.6); border: 1px solid rgba(255,255,255,0.05); padding: 15px; border-radius: 12px; text-align: center;">
                        <span style="display:block; font-size: 11px; font-weight:800; color: #94a3b8; text-transform: uppercase;">Paragraphs (প্যারা)</span>
                        <span id="statParagraphs" style="display:block; font-size: 28px; font-weight:900; color: var(--puro-amber); margin-top: 5px;">0</span>
                    </div>
                    <div style="background: rgba(3,5,9,0.6); border: 1px solid rgba(255,255,255,0.05); padding: 15px; border-radius: 12px; text-align: center;">
                        <span style="display:block; font-size: 11px; font-weight:800; color: #94a3b8; text-transform: uppercase;">Reading Time (সময়)</span>
                        <span id="statTime" style="display:block; font-size: 18px; font-weight:900; color: #fff; margin-top: 12px;">0s</span>
                    </div>
                </div>

                <div class="puro-input-container active" style="margin-bottom: 20px;">
                    <textarea id="puroWordCounterText" placeholder="এখানে আপনার টেক্সট পেস্ট করুন অথবা লিখুন..." style="width:100%; height: 250px; background: rgba(3,5,9,0.8); border: 1.5px solid var(--puro-border); border-radius:14px; padding: 18px; color:#fff; font-size:15px; font-family: var(--font-puro-sans); resize: none; outline:none; transition:0.3s;" oninput="countTextStats()"></textarea>
                </div>

                <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
                    <span style="font-size: 12px; color: #64748b;">💡 টাইপ করার সাথে সাথে রিয়েল-টাইমে ডেটা আপডেট হবে।</span>
                    <button type="button" class="puro-btn-clear" onclick="clearWordCounter()" style="border: 1px solid rgba(255,255,255,0.1); background: rgba(255,255,255,0.02); color:#fff; padding: 10px 20px; border-radius:8px; cursor:pointer; font-weight:800; font-size:12px; transition:0.3s;" onmouseover="this.style.background='rgba(255,255,255,0.05)'" onmouseout="this.style.background='rgba(255,255,255,0.02)'">মুছে ফেলুন (Clear)</button>
                </div>

            </section>

        </main>

        <!-- SEO content & Popular Tools from page-purocheck.php (dynamic lookup) -->
        <?php
        // Include the bottom section of page-purocheck.php (which includes popular and other tools lists)
        include __DIR__ . '/page-purocheck-seo-block-include.php';
        ?>

    </div>
</div>

<script>
function countTextStats() {
    const text = document.getElementById('puroWordCounterText').value;
    
    // Character count
    const charCount = text.length;
    
    // Word count
    const words = text.trim().split(/\s+/).filter(w => w.length > 0);
    const wordCount = words.length;
    
    // Sentence count
    const sentenceCount = text.split(/[.!?।]/).filter(s => s.trim().length > 0).length;
    
    // Paragraph count
    const paragraphCount = text.split(/\n+/).filter(p => p.trim().length > 0).length;
    
    // Reading time (average 200 words per minute)
    const minutes = wordCount / 200;
    const seconds = Math.round(minutes * 60);
    let timeStr = "0s";
    if (seconds >= 60) {
        timeStr = Math.floor(seconds / 60) + "m " + (seconds % 60) + "s";
    } else if (seconds > 0) {
        timeStr = seconds + "s";
    }

    // Update UI
    document.getElementById('statWords').innerText = wordCount;
    document.getElementById('statChars').innerText = charCount;
    document.getElementById('statSentences').innerText = sentenceCount;
    document.getElementById('statParagraphs').innerText = paragraphCount;
    document.getElementById('statTime').innerText = timeStr;
}

function clearWordCounter() {
    document.getElementById('puroWordCounterText').value = '';
    countTextStats();
}
</script>

<?php get_footer(); ?>
