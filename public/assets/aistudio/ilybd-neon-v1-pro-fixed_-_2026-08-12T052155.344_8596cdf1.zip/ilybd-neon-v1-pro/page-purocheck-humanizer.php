<?php
/**
 * Template Name: PuroCheck - AI Humanizer & Rewriter
 */
$preselected_service = 'humanize';
include __DIR__ . '/page-purocheck.php';
