<?php
/**
 * Template Name: PuroCheck - AI Content Detector
 */
$preselected_service = 'ai-detect';
include __DIR__ . '/page-purocheck.php';
