<?php
/**
 * Custom AI Book Center Archive Hub Template (2040 Sovereign Cyber Ecosystem)
 * URL: https://iloveyoubd.com/books
 * Theme: ilybd-neon-v1-pro
 */
get_header(); 

// 1. DETERMINE SEARCH & FILTERS
$search_query = isset($_GET['book_q']) ? sanitize_text_field($_GET['book_q']) : '';
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

// Base query modification for taxonomy pages or search requests
$args = [
    'post_type'      => 'ilybd_book',
    'posts_per_page' => 12,
    'paged'          => $paged,
    'post_status'    => 'publish',
    'orderby'        => 'date',
    'order'          => 'DESC'
];

// If taxonomy archive page, WordPress automatically sets queries, but let's read the term to print elegant custom headings
$current_term = null;
if (is_tax()) {
    $current_term = get_queried_object();
}

if (!empty($search_query)) {
    $args['s'] = $search_query;
    // Search both title and custom fields like ISBN or Year
    $args['meta_query'] = [
        'relation' => 'OR',
        [
            'key'     => '_book_isbn',
            'value'   => $search_query,
            'compare' => 'LIKE'
        ],
        [
            'key'     => '_book_pub_year',
            'value'   => $search_query,
            'compare' => 'LIKE'
        ],
        [
            'key'     => '_book_language',
            'value'   => $search_query,
            'compare' => 'LIKE'
        ]
    ];
}

// Perform Query
$books_query = new WP_Query($args);
?>

<style>
/* Custom book list style */
.book-bento-grid {
    display: grid !important;
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)) !important;
    gap: 20px !important;
}

.book-archive-card {
    background: rgba(13, 21, 39, 0.7) !important;
    border: 1.5px solid rgba(0, 240, 255, 0.15) !important;
    border-radius: 16px !important;
    padding: 20px !important;
    display: flex !important;
    flex-direction: column !important;
    justify-content: space-between !important;
    gap: 15px !important;
    position: relative !important;
    overflow: hidden !important;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.25) !important;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
    backdrop-filter: blur(8px) !important;
    -webkit-backdrop-filter: blur(8px) !important;
}

.book-archive-card:hover {
    border-color: rgba(192, 132, 252, 0.45) !important; /* glowing violet on hover */
    transform: translateY(-4px) !important;
    box-shadow: 0 10px 25px rgba(192, 132, 252, 0.15) !important;
}

.book-list-cover {
    width: 80px !important;
    height: 116px !important;
    flex-shrink: 0 !important;
    border: 1.5px solid rgba(255, 255, 255, 0.1) !important;
    border-radius: 6px !important;
    box-shadow: 3px 5px 15px rgba(0,0,0,0.5) !important;
    position: relative !important;
    overflow: hidden !important;
    display: flex !important;
    flex-direction: column !important;
    justify-content: space-between !important;
    padding: 8px !important;
}

.book-list-cover .spine-effect {
    position: absolute !important;
    left: 0 !important;
    top: 0 !important;
    width: 4px !important;
    height: 100% !important;
    background: rgba(255,255,255,0.18) !important;
    box-shadow: 1px 0 3px rgba(0,0,0,0.4) !important;
}

/* Taxonomy filter lists */
.tax-filter-badge {
    display: inline-block !important;
    padding: 5px 12px !important;
    border-radius: 20px !important;
    font-size: 11.5px !important;
    font-family: monospace !important;
    color: #cbd5e0 !important;
    background: rgba(255,255,255,0.04) !important;
    border: 1.5px solid rgba(255,255,255,0.08) !important;
    text-decoration: none !important;
    transition: all 0.2s ease !important;
    margin-bottom: 6px !important;
}

.tax-filter-badge:hover, .tax-filter-badge.active {
    background: rgba(0, 240, 255, 0.08) !important;
    border-color: #00f0ff !important;
    color: #00f0ff !important;
    box-shadow: 0 0 10px rgba(0, 240, 255, 0.15) !important;
}

/* Category grid quick-navigation */
.category-pill-row {
    display: flex !important;
    flex-wrap: wrap !important;
    gap: 8px !important;
    margin-bottom: 30px !important;
}

/* Touch Targets for Mobile */
@media (max-width: 600px) {
    .book-archive-card {
        padding: 16px !important;
    }
}
</style>

<div class="nextgen-archive-viewport book-hub-viewport" style="background: #070b13; color: #c9d1d9; min-height: 100vh; padding: 30px 12px 80px; font-family: 'Inter', sans-serif;">
    <div style="max-width: 1000px; margin: 0 auto; width: 100%;">

        <!-- 1. BREADCRUMB -->
        <nav aria-label="Breadcrumb" style="margin-bottom: 25px; font-size: 12px; font-family: monospace; opacity: 0.85;">
            <a href="<?php echo esc_url(home_url('/')); ?>" style="color: #64748b; text-decoration: none; transition: color 0.2s;">HOME</a>
            <span style="color: #475569; margin: 0 8px;">/</span>
            <a href="<?php echo esc_url(home_url('/books/')); ?>" style="color: #64748b; text-decoration: none; transition: color 0.2s; font-weight: bold;">BOOKS</a>
            <?php if ($current_term) : ?>
                <span style="color: #475569; margin: 0 8px;">/</span>
                <span style="color: #c084fc; font-weight: bold; text-transform: uppercase;"><?php echo esc_html($current_term->name); ?></span>
            <?php endif; ?>
        </nav>

        <!-- 2. SOVEREIGN TITLE & ADVANCED MULTI-SEARCH CONSOLE -->
        <div class="book-hub-header" style="background: linear-gradient(135deg, #0d1527 0%, #070b13 100%); border: 1.5px solid rgba(0, 240, 255, 0.15); border-radius: 16px; padding: 30px 24px; margin-bottom: 30px; position: relative; overflow: hidden; box-shadow: 0 8px 32px rgba(0,0,0,0.5);">
            <div style="position: absolute; top:0; right:0; width: 150px; height: 150px; background: rgba(192, 132, 252, 0.04); filter: blur(60px); border-radius: 50%;"></div>
            
            <h1 style="color: #fff; font-family: 'Space Grotesk', sans-serif; font-weight: 800; font-size: 28px; margin: 0 0 10px 0; text-shadow: 0 0 15px rgba(0, 240, 255, 0.35);">
                📖 এআই বুক লাইব্রেরি ও সামারি হাব
            </h1>
            <p style="color: #8b949e; font-size: 14px; line-height: 1.6; margin: 0 0 20px 0; max-width: 750px;">
                বিশ্বখ্যাত প্রযুক্তি, সেলফ-ডেভেলপমেন্ট, প্রোগ্রামিং এবং ব্যবসার উপর লিখিত বইসমূহের বিশদ তথ্য, এআই-উত্পন্ন বাংলা সারাংশ, গুরুত্বপূর্ণ পয়েন্ট ও অ্যাকশন গাইডের একমাত্র বিশ্বস্ত হাব।
            </p>

            <!-- Search Form -->
            <form method="get" action="<?php echo esc_url(home_url('/books/')); ?>" style="display: flex; gap: 10px; align-items: center; max-width: 650px;">
                <div style="position: relative; flex-grow: 1;">
                    <i class="fa-solid fa-search" style="position: absolute; left: 14px; top: 50%; transform: translateY(-50%); color: #00f0ff;"></i>
                    <input type="text" name="book_q" value="<?php echo esc_attr($search_query); ?>" placeholder="বইয়ের নাম, লেখক, ISBN কোড বা সাল দিয়ে সার্চ করুন..." style="width: 100%; background: #070b13; border: 1.5px solid rgba(0, 240, 255, 0.25); color: #fff; padding: 12px 12px 12px 42px; border-radius: 10px; font-size: 13.5px; outline: none; font-family: inherit; transition: border-color 0.2s;" onfocus="this.style.borderColor='#c084fc';">
                </div>
                <button type="submit" style="background: linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color: #000; font-weight: bold; border: none; padding: 12px 24px; border-radius: 10px; font-size: 13.5px; cursor: pointer; text-transform: uppercase; font-family: monospace;">সার্চ</button>
            </form>
        </div>

        <!-- 3. CATEGORY & FILTER QUICK PANEL -->
        <div class="category-pill-row">
            <a href="<?php echo esc_url(home_url('/books/')); ?>" class="tax-filter-badge <?php echo !$current_term ? 'active' : ''; ?>">All Books</a>
            <?php 
            $categories = get_terms([
                'taxonomy'   => 'book_category',
                'hide_empty' => false
            ]);
            if (!is_wp_error($categories) && !empty($categories)) {
                foreach ($categories as $cat) {
                    $active_class = ($current_term && $current_term->taxonomy === 'book_category' && $current_term->term_id === $cat->term_id) ? 'active' : '';
                    echo '<a href="' . esc_url(get_term_link($cat)) . '" class="tax-filter-badge ' . $active_class . '">' . esc_html($cat->name) . '</a>';
                }
            }
            ?>
        </div>

        <!-- 4. ACTIVE FILTER BANNER (If filtered) -->
        <?php if ($current_term) : ?>
            <div style="background: rgba(192, 132, 252, 0.05); border-left: 4px solid #c084fc; border-radius: 6px; padding: 15px 20px; margin-bottom: 25px; display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <span style="font-family: monospace; font-size: 11px; color: #c084fc; text-transform: uppercase; font-weight: bold;">[Active Filter Option]</span>
                    <h2 style="color: #fff; margin: 4px 0 0 0; font-size: 18px; font-weight: bold;">ব্রাউজ করছেন: <strong style="color: #00f0ff;"><?php echo esc_html($current_term->name); ?></strong></h2>
                </div>
                <a href="<?php echo esc_url(home_url('/books/')); ?>" style="color: #ff3e3e; font-size: 11.5px; font-family: monospace; text-transform: uppercase; text-decoration: none; font-weight: bold;"><i class="fa-solid fa-xmark"></i> Clear Filters</a>
            </div>
        <?php endif; ?>

        <?php if (!empty($search_query)) : ?>
            <div style="background: rgba(0, 240, 255, 0.05); border-left: 4px solid #00f0ff; border-radius: 6px; padding: 15px 20px; margin-bottom: 25px; display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <span style="font-family: monospace; font-size: 11px; color: #00f0ff; text-transform: uppercase; font-weight: bold;">[Search Transmission Results]</span>
                    <h2 style="color: #fff; margin: 4px 0 0 0; font-size: 18px; font-weight: bold;">ফলাফল: <strong style="color: #c084fc;">"<?php echo esc_html($search_query); ?>"</strong></h2>
                </div>
                <a href="<?php echo esc_url(home_url('/books/')); ?>" style="color: #ff3e3e; font-size: 11.5px; font-family: monospace; text-transform: uppercase; text-decoration: none; font-weight: bold;"><i class="fa-solid fa-xmark"></i> Clear Search</a>
            </div>
        <?php endif; ?>

        <!-- 5. MAIN CARD GRID -->
        <?php if ($books_query->have_posts()) : ?>
            <div class="book-bento-grid">
                <?php while ($books_query->have_posts()) : $books_query->the_post(); 
                    $post_id = get_the_ID();
                    $author_terms = wp_get_post_terms($post_id, 'book_author');
                    $author_name = !empty($author_terms) && !is_wp_error($author_terms) ? $author_terms[0]->name : 'Unknown Author';
                    $cat_terms = wp_get_post_terms($post_id, 'book_category');
                    $cat_name = !empty($cat_terms) && !is_wp_error($cat_terms) ? $cat_terms[0]->name : 'Self Development';
                    $rating = get_post_meta($post_id, '_book_rating', true);
                    if (empty($rating)) $rating = '4.8';
                    $reading_time = get_post_meta($post_id, '_book_reading_time', true);
                    if (empty($reading_time)) $reading_time = '8 mins';
                    $isbn = get_post_meta($post_id, '_book_isbn', true);
                    $pub_year = get_post_meta($post_id, '_book_pub_year', true);

                    $grad_index = get_post_meta($post_id, '_book_gradient_color', true);
                    $gradients = [
                        'linear-gradient(135deg, #0f172a 0%, #1e1b4b 50%, #311042 100%)', // Twilight Indigo
                        'linear-gradient(135deg, #070b13 0%, #0d1527 50%, #064e3b 100%)', // Emerald Dark
                        'linear-gradient(135deg, #08071a 0%, #111827 50%, #1e293b 100%)', // Cosmic Slate
                        'linear-gradient(135deg, #180828 0%, #1e1b4b 50%, #1e293b 100%)', // Cyber Violet
                        'linear-gradient(135deg, #070b13 0%, #111c30 50%, #581c87 100%)'  // Deep Magic Purple
                    ];
                    $active_gradient = isset($gradients[$grad_index]) ? $gradients[$grad_index] : $gradients[0];
                ?>
                    <!-- Book Card -->
                    <div class="book-archive-card">
                        
                        <!-- Top Metadata -->
                        <div style="display: flex; gap: 15px; align-items: flex-start;">
                            <!-- Cover -->
                            <div class="book-list-cover" style="background: <?php echo $active_gradient; ?>;">
                                <div style="font-size: 8px; font-family: monospace; color: #00f0ff; text-transform: uppercase; font-weight: bold; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;"><?php echo esc_html($cat_name); ?></div>
                                <div style="font-size: 11px; font-weight: 800; color: #fff; line-height: 1.1; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; word-break: break-all; text-shadow: 1px 1px 2px rgba(0,0,0,0.8);"><?php the_title(); ?></div>
                                <div style="font-size: 7px; color: rgba(255,255,255,0.7); overflow: hidden; text-overflow: ellipsis; white-space: nowrap;"><?php echo esc_html($author_name); ?></div>
                                <div class="spine-effect"></div>
                            </div>

                            <!-- Details -->
                            <div style="flex-grow: 1; min-width: 0;">
                                <span style="display: inline-block; font-size: 9px; background: rgba(192, 132, 252, 0.08); border: 1px solid rgba(192, 132, 252, 0.2); color: #c084fc; padding: 2px 8px; border-radius: 4px; font-family: monospace; margin-bottom: 6px; font-weight: bold; text-transform: uppercase;"><?php echo esc_html($cat_name); ?></span>
                                
                                <h3 style="font-size: 16px; font-weight: bold; margin: 0 0 6px 0; line-height: 1.3;"><a href="<?php the_permalink(); ?>" style="color: #fff; text-decoration: none; transition: color 0.15s;" onmouseover="this.style.color='#00f0ff';" onmouseout="this.style.color='#fff';"><?php the_title(); ?></a></h3>
                                
                                <div style="font-size: 12.5px; color: #cbd5e0; margin-bottom: 4px;">লেখক: <span style="color: #a0aec0; font-weight: 500;"><?php echo esc_html($author_name); ?></span></div>
                                
                                <div style="display: flex; gap: 8px; align-items: center; margin-top: 4px;">
                                    <div style="display: flex; align-items: center; gap: 3px; font-size: 11px; color: #fbbf24;">
                                        <i class="fa-solid fa-star"></i> <span style="font-weight: bold;"><?php echo esc_html($rating); ?></span>
                                    </div>
                                    <span style="color: rgba(255,255,255,0.15); font-size: 11px;">|</span>
                                    <span style="font-family: monospace; font-size: 10.5px; color: #8b949e;"><?php echo esc_html($pub_year); ?></span>
                                </div>
                            </div>
                        </div>

                        <!-- Mid Summary block -->
                        <div>
                            <p style="font-size: 12.5px; line-height: 1.5; color: #cbd5e0; margin: 0 0 12px 0; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden;"><?php echo esc_html(wp_strip_all_tags(get_the_excerpt())); ?></p>
                            
                            <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px solid rgba(255,255,255,0.06); padding-top: 10px; font-size: 11px;">
                                <span style="font-family: monospace; color: #8b949e;">
                                    ISBN: <span style="color:#00f0ff;"><?php echo esc_html($isbn); ?></span>
                                </span>
                                <span style="font-family: monospace; color: #8b949e; display: flex; align-items: center; gap: 4px;">
                                    <i class="fa-regular fa-clock" style="color: #00ff41;"></i> <?php echo esc_html($reading_time); ?>
                                </span>
                            </div>
                        </div>

                        <!-- Card Action -->
                        <div>
                            <a href="<?php the_permalink(); ?>" style="display: block; text-align: center; background: rgba(0, 240, 255, 0.08); border: 1.5px solid rgba(0, 240, 255, 0.2); color: #00f0ff; padding: 10px; border-radius: 8px; font-size: 12px; font-weight: bold; text-decoration: none; text-transform: uppercase; letter-spacing: 0.5px; transition: all 0.2s;" onmouseover="this.style.background='linear-gradient(135deg, #00f0ff 0%, #0072ff 100%)'; this.style.color='#000'; this.style.borderColor='transparent';" onmouseout="this.style.background='rgba(0, 240, 255, 0.08)'; this.style.color='#00f0ff'; this.style.borderColor='rgba(0, 240, 255, 0.2)';">
                                সম্পূর্ণ এআই অনুবাদ ও সামারি পড়ুন
                            </a>
                        </div>

                    </div>
                <?php endwhile; ?>
            </div>

            <!-- Pagination Module -->
            <div class="nextgen-pagination" style="margin-top: 40px; text-align: center; display: flex; justify-content: center; gap: 8px; font-family: monospace;">
                <?php 
                echo paginate_links([
                    'total'     => $books_query->max_num_pages,
                    'current'   => $paged,
                    'format'    => '?paged=%#%',
                    'prev_text' => '<i class="fa-solid fa-angle-left"></i> Prev',
                    'next_text' => 'Next <i class="fa-solid fa-angle-right"></i>',
                    'type'      => 'plain'
                ]);
                ?>
            </div>
            <?php wp_reset_postdata(); ?>

        <?php else : ?>
            <!-- Fallback No Books Screen -->
            <div style="background: rgba(13, 21, 39, 0.6); border: 1.5px dashed rgba(0, 240, 255, 0.2); border-radius: 16px; padding: 60px 20px; text-align: center;">
                <div style="font-size: 48px; margin-bottom: 20px; color: #8b949e;">📚</div>
                <h2 style="color: #fff; font-size: 20px; font-weight: bold; margin-bottom: 10px;">কোনো বই খুঁজে পাওয়া যায়নি</h2>
                <p style="color: #8b949e; font-size: 14px; max-width: 500px; margin: 0 auto 25px;">
                    আপনার প্রদত্ত অনুসন্ধান বা পছন্দের ক্যাটাগরিতে এই মুহূর্তে কোনো বই পাওয়া যায়নি। অনুগ্রহ করে অন্য কোনো কি-ওয়ার্ড দিয়ে পুনরায় সার্চ করুন।
                </p>
                <a href="<?php echo esc_url(home_url('/books/')); ?>" style="display: inline-block; background: linear-gradient(135deg, #00f0ff 0%, #0072ff 100%); color: #000; font-weight: bold; border: none; padding: 12px 28px; border-radius: 8px; font-size: 13px; text-decoration: none; text-transform: uppercase; font-family: monospace;">লাইব্রেরি হোমপেজে ফিরে যান</a>
            </div>
        <?php endif; ?>

        <!-- 6. HIGH-CONVERTING BOTTOM ADSENSE COMPLIANT PLACEHOLDER -->
        <div style="margin-top: 40px; background: rgba(255,255,255,0.02); border: 1px dashed rgba(255,255,255,0.06); border-radius: 12px; padding: 25px; text-align: center;">
            <div style="font-size: 10px; font-family: monospace; color: #475569; text-transform: uppercase; margin-bottom: 10px; letter-spacing: 1px;">Sponsor Advertisement</div>
            <div style="max-width: 728px; height: 90px; margin: 0 auto; background: rgba(7, 11, 19, 0.8); border: 1px solid rgba(0,240,255,0.1); border-radius: 8px; display: flex; align-items: center; justify-content: center; color: #64748b; font-size: 12px; font-family: monospace;">
                [ Google AdSense Responsive Display Banner Unit ]
            </div>
        </div>

    </div>
</div>

<?php 
get_footer(); 
?>
