<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>

<?php 
$design_preset = get_option('ilybd_design_preset', 'cyber_neon');
?>
<style>
<?php if ($design_preset === 'google_material'): ?>
/* =========================================================
   GOOGLE MATERIAL DESIGN (AUTO LIGHT/DARK)
========================================================= */
:root {
    --neon: #1a73e8; /* Google Blue */
    --dark: #ffffff; /* White background for header */
    --border: #dadce0; 
    --red: #ea4335;
    color-scheme: light dark;
}
body {
    background: #f8f9fa !important;
    color: #202124 !important;
}
header#ilybd-main-header {
    background: #ffffff !important;
    border-bottom: 1px solid var(--border) !important;
}
.header-top { background: #f8f9fa !important; }
.user-hi, .user-hi b { 
    color: #5f6368 !important; 
    text-shadow: none !important; 
    -webkit-text-fill-color: #5f6368 !important; 
    background: none !important;
}
.logo-text { 
    background: none !important; 
    -webkit-text-fill-color: #202124 !important; 
    filter: none !important; 
    color: #202124 !important; 
    animation: none !important; 
}
.rgb-line, .rgb-bottom { display: none !important; }

/* AdSense/Google style overrides */
a { color: #1a73e8 !important; }

/* Broad Card Background Overrides for Light Mode */
.ilybd-post-card, .ilybd-sidebar-widget, .ilybd-single-content, 
.pro-post-card, .slider-card-mode, .hub-card, .popular-horizon-card,
.cyber-sidebar-card, .tbd-vibrant-card, .ilybd-author-v3-card,
.cyber-post-item, .community-card, .qa-card, .news-card, .book-card, .sms-card,
.ilybd-feed-card, .cat-neon-card, .widget, .card, .qa-item, .qa-meta-card, .qa-question, .qa-stats,
.qa-card-body, .status-header, .news-portal-container, .sms-item, .qa-section, .qa-card-header,
.cat-badge, .post-info, .meta-footer, .cyber-page-wrapper, .news-home-card, .cyber-book-bento-card,
.qna-item-box, .qa-content-box, .sms-collection-card, .sms-bento-grid {
    background: #ffffff !important;
    border: 1px solid #dadce0 !important;
    box-shadow: 0 1px 2px 0 rgba(60,64,67,0.3), 0 1px 3px 1px rgba(60,64,67,0.15) !important;
    color: #202124 !important;
}
.cat-badge { border:none !important; }
.meta-footer, .post-info, .sms-bento-grid { box-shadow: none !important; border:none !important; }
.sms-bento-grid { background: transparent !important; }

/* Headings and Text inside Cards */
h1, h2, h3, h4, h5, h6, 
.pro-post-card h3 a, .ilybd-single-content h1, .ilybd-single-content h2, .ilybd-single-content h3,
.post-title, .post-title a, .card-title, .qa-title, .hub-card h3, .news-title, .news-card h3, .book-title,
.qa-card-header h3, .qna-q-title, .news-home-card a, .news-home-card h3 a, .cyber-book-bento-card a,
.sms-card-title, .sms-card-title a {
    color: #202124 !important;
}

p, span, div, .post-excerpt, .ilybd-post-card p, .ilybd-single-content p, .card-desc, .qa-desc, .news-desc, .book-desc, .news-home-card div, .cyber-book-bento-card div, .sms-card-preview, .sms-text-preview, .sms-collection-card div {
    color: #5f6368 !important;
}

.ilybd-post-meta, .ilybd-post-meta span, .meta-link, .meta-link i, .meta-link span, .qna-stat-item span, .qna-stat-item i {
    color: #70757a !important;
}

/* Force override ALL elements that have dark backgrounds explicitly set */
[style*="background:#0d1117"], [style*="background: #0d1117"],
[style*="background:#0b0f15"], [style*="background: #0b0f15"],
[style*="background:#161b22"], [style*="background: #161b22"],
[style*="background:#121822"], [style*="background: #121822"],
[style*="background:#0d1527"], [style*="background: #0d1527"],
[style*="background:#0c0f16"], [style*="background: #0c0f16"],
[style*="background:#0b0f14"], [style*="background: #0b0f14"] {
    background: #ffffff !important;
    border-color: #dadce0 !important;
    color: #202124 !important;
}

/* Override dark transparent backgrounds */
[style*="background: rgba(13, 21, 39, 0.45)"],
[style*="background: rgba(13, 21, 39, 0.65)"],
[style*="background: rgba(13, 17, 23, 0.7)"],
[style*="background: rgba(13, 17, 23, 0.5)"] {
    background: #ffffff !important;
    border-color: #dadce0 !important;
}

/* Gradient overrides */
[style*="background: linear-gradient(135deg, rgba(110, 0, 255, 0.95)"],
[style*="background: linear-gradient(135deg, #0f172a 0%"],
[style*="background: linear-gradient(135deg, #070b13 0%"],
[style*="background: linear-gradient(135deg, #08071a 0%"],
[style*="background: linear-gradient(135deg, #180828 0%"] {
    background: #ffffff !important;
    border-color: #dadce0 !important;
}

/* Force override ALL text elements that have light colors explicitly set */
[style*="color:#c9d1d9"], [style*="color: #c9d1d9"],
[style*="color:#8b949e"], [style*="color: #8b949e"],
[style*="color:#e2e8f0"], [style*="color: #e2e8f0"],
[style*="color:#ffffff"], [style*="color: #ffffff"],
[style*="color:#fff"], [style*="color: #fff"],
[style*="color:#cbd5e0"], [style*="color: #cbd5e0"],
[style*="color:#a0aec0"], [style*="color: #a0aec0"],
[style*="color:#000000"], [style*="color: #000"] {
    color: #5f6368 !important;
}
/* specifically allow black text for titles if they were black but let's just make it dark */

/* Override inline colors where PHP might spit out neon colors */
[style*="color:#00ff41"], [style*="color: #00ff41"], 
[style*="color:#00f0ff"], [style*="color: #00f0ff"] { color: #1a73e8 !important; }

[style*="background:#00ff41"], [style*="background: #00ff41"],
[style*="background:#00f0ff"], [style*="background: #00f0ff"] { background: #1a73e8 !important; color: #fff !important; }

[style*="border-color:#00ff41"], [style*="border-color: #00ff41"],
[style*="border-color:#00f0ff"], [style*="border-color: #00f0ff"] { border-color: #1a73e8 !important; }

[style*="border:1px solid #00ff41"], [style*="border: 1px solid #00ff41"] { border-color: #1a73e8 !important; }

/* Dark Mode Native Adaption */
@media (prefers-color-scheme: dark) {
    :root {
        --neon: #8ab4f8; 
        --dark: #202124; 
        --border: #3c4043; 
        --red: #f28b82;
    }
    body { background: #202124 !important; color: #e8eaed !important; }
    header#ilybd-main-header { background: #202124 !important; border-bottom: 1px solid var(--border) !important; }
    .header-top { background: #303134 !important; }
    .user-hi, .user-hi b { color: #9aa0a6 !important; -webkit-text-fill-color: #9aa0a6 !important; }
    .logo-text { -webkit-text-fill-color: #e8eaed !important; color: #e8eaed !important; }
    
    a { color: #8ab4f8 !important; }
    .ilybd-post-card, .ilybd-sidebar-widget, .ilybd-single-content,
    .pro-post-card, .slider-card-mode, .hub-card, .popular-horizon-card,
    .cyber-sidebar-card, .tbd-vibrant-card, .ilybd-author-v3-card,
    .cyber-post-item, .community-card, .qa-card, .news-card, .book-card, .sms-card,
    .ilybd-feed-card, .cat-neon-card, .widget, .card, .qa-item, .qa-meta-card, .qa-question, .qa-stats,
    .qa-card-body, .status-header, .news-portal-container, .sms-item, .qa-section, .qa-card-header,
    .cat-badge, .post-info, .meta-footer, .cyber-page-wrapper, .news-home-card, .cyber-book-bento-card,
    .qna-item-box, .qa-content-box, .sms-collection-card, .sms-bento-grid {
        background: #303134 !important;
        border: 1px solid #3c4043 !important;
        color: #e8eaed !important;
        box-shadow: none !important;
    }
    .sms-bento-grid { background: transparent !important; border:none !important; }
    
    h1, h2, h3, h4, h5, h6, 
    .pro-post-card h3 a, .ilybd-single-content h1, .ilybd-single-content h2, .ilybd-single-content h3,
    .post-title, .post-title a, .card-title, .qa-title, .hub-card h3, .news-title, .news-card h3, .book-title,
    .qa-card-header h3, .qna-q-title, .news-home-card a, .news-home-card h3 a, .cyber-book-bento-card a,
    .sms-card-title, .sms-card-title a {
        color: #e8eaed !important;
    }
    p, span, div, .post-excerpt, .ilybd-post-card p, .ilybd-single-content p, .card-desc, .qa-desc, .news-desc, .book-desc, .news-home-card div, .cyber-book-bento-card div, .sms-card-preview, .sms-text-preview, .sms-collection-card div {
        color: #9aa0a6 !important;
    }
    .ilybd-post-meta, .ilybd-post-meta span, .meta-link, .meta-link i, .meta-link span, .qna-stat-item span, .qna-stat-item i {
        color: #9aa0a6 !important;
    }
    
    [style*="background:#0d1117"], [style*="background: #0d1117"],
    [style*="background:#0b0f15"], [style*="background: #0b0f15"],
    [style*="background:#161b22"], [style*="background: #161b22"],
    [style*="background:#121822"], [style*="background: #121822"],
    [style*="background:#0d1527"], [style*="background: #0d1527"],
    [style*="background:#0c0f16"], [style*="background: #0c0f16"],
    [style*="background:#0b0f14"], [style*="background: #0b0f14"] {
        background: #303134 !important;
        border-color: #3c4043 !important;
        color: #e8eaed !important;
    }

    [style*="background: rgba(13, 21, 39, 0.45)"],
    [style*="background: rgba(13, 21, 39, 0.65)"],
    [style*="background: rgba(13, 17, 23, 0.7)"],
    [style*="background: rgba(13, 17, 23, 0.5)"] {
        background: #303134 !important;
        border-color: #3c4043 !important;
    }
    
    [style*="background: linear-gradient(135deg, rgba(110, 0, 255, 0.95)"],
    [style*="background: linear-gradient(135deg, #0f172a 0%"],
    [style*="background: linear-gradient(135deg, #070b13 0%"],
    [style*="background: linear-gradient(135deg, #08071a 0%"],
    [style*="background: linear-gradient(135deg, #180828 0%"] {
        background: #303134 !important;
        border-color: #3c4043 !important;
    }

    [style*="color:#c9d1d9"], [style*="color: #c9d1d9"],
    [style*="color:#8b949e"], [style*="color: #8b949e"],
    [style*="color:#e2e8f0"], [style*="color: #e2e8f0"],
    [style*="color:#ffffff"], [style*="color: #ffffff"],
    [style*="color:#fff"], [style*="color: #fff"],
    [style*="color:#cbd5e0"], [style*="color: #cbd5e0"],
    [style*="color:#a0aec0"], [style*="color: #a0aec0"],
    [style*="color:#000000"], [style*="color: #000"] {
        color: #9aa0a6 !important;
    }
    
    [style*="color:#00ff41"], [style*="color: #00ff41"], 
    [style*="color:#00f0ff"], [style*="color: #00f0ff"] { color: #8ab4f8 !important; }
    [style*="background:#00ff41"], [style*="background: #00ff41"],
    [style*="background:#00f0ff"], [style*="background: #00f0ff"] { background: #8ab4f8 !important; color: #202124 !important; }
    [style*="border-color:#00ff41"], [style*="border-color: #00ff41"],
    [style*="border-color:#00f0ff"], [style*="border-color: #00f0ff"] { border-color: #8ab4f8 !important; }
    [style*="border:1px solid #00ff41"], [style*="border: 1px solid #00ff41"] { border-color: #8ab4f8 !important; }
}
<?php else: ?>
/* =========================================================
   CYBER NEON DESIGN (DARK DEFAULT)
========================================================= */
:root{
    --neon:#00ff41;
    --dark:#121822; /* Brighter dark */
    --border:rgba(255,255,255,0.12); /* Brighter border */
    --red:#ff4d4d; /* Brighter red */
}
/* PAGE OFFSET & BRIGHTNESS */
body{
    background:#0b0f15;
    color: #e2e8f0; /* Brighter default text */
}
<?php endif; ?>
/* HIDE WP ADMIN BAR ON FRONTEND & FORCE ZERO TOP GAP */
#wpadminbar { display: none !important; }
html { margin-top: 0px !important; padding-top: 0px !important; }
body, body.admin-bar { margin-top: 0px !important; }

/* MAIN WEBSITE HEADER FIXED AT TOP */
header#ilybd-main-header {
    position: fixed !important;
    top: 0 !important;
    left: 0 !important;
    width: 100% !important;
    z-index: 10000000 !important;
    background: var(--dark) !important;
}

/* GLOBAL CLEAN PAGE HEADER & TITLE OVERLAY FIX */
.cyber-page-wrapper {
    position: relative;
    z-index: 1;
}
.ultra-sticky-header,
.cyber-section-header {
    position: relative !important;
    top: auto !important;
    left: auto !important;
    z-index: 5 !important;
    background: transparent !important;
    padding: 15px 0 10px 0 !important;
    margin-bottom: 20px !important;
    text-align: center !important;
}
.rgb-text-lighting {
    font-size: 2.2rem !important;
    font-weight: 800 !important;
    text-transform: uppercase !important;
    letter-spacing: 1.5px !important;
    margin: 0 0 10px 0 !important;
    color: #00f0ff !important;
    background: none !important;
    -webkit-background-clip: unset !important;
    -webkit-text-fill-color: #00f0ff !important;
    animation: none !important;
    text-shadow: 0 0 12px rgba(0, 240, 255, 0.4) !important;
}
.sticky-rgb-line {
    height: 2px !important;
    width: 100% !important;
    background: linear-gradient(90deg, transparent, #00f0ff, transparent) !important;
    animation: none !important;
    box-shadow: none !important;
}



/* PAGE OFFSET & BRIGHTNESS */


/* HEADER FIXED */


/* ================= RGB LINES ================= */
.rgb-line,
.rgb-bottom{
    height:1px;
    width:100%;
    background:linear-gradient(90deg,transparent,#ff004c,#00ff41,#00e5ff,#ff004c,transparent);
    background-size:200%;
    animation:rgbMove 3s linear infinite;
    opacity:.9;
}

@keyframes rgbMove{
    0%{background-position:0%;}
    100%{background-position:200%;}
}

/* HEADER TOP */
.header-top{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:5px 14px;
    background:#11161d;
}

/* USER TEXT */
.user-hi{
    font-size:16px;
    color:#c9d1d9;
}
.user-hi b{
    font-size:18px;
    color:var(--neon) !important;
    background: transparent !important;
    background-image: none !important;
    -webkit-text-fill-color: var(--neon) !important;
    text-shadow:0 0 10px rgba(0,255,65,0.5);
    transition: all 0.3s ease;
}
.user-profile-link {
    text-decoration: none !important;
    color: inherit !important;
    display: inline-block;
}
.user-profile-link:hover b {
    text-shadow: 0 0 18px var(--neon), 0 0 8px #00f0ff !important;
    filter: brightness(1.2);
}

/* LOGO BIG + CYBER STYLE UPGRADED */
.logo-text{
    font-size: 28px !important;
    font-weight: 900 !important;
    font-style: italic !important;
    text-align: center;
    flex: 1;
    letter-spacing: 2.5px !important;
    text-transform: uppercase !important;
    font-family: 'Space Grotesk', 'Orbitron', 'Rajdhani', sans-serif !important;
    background: linear-gradient(90deg, #00ff41, #00e5ff, #ff004c, #00ff41) !important;
    background-size: 300% !important;
    -webkit-background-clip: text !important;
    -webkit-text-fill-color: transparent !important;
    animation: logoAnim 4s linear infinite !important;
    filter: drop-shadow(0 0 8px rgba(0, 255, 65, 0.45)) !important;
    transition: 0.3s ease;
}
.logo-text:hover {
    filter: drop-shadow(0 0 15px rgba(0, 229, 255, 0.85)) !important;
}

@keyframes logoAnim{
    0%{background-position:0%;}
    100%{background-position:300%;}
}

/* ================= CYBER DROPDOWN SYSTEM ================= */
.tool-icon-wrapper {
    position: relative;
    display: inline-block;
}

/* ⚡ HIGH-TECH COGNITIVE PROFESSIONAL HEADER TTS SPEAKER BUTTON ⚡ */
.header-tts-btn {
    background: rgba(0, 240, 255, 0.08) !important;
    border: 1.2px solid #00f0ff !important;
    color: #00f0ff !important;
    width: 38px !important;
    height: 38px !important;
    border-radius: 50% !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    cursor: pointer !important;
    transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1) !important;
    position: relative !important;
    font-size: 13px !important;
    padding: 0 !important;
    margin: 0 !important;
    text-shadow: 0 0 8px rgba(0, 240, 255, 0.5) !important;
    box-shadow: 0 0 8px rgba(0, 240, 255, 0.15) !important;
    z-index: 999999 !important;
}
.header-tts-btn:hover {
    background: #00f0ff !important;
    color: #000 !important;
    box-shadow: 0 0 15px #00f0ff, 0 0 8px #00ff41 !important;
    transform: scale(1.08) !important;
}
.header-tts-btn.playing {
    background: #ff3b30 !important;
    border-color: #ff3b30 !important;
    color: #fff !important;
    box-shadow: 0 0 15px rgba(255, 59, 48, 0.6) !important;
    animation: headerTtsPulse 1.2s infinite ease-in-out !important;
}
@keyframes headerTtsPulse {
    0% { transform: scale(1); }
    50% { transform: scale(1.08); box-shadow: 0 0 15px rgba(255, 59, 48, 0.7); }
    100% { transform: scale(1); }
}

.tool-icon-btn {
    background: none;
    border: none;
    width: 48px;
    height: 48px;
    padding: 10px;
    margin: 0;
    cursor: pointer;
    color: var(--neon);
    font-size: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: 0.3s;
    text-shadow: 0 0 10px rgba(0,255,65,0.4);
}
.tool-icon-btn:hover {
    color: #00e5ff;
    text-shadow: 0 0 15px rgba(0,229,255,0.8);
    transform: rotate(45deg);
}
.cyber-dropdown-menu {
    display: none;
    position: absolute;
    top: 100%;
    right: 0;
    margin-top: 12px;
    background: #090d13 !important;
    border: 1.5px solid var(--neon) !important;
    box-shadow: 0 10px 30px rgba(0,0,0,0.95), 0 0 15px rgba(0,255,65,0.3) !important;
    border-radius: 12px !important;
    z-index: 9999999 !important;
    width: 200px !important;
    padding: 8px !important;
    overflow: hidden;
    animation: fadeInDropdown 0.25s cubic-bezier(0.16, 1, 0.3, 1) forwards;
}
.cyber-dropdown-menu .dropdown-item {
    display: flex !important;
    align-items: center !important;
    padding: 10px 14px !important;
    font-size: 13.5px !important;
    font-weight: 700 !important;
    color: #c9d1d9 !important;
    text-decoration: none !important;
    border-radius: 8px !important;
    transition: all 0.2s ease !important;
    border-bottom: none !important;
}
.cyber-dropdown-menu .dropdown-item:hover {
    background: rgba(0, 255, 65, 0.12) !important;
    color: #ffffff !important;
    text-shadow: 0 0 5px rgba(0, 255, 65, 0.6) !important;
    padding-left: 18px !important;
}
.cyber-dropdown-menu .dropdown-item.logout:hover {
    background: rgba(255, 45, 45, 0.12) !important;
    color: #ffffff !important;
    text-shadow: 0 0 5px rgba(255, 45, 45, 0.6) !important;
}
@keyframes fadeInDropdown {
    from { opacity: 0; transform: translateY(-10px) scale(0.95); }
    to { opacity: 1; transform: translateY(0) scale(1); }
}

/* TOOL ICON */
.tool-icon a{
    color:var(--neon);
    font-size:22px;
    text-decoration:none;
}

/* NAV GRID */
.nav-grid{
    display:grid;
    grid-template-columns:repeat(5,1fr);
    background: linear-gradient(180deg, #070b13 0%, #0d1527 100%);
    border-top: 1px solid rgba(0, 240, 255, 0.15);
    border-bottom: 1.5px solid rgba(0, 255, 65, 0.15);
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.6), inset 0 1px 0 rgba(255, 255, 255, 0.05);
    padding: 2px 10px;
    align-items: center;
    position: relative;
    z-index: 999;
}

/* NAV ITEM */
.nav-link{
    position:relative;
    display:flex;
    flex-direction:row;
    align-items:center;
    justify-content:center;
    gap:8px;
    padding:12px 10px;
    font-size:13px;
    font-weight:600;
    color:#cbd5e0;
    text-decoration:none;
    transition:all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    font-family: 'Space Grotesk', sans-serif;
    border-radius:8px;
    margin:4px;
}

/* ICON */
.nav-link i, .nav-link svg{
    font-size:16px;
    color:#00f0ff;
    transition:all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    filter:drop-shadow(0 0 4px rgba(0, 240, 255, 0.4));
}

/* HOVER EFFECT */
.nav-link:hover{
    color:#fff;
    background:rgba(0, 240, 255, 0.06);
    box-shadow:0 0 10px rgba(0, 240, 255, 0.1);
}
.nav-link:hover i, .nav-link:hover svg{
    color:#00ff41;
    transform:translateY(-1px);
    filter:drop-shadow(0 0 8px #00ff41);
}

/* ================= FIXED BADGE ================= */
.badge{
    display: inline-flex;
    align-items: center;
    justify-content: center;
    background: #ff004c;
    color: #fff;
    font-size: 9px;
    font-weight: 900;
    min-width: 15px;
    height: 15px;
    border-radius: 50%;
    box-shadow: 0 0 8px #ff004c;
    position: absolute;
    top: 6px;
    right: 6px;
    padding: 2px;
}

/* WALLET STYLE */
.wallet{
    padding:6px 14px;
    background:linear-gradient(135deg, rgba(0, 255, 65, 0.12) 0%, rgba(0, 240, 255, 0.12) 100%);
    border:1.5px solid #00ff41;
    border-radius:20px;
    color:#00ff41;
    font-weight:800;
    font-size:11.5px;
    font-family:'JetBrains Mono', monospace;
    display:flex;
    align-items:center;
    gap:6px;
    box-shadow:0 0 10px rgba(0, 255, 65, 0.15);
    transition:all 0.3s ease;
}

.nav-link:hover .wallet{
    border-color:#00f0ff;
    color:#00f0ff;
    box-shadow:0 0 15px rgba(0, 240, 255, 0.25);
}

@keyframes pulse{
    0%{box-shadow:0 0 5px var(--neon);}
    50%{box-shadow:0 0 18px var(--neon);}
    100%{box-shadow:0 0 5px var(--neon);}
}

/* ================= RGB SEPARATOR (MAIN FIX) ================= */
.rgb-separator{
    height:2px;
    width:100%;
    background:linear-gradient(90deg,transparent,#ff004c,#00ff41,#00e5ff,#ff004c,transparent);
    background-size:200%;
    animation:rgbMove 2.5s linear infinite;
    box-shadow:0 0 10px rgba(0,255,65,0.3);
}

/* LOGIN */
.login-box{
    text-align:center;
    padding:10px;
}
.login-box a{
    color:var(--neon);
    margin:0 6px;
    font-size:13px;
    text-decoration:none;
}

/* MOBILE */
@media(max-width:768px){
    .logo-text{font-size:20px !important;}
    .custom-svg-logo-wrapper svg { max-height: 32px !important; }
    
    /* Elegant bento-row for mobile instead of hiding */
    .nav-grid {
        display: grid !important; 
        grid-template-columns: repeat(5, 1fr) !important;
        gap: clamp(2px, 1vw, 4px) !important;
        padding: 4px clamp(2px, 1vw, 6px) !important;
        background: linear-gradient(180deg, #070b13 0%, #0d1527 100%) !important;
        border-bottom: 2px solid #00ff41 !important;
        border-top: 1px solid rgba(0, 255, 65, 0.1) !important;
        box-shadow: 0 4px 15px rgba(0,0,0,0.7) !important;
    }
    
    .nav-link {
        flex-direction: row !important;
        align-items: center !important;
        justify-content: center !important;
        gap: clamp(2px, 1vw, 5px) !important;
        padding: 6px clamp(1px, 0.8vw, 4px) !important;
        margin: 0 !important;
        font-size: clamp(8.5px, 2.5vw, 11px) !important;
        font-weight: 700 !important;
        color: #cbd5e0 !important;
        border-radius: 6px !important;
        text-align: center !important;
        white-space: nowrap !important;
        letter-spacing: -0.2px !important;
    }
    
    .nav-link i, .nav-link svg {
        font-size: clamp(10px, 3vw, 13px) !important;
        margin-right: 0 !important;
        width: auto !important;
        height: auto !important;
    }
    
    .badge {
        position: absolute !important;
        top: 2px !important;
        right: 2px !important;
        font-size: 8px !important;
        min-width: 12px !important;
        height: 12px !important;
        line-height: 12px !important;
        padding: 0 !important;
    }
    
    .wallet {
        padding: 3px clamp(4px, 1.2vw, 8px) !important;
        font-size: clamp(8.5px, 2.5vw, 11px) !important;
        border-radius: 12px !important;
        border-width: 1px !important;
        text-align: center !important;
        justify-content: center !important;
        width: auto !important;
        white-space: nowrap !important;
        display: inline-flex !important;
        animation: pulse 1.8s infinite !important;
    }
    
    .header-top { padding: 4px 10px !important; }
    .user-hi { font-size: 13px !important; }
    .user-hi b { font-size: 14px !important; }
}
@keyframes pulse-shield {
    0% { transform: scale(1); filter: drop-shadow(0 0 3px #00f0ff); }
    50% { transform: scale(1.08); filter: drop-shadow(0 0 10px #8b5cf6); }
    100% { transform: scale(1); filter: drop-shadow(0 0 3px #00f0ff); }
}
.cyber-shield-header-badge {
    animation: pulse-shield 2.2s infinite ease-in-out;
}

#header-global-tts-btn {
    width: 34px !important;
    height: 34px !important;
    font-size: 12px !important;
}

.header-auth-buttons {
    display: flex !important;
    align-items: center !important;
    gap: 8px !important;
}
.header-auth-btn {
    display: inline-flex !important;
    align-items: center !important;
    gap: 6px !important;
    padding: 5px 12px !important;
    border-radius: 20px !important;
    font-size: 12px !important;
    font-weight: 700 !important;
    text-decoration: none !important;
    transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1) !important;
    font-family: 'Space Grotesk', 'Inter', sans-serif !important;
}
.header-auth-btn.login-btn {
    background: rgba(0, 255, 65, 0.08) !important;
    border: 1px solid rgba(0, 255, 65, 0.4) !important;
    color: #00ff41 !important;
    box-shadow: 0 0 10px rgba(0, 255, 65, 0.1) !important;
}
.header-auth-btn.login-btn:hover {
    background: #00ff41 !important;
    color: #000000 !important;
    box-shadow: 0 0 15px #00ff41 !important;
    transform: translateY(-1px) !important;
}
.header-auth-btn.register-btn {
    background: rgba(0, 240, 255, 0.08) !important;
    border: 1px solid rgba(0, 240, 255, 0.4) !important;
    color: #00f0ff !important;
    box-shadow: 0 0 10px rgba(0, 240, 255, 0.1) !important;
}
.header-auth-btn.register-btn:hover {
    background: #00f0ff !important;
    color: #000000 !important;
    box-shadow: 0 0 15px #00f0ff !important;
    transform: translateY(-1px) !important;
}

@media (max-width: 576px) {
    .header-auth-buttons {
        gap: 5px !important;
    }
    .header-auth-btn {
        padding: 5px 8px !important;
        font-size: 11px !important;
    }
    .header-auth-btn span {
        display: none !important;
    }
}
</style>
</head>

<body <?php body_class(); ?>>

<header id="ilybd-main-header">

<div class="rgb-line"></div>

<div class="header-top">

    <div class="user-hi">
        <?php if(is_user_logged_in()):
            $u = wp_get_current_user();
            ?>
            Hi, <a href="<?php echo esc_url(home_url('/dashboard?action=profile')); ?>" class="user-profile-link" title="আপনার প্রোফাইল দেখুন (View Profile)"><b><?php echo esc_html($u->display_name); ?></b></a>
        <?php else: ?>
            <div class="header-auth-buttons">
                <a href="<?php echo esc_url(wp_login_url()); ?>" class="header-auth-btn login-btn" title="লগইন করুন">
                    <i class="fa-solid fa-right-to-bracket"></i>
                    <span>লগইন</span>
                </a>
                <a href="<?php echo esc_url(wp_registration_url()); ?>" class="header-auth-btn register-btn" title="রেজিস্ট্রেশন">
                    <i class="fa-solid fa-user-plus"></i>
                    <span>রেজিস্টার</span>
                </a>
            </div>
        <?php endif; ?>
    </div>

    <div class="logo-text">
        <a href="<?php echo home_url(); ?>" style="text-decoration:none;color:inherit;display:flex;align-items:center;gap:10px;justify-content:center;">
            <?php 
            $logo_type  = get_option('ilybd_logo_type', 'text');
            $logo_text  = get_option('ilybd_logo_text', 'ILOVEYOUBD');
            $logo_url   = get_option('ilybd_logo_img_url', '');
            $logo_width = intval(get_option('ilybd_logo_width', 180));
            $logo_glow_hover = get_option('ilybd_logo_glow_hover', 'yes');
            $enable_cyber_shield = get_option('ilybd_enable_cyber_shield', 'yes');
            
            // Set up hover animation attributes
            $logo_attr = '';
            if ($logo_glow_hover === 'yes') {
                $logo_attr = 'style="transition: transform 0.3s cubic-bezier(0.16, 1, 0.3, 1), filter 0.3s ease; filter: drop-shadow(0 0 10px rgba(0, 240, 255, 0.45));" onmouseover="this.style.transform=\'scale(1.03)\'; this.style.filter=\'drop-shadow(0 0 18px rgba(0, 240, 255, 0.8))\';" onmouseout="this.style.transform=\'scale(1)\'; this.style.filter=\'drop-shadow(0 0 10px rgba(0, 240, 255, 0.45))\';"';
            }

            if (($logo_type === 'cosmic' || $logo_type === 'glitch')) {
                $filename = ($logo_type === 'cosmic') ? 'logo-cosmic-cyber.svg' : 'logo-minimal-glitch.svg';
                $file_path = get_template_directory() . '/assets/images/' . $filename;
                if (file_exists($file_path)) {
                    $svg_content = file_get_contents($file_path);
                    if ($enable_cyber_shield === 'yes') {
                        echo '<img src="' . esc_url(get_template_directory_uri() . '/assets/images/icon-cyber-shield.svg') . '" alt="Certified" class="cyber-shield-header-badge" style="width: 20px; height: 20px; margin-right: 2px; flex-shrink: 0;" referrerPolicy="no-referrer">';
                    }
                    echo '<div class="custom-svg-logo-wrapper" ' . $logo_attr . ' style="display: flex; align-items: center; justify-content: center; max-height: 42px; width: auto; overflow: hidden; max-width: 100%;">';
                    echo $svg_content;
                    echo '</div>';
                } else {
                    $logo_type = 'text'; // Fallback
                }
            }

            if ($logo_type === 'image' && !empty($logo_url)): 
                if ($enable_cyber_shield === 'yes') {
                    echo '<img src="' . esc_url(get_template_directory_uri() . '/assets/images/icon-cyber-shield.svg') . '" alt="Certified" class="cyber-shield-header-badge" style="width: 20px; height: 20px; margin-right: 4px; flex-shrink: 0;" referrerPolicy="no-referrer">';
                }
                ?>
                <img src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr($logo_text); ?>" style="max-width: 100%; width: <?php echo $logo_width; ?>px; height: auto; display: block; filter: drop-shadow(0 0 10px rgba(0, 240, 255, 0.45)); transition: transform 0.3s ease;" class="custom-header-logo-img" onmouseover="this.style.transform='scale(1.03)';" onmouseout="this.style.transform='scale(1)';" referrerPolicy="no-referrer">
            <?php elseif ($logo_type === 'both' && !empty($logo_url)): 
                if ($enable_cyber_shield === 'yes') {
                    echo '<img src="' . esc_url(get_template_directory_uri() . '/assets/images/icon-cyber-shield.svg') . '" alt="Certified" class="cyber-shield-header-badge" style="width: 20px; height: 20px; margin-right: 4px; flex-shrink: 0;" referrerPolicy="no-referrer">';
                }
                ?>
                <img src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr($logo_text); ?>" style="max-width: 100%; width: <?php echo $logo_width; ?>px; height: auto; display: block; filter: drop-shadow(0 0 10px rgba(0, 240, 255, 0.45)); transition: transform 0.3s ease; max-height: 42px;" class="custom-header-logo-img" onmouseover="this.style.transform='scale(1.03)';" onmouseout="this.style.transform='scale(1)';" referrerPolicy="no-referrer">
                <span class="custom-header-logo-text" style="font-family: 'Space Grotesk', sans-serif; font-weight: 900; letter-spacing: 1px; background: linear-gradient(to right, #00f0ff, #00ff41); -webkit-background-clip: text; -webkit-text-fill-color: transparent; text-shadow: 0 0 12px rgba(0,255,65,0.25); font-size: 18px;"><?php echo esc_html($logo_text); ?></span>
            <?php elseif ($logo_type === 'text'): 
                if ($enable_cyber_shield === 'yes') {
                    echo '<img src="' . esc_url(get_template_directory_uri() . '/assets/images/icon-cyber-shield.svg') . '" alt="Certified" class="cyber-shield-header-badge" style="width: 20px; height: 20px; margin-right: 4px; flex-shrink: 0;" referrerPolicy="no-referrer">';
                }
                ?>
                <span class="custom-header-logo-text" <?php echo $logo_attr; ?> style="font-family: 'Space Grotesk', sans-serif; font-weight: 900; letter-spacing: 1.5px; background: linear-gradient(to right, #00f0ff, #00ff41); -webkit-background-clip: text; -webkit-text-fill-color: transparent; text-shadow: 0 0 15px rgba(0, 240, 255, 0.35); text-transform: uppercase;; font-size: 20px;"><?php echo esc_html($logo_text); ?></span>
            <?php endif; ?>
        </a>
    </div>

    <div style="display: flex; align-items: center; gap: 14px;">

        <div class="tool-icon-wrapper" style="position: relative; display: inline-block;">
            <button id="header-tools-toggle" class="tool-icon-btn" onclick="toggleHeaderTools(event)" title="Tools & Account" aria-label="Tools and Account" aria-expanded="false" aria-haspopup="true">
                <i class="dashicons dashicons-admin-tools"></i>
            </button>
        <div id="header-tools-dropdown" class="cyber-dropdown-menu">
            <?php if(is_user_logged_in()): 
                $logout_url = wp_logout_url(home_url()); ?>
                <div style="font-size: 10px; color: #8b949e; text-transform: uppercase; font-weight: 800; padding: 6px 12px; border-bottom: 1px solid rgba(255,255,255,0.06); margin-bottom: 4px; font-family: 'Space Grotesk', sans-serif;">Account</div>
                <a class="dropdown-item" href="<?php echo home_url('/how-to-earn-money'); ?>" style="color: #00ff41 !important; font-weight: bold;"><i class="fa-solid fa-coins" style="margin-right:8px; color: #00ff41; width: 16px;"></i> Earn & Rewards</a>
                <a class="dropdown-item" href="<?php echo home_url('/dashboard'); ?>"><i class="fa-solid fa-chart-line" style="margin-right:8px; color: var(--neon); width: 16px;"></i> ড্যাশবোর্ড</a>
                <a class="dropdown-item" href="<?php echo admin_url(); ?>"><i class="fa-brands fa-wordpress" style="margin-right:8px; color: var(--neon); width: 16px;"></i> এডমিন প্যানেল</a>
                <a class="dropdown-item" href="<?php echo home_url('/tools'); ?>"><i class="fa-solid fa-toolbox" style="margin-right:8px; color: var(--neon); width: 16px;"></i> টুলস</a>
                <a class="dropdown-item logout" href="<?php echo esc_url($logout_url); ?>" style="color: #ff2d2d !important;"><i class="fa-solid fa-right-from-bracket" style="margin-right:8px; color: #ff2d2d; width: 16px;"></i> লগ আউট</a>
            <?php else: ?>
                <div style="font-size: 10px; color: #8b949e; text-transform: uppercase; font-weight: 800; padding: 6px 12px; border-bottom: 1px solid rgba(255,255,255,0.06); margin-bottom: 4px; font-family: 'Space Grotesk', sans-serif;">Join Us</div>
                <a class="dropdown-item" href="<?php echo home_url('/how-to-earn-money'); ?>" style="color: #00ff41 !important; font-weight: bold;"><i class="fa-solid fa-coins" style="margin-right:8px; color: #00ff41; width: 16px;"></i> Earn & Rewards</a>
                <a class="dropdown-item" href="<?php echo wp_login_url(); ?>"><i class="fa-solid fa-right-to-bracket" style="margin-right:8px; color: var(--neon); width: 16px;"></i> লগইন করুন</a>
                <a class="dropdown-item" href="<?php echo wp_registration_url(); ?>"><i class="fa-solid fa-user-plus" style="margin-right:8px; color: var(--neon); width: 16px;"></i> রেজিস্ট্রেশন</a>
                <a class="dropdown-item" href="<?php echo home_url('/tools'); ?>"><i class="fa-solid fa-toolbox" style="margin-right:8px; color: var(--neon); width: 16px;"></i> টুলস</a>
            <?php endif; ?>
        </div>
    </div>
</div>

</div>

<script>
function toggleHeaderTools(event) {
    event.preventDefault();
    event.stopPropagation();
    var dd = document.getElementById('header-tools-dropdown');
    var btn = document.getElementById('header-tools-toggle');
    if (dd.style.display === 'none' || dd.style.display === '') {
        dd.style.display = 'block';
        if (btn) { btn.setAttribute('aria-expanded', 'true'); }
    } else {
        dd.style.display = 'none';
        if (btn) { btn.setAttribute('aria-expanded', 'false'); }
    }
}
document.addEventListener('click', function() {
    var dd = document.getElementById('header-tools-dropdown');
    var btn = document.getElementById('header-tools-toggle');
    if (dd) { 
        dd.style.display = 'none'; 
        if (btn) { btn.setAttribute('aria-expanded', 'false'); }
    }
});
</script>

<?php if(is_user_logged_in()): 
    $u_id = get_current_user_id();
    $notis = get_user_meta($u_id, 'notifications', true);
    $noti_count = 0;
    if (is_array($notis)) {
        foreach ($notis as $n) {
            if (!isset($n['read']) || $n['read'] == 0) {
                $noti_count++;
            }
        }
    }
    
    global $wpdb;
    $table_wallet = $wpdb->prefix . 'ilybd_wallet';
    $db_balance = null;
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_wallet'") == $table_wallet) {
        $db_balance = $wpdb->get_var($wpdb->prepare("SELECT balance FROM $table_wallet WHERE user_id = %d", $u_id));
    }
    
    if ($db_balance !== null) {
        $balance = (float) $db_balance;
    } else {
        $balance = (float) get_user_meta($u_id, 'user_balance', true);
    }
?>

<div class="rgb-line"></div>
<div class="nav-grid">

    <a class="nav-link" href="<?php echo home_url(); ?>">
        <i class="fa-solid fa-house"></i> Home
    </a>

    <a class="nav-link" href="<?php echo home_url('/dashboard?action=add-post'); ?>">
        <i class="fa-solid fa-pen-to-square"></i> Post
    </a>

    <a class="nav-link" href="<?php echo home_url('/dashboard'); ?>">
        <i class="fa-solid fa-chart-line"></i> Dashboard
    </a>

    <a class="nav-link" href="<?php echo home_url('/dashboard?action=notifications'); ?>">
        <?php if ($noti_count > 0): ?>
            <div style="position: relative; display: inline-flex; align-items: center; justify-content: center; margin-right: 2px;">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="color: #00f0ff; filter: drop-shadow(0 0 4px rgba(0,240,255,0.6)); animation: pulse-shield 2s infinite;"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg>
                <span style="position: absolute; top: -6px; right: -8px; background: #ff004c; color: #fff; font-size: 8.5px; font-weight: 900; min-width: 14px; height: 14px; border-radius: 50%; border: 1.5px solid #0d1527; box-shadow: 0 0 8px #ff004c; display: flex; align-items: center; justify-content: center; padding: 0; margin: 0; z-index: 2;"><?php echo $noti_count; ?></span>
            </div>
        <?php endif; ?>
        Alerts
    </a>

    <a class="nav-link" href="<?php echo home_url('/dashboard?action=wallet'); ?>">
        <span class="wallet">৳ <?php echo number_format($balance, 2); ?></span>
    </a>

</div>

<?php endif; ?>

<div class="rgb-bottom"></div>

</header>