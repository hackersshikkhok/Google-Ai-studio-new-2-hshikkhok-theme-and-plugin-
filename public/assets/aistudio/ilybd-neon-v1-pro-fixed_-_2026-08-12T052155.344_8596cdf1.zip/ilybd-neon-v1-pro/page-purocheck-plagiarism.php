<?php
/**
 * Template Name: PuroCheck - Plagiarism Checker
 */
$preselected_service = 'plagiarism';
include __DIR__ . '/page-purocheck.php';
