<?php
/**
 * Template Name: Maya Pro AI - Flagship Gemini App Page Template
 * Description: Full-Screen High-IQ 2040 Gemini App Workspace Page Template with Live Voice, Vision Camera & Live Web Search
 * Slug / URL: /maya-pro/
 */

if (!defined('ABSPATH')) exit;

// Ensure Maya AI tools renderer is loaded
if (!function_exists('ilybd_render_tool_ai_maya_cloud_assistant')) {
    $ai_tools_file = get_template_directory() . '/inc/tools-suites/ai-tools.php';
    if (file_exists($ai_tools_file)) {
        require_once $ai_tools_file;
    }
}

get_header();
?>

<!-- JSON-LD STRUCTURED DATA SCHEMAS FOR GOOGLE RANK #1 -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebApplication",
  "name": "Maya Pro AI - Powered by ILOVEYOUBD.COM",
  "alternateName": [
    "Maya AI",
    "মায়া এআই",
    "ILOVEYOUBD Maya",
    "Maya Pro AI",
    "মায়া প্রো এআই"
  ],
  "keywords": "iloveyoubd.com maya, maya ai, maya pro ai, iloveyoubd ai, মায়া এআই, মায়া প্রো এআই",
  "url": "https://iloveyoubd.com/maya-pro/",
  "applicationCategory": "EducationalApplication",
  "operatingSystem": "All Browsers, Android, iOS, Windows, macOS",
  "description": "বাংলাদেশে তৈরি সর্বাধুনিক মায়া এআই ও মায়া প্রো এআই (Maya AI / Maya Pro AI)। লাইভ ভয়েস, ভিশন ক্যামেরা ও কোডিং সমাধানসহ হাই-আইকিউ জেনারেটিভ এআই।",
  "softwareVersion": "2040.2.0",
  "offers": {
    "@type": "Offer",
    "price": "0.00",
    "priceCurrency": "BDT"
  },
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": "4.9",
    "ratingCount": "1280"
  }
}
</script>

<div class="ilybd-container" style="max-width: 1200px; margin: 30px auto; padding: 0 15px; min-height: 80vh;">
    <!-- MAYA PRO PAGE BANNER HEADER -->
    <div style="background: linear-gradient(135deg, rgba(13,21,39,0.95), rgba(7,11,19,0.98)); border: 1px solid rgba(168, 85, 247, 0.3); border-radius: 16px; padding: 25px; margin-bottom: 25px; text-align: center; box-shadow: 0 10px 30px rgba(168, 85, 247, 0.1);">
        <div style="display: inline-flex; align-items: center; gap: 10px; background: rgba(168, 85, 247, 0.1); border: 1px solid rgba(168, 85, 247, 0.3); padding: 6px 16px; border-radius: 20px; color: #c084fc; font-size: 12px; font-weight: bold; margin-bottom: 12px; font-family: 'JetBrains Mono', monospace;">
            <span>⚡</span> MAYA PRO AI // HIGH-IQ GEMINI MULTIMODAL STUDIO
        </div>
        <h1 style="color: #ffffff; font-size: 28px; font-weight: 900; margin: 0 0 10px 0; font-family: 'Space Grotesk', 'Hind Siliguri', sans-serif;">
            মায়া প্রো এআই (Maya Pro AI) - অ্যাডভান্সড বাংলা এআই ওয়ার্কস্পেস
        </h1>
        <p style="color: #9ca3af; font-size: 14px; max-width: 750px; margin: 0 auto; line-height: 1.6;" class="bangla-font-siliguri">
            উন্নত কোডিং, হাই-আইকিউ অ্যানালাইসিস, জটিল ম্যাথ সলভিং ও ক্রিয়েটিভ প্রজেক্ট ড্রাফটিংয়ের জন্য মায়া প্রো এআই ব্যবহার করুন।
        </p>
    </div>

    <!-- MAIN INTERACTIVE MAYA CHAT CONSOLE -->
    <div style="margin-bottom: 40px;">
        <?php
        if (function_exists('ilybd_render_tool_ai_maya_cloud_assistant')) {
            ilybd_render_tool_ai_maya_cloud_assistant();
        } else {
            echo '<div style="color:#ef4444; padding:20px; background:#111; border-radius:8px;">মায়া প্রো এআই সার্ভিসটি লোড হতে সমস্যা হচ্ছে। অনুগ্রহ করে পৃষ্ঠাটি রিফ্রেশ করুন।</div>';
        }
        ?>
    </div>

    <!-- SEO KNOWLEDGE SECTION -->
    <div style="background: rgba(13, 21, 39, 0.6); border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 16px; padding: 30px; margin-bottom: 40px;">
        <h2 style="color: #c084fc; font-size: 20px; font-weight: 800; margin-top: 0; margin-bottom: 15px;" class="bangla-font-siliguri">
            মায়া প্রো এআই (Maya Pro AI)-এর অনন্য ফিচারসমূহ
        </h2>
        <ul style="color: #cbd5e0; font-size: 14px; line-height: 1.8;" class="bangla-font-siliguri">
            <li><strong>অ্যাডভান্সড কোডিং অ্যাসিস্ট্যান্ট:</strong> পাইথন, জাভাস্ক্রিপ্ট, এইচটিএমএল, সি++, এবং ওয়ার্ডপ্রেস কোড জেনারেট ও বাগ ফিক্সিং।</li>
            <li><strong>হাই-আইকিউ জেনারেটিভ চ্যাট:</strong> যেকোনো প্রাতিষ্ঠানিক বা ব্যক্তিগত কাজের প্রফেশনাল গাইডলাইন।</li>
            <li><strong>সম্পূর্ণ ফ্রী অ্যাক্সেস:</strong> কোনো হিডেন ফি ছাড়াই ১০০% বিনামূল্যে ব্যবহারযোগ্য।</li>
        </ul>
    </div>
</div>

<?php
get_footer();
