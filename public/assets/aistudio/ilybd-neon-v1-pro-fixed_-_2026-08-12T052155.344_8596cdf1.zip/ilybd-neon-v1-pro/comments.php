<?php
if (post_password_required()) return;

$is_qna = (get_post_type() === 'ilybd_question');
$comments_class = $is_qna ? 'ilybd-qna-comments-wrapper' : 'ilybd-standard-comments-wrapper';

// Customize form details
if ($is_qna) {
    $title_reply = '<span class="response-accent-title" style="font-family: \'Space Grotesk\', sans-serif;"><i class="fa-solid fa-code" style="color: #00f0ff;"></i> আপনার সমাধান বা উত্তর সাবমিট করুন</span>';
    $placeholder = 'এখানে আপনার সমাধান বিস্তারিত বিশ্লেষণ করুন... (প্রয়োজনে কোডব্লক, সাইফার ট্যাগ ও ইমোজি সাপোর্ট করে। প্রতিটি ভেরিফাইড সমাধানের জন্য ৫০ XP ও ৳২.০০ বোনাস পাবেন!)';
    $label_submit = 'সমাধান প্রকাশ করুন 🚀';
} else {
    $title_reply = '<span class="response-accent-title"><i class="fa-solid fa-feather-pointed" style="color: #00ff41;"></i> আলোচনা ও মন্তব্যে অংশ নিন</span>';
    $placeholder = 'গঠনমূলক আলোচনা করুন এবং স্প্যামিং এড়িয়ে চলুন... (ইউটিউব এর মতো কোডব্লক এম্বেড, সাইফার ট্যাগ ও ইমোজি সাপোর্ট করে)';
    $label_submit = 'মন্তব্য প্রকাশ করুন 🎉';
}
?>

<div id="comments" class="ilybd-cyber-comments <?php echo esc_attr($comments_class); ?>" style="margin-top: 50px; text-align: left;">

    <?php if (have_comments()) : ?>
        <!-- Section Header with Neon Counters -->
        <div class="comments-vfx-header" style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 30px; border-bottom: 2px solid <?php echo $is_qna ? 'rgba(0, 240, 255, 0.15)' : 'rgba(0, 255, 65, 0.15)'; ?>; padding-bottom: 12px;">
            <h3 class="comments-title" style="color: #fff; font-size: 19px; margin: 0; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; display: flex; align-items: center; gap: 10px; font-family: 'Rajdhani', sans-serif;">
                <span style="background: <?php echo $is_qna ? 'rgba(0, 240, 255, 0.12)' : 'rgba(0, 255, 65, 0.12)'; ?>; color: <?php echo $is_qna ? '#00f0ff' : '#00ff41'; ?>; border: 1.2px solid <?php echo $is_qna ? '#00f0ff' : '#00ff41'; ?>; padding: 2px 10px; border-radius: 20px; font-size: 13px; font-weight: bold; box-shadow: 0 0 10px <?php echo $is_qna ? 'rgba(0,240,255,0.2)' : 'rgba(0,255,65,0.2)'; ?>;">
                    <i class="fa-solid <?php echo $is_qna ? 'fa-circle-question' : 'fa-comments'; ?>"></i> <?php echo $is_qna ? 'ANSWERS HUB' : 'FEEDBACK'; ?>
                </span>
                <?php echo get_comments_number(); ?> টি <?php echo $is_qna ? 'বিশ্লেষণ ও ফোরাম সমাধান' : 'কন্টেন্ট মন্তব্য ও আলোচনা'; ?>
            </h3>
        </div>

        <ul class="comment-list" style="list-style: none; padding: 0; margin: 0;">
            <?php
            wp_list_comments(array(
                'callback'     => $is_qna ? 'ilybd_qna_comment_format' : 'ilybd_custom_comment_format',
                'style'        => 'ul',
                'short_ping'   => true,
                'avatar_size'  => $is_qna ? 44 : 42,
            ));
            ?>
        </ul>
        
        <!-- Comment Pagination -->
        <?php if (get_comment_pages_count() > 1 && get_option('page_comments')) : ?>
            <nav class="comment-navigation" style="margin-top: 25px; margin-bottom: 25px; display: flex; justify-content: center; gap: 8px;">
                <div class="nav-links">
                    <?php 
                    paginate_comments_links(array(
                        'prev_text' => '<i class="fa-solid fa-arrow-left"></i> আগের মন্তব্য',
                        'next_text' => 'পরের মন্তব্য <i class="fa-solid fa-arrow-right"></i>'
                    )); 
                    ?>
                </div>
            </nav>
        <?php endif; ?>
    <?php endif; ?>

    <!-- Gorgeous Futuristic Comment Responder Form -->
    <div class="comment-respond-outer-glow" style="border-radius: 16px; background: linear-gradient(145deg, #0d1222 0%, #060a12 100%); border: 1.5px solid <?php echo $is_qna ? 'rgba(0, 240, 255, 0.15)' : 'rgba(0, 255, 65, 0.12)'; ?>; padding: 28px; margin-top: 40px; box-shadow: 0 10px 40px rgba(0,0,0,0.8); position: relative; overflow: hidden;">
        <!-- Neon decorative background pattern -->
        <div style="position: absolute; top: -150px; right: -150px; width: 300px; height: 300px; background: radial-gradient(circle, <?php echo $is_qna ? 'rgba(0,240,255,0.03)' : 'rgba(0,255,65,0.03)'; ?> 0%, transparent 75%); pointer-events: none;"></div>

        <?php
        $commenter = wp_get_current_commenter();
        $args = array(
            'title_reply'          => $title_reply,
            'title_reply_to'       => '<span class="response-accent-title"><i class="fa-solid fa-reply" style="color: ' . ($is_qna ? '#00f0ff' : '#00ff41') . ';"></i> %s কে উত্তর দিন</span>',
            'cancel_reply_link'    => '<i class="fa-solid fa-circle-xmark"></i> বাতিল করুন',
            'label_submit'         => $label_submit,
            'class_submit'         => $is_qna ? 'ilybd-btn-cyber-submit ilybd-btn-qna-submit' : 'ilybd-btn-cyber-submit',
            'submit_field'         => '<div class="submit-cyber-wrapper" style="margin-top: 15px; display: flex; justify-content: flex-end;">%1$s %2$s</div>',
            'comment_field'        => '<div class="input-cyber-wrapper" style="margin-bottom: 15px;">
                                        <textarea id="comment" name="comment" placeholder="' . esc_attr($placeholder) . '" rows="5" required style="width: 100%; background: #070a0f; border: 1.5px solid rgba(255,255,255,0.06); border-radius: 10px; padding: 15px; color: #fff; outline: none; font-size: 14.5px; line-height: 1.7; transition: 0.3s; box-shadow: inset 0 2px 8px rgba(0,0,0,0.7); resize: vertical;"></textarea>
                                      </div>',
            'fields' => array(
                'author' => '<div class="flex-inputs-cyber" style="display: flex; gap: 15px; margin-bottom: 15px;">
                                <div style="flex: 1;">
                                    <input name="author" type="text" placeholder="আপনার ডাকনাম বা হ্যান্ডেল*" required style="width: 100%; background: #070a0f; border: 1.5px solid rgba(255,255,255,0.06); border-radius: 10px; padding: 12px 16px; color: #fff; outline: none; font-size: 13.5px; transition: 0.3s; box-shadow: inset 0 2px 8px rgba(0,0,0,0.7);">
                                </div>',
                'email'  => '   <div style="flex: 1;">
                                    <input name="email" type="email" placeholder="ইমেইল এড্রেস (গোপন থাকবে)*" required style="width: 100%; background: #070a0f; border: 1.5px solid rgba(255,255,255,0.06); border-radius: 10px; padding: 12px 16px; color: #fff; outline: none; font-size: 13.5px; transition: 0.3s; box-shadow: inset 0 2px 8px rgba(0,0,0,0.7);">
                                </div>
                             </div>',
            ),
        );
        comment_form($args);
        ?>
    </div>
</div>

<style>
/* --- Standard Comments Hierarchical Threads (TrickBD Style Connectors) --- */
.ilybd-standard-comments-wrapper .comment-list .children {
    list-style: none;
    margin-left: 40px;
    border-left: 2px solid rgba(255, 255, 255, 0.06);
    padding-left: 18px;
    margin-top: 12px;
    position: relative;
    transition: border-color 0.3s;
}

.ilybd-standard-comments-wrapper .comment-list .children:hover {
    border-left-color: rgba(255, 255, 255, 0.15);
}

.ilybd-standard-comments-wrapper .comment-list .children > li::before {
    content: "";
    position: absolute;
    left: -18px;
    top: 25px;
    width: 18px;
    height: 2px;
    border-top: 2px solid rgba(255, 255, 255, 0.06);
}

.ilybd-standard-comments-wrapper .comment-list .children > li:hover::before {
    border-top-color: rgba(255, 255, 255, 0.15);
}

/* --- Q&A Comments Hierarchical Threads (Glowing Cyber Reddit Style Connectors) --- */
.ilybd-qna-comments-wrapper .comment-list .children {
    list-style: none;
    margin-left: 24px !important; /* Elegant compact indent */
    border-left: 1.5px dashed rgba(0, 240, 255, 0.2);
    padding-left: 14px !important;
    margin-top: 12px;
    position: relative;
    transition: border-color 0.3s;
}

.ilybd-qna-comments-wrapper .comment-list .children:hover {
    border-left-color: rgba(0, 240, 255, 0.5);
}

.ilybd-qna-comments-wrapper .comment-list .children > li::before {
    content: "";
    position: absolute;
    left: -14px;
    top: 25px;
    width: 14px;
    height: 1.5px;
    border-top: 1.5px dashed rgba(0, 240, 255, 0.2);
}

.ilybd-qna-comments-wrapper .comment-list .children > li:hover::before {
    border-top-color: rgba(0, 240, 255, 0.5);
}

/* Flatten deeper nested threads to guarantee no horizontal squishing */
.ilybd-qna-comments-wrapper .comment-list .children .children,
.ilybd-standard-comments-wrapper .comment-list .children .children {
    margin-left: 12px !important;
    padding-left: 8px !important;
}

.ilybd-qna-comments-wrapper .comment-list .children .children > li::before,
.ilybd-standard-comments-wrapper .comment-list .children .children > li::before {
    left: -8px !important;
    width: 8px !important;
}

/* Flatten Level 3 and deeper nested threads completely to prevent any horizontal squishing */
.comment-list .children .children .children {
    margin-left: 0 !important;
    padding-left: 0 !important;
    border-left: none !important;
}

.comment-list .children .children .children > li::before {
    display: none !important;
}

/* Custom styling for the glowing Q&A submit button */
.ilybd-btn-qna-submit {
    background: #00f0ff !important;
    color: #000 !important;
    box-shadow: 0 0 15px rgba(0,240,255,0.3) !important;
}

.ilybd-btn-qna-submit:hover {
    background: #fff !important;
    color: #000 !important;
    box-shadow: 0 0 25px #fff !important;
}

/* MOBILE RESPONSIVE OPTIMIZATION: Prevent comment replies from looking "too thin" on standard and Q&A boards */
@media (max-width: 768px) {
    .comment-list .children {
        margin-left: 12px !important;
        padding-left: 8px !important;
    }
    .comment-list .children > li::before {
        left: -8px !important;
        width: 8px !important;
    }
    /* Deeply nested levels on mobile (Level 2 and deeper) should be completely flat to prevent squished narrow text */
    .comment-list .children .children {
        margin-left: 0 !important;
        padding-left: 0 !important;
        border-left: none !important;
    }
    .comment-list .children .children > li::before {
        display: none !important;
    }
    .qna-answer-grid-layout {
        flex-direction: column !important;
        gap: 12px !important;
    }
    .qna-answer-voting-deck {
        flex-direction: row !important;
        width: 100% !important;
        justify-content: center !important;
        gap: 15px !important;
        padding: 6px 12px !important;
    }
}

@media (max-width: 480px) {
    .comment-body {
        padding: 12px 10px !important;
    }
    .comment-meta {
        gap: 8px !important;
    }
    .comment-meta .avatar {
        width: 36px !important;
        height: 36px !important;
    }
}

/* Comment Form Design Override */
#reply-title {
    color: #fff !important;
    font-size: 20px !important;
    font-weight: bold !important;
    margin-top: 0 !important;
    margin-bottom: 25px !important;
    display: inline-block;
    font-family: inherit;
    text-shadow: 0 0 12px rgba(255,255,255,0.05);
}

#cancel-comment-reply-link {
    background: rgba(255, 0, 60, 0.1);
    color: #ff003c;
    border: 1px solid rgba(255, 0, 60, 0.3);
    padding: 3px 10px;
    font-size: 11px;
    border-radius: 5px;
    text-decoration: none;
    margin-left: 15px;
    font-weight: 500;
    transition: 0.2s;
}

#cancel-comment-reply-link:hover {
    background: #ff003c;
    color: #fff;
    box-shadow: 0 0 10px rgba(255,0,60,0.4);
}

/* Input Hover & Focus VFX */
.input-cyber-wrapper textarea:focus,
.flex-inputs-cyber input:focus {
    border-color: #00ff41 !important;
    box-shadow: 0 0 12px rgba(0, 255, 65, 0.15), inset 0 2px 8px rgba(0,0,0,0.8) !important;
    background: #090d15 !important;
}

.ilybd-qna-comments-wrapper .input-cyber-wrapper textarea:focus,
.ilybd-qna-comments-wrapper .flex-inputs-cyber input:focus {
    border-color: #00f0ff !important;
    box-shadow: 0 0 12px rgba(0, 240, 255, 0.15), inset 0 2px 8px rgba(0,0,0,0.8) !important;
    background: #090d15 !important;
}

/* Submit Button VFX */
.ilybd-btn-cyber-submit {
    background: #00ff41 !important;
    color: #000 !important;
    border: none !important;
    padding: 12px 30px !important;
    font-size: 14px !important;
    border-radius: 8px !important;
    cursor: pointer !important;
    font-weight: 800 !important;
    letter-spacing: 0.5px;
    box-shadow: 0 0 15px rgba(0,255,65,0.3) !important;
    transition: 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275) !important;
    transform: translateY(0);
}

.ilybd-btn-cyber-submit:hover {
    background: #fff !important;
    color: #000 !important;
    box-shadow: 0 0 25px #fff !important;
    transform: translateY(-2px);
}

/* Comment Reply Link badge overriding styling */
.comment-reply-link {
    background: rgba(30, 41, 59, 0.55);
    color: #c9d1d9;
    padding: 5px 14px;
    border-radius: 6px;
    font-size: 11.5px;
    text-decoration: none;
    border: 1.2px solid rgba(255, 255, 255, 0.08);
    transition: 0.2s;
    display: inline-flex;
    align-items: center;
    gap: 4px;
    font-weight: 600;
}

.comment-reply-link:hover {
    background: rgba(0, 255, 65, 0.1);
    color: #00ff41;
    border-color: #00ff41;
    box-shadow: 0 0 8px rgba(0,255,65,0.2);
}

.ilybd-qna-comments-wrapper .comment-reply-link:hover {
    background: rgba(0, 240, 255, 0.1);
    color: #00f0ff;
    border-color: #00f0ff;
    box-shadow: 0 0 8px rgba(0,240,255,0.2);
}

/* Pagination Links Styling */
.comment-navigation .page-numbers {
    background: #0d1117;
    border: 1px solid rgba(255, 255, 255, 0.08);
    color: #c9d1d9;
    padding: 6px 14px;
    border-radius: 6px;
    text-decoration: none;
    font-size: 13px;
    font-family: monospace;
    font-weight: bold;
    transition: 0.2s;
}

.comment-navigation .page-numbers:hover,
.comment-navigation .page-numbers.current {
    background: rgba(0, 240, 255, 0.1);
    color: #00f0ff;
    border-color: #00f0ff;
    box-shadow: 0 0 8px rgba(0,240,255,0.25);
}

/* Animation Keyframes */
@keyframes slideInNotif {
    0% { transform: translateY(40px) scale(0.85); opacity: 0; }
    50% { transform: translateY(-4px) scale(1.02); opacity: 0.95; }
    100% { transform: translateY(0) scale(1); opacity: 1; }
}

@keyframes slideOutNotif {
    0% { transform: translateY(0) scale(1); opacity: 1; }
    100% { transform: translateY(30px) scale(0.9); opacity: 0; }
}
</style>

<script>
jQuery(document).ready(function($) {
    // Determine post type context
    var isQnaContext = <?php echo $is_qna ? 'true' : 'false'; ?>;
    var cyberAccentColor = isQnaContext ? '#00f0ff' : '#00ff41';

    // 1. Comment Like Button Handler
    $(document).on('click', '.comment-like-btn', function(e) {
        e.preventDefault();
        var btn = $(this);
        var commentId = btn.data('comment-id');
        if (!commentId) return;

        btn.css('opacity', '0.5');

        $.ajax({
            url: '<?php echo admin_url('admin-ajax.php'); ?>',
            type: 'POST',
            data: {
                action: 'ilybd_like_comment',
                comment_id: commentId
            },
            success: function(response) {
                btn.css('opacity', '1');
                if (response.success) {
                    btn.find('.like-count').text(response.data.likes);
                    btn.addClass('liked-glow');
                    // Spark pulse animation
                    btn.css('color', '#00ff41');
                    // Notification helper
                    showCyberNotif("❤️ মন্তব্যটি পছন্দ হয়েছে!");
                } else {
                    showCyberNotif("⚠️ লাইক দিতে সমস্যা হয়েছে।");
                }
            },
            error: function() {
                btn.css('opacity', '1');
                showCyberNotif("⚠️ নেটওয়ার্ক ত্রুটি!");
            }
        });
    });

    // 2. Share / Copy Comment Link Handler (Zero default alerts!)
    $(document).on('click', '.comment-share-trigger', function(e) {
        e.preventDefault();
        var link = $(this).data('link');
        if (!link) return;

        navigator.clipboard.writeText(link).then(function() {
            showCyberNotif("📋 মন্তব্য লিঙ্ক ক্লিপবোর্ডে কপি করা হয়েছে!");
        }, function() {
            // fallback
            var temp = $("<input>");
            $("body").append(temp);
            temp.val(link).select();
            document.execCommand("copy");
            temp.remove();
            showCyberNotif("📋 মন্তব্য লিঙ্ক কপি করা হয়েছে!");
        });
    });

    // 3. Cyber Inline Comment Editing System (Saves raw reload waiting!)
    window.openCommentEdit = function(commentId, event) {
        if(event) event.preventDefault();
        var parentContainer = $("#comment-text-container-" + commentId);
        
        // If already editing, ignore
        if (parentContainer.find('.inline-edit-form').length) return;

        var originalText = parentContainer.html().trim();
        // Extract raw text accurately
        var cleanedText = parentContainer.clone().find('.inline-edit-form').remove().end().text().trim();

        // Create sleek editor card
        var editForm = $(`
            <div class="inline-edit-form" style="margin-top: 12px; background: #070a0f; border: 1.5px solid ${cyberAccentColor}; border-radius: 10px; padding: 15px; box-shadow: 0 5px 20px rgba(0,0,0,0.8); animation: slideInNotif 0.25s ease-out;">
                <h5 style="color: #fff; font-size: 13px; font-weight: bold; margin: 0 0 10px 0; display: flex; align-items: center; gap: 6px; font-family: sans-serif;">
                    <i class="fa-solid fa-pen-to-square" style="color: ${cyberAccentColor};"></i> মন্তব্য এডিট করুন
                </h5>
                <textarea class="edit-textarea" style="width: 100%; height: 110px; background: #161b22; border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 12px; color: #fff; font-size: 13.5px; outline: none; line-height: 1.6; resize: vertical; transition: border-color 0.2s;" placeholder="মন্তব্যটি পরিবর্তন করুন..."></textarea>
                <div style="display: flex; justify-content: flex-end; gap: 8px; margin-top: 10px;">
                    <button class="edit-cancel-btn" style="background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); color: #8b949e; padding: 5px 12px; border-radius: 6px; font-size: 11.5px; cursor: pointer; font-weight: bold; transition: 0.2s;" onmouseover="this.style.background='rgba(255,255,255,0.1)';" onmouseout="this.style.background='rgba(255,255,255,0.05)';">বাতিল</button>
                    <button class="edit-save-btn" style="background: ${cyberAccentColor}; border: none; color: #000; padding: 5px 15px; border-radius: 6px; font-size: 11.5px; cursor: pointer; font-weight: bold; transition: 0.2s; box-shadow: 0 0 10px ${isQnaContext ? 'rgba(0,240,255,0.25)' : 'rgba(0,255,65,0.25)'};" onmouseover="this.style.background='#fff'; this.style.boxShadow='0 0 15px #fff';" onmouseout="this.style.background='${cyberAccentColor}'; this.style.boxShadow='0 0 10px ${isQnaContext ? 'rgba(0,240,255,0.25)' : 'rgba(0,255,65,0.25)'}';">সংরক্ষণ</button>
                </div>
            </div>
        `);

        // Hide original text and inject editForm
        var originalDisplay = parentContainer.children().not('.inline-edit-form').detach();
        parentContainer.append(editForm);
        // Clean textarea string
        editForm.find('.edit-textarea').val(cleanedText).focus();

        // Cancel click action
        editForm.find('.edit-cancel-btn').on('click', function() {
            editForm.remove();
            parentContainer.append(originalDisplay);
        });

        // Save click action
        editForm.find('.edit-save-btn').on('click', function() {
            var updatedContent = editForm.find('.edit-textarea').val().trim();
            if(!updatedContent) {
                showCyberNotif("⚠️ মন্তব্যটি খালি রাখা সম্ভব নয়!");
                return;
            }

            editForm.css('opacity', '0.6');

            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'ilybd_edit_comment',
                    comment_id: commentId,
                    comment_content: updatedContent
                },
                success: function(response) {
                    if (response.success) {
                        editForm.remove();
                        parentContainer.html(response.data.content);
                        showCyberNotif("✅ মন্তব্যটি সফলভাবে ড্রাফট থেকে আপডেট হয়েছে!");
                    } else {
                        editForm.css('opacity', '1');
                        showCyberNotif("⚠️ " + (response.data.message || "সংরক্ষণ করতে ব্যর্থ হয়েছে।"));
                    }
                },
                error: function() {
                    editForm.css('opacity', '1');
                    showCyberNotif("⚠️ নেটওয়ার্ক সংযোগ বিঘ্নিত হয়েছে!");
                }
            });
        });
    };

    // 4. Q&A Comment/Answer Voting Handler (Upvote/Downvote)
    $(document).on('click', '.qna-comment-vote-btn', function(e) {
        e.preventDefault();
        var btn = $(this);
        var commentId = btn.data('comment-id');
        var type = btn.data('type');
        if (!commentId) return;

        btn.css('opacity', '0.5');

        $.ajax({
            url: '<?php echo admin_url('admin-ajax.php'); ?>',
            type: 'POST',
            data: {
                action: 'ilybd_vote_comment_qna',
                comment_id: commentId,
                vote_type: type
            },
            success: function(response) {
                btn.css('opacity', '1');
                if (response.success) {
                    var countSpan = btn.siblings('.qna-comment-vote-count');
                    countSpan.text(response.data.votes);
                    
                    // short dynamic pulse
                    countSpan.css('color', type === 'up' ? '#00f0ff' : '#ff3b30');
                    setTimeout(function() {
                        countSpan.css('color', '#fff');
                    }, 1000);

                    showCyberNotif(type === 'up' ? "👍 উত্তরটিতে একটি আপভোট দেওয়া হয়েছে!" : "👎 উত্তরটিতে একটি ডাউনভোট দেওয়া হয়েছে!");
                } else {
                    showCyberNotif("⚠️ " + (response.data.message || "ভোট প্রকাশে ব্যর্থতা।"));
                }
            },
            error: function() {
                btn.css('opacity', '1');
                showCyberNotif("⚠️ নেটওয়ার্ক সংযোগ ত্রুটি!");
            }
        });
    });

    // 5. Q&A Accept/Mark Verified Solution Handler
    $(document).on('click', '.qna-accept-solution-btn', function(e) {
        e.preventDefault();
        var btn = $(this);
        var commentId = btn.data('comment-id');
        if (!commentId) return;

        btn.css('opacity', '0.5');

        $.ajax({
            url: '<?php echo admin_url('admin-ajax.php'); ?>',
            type: 'POST',
            data: {
                action: 'ilybd_accept_solution',
                comment_id: commentId
            },
            success: function(response) {
                btn.css('opacity', '1');
                if (response.success) {
                    showCyberNotif("🎯 " + response.data.message);
                    setTimeout(function() {
                        location.reload();
                    }, 1500);
                } else {
                    showCyberNotif("⚠️ " + (response.data.message || "ভেরিফাইড মার্ক করতে ব্যর্থতা।"));
                }
            },
            error: function() {
                btn.css('opacity', '1');
                showCyberNotif("⚠️ নেটওয়ার্ক সংযোগ ত্রুটি!");
            }
        });
    });

    // 6. Cyber Notification popup box
    function showCyberNotif(msg) {
        var notiBox = $('#cyber-comment-noti-box');
        if (!notiBox.length) {
            $('body').append('<div id="cyber-comment-noti-box" style="position:fixed; bottom:30px; right:30px; z-index:99999; display: flex; flex-direction: column; gap: 10px;"></div>');
            notiBox = $('#cyber-comment-noti-box');
        }

        var isNotifQna = (msg.indexOf('উত্তর') > -1 || msg.indexOf('সমাধান') > -1 || msg.indexOf('ভোট') > -1 || isQnaContext);
        var itemAccent = isNotifQna ? '#00f0ff' : '#00ff41';
        var itemShadow = isNotifQna ? 'rgba(0,240,255,0.25)' : 'rgba(0,255,65,0.25)';

        var notiItem = $(`
            <div style="background: rgba(13, 17, 23, 0.96); backdrop-filter: blur(10px); border: 1.5px solid ${itemAccent}; color: #fff; padding: 12px 22px; border-radius: 10px; font-weight: 600; font-size: 13px; font-family: sans-serif; box-shadow: 0 10px 30px ${itemShadow}; display: flex; align-items: center; gap: 8px; animation: slideInNotif 0.35s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards;">
                <i class="fa-solid fa-circle-check" style="color: ${itemAccent}; font-size: 16px;"></i> \${msg}
            </div>
        `);

        notiBox.append(notiItem);
        setTimeout(function() {
            notiItem.css('animation', 'slideOutNotif 0.35s ease forwards');
            setTimeout(function() {
                notiItem.remove();
            }, 400);
        }, 4500);
    }
});
</script>
