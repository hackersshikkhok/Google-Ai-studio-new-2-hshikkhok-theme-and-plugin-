<?php
/**
 * Template Name: Maya (মায়া এআই) - Google Gemini App Replica
 * Description: Dedicated Gemini AI App Workspace & SEO Page for 'Maya' (iloveyoubd.com/maya/)
 * Focus Keywords: maya, iloveyoubd maya, মায়া, মায়া এআই, বাংলা চ্যাটবট
 */

if (!defined('ABSPATH')) exit;

get_header();
?>

<!-- JSON-LD STRUCTURED DATA SCHEMA FOR 'MAYA' (GOOGLE RANK #1) -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "SoftwareApplication",
  "name": "Maya - Your Personal Bangla AI Companion",
  "alternateName": ["Maya", "মায়া", "ILOVEYOUBD Maya"],
  "keywords": "maya, iloveyoubd maya, মায়া, বাংলা চ্যাটবট, iloveyoubd.com maya",
  "url": "https://iloveyoubd.com/maya/",
  "applicationCategory": "ChatApplication",
  "operatingSystem": "All Browsers, Android, iOS, Windows, macOS",
  "description": "বাংলাদেশে তৈরি দ্রুততম ও স্মার্ট মায়া (Maya) এআই অ্যাসিস্ট্যান্ট। সাধারণ কথা বলা, কন্টেন্ট লেখা, পড়াশোনা ও প্রতিদিনের কাজের স্মার্ট বাংলা চ্যাটবট।",
  "softwareVersion": "2040.2.0",
  "offers": {
    "@type": "Offer",
    "price": "0.00",
    "priceCurrency": "BDT"
  },
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": "4.9",
    "ratingCount": "1280"
  }
}
</script>

<div id="gemini-app-root" style="display: flex; height: calc(100vh - 120px); min-height: 600px; background: #070b13; color: #f1f5f9; font-family: 'Space Grotesk', 'Hind Siliguri', sans-serif; overflow: hidden; position: relative;">
    
    <!-- LEFT SIDEBAR / DRAWERS -->
    <aside id="gemini-sidebar" style="width: 280px; background: #0b111e; border-right: 1px solid rgba(255, 255, 255, 0.08); display: flex; flex-direction: column; transition: all 0.3s ease; flex-shrink: 0; z-index: 50;">
        <!-- New Chat Trigger -->
        <div style="padding: 16px;">
            <button onclick="startNewMayaSession()" style="width: 100%; background: rgba(0, 240, 255, 0.06); border: 1px solid rgba(0, 240, 255, 0.2); color: #00f0ff; border-radius: 12px; padding: 12px 24px; font-size: 14px; font-weight: 700; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px; transition: all 0.2s;" onmouseover="this.style.background='rgba(0, 240, 255, 0.12)'; this.style.borderColor='#00f0ff';" onmouseout="this.style.background='rgba(0, 240, 255, 0.06)'; this.style.borderColor='rgba(0, 240, 255, 0.2)';">
                <span style="font-size: 18px;">+</span> New Chat / নতুন চ্যাট
            </button>
        </div>

        <!-- Chat History List -->
        <div style="flex: 1; overflow-y: auto; padding: 0 16px;">
            <div style="color: #64748b; font-size: 11px; font-weight: bold; letter-spacing: 1px; text-transform: uppercase; margin-bottom: 12px; margin-top: 10px; font-family: 'JetBrains Mono', monospace;">Recent Chats</div>
            <div id="maya-history-list" style="display: flex; flex-direction: column; gap: 6px;">
                <!-- Dynamically loaded history -->
            </div>
        </div>

        <!-- Sidebar Footer Actions -->
        <div style="padding: 16px; border-top: 1px solid rgba(255, 255, 255, 0.05); display: flex; flex-direction: column; gap: 8px;">
            <!-- Sound Toggle -->
            <button onclick="toggleMayaAudioMute()" id="sidebar-audio-toggle" style="width: 100%; background: transparent; border: 1px solid rgba(255, 255, 255, 0.08); color: #94a3b8; border-radius: 8px; padding: 8px 16px; font-size: 13px; font-weight: 600; cursor: pointer; display: flex; align-items: center; gap: 8px; text-align: left; transition: all 0.2s;" onmouseover="this.style.background='rgba(255,255,255,0.03)'" onmouseout="this.style.background='transparent'">
                <span id="sidebar-audio-icon">🔊</span> <span id="sidebar-audio-text">Sound: ON</span>
            </button>
            <!-- User Status / Credits Info -->
            <div style="background: rgba(255,255,255,0.02); border: 1px solid rgba(255, 255, 255, 0.05); border-radius: 8px; padding: 10px 14px; font-size: 11px; color: #94a3b8; line-height: 1.4;">
                <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
                    <span>Secure Protocol:</span>
                    <span style="color: #00ff41; font-weight: bold;">SYNCED</span>
                </div>
                <div style="display: flex; justify-content: space-between;">
                    <span>Client ID:</span>
                    <span style="font-family: 'JetBrains Mono', monospace; font-size: 10px; color: #fbbf24;">IBD-M-<?php echo substr(md5(get_current_user_id() . $_SERVER['REMOTE_ADDR']), 0, 8); ?></span>
                </div>
            </div>
        </div>
    </aside>

    <!-- SIDEBAR TOGGLE FLOATER BUTTON (Mobile friendly collapse) -->
    <button onclick="toggleMayaSidebar()" style="position: absolute; left: 16px; bottom: 85px; z-index: 100; width: 40px; height: 40px; background: #0b111e; border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 50%; color: #fff; cursor: pointer; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 12px rgba(0,0,0,0.4);" class="sidebar-toggle-btn">
        🍔
    </button>

    <!-- MAIN APLET CONTAINER -->
    <main style="flex: 1; display: flex; flex-direction: column; background: #070b13; position: relative; height: 100%;">
        
        <!-- TOP VIEW BAR HEADER -->
        <header style="height: 60px; background: #0b111e; border-bottom: 1px solid rgba(255, 255, 255, 0.08); display: flex; align-items: center; justify-content: space-between; padding: 0 24px;">
            <!-- Left Header: Model Selector -->
            <div style="display: flex; align-items: center; gap: 12px;">
                <div style="display: flex; align-items: center; gap: 8px; color: #fbbf24; font-weight: 800;">
                    <span style="font-size: 20px;">🤖</span>
                    <span style="font-size: 16px; letter-spacing: 0.5px; font-family: 'Space Grotesk', sans-serif;">MAYA PRO</span>
                </div>
                <select id="gemini-model-selector" style="background: #111827; border: 1px solid rgba(255, 255, 255, 0.12); color: #e2e8f0; border-radius: 8px; padding: 6px 12px; font-size: 12.5px; font-family: 'JetBrains Mono', monospace; cursor: pointer; outline: none;" onchange="updateSelectedModel()">
                    <option value="gemini-3.6-flash">Gemini 3.6 Flash (Fast)</option>
                    <option value="gemini-3.1-pro-preview">Gemini 3.1 Pro (Reasoning)</option>
                    <option value="gemini-3.1-flash-lite">Gemini 3.1 Flash-Lite</option>
                </select>
            </div>

            <!-- Right Header: Status Indicator -->
            <div style="display: flex; align-items: center; gap: 12px;">
                <div style="display: flex; align-items: center; gap: 6px; background: rgba(0, 255, 65, 0.08); border: 1px solid rgba(0, 255, 65, 0.2); border-radius: 20px; padding: 4px 12px; font-size: 11px; font-family: 'JetBrains Mono', monospace; color: #00ff41; font-weight: bold;">
                    <span style="width: 6px; height: 6px; background: #00ff41; border-radius: 50%; display: inline-block;"></span>
                    <span>ONLINE</span>
                </div>
            </div>
        </header>

        <!-- FEED SPACE -->
        <div id="maya-feed-container" style="flex: 1; overflow-y: auto; padding: 30px 24px; display: flex; flex-direction: column; gap: 24px; scroll-behavior: smooth;">
            
            <!-- GREETING SCREEN (Shown when there are no messages) -->
            <div id="maya-greeting-screen" style="max-width: 800px; margin: 40px auto; width: 100%; display: flex; flex-direction: column; gap: 35px;">
                <div>
                    <h1 style="font-size: 38px; font-weight: 900; margin: 0 0 10px 0; background: linear-gradient(135deg, #00f0ff, #fbbf24); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                        Hello, Guest
                    </h1>
                    <h2 style="font-size: 28px; font-weight: 700; color: #94a3b8; margin: 0;" class="bangla-font-siliguri">
                        আজ কীভাবে আপনাকে সাহায্য করতে পারি?
                    </h2>
                </div>

                <!-- Bento Suggestion Grid -->
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 16px;">
                    <!-- Bento Card 1 -->
                    <div onclick="applySuggestion('বিকাশ অ্যাপ ক্লোন করার জন্য সুন্দর এইচটিএমএল ডিজাইন কোড বানিয়ে দাও')" style="background: #0b111e; border: 1px solid rgba(255, 255, 255, 0.05); border-radius: 12px; padding: 16px; cursor: pointer; transition: all 0.2s;" onmouseover="this.style.borderColor='#00f0ff'; this.style.background='rgba(0, 240, 255, 0.03)';" onmouseout="this.style.borderColor='rgba(255, 255, 255, 0.05)'; this.style.background='#0b111e';">
                        <div style="font-size: 20px; margin-bottom: 12px;">📱</div>
                        <div style="font-size: 13.5px; font-weight: bold; color: #e2e8f0; margin-bottom: 6px;">বিকাশ অ্যাপ ক্লোন</div>
                        <div style="font-size: 12px; color: #64748b; line-height: 1.4;" class="bangla-font-siliguri">সুন্দর এইচটিএমএল রেসপন্সিভ ডিজাইন ও স্টাইল মেকার কোড</div>
                    </div>
                    <!-- Bento Card 2 -->
                    <div onclick="applySuggestion('এসইও (SEO) শিখে কীভাবে ফ্রিল্যান্সিং শুরু করব বিস্তারিত গাইডলাইন দিন')" style="background: #0b111e; border: 1px solid rgba(255, 255, 255, 0.05); border-radius: 12px; padding: 16px; cursor: pointer; transition: all 0.2s;" onmouseover="this.style.borderColor='#fbbf24'; this.style.background='rgba(251, 191, 36, 0.03)';" onmouseout="this.style.borderColor='rgba(255, 255, 255, 0.05)'; this.style.background='#0b111e';">
                        <div style="font-size: 20px; margin-bottom: 12px;">🚀</div>
                        <div style="font-size: 13.5px; font-weight: bold; color: #e2e8f0; margin-bottom: 6px;">এসইও গাইডলাইন</div>
                        <div style="font-size: 12px; color: #64748b; line-height: 1.4;" class="bangla-font-siliguri">সার্চ ইঞ্জিন অপ্টিমাইজেশন শিখে আর্নিং শুরুর প্রফেশনাল মেথড</div>
                    </div>
                    <!-- Bento Card 3 -->
                    <div onclick="applySuggestion('পাইথন দিয়ে কোনো ইমেইল ভ্যালিড কি না চেক করার স্ক্রিপ্ট কোড লিখে দাও')" style="background: #0b111e; border: 1px solid rgba(255, 255, 255, 0.05); border-radius: 12px; padding: 16px; cursor: pointer; transition: all 0.2s;" onmouseover="this.style.borderColor='#3b82f6'; this.style.background='rgba(59, 130, 246, 0.03)';" onmouseout="this.style.borderColor='rgba(255, 255, 255, 0.05)'; this.style.background='#0b111e';">
                        <div style="font-size: 20px; margin-bottom: 12px;">🐍</div>
                        <div style="font-size: 13.5px; font-weight: bold; color: #e2e8f0; margin-bottom: 6px;">পাইথন স্ক্রিপ্ট কোড</div>
                        <div style="font-size: 12px; color: #64748b; line-height: 1.4;" class="bangla-font-siliguri">ইমেল ভ্যালিডিটি ফিল্টারিং ও ভ্যালিডেশন কোড লাইব্রেরি</div>
                    </div>
                    <!-- Bento Card 4 -->
                    <div onclick="applySuggestion('বাংলাদেশ নিয়ে একটি মনমুগ্ধকর কবিতা লিখে দাও')" style="background: #0b111e; border: 1px solid rgba(255, 255, 255, 0.05); border-radius: 12px; padding: 16px; cursor: pointer; transition: all 0.2s;" onmouseover="this.style.borderColor='#10b981'; this.style.background='rgba(16, 185, 129, 0.03)';" onmouseout="this.style.borderColor='rgba(255, 255, 255, 0.05)'; this.style.background='#0b111e';">
                        <div style="font-size: 20px; margin-bottom: 12px;">✍️</div>
                        <div style="font-size: 13.5px; font-weight: bold; color: #e2e8f0; margin-bottom: 6px;">ক্রিয়েটিভ রাইটিং</div>
                        <div style="font-size: 12px; color: #64748b; line-height: 1.4;" class="bangla-font-siliguri">বাংলায় চমৎকার ও প্রফেশনাল কবিতা বা কন্টেন্ট জেনারেটর</div>
                    </div>
                </div>
            </div>

            <!-- CHAT LOG CONTAINER (Shown when chat starts) -->
            <div id="maya-active-chat-feed" style="max-width: 800px; margin: 0 auto; width: 100%; display: none; flex-direction: column; gap: 24px;">
                <!-- User and Model messages loaded dynamically -->
            </div>

        </div>

        <!-- BOTTOM CHAT PIL INPUT CONTAINER -->
        <div style="background: linear-gradient(to top, #070b13 80%, transparent); padding: 10px 24px 20px 24px; position: relative;">
            <div style="max-width: 800px; margin: 0 auto; width: 100%;">
                
                <!-- Floating File Preview Bubble -->
                <div id="file-upload-preview-bar" style="display: none; background: #0b111e; border: 1px solid rgba(0,240,255,0.2); border-radius: 12px; padding: 10px 16px; margin-bottom: 10px; align-items: center; justify-content: space-between; max-width: 320px;">
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <span style="font-size: 20px;" id="preview-file-icon">📄</span>
                        <div>
                            <div id="preview-file-name" style="font-size: 12px; font-weight: bold; color: #f1f5f9; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 180px;">file.txt</div>
                            <div id="preview-file-size" style="font-size: 10px; color: #64748b;">12 KB</div>
                        </div>
                    </div>
                    <button onclick="removeUploadedFile()" style="background: none; border: none; color: #ef4444; font-size: 16px; cursor: pointer;">✕</button>
                </div>

                <!-- Input Pill -->
                <div id="input-pill-wrapper" style="background: #0b111e; border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 28px; padding: 6px 12px; display: flex; align-items: center; gap: 10px; position: relative; box-shadow: 0 4px 20px rgba(0,0,0,0.3); transition: all 0.2s;">
                    <!-- Upload File Button -->
                    <button onclick="triggerMayaFileUpload()" title="Upload File" style="background: none; border: none; color: #94a3b8; width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; cursor: pointer; transition: all 0.2s;" onmouseover="this.style.background='rgba(255,255,255,0.04)'; this.style.color='#00f0ff';" onmouseout="this.style.background='none'; this.style.color='#94a3b8';">
                        📎
                    </button>
                    <input type="file" id="maya-hidden-file-input" style="display: none;" onchange="handleMayaFileSelected(event)">

                    <!-- Textarea input field -->
                    <textarea id="maya-app-user-input" placeholder="মায়াকে প্রশ্ন করুন অথবা কোড বা যেকোনো তথ্য জানতে চান..." style="flex: 1; background: transparent; border: none; outline: none; color: #f1f5f9; font-size: 14px; line-height: 1.5; resize: none; max-height: 150px; height: 36px; padding: 8px 0; font-family: 'Space Grotesk', 'Hind Siliguri', sans-serif;" onkeypress="handleMayaInputKeyPress(event)" oninput="autoGrowMayaInput(this)"></textarea>

                    <!-- Voice Input (Mic) button -->
                    <button id="maya-mic-btn" onclick="toggleMayaSpeechInput()" title="Voice Input" style="background: none; border: none; color: #94a3b8; width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; cursor: pointer; transition: all 0.2s;" onmouseover="this.style.background='rgba(255,255,255,0.04)'; this.style.color='#ef4444';" onmouseout="this.style.background='none'; if(!speechActive) { this.style.color='#94a3b8'; }">
                        🎙️
                    </button>

                    <!-- Send button -->
                    <button onclick="sendMayaChatMessage()" id="maya-send-pill-btn" title="Send" style="background: #fbbf24; border: none; color: #000; width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; cursor: pointer; font-weight: bold; transition: all 0.2s;" onmouseover="this.style.background='#f59e0b'; this.style.boxShadow='0 0 12px rgba(251,191,36,0.4)';" onmouseout="this.style.background='#fbbf24'; this.style.boxShadow='none';">
                        ➔
                    </button>
                </div>

                <!-- Footer disclaimer notice -->
                <div style="text-align: center; font-size: 11px; color: #475569; margin-top: 10px; font-family: 'Hind Siliguri', sans-serif;">
                    মায়া ভুল তথ্য প্রদান করতে পারে, তাই গুরুত্বপূর্ণ তথ্যসমূহ বা কোড সর্বদা যাচাই করে নিন।
                </div>
            </div>
        </div>

    </main>
</div>

<!-- STYLES & AUDIO TICKERS -->
<audio id="sound-tick" src="https://assets.mixkit.co/active_storage/sfx/2568/2568-84.wav" preload="auto" volume="0.1"></audio>
<audio id="sound-alert" src="https://assets.mixkit.co/active_storage/sfx/2019/2019-84.wav" preload="auto" volume="0.15"></audio>

<style>
/* CSS Reset constraints for pristine rendering */
#gemini-app-root * {
    box-sizing: border-box;
}
#gemini-app-root select, #gemini-app-root button, #gemini-app-root textarea {
    font-family: inherit;
}
#gemini-app-root pre {
    background: #0d1527 !important;
    border: 1px solid rgba(251, 191, 36, 0.15) !important;
    border-radius: 8px !important;
    padding: 14px !important;
    color: #e2e8f0 !important;
    font-family: 'JetBrains Mono', monospace !important;
    font-size: 12.5px !important;
    overflow-x: auto;
    position: relative;
    margin: 16px 0;
}
#gemini-app-root pre code {
    background: transparent !important;
    padding: 0 !important;
    border: none !important;
    color: inherit !important;
    font-family: inherit !important;
}
#gemini-app-root code {
    background: rgba(251, 191, 36, 0.08) !important;
    border: 1px solid rgba(251, 191, 36, 0.2) !important;
    color: #f59e0b !important;
    padding: 2px 6px !important;
    border-radius: 4px !important;
    font-family: 'JetBrains Mono', monospace !important;
    font-size: 12px;
}
.gemini-history-item {
    padding: 10px 14px;
    border-radius: 8px;
    cursor: pointer;
    font-size: 13px;
    color: #cbd5e0;
    display: flex;
    align-items: center;
    justify-content: space-between;
    transition: all 0.15s ease;
    border: 1px solid transparent;
}
.gemini-history-item:hover {
    background: rgba(255, 255, 255, 0.03);
    border-color: rgba(255,255,255,0.05);
    color: #fff;
}
.gemini-history-item.active {
    background: rgba(0, 240, 255, 0.05);
    border-color: rgba(0, 240, 255, 0.15);
    color: #00f0ff;
    font-weight: 700;
}
.user-msg-bubble {
    align-self: flex-end;
    max-width: 75%;
    background: linear-gradient(135deg, #1e293b, #0f172a);
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 16px 16px 0 16px;
    padding: 14px 18px;
    color: #f8fafc;
    font-size: 14px;
    line-height: 1.6;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}
.maya-msg-bubble {
    align-self: flex-start;
    max-width: 85%;
    display: flex;
    gap: 12px;
    width: 100%;
}
.maya-msg-avatar {
    width: 36px;
    height: 36px;
    background: rgba(251, 191, 36, 0.1);
    border: 1px solid rgba(251, 191, 36, 0.3);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 15px;
    flex-shrink: 0;
    color: #fbbf24;
    font-weight: bold;
}
.maya-msg-content {
    flex: 1;
    background: transparent;
    color: #e2e8f0;
    font-size: 14px;
    line-height: 1.6;
}
.maya-action-btn-list {
    display: flex;
    gap: 8px;
    margin-top: 8px;
}
.maya-utility-action-btn {
    background: none;
    border: 1px solid rgba(255, 255, 255, 0.06);
    color: #64748b;
    padding: 4px 10px;
    border-radius: 12px;
    font-size: 11px;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 4px;
    transition: all 0.15s ease;
}
.maya-utility-action-btn:hover {
    border-color: rgba(255, 255, 255, 0.15);
    color: #fff;
    background: rgba(255, 255, 255, 0.02);
}
.pre-copy-btn {
    position: absolute;
    right: 8px;
    top: 8px;
    background: rgba(255, 255, 255, 0.08);
    border: 1px solid rgba(255, 255, 255, 0.15);
    color: #fbbf24;
    font-size: 10.5px;
    padding: 3px 8px;
    border-radius: 4px;
    cursor: pointer;
    font-weight: bold;
    z-index: 10;
    transition: all 0.15s;
}
.pre-copy-btn:hover {
    background: #fbbf24;
    color: #000;
}
.pulse-indicator {
    display: inline-block;
    width: 6px;
    height: 6px;
    background: #ef4444;
    border-radius: 50%;
    box-shadow: 0 0 8px #ef4444;
    animation: micPulse 1.2s infinite;
}
@keyframes micPulse {
    0%, 100% { transform: scale(1); opacity: 0.6; }
    50% { transform: scale(1.3); opacity: 1; }
}

/* Scrollbar customization for pro-level app feel */
#gemini-sidebar::-webkit-scrollbar, #maya-feed-container::-webkit-scrollbar, #gemini-app-root *::-webkit-scrollbar {
    width: 6px;
    height: 6px;
}
#gemini-sidebar::-webkit-scrollbar-thumb, #maya-feed-container::-webkit-scrollbar-thumb, #gemini-app-root *::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.05);
    border-radius: 3px;
}
#gemini-sidebar::-webkit-scrollbar-thumb:hover, #maya-feed-container::-webkit-scrollbar-thumb:hover, #gemini-app-root *::-webkit-scrollbar-thumb:hover {
    background: rgba(255, 255, 255, 0.15);
}
</style>

<!-- WEB APP ENGINE JAVASCRIPT -->
<script>
document.addEventListener("DOMContentLoaded", function() {
    initMayaSessionManager();
});

// Session & Storage Management
var audioMuted = false;
var activeSessionId = null;
var sessions = {};
var speechActive = false;
var recognition = null;
var uploadedFile = null;

function initMayaSessionManager() {
    var stored = localStorage.getItem("ilybd_maya_sessions");
    if (stored) {
        try {
            sessions = JSON.parse(stored);
        } catch(e) {
            sessions = {};
        }
    }
    
    // If empty, generate a first one
    var keys = Object.keys(sessions);
    if (keys.length === 0) {
        startNewMayaSession();
    } else {
        // Load latest session
        activeSessionId = keys[keys.length - 1];
        renderHistoryList();
        loadActiveSessionChat();
    }
}

function saveSessions() {
    localStorage.setItem("ilybd_maya_sessions", JSON.stringify(sessions));
    renderHistoryList();
}

function startNewMayaSession() {
    playAlertSound("sound-tick");
    var id = "sess-" + Date.now();
    sessions[id] = {
        id: id,
        title: "নতুন চ্যাট আলাপ...",
        model: "gemini-3.6-flash",
        messages: []
    };
    activeSessionId = id;
    saveSessions();
    loadActiveSessionChat();
}

function deleteMayaSession(id, e) {
    if (e) e.stopPropagation();
    if (confirm("আপনি কি এই চ্যাট ডিলিট করতে চান?")) {
        delete sessions[id];
        var keys = Object.keys(sessions);
        if (keys.length === 0) {
            startNewMayaSession();
        } else {
            if (activeSessionId === id) {
                activeSessionId = keys[keys.length - 1];
            }
            saveSessions();
            loadActiveSessionChat();
        }
    }
}

function selectMayaSession(id) {
    if (activeSessionId === id) return;
    playAlertSound("sound-tick");
    activeSessionId = id;
    loadActiveSessionChat();
    renderHistoryList();
}

function renderHistoryList() {
    var list = document.getElementById("maya-history-list");
    if (!list) return;
    list.innerHTML = "";
    
    var keys = Object.keys(sessions).reverse();
    keys.forEach(function(key) {
        var sess = sessions[key];
        var item = document.createElement("div");
        item.className = "gemini-history-item" + (activeSessionId === key ? " active" : "");
        item.onclick = function() { selectMayaSession(key); };
        
        var text = document.createElement("span");
        text.style.overflow = "hidden";
        text.style.textOverflow = "ellipsis";
        text.style.whiteSpace = "nowrap";
        text.style.maxWidth = "180px";
        text.textContent = sess.title;
        
        var delBtn = document.createElement("button");
        delBtn.style.background = "none";
        delBtn.style.border = "none";
        delBtn.style.color = "#64748b";
        delBtn.style.cursor = "pointer";
        delBtn.style.fontSize = "12px";
        delBtn.innerHTML = "🗑️";
        delBtn.title = "Delete Chat";
        delBtn.onclick = function(e) { deleteMayaSession(key, e); };
        delBtn.onmouseover = function() { this.style.color = "#ef4444"; };
        delBtn.onmouseout = function() { this.style.color = "#64748b"; };

        item.appendChild(text);
        item.appendChild(delBtn);
        list.appendChild(item);
    });
}

function loadActiveSessionChat() {
    var sess = sessions[activeSessionId];
    if (!sess) return;
    
    // Set model selector to reflect session model
    var sel = document.getElementById("gemini-model-selector");
    if (sel) sel.value = sess.model;

    var greet = document.getElementById("maya-greeting-screen");
    var feed = document.getElementById("maya-active-chat-feed");
    
    if (sess.messages.length === 0) {
        greet.style.display = "flex";
        feed.style.display = "none";
    } else {
        greet.style.display = "none";
        feed.style.display = "flex";
        renderChatMessages();
    }
}

function updateSelectedModel() {
    var sel = document.getElementById("gemini-model-selector");
    if (sel && sessions[activeSessionId]) {
        sessions[activeSessionId].model = sel.value;
        saveSessions();
    }
}

function renderChatMessages() {
    var feed = document.getElementById("maya-active-chat-feed");
    if (!feed) return;
    feed.innerHTML = "";
    
    var msgs = sessions[activeSessionId].messages;
    msgs.forEach(function(msg, index) {
        if (msg.role === "user") {
            var bubble = document.createElement("div");
            bubble.className = "user-msg-bubble bangla-font-siliguri";
            
            // Format attachments
            var attachStr = "";
            if (msg.attachment) {
                attachStr = `<div style="background:rgba(255,255,255,0.06); border:1px solid rgba(255,255,255,0.1); border-radius:8px; padding:6px 12px; margin-bottom:8px; font-size:11px; color:#fbbf24; font-family:'JetBrains Mono', monospace; display:inline-flex; align-items:center; gap:6px;">📎 File Attachment: ${msg.attachment.name}</div><br>`;
            }
            bubble.innerHTML = attachStr + escapeHtmlText(msg.text);
            feed.appendChild(bubble);
        } else {
            var wrap = document.createElement("div");
            wrap.className = "maya-msg-bubble";
            
            var avatar = document.createElement("div");
            avatar.className = "maya-msg-avatar";
            avatar.textContent = "M";
            
            var contentWrap = document.createElement("div");
            contentWrap.className = "maya-msg-content bangla-font-siliguri";
            
            var textDiv = document.createElement("div");
            textDiv.innerHTML = formatMarkdownText(msg.text);
            
            // Render tool actions bar
            var actionList = document.createElement("div");
            actionList.className = "maya-action-btn-list";
            
            // Read Out Loud action
            var speakBtn = document.createElement("button");
            speakBtn.className = "maya-utility-action-btn";
            speakBtn.innerHTML = "🔊 Read Out Loud";
            speakBtn.onclick = function() { readMayaOutputOutLoud(msg.text, speakBtn); };
            
            // Copy Response action
            var copyBtn = document.createElement("button");
            copyBtn.className = "maya-utility-action-btn";
            copyBtn.innerHTML = "📋 Copy Text";
            copyBtn.onclick = function() { copyTextToClipboard(msg.text, copyBtn); };

            // Share dialogue
            var shareBtn = document.createElement("button");
            shareBtn.className = "maya-utility-action-btn";
            shareBtn.innerHTML = "📤 Share Chat";
            shareBtn.onclick = function() { shareMayaResponse(msg.text, shareBtn); };

            actionList.appendChild(speakBtn);
            actionList.appendChild(copyBtn);
            actionList.appendChild(shareBtn);
            
            contentWrap.appendChild(textDiv);
            contentWrap.appendChild(actionList);
            wrap.appendChild(avatar);
            wrap.appendChild(contentWrap);
            feed.appendChild(wrap);
        }
    });
    
    // Auto Scroll Feed
    var container = document.getElementById("maya-feed-container");
    container.scrollTop = container.scrollHeight;
}

// suggestion selection
function applySuggestion(txt) {
    var input = document.getElementById("maya-app-user-input");
    if (input) {
        input.value = txt;
        autoGrowMayaInput(input);
        input.focus();
        sendMayaChatMessage();
    }
}

// dynamic growth
function autoGrowMayaInput(element) {
    element.style.height = "36px";
    element.style.height = (element.scrollHeight) + "px";
}

function handleMayaInputKeyPress(e) {
    if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        sendMayaChatMessage();
    }
}

function playAlertSound(id) {
    if (audioMuted) return;
    var sound = document.getElementById(id);
    if (sound) {
        sound.currentTime = 0;
        sound.play().catch(function(err){});
    }
}

function toggleMayaAudioMute() {
    audioMuted = !audioMuted;
    var btn = document.getElementById("sidebar-audio-toggle");
    var icon = document.getElementById("sidebar-audio-icon");
    var text = document.getElementById("sidebar-audio-text");
    
    if (audioMuted) {
        icon.innerHTML = "🔇";
        text.innerHTML = "Sound: OFF";
        btn.style.color = "#64748b";
    } else {
        icon.innerHTML = "🔊";
        text.innerHTML = "Sound: ON";
        btn.style.color = "#94a3b8";
        playAlertSound("sound-tick");
    }
}

// Speech Input (Speech Recognition) Web standard
function toggleMayaSpeechInput() {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
        alert("আপনার ব্রাউজারে স্পিচ রিকগনিশন (Voice Input) সাপোর্ট করে না। অনুগ্রহ করে গুগল ক্রোম ব্রাউজার ব্যবহার করুন।");
        return;
    }
    
    var btn = document.getElementById("maya-mic-btn");
    
    if (speechActive) {
        // Turn off
        if (recognition) recognition.stop();
        speechActive = false;
        btn.style.color = "#94a3b8";
        btn.style.background = "none";
        btn.innerHTML = "🎙️";
        playAlertSound("sound-tick");
    } else {
        // Turn on
        var SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
        recognition = new SpeechRec();
        recognition.lang = "bn-BD"; // Bengali language support!
        recognition.continuous = false;
        recognition.interimResults = false;
        
        recognition.onstart = function() {
            speechActive = true;
            btn.style.color = "#ff003c";
            btn.style.background = "rgba(255, 0, 60, 0.08)";
            btn.innerHTML = `<span class="pulse-indicator"></span>`;
            playAlertSound("sound-tick");
        };
        
        recognition.onresult = function(event) {
            var resultText = event.results[0][0].transcript;
            var input = document.getElementById("maya-app-user-input");
            if (input && resultText) {
                input.value += (input.value ? " " : "") + resultText;
                autoGrowMayaInput(input);
                input.focus();
            }
        };
        
        recognition.onerror = function(event) {
            console.error("Speech Recognition Error", event);
            recognition.stop();
            speechActive = false;
            btn.style.color = "#94a3b8";
            btn.style.background = "none";
            btn.innerHTML = "🎙️";
        };
        
        recognition.onend = function() {
            speechActive = false;
            btn.style.color = "#94a3b8";
            btn.style.background = "none";
            btn.innerHTML = "🎙️";
        };
        
        recognition.start();
    }
}

// Text-to-Speech (Speaks out response)
function readMayaOutputOutLoud(text, btn) {
    if ('speechSynthesis' in window) {
        // Check if already speaking
        if (window.speechSynthesis.speaking) {
            window.speechSynthesis.cancel();
            btn.innerHTML = "🔊 Read Out Loud";
            return;
        }
        
        // Sanitize markdown tags from TTS
        var cleanText = text.replace(/`{3}[\s\S]*?`{3}/g, "").replace(/[*`#_\-]/g, "");
        var utterance = new SpeechSynthesisUtterance(cleanText);
        
        // Detect Bengali text
        if (/[\u0980-\u09FF]/.test(text)) {
            utterance.lang = "bn-BD";
        } else {
            utterance.lang = "en-US";
        }
        
        btn.innerHTML = "⏹️ Stop Reading";
        utterance.onend = function() {
            btn.innerHTML = "🔊 Read Out Loud";
        };
        utterance.onerror = function() {
            btn.innerHTML = "🔊 Read Out Loud";
        };
        window.speechSynthesis.speak(utterance);
    } else {
        alert("আপনার ব্রাউজারে ভয়েস স্পিচ সংশ্লেষণ সাপোর্ট করে না।");
    }
}

// File attachment triggers
function triggerMayaFileUpload() {
    var input = document.getElementById("maya-hidden-file-input");
    if (input) input.click();
}

function handleMayaFileSelected(event) {
    var file = event.target.files[0];
    if (!file) return;
    
    uploadedFile = {
        name: file.name,
        size: Math.round(file.size / 1024) + " KB",
        type: file.type
    };
    
    var previewBar = document.getElementById("file-upload-preview-bar");
    var nameSpan = document.getElementById("preview-file-name");
    var sizeSpan = document.getElementById("preview-file-size");
    var iconSpan = document.getElementById("preview-file-icon");
    
    if (previewBar && nameSpan && sizeSpan) {
        nameSpan.textContent = file.name;
        sizeSpan.textContent = Math.round(file.size / 1024) + " KB";
        
        // Set icon by file type
        if (file.type.startsWith("image/")) {
            iconSpan.textContent = "🖼️";
        } else if (file.type.includes("pdf")) {
            iconSpan.textContent = "📕";
        } else if (file.type.includes("zip") || file.type.includes("rar")) {
            iconSpan.textContent = "📦";
        } else {
            iconSpan.textContent = "📄";
        }
        
        previewBar.style.display = "flex";
        playAlertSound("sound-tick");
    }
}

function removeUploadedFile() {
    uploadedFile = null;
    var previewBar = document.getElementById("file-upload-preview-bar");
    if (previewBar) previewBar.style.display = "none";
    
    var fileInput = document.getElementById("maya-hidden-file-input");
    if (fileInput) fileInput.value = "";
    playAlertSound("sound-tick");
}

// Copy Action
function copyTextToClipboard(text, btn) {
    navigator.clipboard.writeText(text).then(function() {
        var prev = btn.innerHTML;
        btn.innerHTML = "📋 Copied!";
        btn.style.color = "#00ff41";
        btn.style.borderColor = "rgba(0,255,65,0.3)";
        setTimeout(function() {
            btn.innerHTML = prev;
            btn.style.color = "#64748b";
            btn.style.borderColor = "rgba(255,255,255,0.06)";
        }, 2000);
    });
}

// Share Action
function shareMayaResponse(text, btn) {
    var shareUrl = window.location.href;
    navigator.clipboard.writeText(shareUrl + "?share_id=" + Date.now()).then(function() {
        var prev = btn.innerHTML;
        btn.innerHTML = "📤 Link Copied!";
        btn.style.color = "#00f0ff";
        btn.style.borderColor = "rgba(0,240,255,0.3)";
        setTimeout(function() {
            btn.innerHTML = prev;
            btn.style.color = "#64748b";
            btn.style.borderColor = "rgba(255,255,255,0.06)";
        }, 2000);
    });
}

function sendMayaChatMessage() {
    var input = document.getElementById("maya-app-user-input");
    if (!input) return;
    
    var text = input.value.trim();
    if (!text && !uploadedFile) return;
    
    var sess = sessions[activeSessionId];
    if (!sess) return;
    
    // Clear Input
    input.value = "";
    autoGrowMayaInput(input);
    
    // Prepare User Msg Object
    var userMsg = {
        role: "user",
        text: text,
        timestamp: Date.now()
    };
    if (uploadedFile) {
        userMsg.attachment = uploadedFile;
        // Reset attached file UI
        removeUploadedFile();
    }
    
    // Update active session messages
    sess.messages.push(userMsg);
    
    // Auto generate session title if it was default
    if (sess.title === "নতুন চ্যাট আলাপ..." && text) {
        sess.title = text.length > 25 ? text.substring(0, 22) + "..." : text;
    }
    
    saveSessions();
    loadActiveSessionChat();
    
    // 2. Append temporary bot typing indicator
    var feed = document.getElementById("maya-active-chat-feed");
    var typingWrap = document.createElement("div");
    typingWrap.className = "maya-msg-bubble typing-indicator-wrap";
    typingWrap.style.marginTop = "10px";
    
    typingWrap.innerHTML = `
        <div class="maya-msg-avatar">M</div>
        <div class="maya-msg-content" style="color:#64748b; font-size:13px; font-family:'JetBrains Mono', monospace; display:flex; align-items:center; gap:8px;">
            <span style="display:inline-block; width:6px; height:6px; background:#fbbf24; border-radius:50%; animation: pulse 1s infinite alternate;"></span>
            <span>MAYA THINKING GENERATING CONTENT...</span>
        </div>
    `;
    feed.appendChild(typingWrap);
    var container = document.getElementById("maya-feed-container");
    container.scrollTop = container.scrollHeight;
    
    // Perform AJAX to WordPress core balancer API
    jQuery.ajax({
        url: "<?php echo admin_url('admin-ajax.php'); ?>",
        type: "POST",
        dataType: "json",
        data: {
            action: "ilybd_ai_chat",
            nonce: "<?php echo wp_create_nonce('ilybd_ai_nonce'); ?>",
            message: text,
            model: sess.model
        },
        success: function(response) {
            // Remove typing indicator
            jQuery(".typing-indicator-wrap").remove();
            
            var reply = "বস্, কানেকশনে জ্যাম আছে। দয়া করে রিফ্রেশ করে আবার ট্রাই করুন।";
            if (response.success && response.data && response.data.reply) {
                reply = response.data.reply;
            }
            
            // Push bot message
            sess.messages.push({
                role: "model",
                text: reply,
                timestamp: Date.now()
            });
            saveSessions();
            loadActiveSessionChat();
            playAlertSound("sound-alert");
        },
        error: function() {
            jQuery(".typing-indicator-wrap").remove();
            sess.messages.push({
                role: "model",
                text: "দুঃখিত বস্, কৃত্রিম বুদ্ধিমত্তা ইঞ্জিনে ত্রুটি দেখা দিয়েছে। দয়া করে আবার টাইপ করুন।",
                timestamp: Date.now()
            });
            saveSessions();
            loadActiveSessionChat();
            playAlertSound("sound-alert");
        }
    });
}

// Utilities escaping
function escapeHtmlText(text) {
    if (!text) return "";
    return text
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}

function formatMarkdownText(text) {
    if (!text) return "";
    
    let escaped = escapeHtmlText(text);

    // Format Code Blocks ```lang ... ```
    escaped = escaped.replace(/```(?:[a-zA-Z0-9]+)?\n([\s\S]*?)```/g, function(match, code) {
        return '<div style="position:relative;"><button class="pre-copy-btn" onclick="copyPreCodePayload(this)">COPY</button><pre><code>' + code.trim() + '</code></pre></div>';
    });

    // Inline codes `code`
    escaped = escaped.replace(/`([^`]+)`/g, '<code>$1</code>');

    // Bold **text**
    escaped = escaped.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');

    // Bullet lists
    escaped = escaped.replace(/^\s*-\s+([^\n]+)/gm, '<li style="margin-left:15px; list-style-type:square; color:#cbd5e0;">$1</li>');
    escaped = escaped.replace(/^\s*\*\s+([^\n]+)/gm, '<li style="margin-left:15px; list-style-type:circle; color:#cbd5e0;">$1</li>');

    // Double line breaks
    escaped = escaped.replace(/\n\n/g, '<br><br>');
    // Single line breaks
    escaped = escaped.replace(/\n/g, '<br>');

    return escaped;
}

function copyPreCodePayload(btn) {
    var code = btn.nextElementSibling.innerText;
    navigator.clipboard.writeText(code).then(function() {
        var prev = btn.innerHTML;
        btn.innerHTML = "COPIED!";
        btn.style.background = "#00ff41";
        btn.style.color = "#000";
        setTimeout(function() {
            btn.innerHTML = prev;
            btn.style.background = "rgba(255, 255, 255, 0.08)";
            btn.style.color = "#fbbf24";
        }, 1500);
    });
}

function toggleMayaSidebar() {
    var sidebar = document.getElementById("gemini-sidebar");
    if (sidebar) {
        if (sidebar.style.width === "0px" || sidebar.style.display === "none") {
            sidebar.style.width = "280px";
            sidebar.style.display = "flex";
        } else {
            sidebar.style.width = "0px";
            setTimeout(function() {
                if(sidebar.style.width === "0px") sidebar.style.display = "none";
            }, 300);
        }
    }
}
</script>

<?php
get_footer();
