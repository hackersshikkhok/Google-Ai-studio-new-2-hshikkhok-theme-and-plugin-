<?php
/**
 * Template Name: Certificate Verification Page
 * Description: Public Cryptographic Certificate Verification Portal for HackersShikkhok
 * 
 * @package HackersShikkhok
 */

declare(strict_types=1);

get_header();

global $wpdb;
$cert_hash = sanitize_text_field( (string) ( get_query_var( 'cert_hash' ) ?: ( $_GET['hash'] ?? ( $_GET['cert_id'] ?? ( $_GET['cert_code'] ?? '' ) ) ) ) );
$cert = null;

if ( ! empty( $cert_hash ) ) {
    $hs_table    = $wpdb->prefix . 'hs_certificates';
    $cyber_table = $wpdb->prefix . 'cyber_certificates';

    if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $hs_table ) ) === $hs_table ) {
        $row = $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM {$hs_table} WHERE cert_code = %s OR sha256_signature = %s LIMIT 1", $cert_hash, $cert_hash ),
            ARRAY_A
        );
        if ( $row ) {
            $cert = array(
                'student_name'      => $row['recipient_display_name'] ?? '',
                'course_title'      => $row['course_title_snapshot'] ?? '',
                'issued_at'         => $row['issued_at'] ?? '',
                'xp_earned'         => 500,
                'bdt_awarded'       => 50,
                'verification_hash' => $row['sha256_signature'] ?? $cert_hash,
                'cert_code'         => $row['cert_code'] ?? $cert_hash,
                'status'            => $row['status'] ?? 'valid',
            );
        }
    }

    if ( ! $cert && $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $cyber_table ) ) === $cyber_table ) {
        $cert = $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM {$cyber_table} WHERE verification_hash = %s LIMIT 1", $cert_hash ),
            ARRAY_A
        );
    }
}
?>

<div class="cyber-verify-wrapper" style="min-height:85vh; background:#070b14; color:#f8fafc; padding:40px 20px; font-family:'JetBrains Mono', 'Fira Code', monospace;">
    <div style="max-width:850px; margin:0 auto;">
        
        <!-- Header -->
        <div style="text-align:center; margin-bottom:35px;">
            <div style="display:inline-flex; align-items:center; gap:8px; padding:6px 16px; background:rgba(0,255,102,0.1); border:1px solid #00ff66; border-radius:9999px; color:#00ff66; font-size:12px; font-weight:bold; letter-spacing:1px; margin-bottom:12px;">
                <span style="width:8px; height:8px; background:#00ff66; border-radius:50%; box-shadow:0 0 10px #00ff66;"></span>
                HACKERSSHIKKHOK CYBER DEFENSE ACADEMY
            </div>
            <h1 style="font-size:28px; font-weight:800; color:#f8fafc; margin:0 0 8px 0; text-shadow:0 0 20px rgba(0,255,102,0.3);">
                CRYPTOGRAPHIC CERTIFICATE VERIFIER
            </h1>
            <p style="color:#94a3b8; font-size:14px; margin:0;">
                SHA-256 On-Chain Validation &amp; Official Cyber Defense Credential Verification System
            </p>
        </div>

        <!-- Search / Hash Input -->
        <div style="background:#0f172a; border:1px solid #1e293b; border-radius:12px; padding:20px; margin-bottom:30px; box-shadow:0 10px 25px rgba(0,0,0,0.5);">
            <form method="get" action="<?php echo esc_url( home_url( '/verify-certificate/' ) ); ?>" style="display:flex; gap:10px; flex-wrap:wrap;">
                <input 
                    type="text" 
                    name="hash" 
                    placeholder="Paste Certificate SHA-256 Verification Hash..." 
                    value="<?php echo esc_attr( $cert_hash ); ?>"
                    required 
                    style="flex:1; min-width:260px; background:#050811; border:1px solid #334155; color:#00ff66; padding:12px 16px; border-radius:8px; font-family:monospace; font-size:13px; outline:none;"
                />
                <button type="submit" style="background:#00f5d4; color:#050811; font-weight:bold; border:none; padding:12px 24px; border-radius:8px; cursor:pointer; font-size:14px; display:inline-flex; align-items:center; gap:8px;">
                    🔍 Verify Certificate
                </button>
            </form>
        </div>

        <?php if ( ! empty( $cert_hash ) ) : ?>
            <?php if ( $cert ) : ?>
                <!-- Verified Badge & Certificate Card -->
                <div style="background:linear-gradient(145deg, #0f172a, #0b1120); border:2px solid #00ff66; border-radius:16px; padding:32px; box-shadow:0 0 40px rgba(0,255,102,0.2); position:relative; overflow:hidden;">
                    
                    <!-- Neon Corner Accents -->
                    <div style="position:absolute; top:0; right:0; background:#00ff66; color:#050811; font-size:11px; font-weight:900; padding:4px 16px; border-bottom-left-radius:10px; letter-spacing:1px;">
                        AUTHENTIC RECORD ✓
                    </div>

                    <div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:20px; border-bottom:1px solid #1e293b; padding-bottom:20px; margin-bottom:20px;">
                        <div>
                            <span style="color:#00ff66; font-size:12px; font-weight:bold; letter-spacing:1.5px;">OFFICIAL CYBER DEFENSE RECORD</span>
                            <h2 style="color:#f8fafc; font-size:24px; font-weight:800; margin:6px 0 0 0;">
                                <?php echo esc_html( $cert['student_name'] ?? 'Candidate' ); ?>
                            </h2>
                            <p style="color:#94a3b8; font-size:14px; margin:4px 0 0 0;">
                                Course: <strong style="color:#38bdf8;"><?php echo esc_html( $cert['course_title'] ?? 'Cybersecurity Specialization' ); ?></strong>
                            </p>
                        </div>

                        <?php if ( ! empty( $cert['qr_code_url'] ) ) : ?>
                            <div style="text-align:center;">
                                <img src="<?php echo esc_url( $cert['qr_code_url'] ); ?>" alt="QR Code" style="width:100px; height:100px; border-radius:8px; border:2px solid #1e293b; background:#fff; padding:4px;" />
                                <span style="display:block; font-size:10px; color:#64748b; margin-top:4px;">SCAN TO VERIFY</span>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Meta Details Grid -->
                    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(180px, 1fr)); gap:16px; margin-bottom:24px;">
                        <div style="background:#070b14; padding:12px 16px; border-radius:8px; border:1px solid #1e293b;">
                            <span style="font-size:11px; color:#64748b; display:block;">Issued Date</span>
                            <strong style="color:#f8fafc; font-size:13px;"><?php echo esc_html( $cert['issued_at'] ?? '2026-10-15' ); ?></strong>
                        </div>
                        <div style="background:#070b14; padding:12px 16px; border-radius:8px; border:1px solid #1e293b;">
                            <span style="font-size:11px; color:#64748b; display:block;">Earned Points</span>
                            <strong style="color:#a855f7; font-size:13px;">⚡ <?php echo esc_html( (string) ($cert['xp_earned'] ?? 500) ); ?> XP</strong>
                        </div>
                        <div style="background:#070b14; padding:12px 16px; border-radius:8px; border:1px solid #1e293b;">
                            <span style="font-size:11px; color:#64748b; display:block;">Wallet Bounty</span>
                            <strong style="color:#10b981; font-size:13px;">BDT <?php echo esc_html( (string) ($cert['bdt_awarded'] ?? 0) ); ?> BDT</strong>
                        </div>
                        <div style="background:#070b14; padding:12px 16px; border-radius:8px; border:1px solid #1e293b;">
                            <span style="font-size:11px; color:#64748b; display:block;">Cryptographic Status</span>
                            <strong style="color:#00ff66; font-size:13px;">VALID &amp; SIGNED</strong>
                        </div>
                    </div>

                    <!-- Cryptographic Hash Display -->
                    <div style="background:#050811; border:1px solid rgba(0,255,102,0.3); padding:12px 16px; border-radius:8px; margin-bottom:24px;">
                        <span style="font-size:11px; color:#64748b; display:block; margin-bottom:4px;">SHA-256 CRYPTOGRAPHIC SIGNATURE:</span>
                        <code style="color:#00ff66; font-size:12px; word-break:break-all; display:block;">
                            <?php echo esc_html( $cert['verification_hash'] ?? $cert_hash ); ?>
                        </code>
                    </div>

                    <!-- PDF Download Button -->
                    <div style="text-align:right;">
                        <a href="<?php echo esc_url( rest_url( 'lms/v1/certificate/download/' . ( $cert['verification_hash'] ?? $cert_hash ) ) ); ?>" style="display:inline-flex; align-items:center; gap:8px; background:#00ff66; color:#050811; font-weight:bold; padding:12px 24px; border-radius:8px; text-decoration:none; font-size:14px; box-shadow:0 0 20px rgba(0,255,102,0.3);">
                            📥 Download Official PDF Certificate
                        </a>
                    </div>
                </div>
            <?php else : ?>
                <!-- Not Found Alert -->
                <div style="background:rgba(239,68,68,0.1); border:1px solid #ef4444; border-radius:12px; padding:24px; text-align:center;">
                    <span style="font-size:32px;">⚠️</span>
                    <h3 style="color:#ef4444; margin:10px 0 6px 0;">Certificate Record Not Found</h3>
                    <p style="color:#94a3b8; font-size:13px; margin:0;">
                        The provided cryptographic hash was not found in our ledger or has been revoked. Please check the hash string and try again.
                    </p>
                </div>
            <?php endif; ?>
        <?php endif; ?>

    </div>
</div>

<?php get_footer(); ?>
